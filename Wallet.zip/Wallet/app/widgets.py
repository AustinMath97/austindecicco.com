"""
widgets.py — the reusable form-widget toolkit shared by the Add dialogs
(forms.py) and the Edit dialogs (cards.py): the recurrence schedule widget,
vehicle identity fields with VIN decode, the tax-deductible expense fields,
widget-state reset helpers, and the seed-tracked default pattern.

Sits below forms/cards in the import graph (it imports neither), so both can
share these without a cycle.
"""

import hashlib
import json
import math
from datetime import date

import pandas as pd
import streamlit as st

import db
import recurrence
import stats
from utils import (VEHICLE_CONDITIONS, esc, md_escape, ordinal,
                   safe_eval_formula, safe_str, utilization_color,
                   vehicle_value_url)
from vin import decode_vin


# Tax-deduction categories for a deductible expense (shared by the Add and
# Edit expense dialogs via deductible_widgets below).
DEDUCTION_CATEGORIES = [
    "Charitable Contributions", "Mortgage Interest", "State & Local Taxes (SALT)",
    "Property Taxes", "Medical Expenses", "Student Loan Interest",
    "Traditional IRA / 401(k) Contribution", "HSA Contribution",
    "Business Expense", "Education Expense", "Other",
]


# ---------------------------------------------------------------------------
# Margin Loan fields — shared by Add Debt (forms) and Edit Debt (edit_dialogs)
# so the two dialogs can't drift. A margin loan stores the investment-account
# label it's borrowed against (a plain datapoint over the DERIVED grouping in
# stats.investment_accounts — not a link) and an APR formula over the economic
# variables, evaluated live here and re-derived by db.refresh_margin_aprs.
# ---------------------------------------------------------------------------

def margin_account_picker(key_prefix, current_account=None):
    """The 'Borrowed against' selectbox over the current investment accounts.
    Returns (margin_account, lender) — lender inferred from the picked account's
    institution (None until an account is picked). Never silently defaults: a new
    loan starts unselected, and a stored label that no longer matches any account
    (renamed / emptied) warns and forces an explicit re-pick instead of quietly
    swapping to whichever account happens to sort first."""
    accts = stats.investment_accounts(db.load_df("assets"))
    labels = [a["label"] for a in accts]
    if not labels:
        st.warning("No investment accounts to borrow against — add an investment "
                   "holding (a brokerage stock / ETF / crypto position) first.")
    elif current_account and current_account not in labels:
        st.warning(f"The linked account **{md_escape(current_account)}** no longer "
                   "matches any investment account (renamed or emptied?) — pick "
                   "its current name to keep the loan attributed.")
    margin_account = st.selectbox(
        "Borrowed against (investment account)", labels,
        index=labels.index(current_account) if current_account in labels else None,
        placeholder="Select the account the loan is against…",
        key=f"{key_prefix}macct",
        help="Which investment account this loan is margined against. The balance "
             "counts as negative liquidity on the Overview; the brokerage/lender "
             "is inferred from the account.")
    acct = next((a for a in accts if a["label"] == margin_account), None)
    return margin_account, ((acct or {}).get("institution") or None)


def margin_apr_formula_input(key_prefix, balance, current_formula=None):
    """The APR-formula input with its live evaluation caption (current APR and
    projected monthly interest at `balance`). Returns (apr_formula, apr) — apr is
    None while the formula doesn't evaluate (the error is shown here; save
    handlers just check for None instead of re-evaluating)."""
    apr_formula = st.text_input(
        "APR formula", value=current_formula or "fed_funds_rate + 0.02",
        key=f"{key_prefix}aprf",
        help="Arithmetic over the economic variables — e.g. fed_funds_rate + 0.02 "
             "(a broker base rate plus a 2% spread). Recomputes as the rates change.")
    econ = db.economic_variables()
    st.caption("Variables you can use — "
               + " · ".join(f"{md_escape(k)} = {econ[k] * 100:.2f}%" for k in econ))
    if all(v == 0 for v in econ.values()):
        st.warning("All the economic variables read 0% — set them on the Economic "
                   "page first, or the APR is just the formula's constant part.")
    apr = None
    try:
        apr = safe_eval_formula(apr_formula, econ)
        st.caption(f"Current APR: **{apr * 100:.2f}%** "
                   f"(\\${balance * apr / 12:,.0f}/mo interest at this balance) "
                   "— updates live as the variables change.")
    except ValueError as exc:
        st.error(str(exc))
    return apr_formula, apr


# ---------------------------------------------------------------------------
# Calendar scheduling widget — shared by Add Income (forms) and Edit Income
# (cards). Renders friendly inputs for any recurrence and returns the income
# row columns that store it. Keeping it here lets both dialogs stay in sync.
# ---------------------------------------------------------------------------

SCHEDULE_CHOICES = [
    (recurrence.WEEKLY,          "Weekly — same weekday every week"),
    (recurrence.BIWEEKLY,        "Every two weeks — same weekday"),
    (recurrence.SEMIMONTHLY,     "Twice a month — set days (e.g. 1st & 15th)"),
    (recurrence.MONTHLY,         "Monthly — one day of the month"),
    (recurrence.MONTHLY_WEEKDAY, "Monthly — a weekday (e.g. first Monday)"),
    (recurrence.QUARTERLY,       "Quarterly — a day in chosen months"),
    (recurrence.ANNUAL,          "Once a year — a date"),
    (recurrence.ONE_TIME,        "One-time — a single date"),
    (recurrence.NONE,            "Irregular — don't show on the calendar"),
]


_ord_label = ordinal    # shared implementation (utils.ordinal)


def _as_date(v):
    if isinstance(v, date):
        return v
    s = str(v or "").strip()
    if not s or s.lower() in ("nan", "none"):
        return None
    try:
        return date.fromisoformat(s[:10])
    except ValueError:
        return None


def _seed_once(key, value):
    """Seed a widget's session_state once (so its widget below passes no default and
    won't warn when the value is also set via the Session State API)."""
    if key not in st.session_state:
        st.session_state[key] = value


def set_schedule_widget_keys(key_prefix, sched):
    """Force a schedule_widget (at `key_prefix`) to a given recurrence schedule by
    writing its session_state keys directly — used by the income 'Import interest'
    button. `sched` is a recurrence dict (type/weekday/ordinal/anchor/month_days/months,
    as recurrence.from_row returns). Runs in an on_click callback, before the widgets
    re-instantiate, and pairs with the seed-once widgets so there's no default/state
    clash. Only the keys for the chosen type are set; leftover keys from other types
    aren't rendered, so they're harmless."""
    stype = sched.get("type") or recurrence.NONE
    st.session_state[f"{key_prefix}_stype"] = stype
    wd = _as_int(sched.get("weekday"))
    md = [int(x) for x in (sched.get("month_days") or [])]
    months = [int(x) for x in (sched.get("months") or [])]
    anchor = sched.get("anchor")
    anchor = anchor if isinstance(anchor, date) else _as_date(anchor)
    if stype == recurrence.WEEKLY and wd is not None:
        st.session_state[f"{key_prefix}_wd"] = wd
    elif stype == recurrence.BIWEEKLY and anchor:
        st.session_state[f"{key_prefix}_anchor"] = anchor
    elif stype == recurrence.MONTHLY_WEEKDAY:
        if _as_int(sched.get("ordinal")) is not None:
            st.session_state[f"{key_prefix}_ord"] = _as_int(sched.get("ordinal"))
        if wd is not None:
            st.session_state[f"{key_prefix}_mwd"] = wd
    elif stype == recurrence.MONTHLY and md:
        st.session_state[f"{key_prefix}_md1"] = md[0]
    elif stype in (recurrence.SEMIMONTHLY, recurrence.QUARTERLY):
        st.session_state[f"{key_prefix}_mdN"] = md
        if stype == recurrence.QUARTERLY:
            st.session_state[f"{key_prefix}_months"] = months
    elif stype in (recurrence.ANNUAL, recurrence.ONE_TIME) and anchor:
        st.session_state[f"{key_prefix}_date"] = anchor


def schedule_widget(defaults, key_prefix):
    """Render the calendar-scheduling inputs and return the income-row columns
    that describe the recurrence: schedule_type, weekday, week_ordinal,
    anchor_date, pay_days, months, frequency, pay_day (human summary).

    `defaults` is a normalized schedule dict (recurrence.from_row(row)) when
    editing, or None for a fresh Add. `key_prefix` namespaces the widget keys.
    """
    d = defaults or {}
    types = [t for t, _ in SCHEDULE_CHOICES]
    labels = dict(SCHEDULE_CHOICES)
    cur = d.get("type") or recurrence.NONE
    # Seed each widget's session_state once from `defaults` and pass NO index=/value=/
    # default=, so external code (the "Import interest" button via set_schedule_widget_
    # keys) can set these keys directly and have the widgets reflect them — without the
    # "default value + Session State API" warning, and without a fragile clear/re-seed.
    _seed_once(f"{key_prefix}_stype", cur if cur in types else recurrence.NONE)
    stype = st.selectbox("How often does it arrive?", types,
                         format_func=lambda t: labels[t], key=f"{key_prefix}_stype")

    weekday = ordinal = anchor = months = pay_days = None
    WD = list(range(7))

    if stype == recurrence.WEEKLY:
        cur_wd = _as_int(d.get("weekday"))
        _seed_once(f"{key_prefix}_wd", cur_wd if cur_wd in WD else 4)  # default Friday
        weekday = st.selectbox("Which weekday", WD,
                               format_func=lambda i: recurrence.WEEKDAY_NAMES[i],
                               key=f"{key_prefix}_wd")

    elif stype == recurrence.BIWEEKLY:
        _seed_once(f"{key_prefix}_anchor", _as_date(d.get("anchor")) or date.today())
        a = st.date_input("A recent pay date (sets the every-other-week rhythm)",
                          format="MM/DD/YYYY", key=f"{key_prefix}_anchor")
        anchor = a.isoformat() if a else None
        weekday = a.weekday() if a else None

    elif stype == recurrence.MONTHLY_WEEKDAY:
        oc1, oc2 = st.columns(2)
        ord_opts = [1, 2, 3, 4, -1]
        cur_o = _as_int(d.get("ordinal"))
        _seed_once(f"{key_prefix}_ord", cur_o if cur_o in ord_opts else 1)
        ordinal = oc1.selectbox("Which one", ord_opts,
                                format_func=lambda o: recurrence.ORDINAL_LABEL[o],
                                key=f"{key_prefix}_ord")
        cur_wd = _as_int(d.get("weekday"))
        _seed_once(f"{key_prefix}_mwd", cur_wd if cur_wd in WD else 0)
        weekday = oc2.selectbox("Weekday", WD,
                                format_func=lambda i: recurrence.WEEKDAY_NAMES[i],
                                key=f"{key_prefix}_mwd")

    elif stype == recurrence.MONTHLY:
        cur_days = d.get("month_days") or []
        default_day = cur_days[0] if cur_days else 1
        _seed_once(f"{key_prefix}_md1", min(max(int(default_day), 1), 31))
        day = st.selectbox("Day of the month", list(range(1, 32)),
                           format_func=_ord_label, key=f"{key_prefix}_md1")
        pay_days = str(day)

    elif stype in (recurrence.SEMIMONTHLY, recurrence.QUARTERLY):
        cur_days = d.get("month_days") or ([1, 15] if stype == recurrence.SEMIMONTHLY else [15])
        _seed_once(f"{key_prefix}_mdN", [x for x in cur_days if 1 <= x <= 31])
        sel = st.multiselect("Day(s) of the month", list(range(1, 32)),
                             format_func=_ord_label, key=f"{key_prefix}_mdN")
        pay_days = ",".join(str(x) for x in sorted(sel)) or None
        if stype == recurrence.QUARTERLY:
            cur_m = d.get("months") or [3, 6, 9, 12]
            _seed_once(f"{key_prefix}_months", [m for m in cur_m if 1 <= m <= 12])
            msel = st.multiselect("In which months", list(range(1, 13)),
                                  format_func=lambda m: recurrence.MONTH_NAMES[m - 1],
                                  key=f"{key_prefix}_months")
            months = ",".join(str(m) for m in sorted(msel)) or None

    elif stype in (recurrence.ANNUAL, recurrence.ONE_TIME):
        prompt = ("Date each year (the year is ignored)"
                  if stype == recurrence.ANNUAL else "Date")
        _seed_once(f"{key_prefix}_date", _as_date(d.get("anchor")) or date.today())
        a = st.date_input(prompt, format="MM/DD/YYYY", key=f"{key_prefix}_date")
        anchor = a.isoformat() if a else None

    sched = {"type": stype, "weekday": weekday, "ordinal": ordinal,
             "anchor": anchor, "month_days": pay_days, "months": months}
    desc = recurrence.describe(sched)
    if stype != recurrence.NONE:
        st.caption(f"📅 {desc}" if desc else "📅 Finish the fields above to place it on the calendar.")

    return {
        "schedule_type": stype,
        "weekday": weekday,
        "week_ordinal": ordinal,
        "anchor_date": anchor,
        "pay_days": pay_days,
        "months": months,
        "frequency": recurrence.frequency_label(stype),
        "pay_day": desc or None,
    }


# ---------------------------------------------------------------------------
# Expense amount widget — "Set" (a fixed per-occurrence amount) or "Variable"
# (record each of the past year's payments and project them forward). Shared by
# Add Expense (forms) and Edit Expense (edit_dialogs). Returns the amount stored
# in `amount`, the {amount_mode, variable_method, variable_amounts} columns, and
# an error message (when variable mode is incomplete) so the caller blocks Save.
# ---------------------------------------------------------------------------

def expense_amount_widget(sched_fields, key_prefix, defaults=None, step=5.0):
    """Render the amount section and return (amount, fields, error).

    `sched_fields` is the dict schedule_widget returned (its past-year occurrence
    dates drive the variable inputs). `defaults` is the stored expense row when
    editing, else None. Widget keys are namespaced by `key_prefix` (include the
    trailing separator, e.g. "axe_") so a debt-payment import can pre-set them.
    """
    d = defaults or {}
    cur_variable = stats.is_variable(d)
    _seed_once(f"{key_prefix}mode", "Variable" if cur_variable else "Set")
    mode = st.radio(
        "Amount", ["Set", "Variable"], horizontal=True, key=f"{key_prefix}mode",
        help="Set = one fixed amount every period. Variable = it changes each "
             "period — record the past year's payments and project them forward.")

    sched = recurrence.from_row(sched_fields)
    occ = recurrence.occurrences_per_year(sched)

    if mode == "Set":
        _seed_once(f"{key_prefix}amount",
                   float(d.get("amount") or 0.0) if not cur_variable else 0.0)
        amount = st.number_input("Amount ($)", min_value=0.0, step=step,
                                 key=f"{key_prefix}amount")
        if amount > 0 and occ:
            st.caption(f"Annual equivalent: **${amount * occ:,.0f}**")
        return amount, {"amount_mode": "set", "variable_method": None,
                        "variable_amounts": None, "variable_years": None}, None

    # ── Variable ─────────────────────────────────────────────────────────────
    # History length: how many years of actual payments the grid records. More
    # history sharpens the average and gives the seasonal projection real data.
    _seed_once(f"{key_prefix}vyrs", min(5, stats.variable_years_of(d)))
    years = st.selectbox(
        "History to record", [1, 2, 3, 4, 5], key=f"{key_prefix}vyrs",
        format_func=lambda y: f"{y} year" + ("s" if y > 1 else ""),
        help="How many years of actual payments to keep. Longer history steadies "
             "the average and powers the seasonal per-period projection.")
    dates = stats.variable_occurrence_dates(sched, date.today(), years)
    if not dates:
        st.warning("Variable amounts need a recurring schedule with at least one "
                   "occurrence in the past year — set the schedule above first.")
        return 0.0, {"amount_mode": "variable", "variable_method": None,
                     "variable_amounts": None, "variable_years": int(years)}, \
            "the schedule has no past dates to record"

    _occ_goal = int(round(occ)) * years
    if _occ_goal and len(dates) < _occ_goal:
        st.caption(f":orange[Only {len(dates)} occurrence(s) exist within the last "
                   f"{years} year{'s' if years > 1 else ''} — the schedule hasn't "
                   "been running that long, so that's what gets recorded.]")
    st.caption(f"Enter what you actually paid on each of the last {len(dates)} "
               f"payment dates ({years}-year history) — every date is required.")
    stored = stats.parse_variable_amounts(d)
    grid = pd.DataFrame({"Date": [dt.isoformat() for dt in dates],
                         "Amount ($)": [stored.get(dt, None) for dt in dates]})
    # The editor's key is a digest of the DATE LIST: its edit-state is
    # POSITIONAL, so reusing one key while the rows change (a different history
    # length, or the schedule edited above in the same dialog) would silently
    # remap every typed amount onto different dates. A fresh key per date-set
    # re-seeds from the stored amounts instead.
    _grid_sig = hashlib.md5(
        "|".join(dt.isoformat() for dt in dates).encode()).hexdigest()[:8]
    edited = st.data_editor(
        grid, key=f"{key_prefix}var_{_grid_sig}", hide_index=True, width="stretch",
        disabled=["Date"],
        # step is the data editor's input GRANULARITY (browser-validated), not
        # just the +/- increment — anything coarser than 0.01 rejects cents.
        column_config={"Amount ($)": st.column_config.NumberColumn(
            min_value=0.0, step=0.01, format="$%.2f")})

    amounts, missing = {}, 0
    for i, dt in enumerate(dates):
        v = edited["Amount ($)"].iloc[i]
        if v is None or (isinstance(v, float) and v != v):     # NaN-safe blank check
            missing += 1
        else:
            amounts[dt] = float(v)

    st.markdown("**Calendar Settings** — how to project these into the future")
    _METHOD_LABEL = {"average": "Average expense",
                     "by_period": "Set expense by period",
                     "seasonal": "Seasonal average by period"}
    _stored_method = safe_str(d.get("variable_method") if hasattr(d, "get") else "")
    _seed_once(f"{key_prefix}vm", _METHOD_LABEL.get(_stored_method, "Average expense"))
    method = st.radio(
        "Project future periods by", list(_METHOD_LABEL.values()),
        key=f"{key_prefix}vm",
        help="Average expense = every future period uses the recorded average. "
             "Set expense by period = repeat the recorded payments in order "
             "(with multi-year history, the whole recorded cycle). "
             "Seasonal average by period = each future period uses its own "
             "occurrence's average across the recorded years — e.g. January "
             "projects as the mean of the recorded Januaries.")
    method_key = next(k for k, v in _METHOD_LABEL.items() if v == method)

    vals = list(amounts.values())
    avg = sum(vals) / len(vals) if vals else 0.0
    if missing:
        st.error(f"{missing} of {len(dates)} dates are blank — fill every recorded "
                 "amount (missing observations aren't allowed).")
        err = f"{missing} variable amount(s) still blank"
    else:
        err = None
        # esc(): three $ amounts in one markdown string would otherwise render
        # the spans between them as KaTeX — see the markdown-LaTeX memory.
        st.caption(esc(f"Recorded {years}-year total **${sum(vals):,.2f}** · "
                       f"average per period **${avg:,.2f}** · "
                       f"annual equivalent **${avg * occ:,.0f}**"))
    payload = json.dumps({dt.isoformat(): amounts[dt] for dt in dates if dt in amounts})
    return avg, {"amount_mode": "variable", "variable_method": method_key,
                 "variable_amounts": payload, "variable_years": int(years)}, err


_MP_MODES = [("fixed", "Fixed $"),
             ("percent", "% of balance"),
             ("percent_floor", "% of balance, with a $ floor"),
             ("percent_interest", "% of balance + interest"),
             ("percent_interest_floor", "% of balance + interest, with a $ floor")]
# Which models take a percent input, and which take a dollar floor.
_MP_PCT_TYPES = {"percent", "percent_floor", "percent_interest", "percent_interest_floor"}
_MP_FLOOR_TYPES = {"percent_floor", "percent_interest_floor"}


def statement_schedule_widget(defaults, key_prefix):
    """The credit-card statement-close date as a restricted monthly schedule — a
    fixed day of the month, OR an ordinal weekday (e.g. the last Friday, which drifts
    month to month). A trimmed version of the calendar schedule picker, with only the
    options that make sense for a once-a-month statement. Returns
    {statement_day, statement_weekday, statement_week_ordinal} (only the chosen mode's
    fields are set)."""
    d = defaults or {}
    cur_wd, cur_ord = _as_int(d.get("statement_weekday")), _as_int(d.get("statement_week_ordinal"))
    cur_day = _as_int(d.get("statement_day"))
    MODES = [("day", "A day of the month"), ("weekday", "A weekday of the month")]
    _seed_once(f"{key_prefix}smode",
               "weekday" if (cur_wd is not None and cur_ord is not None) else "day")
    mode = st.selectbox(
        "Statement closes on", [m for m, _ in MODES], key=f"{key_prefix}smode",
        format_func=lambda m: dict(MODES)[m],
        help="When the statement closes — its balance sets the minimum payment, paid "
             "on the due day. An ordinal weekday (e.g. last Friday) varies month to "
             "month; a fixed day does not.")

    statement_day = statement_weekday = statement_week_ordinal = None
    if mode == "day":
        opts = ["—"] + [str(i) for i in range(1, 32)]
        _seed_once(f"{key_prefix}sday",
                   str(cur_day) if cur_day and 1 <= cur_day <= 31 else "—")
        val = st.selectbox("Day of the month", opts, key=f"{key_prefix}sday",
                           format_func=lambda s: _ord_label(int(s)) if s != "—" else "—")
        statement_day = int(val) if val != "—" else None
    else:
        oc1, oc2 = st.columns(2)
        ord_opts = [1, 2, 3, 4, -1]
        _seed_once(f"{key_prefix}sord", cur_ord if cur_ord in ord_opts else -1)
        statement_week_ordinal = oc1.selectbox(
            "Which one", ord_opts, format_func=lambda o: recurrence.ORDINAL_LABEL[o],
            key=f"{key_prefix}sord")
        WD = list(range(7))
        _seed_once(f"{key_prefix}swd", cur_wd if cur_wd in WD else 4)   # default Friday
        statement_weekday = oc2.selectbox(
            "Weekday", WD, format_func=lambda i: recurrence.WEEKDAY_NAMES[i],
            key=f"{key_prefix}swd")

    sched = ({"type": recurrence.MONTHLY_WEEKDAY, "weekday": statement_weekday,
              "ordinal": statement_week_ordinal} if mode == "weekday"
             else {"type": recurrence.MONTHLY,
                   "month_days": [statement_day] if statement_day else []})
    desc = recurrence.describe(sched)
    st.caption(f"📄 Statement closes {desc}." if desc
               else "📄 No statement date set — the minimum will use the due-day balance.")
    return {"statement_day": statement_day, "statement_weekday": statement_weekday,
            "statement_week_ordinal": statement_week_ordinal}


def min_payment_fields(defaults, key_prefix, balance=0.0, apr=0.0):
    """Credit-card limit + statement-close date + minimum-payment model (a fixed
    dollar amount, a percent of the balance, a percent of balance plus the period's
    interest, or either percent model with a dollar floor). `apr` feeds the
    interest models' live preview. Shared by Add Debt (the Credit Card branch) and
    Edit Debt (when the type is revolving). Returns {credit_limit, min_payment,
    min_payment_type, min_payment_pct, statement_day, statement_weekday,
    statement_week_ordinal}."""
    d = defaults or {}
    labels = dict(_MP_MODES)
    types = [t for t, _ in _MP_MODES]

    c1, c2 = st.columns(2)
    _seed_once(f"{key_prefix}climit", float(d.get("credit_limit") or 0.0))
    credit_limit = c1.number_input("Credit limit ($)", min_value=0.0, step=100.0,
                                   key=f"{key_prefix}climit")
    cur_type = (d.get("min_payment_type") or "fixed")
    _seed_once(f"{key_prefix}mptype", cur_type if cur_type in types else "fixed")
    mp_type = c2.selectbox("Minimum payment", types, key=f"{key_prefix}mptype",
                           format_func=lambda t: labels[t],
                           help="How the card's minimum is figured each month. The "
                                "'+ interest' models add the period's interest to the "
                                "percent of balance — how most issuers actually bill it.")

    m1, m2 = st.columns(2)
    min_payment = mp_pct = 0.0
    if mp_type in _MP_PCT_TYPES:
        _seed_once(f"{key_prefix}mppct", float(d.get("min_payment_pct") or 0.02) * 100)
        mp_pct = m1.number_input("Minimum (% of balance)", min_value=0.0, max_value=100.0,
                                 step=0.25, key=f"{key_prefix}mppct") / 100.0
    if mp_type == "fixed" or mp_type in _MP_FLOOR_TYPES:
        _seed_once(f"{key_prefix}mpfix", float(d.get("min_payment") or 0.0))
        min_payment = m2.number_input(
            "Minimum payment ($)" if mp_type == "fixed" else "Floor — minimum $ amount",
            min_value=0.0, step=5.0, key=f"{key_prefix}mpfix")

    stmt = statement_schedule_widget(d, key_prefix)

    # Show this month's computed minimum so the model is concrete. Dollar signs are
    # escaped (\$) so a pair of them isn't parsed as LaTeX math by st.caption.
    due = stats.min_payment_due(balance, mp_type, mp_pct, min_payment, apr=apr)
    if balance > 0 and due > 0:
        _full = "  (the full balance — it's below the minimum)" if due >= balance else ""
        st.caption(f"This month's minimum on a \\${balance:,.0f} balance: "
                   f"**\\${due:,.2f}**{_full}")
    if credit_limit and balance > 0:
        util = balance / credit_limit * 100
        st.markdown(f"Utilization: **:{utilization_color(util)}[{util:.1f}%]**  (aim for ≤ 10%)"
                    + ("  ·  :red[over limit!]" if balance > credit_limit else ""))

    return {"credit_limit": credit_limit or None, "min_payment": min_payment,
            "min_payment_type": mp_type, "min_payment_pct": mp_pct or None, **stmt}


def _as_int(v):
    try:
        return int(float(v))
    except (TypeError, ValueError):
        return None


# ---------------------------------------------------------------------------
# Vehicle identity widget — shared by Add Asset (forms) and Edit Asset (cards).
# Captures year/make/model/trim/condition/zip/mileage/VIN and renders the single
# best valuation deep link, built from make/model/year. A "Decode VIN" button
# fills year/make/model/trim from the free NHTSA lookup. Widget state is keyed so
# the decode can write back into the inputs (Streamlit only allows that from a
# callback that runs before the widgets are re-instantiated).
# ---------------------------------------------------------------------------

def clear_widget_state(*prefixes):
    """Delete every session_state entry whose key starts with any of `prefixes`.
    Used to reset a dialog's keyed widgets (e.g. the vehicle/schedule fields) when
    it (re)opens, so leftover values don't carry into the next open."""
    if not prefixes:
        return
    for key in [k for k in st.session_state if k.startswith(prefixes)]:
        del st.session_state[key]


def seed_tracked(key, default):
    """Seed-or-refresh a widget key that follows a system default until the user
    hand-edits it. A "__seed" shadow records what the box was last system-set
    to: while the current value still equals the shadow (untouched), both track
    the new default each run; once the user types something else, their value
    survives. Call BEFORE the widget is instantiated. Callers that persist hand
    edits must also move the shadow to the stored value (see the Taxes-page
    income buckets), so the edit isn't later mistaken for a stale seed."""
    seed_k = key + "__seed"
    if key not in st.session_state or st.session_state[key] == st.session_state.get(seed_k):
        st.session_state[key] = default
        st.session_state[seed_k] = default


def _decode_vin_cb(p):
    """on_click handler: decode the VIN and write year/make/model/trim into the
    widgets. Runs before widgets are instantiated on the rerun, which is the only
    point Streamlit allows modifying a widget's keyed session-state value."""
    dec = decode_vin(st.session_state.get(f"{p}_vin", ""))
    if not dec:
        st.session_state[f"{p}_vinmsg"] = ("err",
            "Couldn't decode that VIN — check it's the full 17 characters.")
        return
    if str(dec["year"]).isdigit():
        st.session_state[f"{p}_year"] = int(dec["year"])
    st.session_state[f"{p}_make"] = dec["make"]
    st.session_state[f"{p}_model"] = dec["model"]
    if dec["trim"]:
        st.session_state[f"{p}_trim"] = dec["trim"]
    body = f" · {dec['body']}" if dec["body"] else ""
    st.session_state[f"{p}_vinmsg"] = ("ok",
        f"Decoded: {dec['year']} {dec['make']} {dec['model']}"
        + (f" {dec['trim']}" if dec["trim"] else "") + body)


def vehicle_fields(defaults, key_prefix, vehicle_type):
    """Render the vehicle identity inputs + valuation link; return the asset
    columns to store. `defaults` is a dict (year/make/model/trim/condition/
    zip_code/mileage/vin) when editing, or None for a fresh Add."""
    p = key_prefix
    d = defaults or {}

    # Seed widget state once per dialog open (cleared on Save/Cancel).
    if f"{p}_vinit" not in st.session_state:
        st.session_state[f"{p}_vinit"] = True
        st.session_state[f"{p}_year"] = _as_int(d.get("year")) or date.today().year
        st.session_state[f"{p}_make"] = d.get("make") or ""
        st.session_state[f"{p}_model"] = d.get("model") or ""
        st.session_state[f"{p}_trim"] = d.get("trim") or ""
        cond = d.get("condition") or "Good"
        st.session_state[f"{p}_cond"] = cond if cond in VEHICLE_CONDITIONS else "Good"
        st.session_state[f"{p}_zip"] = d.get("zip_code") or ""
        st.session_state[f"{p}_miles"] = _as_int(d.get("mileage")) or 0
        st.session_state[f"{p}_vin"] = d.get("vin") or ""

    c1, c2, c3 = st.columns(3)
    year = c1.number_input("Year", min_value=1900, max_value=date.today().year + 1,
                           step=1, key=f"{p}_year")
    make = c2.text_input("Make", key=f"{p}_make", placeholder="e.g. Toyota, Sea Ray").strip()
    model = c3.text_input("Model", key=f"{p}_model", placeholder="e.g. Camry, CBR500R").strip()

    t1, t2, t3 = st.columns(3)
    trim = t1.text_input("Trim", key=f"{p}_trim", placeholder="e.g. SE, Limited").strip()
    condition = t2.selectbox("Condition", VEHICLE_CONDITIONS, key=f"{p}_cond")
    zip_code = t3.text_input("ZIP", key=f"{p}_zip", max_chars=10, placeholder="07042").strip()

    v1, v2 = st.columns([3, 1])
    vin = v1.text_input("VIN (optional)", key=f"{p}_vin",
                        placeholder="17-character VIN").strip().upper()
    v2.markdown("<div style='height:1.85em'></div>", unsafe_allow_html=True)  # align with input
    v2.button("🔎 Decode VIN", key=f"{p}_dec", on_click=_decode_vin_cb, args=(p,),
              width="stretch",
              help="Auto-fill year / make / model / trim from the VIN (free NHTSA lookup).")
    msg = st.session_state.get(f"{p}_vinmsg")
    if msg:
        (st.success if msg[0] == "ok" else st.warning)(msg[1])

    mileage = int(st.number_input("Mileage (mi)", min_value=0, step=1000, key=f"{p}_miles"))

    yr = str(int(year)) if year else ""
    url = vehicle_value_url(make, model, yr, vehicle_type)
    st.caption(f"[🔗 Look up this vehicle's value ↗]({url}) — free; read the value and enter it.")

    return {
        "make": make or None, "model": model or None,
        "model_year": int(year) if year else None,
        "trim": trim or None, "condition": condition,
        "zip_code": zip_code or None, "mileage": mileage or None,
        "vin": vin or None,
        "display_name": " ".join(x for x in (yr, make, model) if x),
    }


def deductible_widgets(key_prefix="", data=None):
    """Render the 'Tax-deductible' checkbox and, when checked, its detail fields.
    Returns the expense deduction columns as a dict. `key_prefix` namespaces the
    widget keys (pass the edit-dialog prefix; empty string for the Add form);
    `data` pre-fills from an existing row in the edit case."""
    data = data or {}

    def _g(key, default):
        v = data.get(key)
        try:
            if v is None or (isinstance(v, float) and math.isnan(v)):
                return default
        except TypeError:
            pass
        return v

    def _k(name):
        return f"{key_prefix}{name}" if key_prefix else None

    deductible = st.checkbox("🧾 Tax-deductible", value=bool(_g("deductible", 0)),
                             key=_k("ded"))
    if not deductible:
        return {"deductible": 0, "deduction_category": None, "deductible_ytd": 0.0,
                "deductible_expected": 0.0, "deduct_federal": 1, "deduct_state": 1,
                "deduction_notes": None}

    cats = DEDUCTION_CATEGORIES
    cur_cat = _g("deduction_category", "")
    opts = ([cur_cat] + cats) if cur_cat and cur_cat not in cats else cats
    category = st.selectbox("Deduction category", opts,
                            index=opts.index(cur_cat) if cur_cat in opts else 0,
                            key=_k("dedcat"))

    d1, d2 = st.columns(2)
    deductible_ytd = d1.number_input("Deductible Year-to-Date ($)", min_value=0.0, step=50.0,
                                     value=float(_g("deductible_ytd", 0.0)), key=_k("dedytd"))
    deductible_expected = d2.number_input("Deductible expected ($)", min_value=0.0, step=50.0,
                                          value=float(_g("deductible_expected", 0.0)),
                                          key=_k("dedexp"))

    st.caption("Applies to — which return(s) this deduction counts on")
    ac1, ac2 = st.columns(2)
    deduct_federal = ac1.checkbox("Federal", value=bool(_g("deduct_federal", 1)), key=_k("dedfed"))
    deduct_state = ac2.checkbox("State", value=bool(_g("deduct_state", 1)), key=_k("dedstate"))

    notes = st.text_area("Deduction notes — optional", value=str(_g("deduction_notes", "") or ""),
                         placeholder="Form numbers, payer, anything to remember at filing time",
                         key=_k("dednotes"))

    return {"deductible": 1, "deduction_category": category,
            "deductible_ytd": deductible_ytd, "deductible_expected": deductible_expected,
            "deduct_federal": 1 if deduct_federal else 0,
            "deduct_state": 1 if deduct_state else 0,
            "deduction_notes": notes or None}
