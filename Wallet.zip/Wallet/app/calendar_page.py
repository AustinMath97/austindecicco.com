"""
calendar_page.py — Monthly cash flow calendar.

Builds a day-by-day grid of every income arrival, expense due date, and debt
payment in the selected month. Uses:
  - income.* schedule (recurrence.from_row → occurrences_in_month)
  - income.pay_amount (per-occurrence dollar amount)
  - expenses.* schedule (same recurrence model as income)
  - debts.due_day     (day of month)
"""

import calendar
from datetime import date

import pandas as pd
import streamlit as st

import cards
import db
import recurrence
import stats
from utils import is_cash, ordinal, safe_float, safe_str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# 1-indexed (leading "") so MONTH_NAMES[month] works with calendar month ints;
# the names themselves come from the shared list in recurrence.
MONTH_NAMES = [""] + recurrence.MONTH_NAMES

_ordinal = ordinal      # shared implementation (utils.ordinal)


# NaN-safe coercers — the shared utils implementations.
_safe_float = safe_float
_safe_str = safe_str


# ---------------------------------------------------------------------------
# Event computation
# ---------------------------------------------------------------------------

def _build_events(year, month):
    """
    Returns (events, notes) where events is {day_int: [event_dict]} for the
    given month and notes is a list of human-readable strings explaining what
    was left off (e.g. income without a per-occurrence amount).

    event_dict keys:
        kind         – 'income' | 'expense' | 'debt'
        name         – display label
        amount       – dollar amount for this occurrence
        auto_draft   – bool (expenses only)
        draft_source – str (expenses only)
    """
    income_df   = db.load_df("income")
    expenses_df = db.load_df("expenses")
    debts_df    = db.load_df("debts")

    _, days_in_month = calendar.monthrange(year, month)
    events: dict[int, list] = {}
    notes: list[str] = []

    def _add(day, ev):
        # A due day past the month's length (e.g. the 31st in February) falls
        # on the last day of the month — standard "end of month" behaviour.
        day = min(max(int(day), 1), days_in_month)
        events.setdefault(day, []).append(ev)

    # ── Income (schedule-aware: weekly / biweekly / monthly / etc.) ───────────
    # Each row's recurrence is expanded against THIS month, so "every Wednesday"
    # lands on the real Wednesdays of this month rather than fixed day numbers.
    hidden_income: list[str] = []
    unscheduled_income: list[str] = []
    for _, row in income_df.iterrows():
        name = _safe_str(row.get("source"), "Income")
        sched = recurrence.from_row(row)
        if sched["type"] == recurrence.NONE:
            # No schedule at all: this stream can never land on a calendar day —
            # say so rather than silently leaving it off every month.
            unscheduled_income.append(name)
            continue
        if sched["type"] in (recurrence.SEMIMONTHLY, recurrence.MONTHLY,
                             recurrence.QUARTERLY) and not sched["month_days"]:
            # Claims a day-of-month schedule but no days were saved: it fires in
            # NO month, ever — that's unscheduled in practice, not "a different
            # month", so it must land in the note below instead of vanishing.
            unscheduled_income.append(name)
            continue
        days = recurrence.occurrences_in_month(sched, year, month)
        if not days:
            continue                # scheduled, just fires in a different month

        pay_amount = _safe_float(row.get("pay_amount"))
        if pay_amount <= 0:
            # Scheduled but no per-occurrence amount: don't guess by splitting the
            # YTD/expected total (that conflates a whole-period figure with one
            # paycheck).
            hidden_income.append(name)
            continue

        autodep = bool(int(_safe_float(row.get("auto_deposit"))))
        dep_target = _safe_str(row.get("deposit_target"))
        for day in days:
            _add(day, {"kind": "income", "name": name, "amount": pay_amount,
                       "auto_draft": False, "draft_source": None,
                       "auto_deposit": autodep, "deposit_target": dep_target,
                       "table": "income", "id": int(row["id"])})
    if hidden_income:
        uniq = ", ".join(sorted(set(hidden_income)))
        notes.append(f"Income hidden (scheduled, but no per-occurrence amount set): {uniq}.")
    if unscheduled_income:
        uniq = ", ".join(sorted(set(unscheduled_income)))
        notes.append(f"Income not on the calendar (no usable schedule — none set, "
                     f"or no days picked): {uniq}. "
                     "Set a schedule on the Income page to place them.")

    # ── Expenses (schedule-aware: weekly / biweekly / monthly / quarterly / …) ─
    # Each bill's recurrence is expanded against THIS month, exactly like income —
    # so a quarterly water bill shows only in its real months and a semi-annual
    # premium lands on both its dates, not every month.
    hidden_expenses: list[str] = []
    for _, row in expenses_df.iterrows():
        sub  = _safe_str(row.get("subcategory"))
        name = sub if sub else _safe_str(row.get("category"), "Expense")
        sched = recurrence.from_row(row)
        if sched["type"] == recurrence.NONE:
            hidden_expenses.append(name)         # no usable schedule at all
            continue
        if sched["type"] in (recurrence.SEMIMONTHLY, recurrence.MONTHLY,
                             recurrence.QUARTERLY) and not sched["month_days"]:
            hidden_expenses.append(name)         # day-of-month schedule, no days picked
            continue
        # Per-occurrence amounts in this month: fixed for a set bill, recorded /
        # projected (average or repeat-by-period) for a variable one.
        amounts = stats.occurrence_amounts(
            row, date(year, month, 1), date(year, month, days_in_month), date.today())
        if not amounts:
            continue                             # scheduled, just fires in another month

        auto = bool(int(_safe_float(row.get("auto_draft"))))
        src  = _safe_str(row.get("draft_source"))
        for dt, amt in amounts.items():
            _add(dt.day, {
                "kind": "expense", "name": name, "amount": amt,
                "auto_draft": auto, "draft_source": src,
                "table": "expenses", "id": int(row["id"]),
            })
    if hidden_expenses:
        uniq = ", ".join(sorted(set(hidden_expenses)))
        notes.append(f"Expenses not on the calendar (no usable schedule — none set, "
                     f"or no days picked): {uniq}. "
                     "Set a schedule on the Expenses page to place them on the calendar.")

    # ── Debt payments (skip anything already paid off) ────────────────────────
    # A debt linked to an expense is the SAME payment seen twice (e.g. an auto-loan
    # debt and its auto-drafted "Car Payment" expense). The expense wins — it carries
    # the schedule the user set — so the debt's own due-day payment is suppressed to
    # avoid drawing the bill on two different days.
    debts_with_expense = db.linked_id_set("debts", "expenses")
    hidden_debts: list[str] = []
    deduped_debts: list[str] = []
    for _, row in debts_df.iterrows():
        balance = _safe_float(row.get("balance"))
        if balance <= 0:
            continue                      # nothing left owed → no payment shown
        name = _safe_str(row.get("name"), "Debt payment")
        if int(row["id"]) in debts_with_expense:
            deduped_debts.append(name)    # already shown as its linked expense
            continue
        due_day = row.get("due_day")
        # The minimum honors the card's model (%/floor) and is capped at the balance,
        # so a card below its minimum shows just the remaining balance.
        min_pay = stats.debt_min_payment(row)
        if not due_day or _safe_float(due_day) == 0 or min_pay <= 0:
            # Still owed, but missing a due day and/or a minimum payment — it
            # can't be placed or sized, so note it instead of dropping it silently.
            hidden_debts.append(name)
            continue
        _add(int(_safe_float(due_day)), {
            "kind": "debt",
            "name": name,
            "amount": min_pay,
            "auto_draft": False,
            "draft_source": None,
            "table": "debts", "id": int(row["id"]),
        })
    if hidden_debts:
        uniq = ", ".join(sorted(set(hidden_debts)))
        notes.append(f"Debt payments not shown (no due day and/or minimum payment "
                     f"set): {uniq}. Set both on the Debts page to place them.")
    if deduped_debts:
        uniq = ", ".join(sorted(set(deduped_debts)))
        notes.append(f"Debt payments shown via their linked expense (not drawn twice): "
                     f"{uniq}.")

    return events, notes


# ---------------------------------------------------------------------------
# Calendar grid (native Streamlit buttons — every item is clickable, color-coded
# by kind via CSS targeting the per-key `st-key-…` classes Streamlit emits)
# ---------------------------------------------------------------------------

_CAL_CSS = """
<style>
/* compact, left-aligned, color-coded calendar item buttons (grid: cg_, list: cl_) */
[class*="st-key-cg_"] button, [class*="st-key-cl_"] button {
    padding: 1px 8px !important; min-height: 0 !important; height: auto !important;
    line-height: 1.4 !important; font-size: .82rem !important; font-weight: 500 !important;
    text-align: left !important; justify-content: flex-start !important;
    border-radius: 5px !important; width: 100% !important; box-shadow: none !important;
}
[class*="st-key-cg_"] button {                       /* grid items stay one line */
    white-space: nowrap !important; overflow: hidden !important; text-overflow: ellipsis !important;
}
[class*="st-key-cg_inc"]  button, [class*="st-key-cl_inc"]  button { background:#d1f0d8 !important; color:#155724 !important; border:1px solid #a7d7b5 !important; }
[class*="st-key-cg_expM"] button, [class*="st-key-cl_expM"] button { background:#fde8cc !important; color:#7a4010 !important; border:1px solid #f3cfa0 !important; }
[class*="st-key-cg_expA"] button, [class*="st-key-cl_expA"] button { background:#fcd8dc !important; color:#7b1d23 !important; border:1px solid #f0b6bd !important; }
[class*="st-key-cg_debt"] button, [class*="st-key-cl_debt"] button { background:#fef9c3 !important; color:#7a5c0a !important; border:1px solid #ece2a0 !important; }

/* the month grid: a box around it, bordered cells, equal-height rows, tight spacing.
   The day number is pinned to the top of each cell (position:absolute) and the
   items flow below it via the cell's top padding — so an item physically cannot
   ride up over the date or its underline regardless of Streamlit's flex margins. */
.st-key-calgrid { border:1px solid #d8dde4; border-radius:10px; padding:8px; background:#fafbfc; }
.st-key-calgrid [data-testid="stHorizontalBlock"] { gap:5px !important; align-items:stretch !important; }
.st-key-calgrid [data-testid="stColumn"] {
    position:relative; border:1px solid #e5e7eb; border-radius:6px; background:#fff;
    padding:24px 6px 5px; min-height:84px; gap:3px !important;
}
.st-key-calgrid [data-testid="stColumn"] [data-testid="stVerticalBlock"] { gap:3px !important; }
/* Streamlit element containers are position:relative, so an absolutely-positioned
   child anchors to its OWN container (which sat below the 24px top padding) — that's
   why the date dropped down. Forcing them static lets .cgday anchor to the cell. */
.st-key-calgrid [data-testid="stElementContainer"] { position:static !important; margin:0 !important; }
.cgday {
    position:absolute; top:4px; left:7px; right:7px;
    font-size:.78em; font-weight:700; line-height:1;
    padding-bottom:5px; border-bottom:1px solid #eef1f5;
}

/* month-at-a-glance: one bordered box per day (no columns). The rotated weekday+
   date is absolutely pinned to a left strip and flex-centred down the FULL box
   height — exact regardless of item count; items flow in the padded area to its
   right, separated by a thin divider. Element containers are forced static so the
   absolute .caldate anchors to the box (which is position:relative), not itself. */
[class*="st-key-calday"] {
    position:relative;
    border:1px solid #e5e7eb; border-radius:8px; background:#fff;
    padding:6px 12px 6px 36px; margin-bottom:6px; gap:4px !important;
}
[class*="st-key-calday"]::before {
    content:''; position:absolute; left:30px; top:6px; bottom:6px;
    border-left:1px solid #eef1f5;
}
[class*="st-key-calday"] [data-testid="stVerticalBlock"] { gap:4px !important; }
[class*="st-key-calday"] [data-testid="stElementContainer"] { position:static !important; margin:0 !important; }
.caldate {
    position:absolute; left:0; top:0; bottom:0; width:30px;
    display:flex; align-items:center; justify-content:center;
}
.caldate span {
    writing-mode:vertical-rl; transform:rotate(180deg);
    font-weight:800; color:#475569; font-size:.72rem; letter-spacing:.3px;
    white-space:nowrap; line-height:1;
}
</style>
"""

_DAY_HEAD = ("<div style='display:grid;grid-template-columns:repeat(7,1fr);gap:5px;"
             "text-align:center;font-weight:700;color:#6b7280;font-size:.78rem;"
             "margin:2px 0 6px'>"
             + "".join(f"<div>{d}</div>" for d in ("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"))
             + "</div>")


def _cat(ev):
    """Colour category / key token for an event."""
    if ev["kind"] == "income":
        return "inc"
    if ev["kind"] == "debt":
        return "debt"
    return "expA" if ev.get("auto_draft") else "expM"


def _short_amt(a):
    """Compact money for a tight grid cell: 1895 → $1.9k, 450 → $450."""
    a = abs(float(a))
    if a >= 1000:
        return f"${f'{a / 1000:.1f}'.rstrip('0').rstrip('.')}k"
    return f"${a:,.0f}"


def _event_button(container, ev, prefix, n, full=False):
    """One clickable, colour-coded calendar item; opens the record's card pop-up.
    The key encodes the colour category so the CSS above can style it. `full`
    shows the whole name + exact amount (day list); otherwise it's abbreviated to
    fit a grid cell, with the detail in the hover tooltip."""
    name = ev["name"]
    auto = ("  ·  auto-draft" if ev.get("auto_draft")
            else "  ·  auto-deposit" if ev.get("auto_deposit") else "")
    if full:
        label = f"{name}  —  ${ev['amount']:,.2f}{auto}"
    else:
        label = f"{name if len(name) <= 10 else name[:10] + '…'}  {_short_amt(ev['amount'])}"
    tip = f"{name} — ${ev['amount']:,.2f}{auto}"
    key = f"{prefix}_{_cat(ev)}_{n}"
    tbl, rid = ev.get("table"), ev.get("id")
    if tbl and rid:
        if container.button(label, key=key, help=tip, width="stretch"):
            cards.view_record(tbl, int(rid))
    else:
        container.button(label, key=key, help=tip, width="stretch", disabled=True)


def _render_calendar_grid(year, month, events_by_day):
    """Month grid, boxed and styled like a calendar (see _CAL_CSS), with every
    event rendered as a clickable, colour-coded button."""
    today = date.today()
    with st.container(key="calgrid"):
        st.markdown(_DAY_HEAD, unsafe_allow_html=True)
        btn = 0
        for week in calendar.monthcalendar(year, month):
            cols = st.columns(7, gap="small")
            for di, day in enumerate(week):
                cell = cols[di]
                if day == 0:
                    cell.markdown("<div style='color:#d1d5db;font-size:.78em'>·</div>",
                                  unsafe_allow_html=True)
                    continue
                is_today = date(year, month, day) == today
                col = "#2563eb" if is_today else "#9ca3af"
                cell.markdown(f"<div class='cgday' style='color:{col}'>"
                              f"{day}{' • today' if is_today else ''}</div>",
                              unsafe_allow_html=True)
                for ev in events_by_day.get(day, []):
                    btn += 1
                    _event_button(cell, ev, "cg", btn)


# ---------------------------------------------------------------------------
# Page
# ---------------------------------------------------------------------------

def calendar_page():
    st.header("Cash Flow Calendar")
    st.markdown(_CAL_CSS, unsafe_allow_html=True)

    today = date.today()
    if "cal_year"  not in st.session_state:
        st.session_state.cal_year  = today.year
    if "cal_month" not in st.session_state:
        st.session_state.cal_month = today.month

    # ── Month navigation ─────────────────────────────────────────────────────
    c1, c2, c3, c4, c5 = st.columns([1, 1, 4, 1, 1])
    if c1.button("«", width="stretch", help="Previous year"):
        st.session_state.cal_year -= 1
        st.rerun()
    if c2.button("‹", width="stretch", help="Previous month"):
        if st.session_state.cal_month == 1:
            st.session_state.cal_month, st.session_state.cal_year = 12, st.session_state.cal_year - 1
        else:
            st.session_state.cal_month -= 1
        st.rerun()
    c3.markdown(
        f"<h3 style='text-align:center;margin:4px 0'>"
        f"{MONTH_NAMES[st.session_state.cal_month]} {st.session_state.cal_year}</h3>",
        unsafe_allow_html=True,
    )
    if c4.button("›", width="stretch", help="Next month"):
        if st.session_state.cal_month == 12:
            st.session_state.cal_month, st.session_state.cal_year = 1, st.session_state.cal_year + 1
        else:
            st.session_state.cal_month += 1
        st.rerun()
    if c5.button("»", width="stretch", help="Next year"):
        st.session_state.cal_year += 1
        st.rerun()

    year  = st.session_state.cal_year
    month = st.session_state.cal_month

    # ── Build events ─────────────────────────────────────────────────────────
    events_by_day, notes = _build_events(year, month)

    # ── Monthly summary ───────────────────────────────────────────────────────
    total_income   = sum(e["amount"] for evs in events_by_day.values()
                         for e in evs if e["kind"] == "income")
    total_expenses = sum(e["amount"] for evs in events_by_day.values()
                         for e in evs if e["kind"] == "expense")
    total_debt     = sum(e["amount"] for evs in events_by_day.values()
                         for e in evs if e["kind"] == "debt")
    net            = total_income - total_expenses - total_debt

    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Income in",      f"${total_income:,.0f}")
    m2.metric("Expenses out",   f"${total_expenses:,.0f}")
    m3.metric("Debt payments",  f"${total_debt:,.0f}")
    net_label = f"+${net:,.0f}" if net >= 0 else f"-${abs(net):,.0f}"
    # st.metric reads the arrow direction from a leading "-" in the delta text;
    # plain "shortfall" rendered an UP arrow next to the word shortfall.
    m4.metric("Net cash flow",  net_label,
              delta="surplus" if net >= 0 else "-shortfall",
              delta_color="normal")

    # ── Legend ────────────────────────────────────────────────────────────────
    def _swatch(label, bg, fg, bd):
        return (f"<span style='background:{bg};color:{fg};border:1px solid {bd};"
                f"padding:1px 9px;border-radius:5px;font-size:.8em;margin-right:6px'>"
                f"{label}</span>")
    st.markdown(
        _swatch("Income", "#d1f0d8", "#155724", "#a7d7b5")
        + _swatch("Expense", "#fde8cc", "#7a4010", "#f3cfa0")
        + _swatch("Auto-draft", "#fcd8dc", "#7b1d23", "#f0b6bd")
        + _swatch("Debt payment", "#fef9c3", "#7a5c0a", "#ece2a0")
        + "<span style='color:#6b7280;font-size:.8em'> — click any item to view, "
          "edit, or delete it.</span>",
        unsafe_allow_html=True)
    st.write("")

    # ── Calendar grid (clickable) ─────────────────────────────────────────────
    if events_by_day:
        _render_calendar_grid(year, month, events_by_day)
    else:
        st.info(
            "No scheduled events this month. "
            "Add **day(s) of month** to income entries and **due day** to expenses and debts "
            "to see them here. Annual expenses also need a **due month**."
        )

    for note in notes:
        st.caption(f"ℹ️ {note}")

    st.divider()

    # ── Chronological list ────────────────────────────────────────────────────
    st.subheader("Month at a glance")

    st.caption("Grouped by day. Click an item to open its card — view, edit, or delete it.")

    if events_by_day:
        cln = 0
        for day in sorted(events_by_day):
            evs = events_by_day[day]
            d = date(year, month, day)
            day_in = sum(e["amount"] for e in evs if e["kind"] == "income")
            day_out = sum(e["amount"] for e in evs if e["kind"] in ("expense", "debt"))
            net = day_in - day_out
            net_txt = (f":green[**+${net:,.0f}**]" if net >= 0
                       else f":red[**−${abs(net):,.0f}**]")
            box = st.container(key=f"calday_{day}")
            # rotated date label is absolutely pinned to the left strip and centred
            # down the full box height (see _CAL_CSS); items flow in the padded area
            box.markdown(
                f"<div class='caldate'><span>{d.strftime('%a').upper()} {day}</span></div>",
                unsafe_allow_html=True,
            )
            box.markdown(f"{net_txt}  ·  net for the day")
            for ev in evs:
                cln += 1
                _event_button(box, ev, "cl", cln, full=True)
    else:
        st.caption("Nothing scheduled this month.")

    # ── Running balance ───────────────────────────────────────────────────────
    if events_by_day:
        st.divider()
        st.subheader("Day-by-day running balance")

        # The opening balance is TODAY's liquid cash, so days already in the past
        # can't be replayed on top of it — their flows are in those balances
        # already (replaying them double-counted a mid-month paycheck). A past
        # month gets no projection at all; the current month projects from today
        # onward; a future month projects all days but can't see the flows between
        # today and its 1st.
        _today = date.today()
        if (year, month) < (_today.year, _today.month):
            st.caption("No projection for a past month — that month's flows are "
                       "already reflected in today's balances.")
        else:
            # Seed from liquid cash assets
            assets_df = db.load_df("assets")
            liquid_cash = float(
                assets_df.loc[
                    assets_df["asset_type"].apply(is_cash) & (assets_df["liquid"] == 1),
                    "value"
                ].sum()
            ) if not assets_df.empty else 0.0

            current_month = (year, month) == (_today.year, _today.month)
            from_day = _today.day if current_month else 1

            running = liquid_cash
            balance_rows = [{"Date": "Opening balance", "Change": 0.0, "Balance": running}]

            for day in sorted(events_by_day):
                if day < from_day:
                    continue                     # already reflected in balances
                day_in  = sum(e["amount"] for e in events_by_day[day] if e["kind"] == "income")
                day_out = sum(e["amount"] for e in events_by_day[day]
                             if e["kind"] in ("expense", "debt"))
                change  = day_in - day_out
                running += change
                balance_rows.append({
                    "Date":    f"{month:02d}/{day:02d}/{year}",
                    "Change":  change,
                    "Balance": running,
                })

            bal_df = pd.DataFrame(balance_rows)
            st.dataframe(
                bal_df,
                column_config={
                    "Change":  st.column_config.NumberColumn("Change",  format="$%.2f"),
                    "Balance": st.column_config.NumberColumn("Balance", format="$%.2f"),
                },
                hide_index=True,
                width="stretch",
            )
            scope = ("Days before today are omitted — their flows are already in "
                     "your balances; today's items count as still pending."
                     if current_month else
                     f"Flows between today and {MONTH_NAMES[month]} 1 aren't "
                     "projected here — see the Accounts page for the rolling "
                     "30-day projection.")
            st.caption(
                f"Opening balance is your liquid cash on hand as of today — "
                f"checking/savings marked liquid (${liquid_cash:,.0f}), not "
                f"brokerage or other liquid holdings. {scope} Includes monthly "
                "expenses, annual expenses due this month, and payments on debts "
                "that still carry a balance."
            )
