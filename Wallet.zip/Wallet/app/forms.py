"""
forms.py — modal dialog forms for adding new records.

Each public function is decorated with @st.dialog. Calling it opens a pop-up.
The form adjusts dynamically based on the user's category selection.
st.rerun() inside a dialog closes it.
"""

from datetime import date

import streamlit as st

import accounts
import db
import prices
import recurrence
import stats
import taxes
from utils import (ACCOUNT_TYPE_GROUPS, ASSET_TYPES_BY_FAMILY, SECURITY_ASSET_TYPES,
                   coingecko_url, format_address, is_cash, is_distribution,
                   ordinal, safe_float, safe_str, zillow_search_url)
from widgets import (deductible_widgets, expense_amount_widget,
                     margin_account_picker, margin_apr_formula_input,
                     min_payment_fields, schedule_widget, seed_tracked,
                     set_schedule_widget_keys, vehicle_fields)

# Latest published contribution / gift figures (IRS, tax year 2025). Update
# annually. Shown as guidance only — they don't constrain what you can enter.
LIMITS_YEAR = 2025
CONTRIBUTION_LIMITS = {
    "Roth IRA": 7000, "Traditional IRA": 7000,
    "401(k)": 23500, "Roth 401(k)": 23500, "403(b)": 23500, "457(b)": 23500,
    "Solo 401(k)": 70000, "SEP IRA": 70000, "SIMPLE IRA": 16500,
    "HSA (invested)": 4300,
}
GIFT_TAX_ANNUAL_EXCLUSION = 19000   # per recipient, 2025

MONTH_NAMES = recurrence.MONTH_NAMES    # single source for month names


def _append(table, row_dict):
    """Insert one new row, preserving the ids of every existing row. Returns the new
    row's id (so the caller can immediately link it to other records)."""
    return db.insert_row(table, row_dict)


# ---------------------------------------------------------------------------
# Link picker — lets a brand-new record be grouped with existing records as it's
# created. A new row has no id until it's inserted, so link_picker only gathers
# the intent and apply_new_links() creates the links once the id exists.
# ---------------------------------------------------------------------------

LINK_TABLES = ["assets", "debts", "income", "expenses"]
LINK_TABLE_LABEL = {"assets": "Asset", "debts": "Debt",
                    "income": "Income", "expenses": "Expense"}


def _new_link_label(table, row):
    """Short label for a candidate row (a pandas Series) in the link picker."""
    if table == "income":
        return safe_str(row.get("source")) or "Income"
    if table == "expenses":
        cat, sub = safe_str(row.get("category")), safe_str(row.get("subcategory"))
        return (f"{cat} — {sub}" if sub else cat) or "Expense"
    return safe_str(row.get("name")) or LINK_TABLE_LABEL.get(table, "Item")


def link_picker(key_prefix):
    """Render an optional 'link to other records' section for an Add dialog and
    return the intent (applied after insert by apply_new_links). One of:
        {"mode": "new",      "name": str|None, "targets": [(table, id), ...]}
        {"mode": "existing", "group_id": int}
    """
    with st.expander("🔗 Link to other records (optional)"):
        st.caption("Group this with related records — a property with its mortgage, a "
                   "loan with its payment, a rental with its income. Everyone in a group "
                   "is linked to everyone else; you can refine it later from Edit.")
        groups = db.all_groups()
        opts = ["__new__"] + [g["id"] for g in groups]

        def _fmt(v):
            if v == "__new__":
                return "➕ New group"
            g = next((x for x in groups if x["id"] == v), None)
            return g["name"] if (g and g["name"]) else "Unnamed group"

        choice = st.selectbox("Group", opts, format_func=_fmt, key=f"{key_prefix}grp")
        if choice != "__new__":
            st.caption("This record will join that group and link to its members.")
            role = st.text_input("Relationship (optional)", key=f"{key_prefix}role",
                                 placeholder="e.g. payment, insurance, rental income",
                                 help="This record's role in the group — shown next to "
                                      "it in the linked-records list.")
            return {"mode": "existing", "group_id": int(choice),
                    "role": role.strip() or None}

        name = st.text_input("New group name", key=f"{key_prefix}gname",
                             placeholder="e.g. 123 Oak Lane — mortgage")
        label_map = {}
        for t in LINK_TABLES:
            df = db.load_df(t)
            if df.empty:
                continue
            for _, r in df.iterrows():
                label_map[(t, int(r["id"]))] = f"{LINK_TABLE_LABEL[t]}: {_new_link_label(t, r)}"
        if not label_map:
            st.caption("No other records yet to link to.")
            return {"mode": "new", "name": name.strip() or None, "targets": []}
        picked = st.multiselect("Link to these records", list(label_map.keys()),
                                format_func=lambda k: label_map.get(k, str(k)),
                                key=f"{key_prefix}targets")
        role = None
        if picked:
            role = st.text_input("Relationship (optional)", key=f"{key_prefix}role",
                                 placeholder="e.g. payment, insurance, rental income",
                                 help="This record's role in the new group — shown next "
                                      "to it in the linked-records list (matches the "
                                      "role field in the Edit dialog's link section).")
        if picked and not name.strip():
            st.caption(":red[Name the new group to link these records on save.]")
        return {"mode": "new", "name": name.strip() or None, "targets": picked,
                "role": (role or "").strip() or None}


def apply_new_links(table, new_id, spec):
    """Create the links chosen in link_picker for a just-inserted row. A new group is
    only created when at least one target is selected (a one-member group links
    nothing and would be pruned anyway)."""
    if not spec:
        return
    role = spec.get("role")
    if spec.get("mode") == "existing":
        db.add_to_group(int(spec["group_id"]), table, int(new_id), role)
    elif spec.get("mode") == "new":
        targets = spec.get("targets") or []
        if not targets:
            return
        gid = db.create_group(spec.get("name"))
        db.add_to_group(gid, table, int(new_id), role)
        for ttable, tid in targets:
            db.add_to_group(gid, ttable, int(tid))


def link_spec_error(spec):
    """Validation message for a link_picker spec, or None if it's fine. A new group
    must be named when records are selected to link (new groups require a name); the
    save handler blocks on this before inserting the row."""
    if spec and spec.get("mode") == "new" and spec.get("targets") and not spec.get("name"):
        return "Name the new group (or clear the linked records) before saving."
    return None


# ---------------------------------------------------------------------------
# Import-from-linked-record buttons for the Add dialogs. The new row has no id /
# saved group yet, so candidates are read from the PENDING link selection rather
# than from db.linked_records (which the Edit dialogs use). The buttons prefill the
# keyed Add-form inputs (axe_*/axi_*), mirroring the Edit-dialog prefill helpers.
# ---------------------------------------------------------------------------

def _spec_linked_rows(spec, other_table):
    """Rows of `other_table` implied by a link_picker spec: the selected targets for a
    new group, or the chosen group's current members for an existing one."""
    if not spec:
        return []
    ids = set()
    if spec.get("mode") == "new":
        ids = {int(i) for (t, i) in (spec.get("targets") or []) if t == other_table}
    elif spec.get("mode") == "existing":
        for m in db.group_members(int(spec["group_id"])):
            if m["table"] == other_table:
                ids.add(int(m["id"]))
    if not ids:
        return []
    df = db.load_df(other_table)
    if df.empty:
        return []
    return [r.to_dict() for _, r in df.iterrows() if int(r["id"]) in ids]


def _debt_min_by_id(debt_id):
    """A debt's current minimum payment, looked up by id (0.0 if not found) — used
    to confirm an imported 'pays this debt' pairing against the saved amount."""
    df = db.load_df("debts")
    m = df[df["id"] == int(debt_id)] if not df.empty else df
    return stats.debt_min_payment(m.iloc[0].to_dict()) if not getattr(m, "empty", True) else 0.0


def _prefill_new_expense_from_debt(debt):
    """on_click: fill the Add-expense amount + schedule from a linked debt's payment
    (a debt pays monthly on its due day). Writes the keyed inputs before they
    re-instantiate on the rerun."""
    mp = safe_float(debt.get("min_payment"))
    if mp > 0:
        st.session_state["axe_amount"] = float(mp)
        st.session_state["axe_mode"] = "Set"     # importing a debt payment is a set amount
    # Remember this expense IS the debt's payment, so group stats de-dup the pair
    # without prompting. Confirmed against the amount at save (guards stale state).
    st.session_state["axe_pays_debt"] = int(debt["id"])
    dd = safe_float(debt.get("due_day"))
    sched = {"type": recurrence.MONTHLY,
             "month_days": [int(dd)] if dd > 0 else []}
    set_schedule_widget_keys("add_exp", sched)   # the Add form's schedule prefix


def _prefill_new_income_from_cash(asset):
    """on_click: import a linked cash account's interest into the Add-income form — the
    annual and per-payment amounts from its APY compounded on its actual payout schedule
    (the same math as the Edit dialog's import, so the two buttons can't disagree), and
    the payout schedule itself into the form's schedule widgets."""
    value, apy = safe_float(asset.get("value")), safe_float(asset.get("apy"))
    if value <= 0 or apy <= 0:
        return
    sched = accounts.asset_interest_sched(asset)
    if sched.get("type") in (None, "", recurrence.NONE):
        sched = accounts.DEFAULT_INTEREST_SCHED
    annual, per = accounts.interest_income_amounts(value, apy, sched)
    st.session_state["axi_amount"] = float(round(annual, 2))
    st.session_state["axi_payamt"] = float(round(per, 2))
    set_schedule_widget_keys("add_inc", sched)   # the Add form's schedule prefix


def expense_import_buttons(link_spec):
    """Render an import button per linked debt (from the pending link selection) that
    has a payment, so a new expense can pull a debt's payment as it's created."""
    debts = [d for d in _spec_linked_rows(link_spec, "debts")
             if safe_float(d.get("min_payment")) > 0]
    if not debts:
        return
    st.caption("Import a payment from a linked debt:")
    for d in sorted(debts, key=lambda x: safe_str(x.get("name")).lower()):
        mp, dd = safe_float(d.get("min_payment")), safe_float(d.get("due_day"))
        st.button(
            f"↪ Use {safe_str(d.get('name'))} payment: ${mp:,.0f}/mo"
            + (f", due {ordinal(int(dd))}" if dd > 0 else ""),
            key=f"axe_pf_{int(d['id'])}",
            on_click=_prefill_new_expense_from_debt, args=(d,))


def income_import_buttons(link_spec, annual_lands=True):
    """Render an import button per linked interest-bearing cash account (from the
    pending link selection), so a new income can pull its interest amounts + payout
    schedule as it's created. annual_lands=False flags income-type branches that
    derive their annual amount from their own fields (hourly wage, monthly rent) —
    the import still fills the per-payment amount and schedule, but the annual
    amount has nowhere to land, so say so instead of silently dropping it."""
    accts = [a for a in _spec_linked_rows(link_spec, "assets")
             if is_cash(a.get("asset_type"))
             and safe_float(a.get("apy")) > 0 and safe_float(a.get("value")) > 0]
    if not accts:
        return
    st.caption("Import interest from a linked cash account (amounts + payout schedule):")
    if not annual_lands:
        st.caption(":orange[This income type computes its annual amount from its own "
                   "fields, so the import fills the per-payment amount and schedule only.]")
    for a in sorted(accts, key=lambda x: safe_str(x.get("name")).lower()):
        sched = accounts.asset_interest_sched(a)
        if sched.get("type") in (None, "", recurrence.NONE):
            sched = accounts.DEFAULT_INTEREST_SCHED
        annual, per = accounts.interest_income_amounts(
            safe_float(a.get("value")), safe_float(a.get("apy")), sched)
        st.button(
            f"↪ Import interest from {safe_str(a.get('name'))}: "
            f"${annual:,.0f}/yr (${per:,.2f}/payment)",
            key=f"axi_pf_{int(a['id'])}",
            on_click=_prefill_new_income_from_cash, args=(a,))


def _gl_caption(value, cost_basis, ticker=None):
    """Show an unrealized gain/loss preview from a manually-entered value, or —
    for a tickered position whose value isn't known until the price fetch — a
    note that it'll appear once prices refresh."""
    if cost_basis and cost_basis > 0 and value and value > 0:
        gl = value - cost_basis
        st.caption(f":{'green' if gl >= 0 else 'red'}[Unrealized {'gain' if gl >= 0 else 'loss'}: "
                   f"**{'+$' if gl >= 0 else '-$'}{abs(gl):,.2f}** ({gl / cost_basis * 100:+.1f}%)]")
    elif cost_basis and cost_basis > 0 and ticker:
        st.caption("Unrealized gain/loss appears once the live price is fetched.")


# ---------------------------------------------------------------------------
# Assets
# ---------------------------------------------------------------------------

@st.dialog("Add Asset", width="large")
def add_asset():
    CATEGORIES = [
        "Brokerage Account",
        "Retirement Account",
        "Inherited / Estate Account",
        "Cash & Bank Account",
        "Cryptocurrency",
        "Real Estate",
        "Vehicle",
        "Business Ownership",
        "Receivable (money owed to you)",
        "Collectible / Valuable Item",
        "Other",
    ]
    category = st.selectbox("Asset category", CATEGORIES)

    name = ticker = institution = None
    # The two new fields: the tax/custody wrapper (NULL for directly-held things)
    # and what the holding actually is. Each branch sets them explicitly.
    account_type = None
    asset_type = None
    shares = None
    value = 0.0
    liquid = 0
    cost_basis = None
    mileage = None
    vin = None
    street = city = state = zip_code = None
    beds = baths = sqft = year_built = None
    apy = None
    interest_sched = {}      # interest payout schedule columns (set for cash w/ APY)
    ownership_pct = maturity_date = trim = condition = None
    collection_date = collection_prob = None
    make = model = model_year = None

    # ── Brokerage ────────────────────────────────────────────────────────────
    if category == "Brokerage Account":
        account_type = "Brokerage"
        c1, c2 = st.columns(2)
        institution = c1.text_input("Broker / platform", placeholder="e.g. Fidelity, Schwab, Robinhood")
        asset_type = c2.selectbox("Asset type", SECURITY_ASSET_TYPES)

        entry_mode = st.radio(
            "Track as",
            ["Individual holding (one position at a time)", "Total account value"],
            horizontal=True,
            help="Use 'Individual holding' to track each stock or fund separately "
                 "with live prices, or 'Total account value' to log the whole "
                 "account as one lump sum.",
        )

        if entry_mode.startswith("Individual"):
            name = st.text_input("Position label", placeholder="e.g. NVDA, S&P 500 Index Fund")
            c3, c4 = st.columns(2)
            raw = c3.text_input("Ticker symbol", placeholder="e.g. NVDA, VTI")
            ticker = raw.upper().strip() or None
            shares = c4.number_input("Shares / units", min_value=0.0, step=0.0001, format="%.4f")
            if ticker:
                st.caption(f"Live price for **{ticker}** will be fetched on save.")
            else:
                value = st.number_input("Current value ($)", min_value=0.0, step=100.0)
        else:
            name = f"{institution} Brokerage" if institution else "Brokerage Account"
            value = st.number_input("Total account value ($)", min_value=0.0, step=100.0)

        cost_basis = st.number_input("Total cost basis ($)", min_value=0.0, step=100.0,
                                     help="Total amount paid. Used to calculate unrealized gain/loss.")
        _gl_caption(value, cost_basis, ticker)
        liquid = 1

    # ── Retirement ───────────────────────────────────────────────────────────
    elif category == "Retirement Account":
        liquid = 0
        c1, c2 = st.columns(2)
        account_type = c1.selectbox("Account type", ACCOUNT_TYPE_GROUPS["Retirement"])
        institution = c2.text_input("Institution", placeholder="e.g. Vanguard, Fidelity, employer plan")
        asset_type = st.selectbox("Asset type (what this account holds)", SECURITY_ASSET_TYPES)

        contrib_limit = CONTRIBUTION_LIMITS.get(account_type)
        if contrib_limit:
            st.caption(f"{LIMITS_YEAR} contribution limit: **${contrib_limit:,}** "
                       f"(under-50; catch-up adds more)")

        entry_mode = st.radio(
            "Track as",
            ["Individual holding (one position at a time)", "Total account value"],
            horizontal=True,
            help="Use 'Individual holding' to track each stock or fund separately inside this account.",
        )

        if entry_mode.startswith("Individual"):
            c3, c4 = st.columns(2)
            raw = c3.text_input("Ticker symbol", placeholder="e.g. VTI, VXUS, FXAIX, VTTSX")
            ticker = raw.upper().strip() or None
            shares = c4.number_input("Shares", min_value=0.0, step=0.0001, format="%.4f")
            name = ticker if ticker else (account_type + (f" — {institution}" if institution else ""))
            if ticker:
                st.caption(f"Live price for **{ticker}** will be fetched on save.")
            else:
                value = st.number_input("Position value ($)", min_value=0.0, step=100.0)
        else:
            name = account_type + (f" — {institution}" if institution else "")
            value = st.number_input("Total account value ($)", min_value=0.0, step=100.0)
        cost_basis = st.number_input(
            "Cost basis ($)", min_value=0.0, step=100.0,
            help="Total contributed / paid, for gain-loss tracking. Leave 0 if not tracking.")
        _gl_caption(value, cost_basis, ticker)

    # ── Inherited / Estate ───────────────────────────────────────────────────
    elif category == "Inherited / Estate Account":
        c1, c2 = st.columns(2)
        account_type = c1.selectbox("Account type", ACCOUNT_TYPE_GROUPS["Inherited"])
        institution = c2.text_input("Institution / Estate",
                                    placeholder="e.g. Fidelity, Smith Family Trust")
        # Inherited taxable/brokerage assets are generally sellable; tax-advantaged
        # and pending-distribution ones are not treated as liquid.
        liquid = 1 if ("Brokerage" in account_type or "Taxable" in account_type) else 0

        if is_distribution(account_type):
            asset_type = "Cash"      # a pending cash distribution, grouped with receivables
            name = account_type + (f" — {institution}" if institution else "")
            value = st.number_input("Amount expected / value ($)", min_value=0.0, step=100.0)
        else:
            asset_type = st.selectbox("Asset type (what this account holds)",
                                      SECURITY_ASSET_TYPES)
            entry_mode = st.radio(
                "Track as",
                ["Individual holding (one position at a time)", "Total account value"],
                horizontal=True,
                help="Track each holding inside the inherited account separately "
                     "with live prices, or log the whole account as a lump sum.",
            )
            if entry_mode.startswith("Individual"):
                c3, c4 = st.columns(2)
                raw = c3.text_input("Ticker symbol", placeholder="e.g. VTI, AAPL")
                ticker = raw.upper().strip() or None
                shares = c4.number_input("Shares / units", min_value=0.0, step=0.0001, format="%.4f")
                name = ticker if ticker else (account_type + (f" — {institution}" if institution else ""))
                if ticker:
                    st.caption(f"Live price for **{ticker}** will be fetched on save.")
                else:
                    value = st.number_input("Position value ($)", min_value=0.0, step=100.0)
            else:
                name = account_type + (f" — {institution}" if institution else "")
                value = st.number_input("Total account value ($)", min_value=0.0, step=100.0)
            cost_basis = st.number_input(
                "Cost / stepped-up basis ($)", min_value=0.0, step=100.0,
                help="Inherited assets usually receive a stepped-up basis to fair "
                     "market value as of the date of death. Leave 0 if not tracking.")
            _gl_caption(value, cost_basis, ticker)

    # ── Cash & Bank ──────────────────────────────────────────────────────────
    elif category == "Cash & Bank Account":
        asset_type = "Cash"
        account_type = st.selectbox("Account type", ACCOUNT_TYPE_GROUPS["Cash / Bank"])
        institution = st.text_input("Institution", placeholder="e.g. Chase, Ally, Marcus")
        name = account_type + (f" — {institution}" if institution else "")
        c1, c2 = st.columns(2)
        value = c1.number_input("Balance ($)", min_value=0.0, step=100.0)
        apy_pct = c2.number_input("APY (%)", min_value=0.0, step=0.01,
                                  help="Annual percentage yield, if interest-bearing.")
        apy = apy_pct / 100 if apy_pct > 0 else None
        if apy and value:
            st.caption(f"Annual yield at current balance: ${value * apy:,.0f}")
        # When the interest is paid out — same schedule options as income (weekly,
        # biweekly, semi-monthly, monthly, quarterly in chosen months, annual…). Drives
        # the Accounts projection and the income "Import interest" button.
        if apy:
            st.markdown("**Interest payout** — when the interest is paid out")
            _isf = schedule_widget(accounts.DEFAULT_INTEREST_SCHED, key_prefix="add_aint")
            interest_sched = {
                "interest_schedule_type": _isf["schedule_type"],
                "interest_weekday":       _isf["weekday"],
                "interest_week_ordinal":  _isf["week_ordinal"],
                "interest_anchor_date":   _isf["anchor_date"],
                "interest_pay_days":      _isf["pay_days"],
                "interest_months":        _isf["months"],
            }
        # CDs and Treasuries mature on a date; capture it for liquidity/calendar.
        if account_type.startswith("CD") or "Treasury" in account_type:
            md = st.date_input("Maturity date", value=None,
                               help="When the CD / treasury matures and becomes liquid.")
            maturity_date = md.isoformat() if md else None
        # CDs are locked; an HSA is medical-restricted — neither is liquid.
        liquid = 0 if (account_type.startswith("CD") or "HSA" in account_type) else 1

    # ── Crypto ───────────────────────────────────────────────────────────────
    elif category == "Cryptocurrency":
        asset_type = "Cryptocurrency"
        c1, c2 = st.columns(2)
        coin = c1.text_input("Coin / token name", placeholder="e.g. Bitcoin, Ethereum, Solana")
        raw = c2.text_input("Yahoo Finance ticker", placeholder="e.g. BTC-USD, ETH-USD, SOL-USD")
        ticker = raw.upper().strip() or None
        account_type = st.selectbox("Held where", ACCOUNT_TYPE_GROUPS["Crypto"])
        institution = st.text_input("Platform / wallet", placeholder="e.g. Coinbase, Ledger, MetaMask")
        shares = st.number_input("Amount held", min_value=0.0, step=0.000001, format="%.6f")
        name = coin or ticker or "Crypto"
        if ticker:
            st.caption(f"Live price for **{ticker}** will be fetched on save "
                       "(CoinGecko, falling back to Yahoo Finance).")
        else:
            value = st.number_input("Current value ($)", min_value=0.0, step=100.0)
        st.caption(f"[🔗 Price reference on CoinGecko ↗]({coingecko_url(coin or ticker)}) — "
                   "for coins that can't be priced automatically.")
        cost_basis = st.number_input("Cost basis ($)", min_value=0.0, step=100.0,
                                     help="Total fiat paid to acquire this position.")
        _gl_caption(value, cost_basis, ticker)
        liquid = 1 if st.checkbox("Liquid (quickly sellable)", value=account_type.startswith("Centralized")) else 0

    # ── Real Estate ──────────────────────────────────────────────────────────
    elif category == "Real Estate":
        asset_type = st.selectbox("Property type", ASSET_TYPES_BY_FAMILY["real_estate"])
        street = st.text_input("Street address", placeholder="e.g. 123 Oak Lane")
        ac1, ac2, ac3 = st.columns([2, 1, 1])
        city = ac1.text_input("City", placeholder="e.g. Montclair")
        state = ac2.text_input("State", placeholder="NJ", max_chars=2)
        zip_code = ac3.text_input("ZIP", placeholder="07042", max_chars=10)
        pc1, pc2, pc3, pc4 = st.columns(4)
        beds = pc1.number_input("Beds", min_value=0.0, step=1.0) or None
        baths = pc2.number_input("Baths", min_value=0.0, step=0.5) or None
        sqft = int(pc3.number_input("Sq ft", min_value=0, step=50, value=0)) or None
        year_built = int(pc4.number_input("Year built", min_value=0,
                                          max_value=date.today().year, step=1, value=0)) or None
        c1, c2 = st.columns(2)
        value = c1.number_input("Estimated market value ($)", min_value=0.0, step=1000.0)
        mortgage_bal = c2.number_input(
            "Mortgage balance ($) — for equity reference", min_value=0.0, step=1000.0,
            help="Used only for the equity estimate below — it is NOT saved with the "
                 "property. Add the mortgage as a Debt record and link it to this "
                 "property; the card derives equity from linked debts.")
        if value > 0 and mortgage_bal > 0:
            equity = value - mortgage_bal
            st.caption(f"Estimated equity: ${equity:,.0f} ({equity/value*100:.1f}%) — "
                       "reference only; the balance isn't saved with this asset.")
        cost_basis = st.number_input(
            "Purchase price / cost basis ($)", min_value=0.0, step=1000.0,
            help="What you paid, plus capital improvements. Used for unrealized gain/loss "
                 "and, if you sell, the taxable gain.")
        _gl_caption(value, cost_basis)

        name = street.strip() or asset_type
        addr = format_address(street, city, state, zip_code)
        if addr:
            st.caption(f"[🔗 Check the Zestimate on Zillow ↗]({zillow_search_url(addr)}) — "
                       "free; read the value and enter it above.")
        street = street.strip() or None
        city = city.strip() or None
        state = state.strip().upper() or None
        zip_code = zip_code.strip() or None
        liquid = 0

    # ── Vehicle ──────────────────────────────────────────────────────────────
    elif category == "Vehicle":
        asset_type = st.selectbox("Vehicle type", ASSET_TYPES_BY_FAMILY["vehicle"])
        vf = vehicle_fields(None, key_prefix="add_veh", vehicle_type=asset_type)
        make, model, model_year = vf["make"], vf["model"], vf["model_year"]
        trim, condition, zip_code = vf["trim"], vf["condition"], vf["zip_code"]
        mileage, vin = vf["mileage"], vf["vin"]
        # Name from year/make/model, falling back to the type so it isn't blank.
        name = vf["display_name"] or asset_type
        value = st.number_input("Estimated value ($)", min_value=0.0, step=500.0,
                                help="Your equity in the vehicle, before any loan.")
        liquid = 0

    # ── Business Ownership ───────────────────────────────────────────────────
    elif category == "Business Ownership":
        asset_type = st.selectbox("Ownership type", ASSET_TYPES_BY_FAMILY["business"])
        name = st.text_input("Business name", placeholder="e.g. Smith Consulting LLC")
        c1, c2 = st.columns(2)
        value = c1.number_input("Total business value ($)", min_value=0.0, step=1000.0,
                                help="Total value of the whole business. Net worth counts "
                                     "your stake — this × your ownership %.")
        own_pct = c2.number_input("Ownership %", min_value=0.0, max_value=100.0, step=1.0, value=100.0)
        ownership_pct = own_pct / 100.0
        if own_pct != 100 and value > 0:
            st.caption(f"Your stake: ${value * own_pct / 100:,.0f} (counts toward net worth)")
        liquid = 0

    # ── Receivable ───────────────────────────────────────────────────────────
    elif category == "Receivable (money owed to you)":
        asset_type = st.selectbox("Type", ASSET_TYPES_BY_FAMILY["receivable"])
        name = st.text_input("Description", placeholder="e.g. Loan to John, Q4 invoice — Acme Corp")
        institution = st.text_input("Owed by (person, company, agency)",
                                    placeholder="e.g. John Smith, Acme Corp, IRS") or None
        c1, c2 = st.columns(2)
        value = c1.number_input("Amount owed ($)", min_value=0.0, step=50.0)
        cd = c2.date_input("Expected collection date", value=None,
                           help="When you expect payment — drives liquidity and the cash-flow calendar.")
        collection_date = cd.isoformat() if cd else None
        collection_prob = st.number_input(
            "Likelihood of collecting (0–1)", min_value=0.0, max_value=1.0,
            value=1.0, step=0.05,
            help="Probability you'll actually collect: 1.0 = certain, 0.5 = coin-flip, 0.0 = written off.")
        if value > 0 and collection_prob < 1.0:
            st.caption(f"Risk-adjusted value: ${value * collection_prob:,.0f} "
                       f"({int(collection_prob * 100)}% likely).")
        if asset_type == "Personal Loan to Someone":
            apy_pct = st.number_input("Agreed interest rate (% APR, optional)", min_value=0.0, step=0.1)
            apy = apy_pct / 100 if apy_pct > 0 else None
        # Liquid if expected within ~30 days.
        liquid = 1 if (cd and (cd - date.today()).days <= 30) else 0

    # ── Collectible ──────────────────────────────────────────────────────────
    elif category == "Collectible / Valuable Item":
        asset_type = st.selectbox("Category", ASSET_TYPES_BY_FAMILY["collectible"])
        name = st.text_input("Description", placeholder="e.g. Vintage Rolex Submariner, 1952 Mickey Mantle PSA 8")
        value = st.number_input("Estimated value ($)", min_value=0.0, step=100.0,
                                help="Use recent comparable sales. Be conservative.")
        cost_basis = st.number_input("Cost basis ($)", min_value=0.0, step=100.0,
                                     help="What you paid. Leave 0 if not tracking gain/loss.")
        _gl_caption(value, cost_basis)
        liquid = 0

    # ── Other ────────────────────────────────────────────────────────────────
    else:
        name = st.text_input("Asset name")
        asset_type = st.text_input("Asset type (optional)",
                                   placeholder="e.g. Intellectual Property, Life Insurance CV") or "Other"
        value = st.number_input("Estimated value ($)", min_value=0.0, step=100.0)
        cost_basis = st.number_input("Cost basis ($)", min_value=0.0, step=100.0,
                                     help="What you paid. Leave 0 if not tracking gain/loss.")
        _gl_caption(value, cost_basis)
        liquid = 1 if st.checkbox("Liquid", value=False) else 0

    if not name:
        name = None

    link_spec = link_picker("lnk_assets_")

    st.divider()
    c1, c2 = st.columns(2)
    if c1.button("Save", type="primary", width="stretch"):
        if not name:
            st.error("Please provide a name.")
            st.stop()
        _lerr = link_spec_error(link_spec)
        if _lerr:
            st.error(_lerr)
            st.stop()
        new_id = _append("assets", {
            "name": name, "account_type": account_type, "asset_type": asset_type,
            "ticker": ticker,
            # 0 shares means "no share count tracked" (a lump-sum holding) — store
            # NULL so refreshes don't compute value = 0 × price (Edit does the same).
            "shares": shares if shares else None, "value": value, "liquid": liquid,
            "last_price": None, "updated_at": None,
            "institution": institution,
            "cost_basis": cost_basis or None, "mileage": mileage, "vin": vin,
            "street": street, "city": city, "state": state, "zip_code": zip_code,
            "beds": beds, "baths": baths, "sqft": sqft, "year_built": year_built,
            "apy": apy, "ownership_pct": ownership_pct, "maturity_date": maturity_date,
            "trim": trim, "condition": condition,
            "collection_date": collection_date, "collection_prob": collection_prob,
            "make": make, "model": model, "model_year": model_year,
            **interest_sched,
        })
        apply_new_links("assets", int(new_id), link_spec)
        if ticker:
            # Price just this asset — not the whole portfolio (one network call,
            # not one per holding). A tickered lump sum still caches last_price.
            with st.spinner(f"Fetching price for {ticker}…"):
                prices.refresh_asset_prices(only_id=int(new_id))
        st.rerun()
    if c2.button("Cancel", width="stretch"):
        st.rerun()


# ---------------------------------------------------------------------------
# Debts
# ---------------------------------------------------------------------------

@st.dialog("Add Debt", width="large")
def add_debt():
    CATEGORIES = [
        "Credit Card",
        "Student Loan",
        "Auto Loan",
        "Mortgage",
        "Home Equity Loan / HELOC",
        "Personal Loan",
        "Buy Now Pay Later (BNPL)",
        "Medical Debt",
        "Tax Debt (IRS / State)",
        "Business Loan / Line of Credit",
        "Margin Loan",
        "Loan from Family or Friend",
        "Other",
    ]
    category = st.selectbox("Debt type", CATEGORIES)

    name = lender = ""
    balance = apr_pct = min_payment = orig_balance = 0.0
    months_remaining = 0
    debt_type = "other"
    credit_limit = mp_pct = None          # revolving-card fields (None for other debts)
    mp_type = "fixed"
    stmt = {"statement_day": None, "statement_weekday": None, "statement_week_ordinal": None}
    apr_formula = None                    # margin loans: APR as a live formula
    margin_account = None                 # margin loans: the investment account (a datapoint, not a link)

    # ── Credit Card ──────────────────────────────────────────────────────────
    if category == "Credit Card":
        debt_type = "revolving"
        c1, c2 = st.columns(2)
        issuer = c1.text_input("Issuer / bank", placeholder="e.g. Chase, Amex, Capital One")
        card_name = c2.text_input("Card name (optional)", placeholder="e.g. Sapphire Reserve, Freedom")
        name = (issuer or "Credit Card") + (f" — {card_name}" if card_name else "")
        lender = issuer
        c3, c4 = st.columns(2)
        balance = c3.number_input("Current balance ($)", min_value=0.0, step=10.0)
        apr_pct = c4.number_input("APR (%)", min_value=0.0, max_value=100.0, step=0.01, value=24.99)
        _mpf = min_payment_fields(None, "axd_cc_", balance=balance, apr=apr_pct / 100.0)
        credit_limit = _mpf["credit_limit"]
        min_payment = _mpf["min_payment"]
        mp_type = _mpf["min_payment_type"]
        mp_pct = _mpf["min_payment_pct"]
        stmt = {k: _mpf[k] for k in
                ("statement_day", "statement_weekday", "statement_week_ordinal")}

    # ── Student Loan ─────────────────────────────────────────────────────────
    elif category == "Student Loan":
        debt_type = "education"
        loan_kind = st.selectbox("Loan type", ["Federal Direct Subsidized", "Federal Direct Unsubsidized", "Federal Grad PLUS", "Federal Parent PLUS", "Private"])
        c1, c2 = st.columns(2)
        servicer = c1.text_input("Servicer / lender", placeholder="e.g. MOHELA, Nelnet, Sallie Mae")
        lender = servicer
        name = loan_kind + (f" — {servicer}" if servicer else "")
        balance = c2.number_input("Current balance ($)", min_value=0.0, step=100.0)
        c3, c4 = st.columns(2)
        apr_pct = c3.number_input("Interest rate (%)", min_value=0.0, max_value=30.0, step=0.125)
        min_payment = c4.number_input("Monthly payment ($)", min_value=0.0, step=10.0)
        repayment = st.selectbox("Repayment plan", ["Standard (10 yr)", "Extended", "Graduated", "IBR", "PAYE / SAVE", "ICR", "PSLF track", "Other"])

    # ── Auto Loan ────────────────────────────────────────────────────────────
    elif category == "Auto Loan":
        debt_type = "auto"
        vehicle = st.text_input("Vehicle", placeholder="e.g. 2022 Honda Accord")
        c1, c2 = st.columns(2)
        lender = c1.text_input("Lender", placeholder="e.g. Toyota Financial, local credit union")
        name = (f"Auto — {vehicle}" if vehicle else "Auto Loan") + (f" ({lender})" if lender else "")
        balance = c2.number_input("Remaining balance ($)", min_value=0.0, step=100.0)
        c3, c4, c5 = st.columns(3)
        apr_pct = c3.number_input("APR (%)", min_value=0.0, max_value=30.0, step=0.1)
        min_payment = c4.number_input("Monthly payment ($)", min_value=0.0, step=10.0)
        months_remaining = int(c5.number_input("Months remaining", min_value=0, max_value=360, step=1))

    # ── Mortgage ─────────────────────────────────────────────────────────────
    elif category == "Mortgage":
        debt_type = "mortgage"
        mortgage_type = st.selectbox("Mortgage type", ["Conventional Fixed", "Conventional ARM", "FHA", "VA", "Jumbo", "USDA", "Other"])
        c1, c2 = st.columns(2)
        prop = c1.text_input("Property", placeholder="e.g. 123 Main St")
        lender = c2.text_input("Lender / servicer", placeholder="e.g. Wells Fargo, Rocket Mortgage")
        name = f"Mortgage — {prop}" if prop else f"{mortgage_type} Mortgage"
        c3, c4 = st.columns(2)
        balance = c3.number_input("Remaining balance ($)", min_value=0.0, step=1000.0)
        orig_balance = c4.number_input("Original loan amount ($)", min_value=0.0, step=1000.0)
        c5, c6, c7 = st.columns(3)
        apr_pct = c5.number_input("Interest rate (%)", min_value=0.0, max_value=20.0, step=0.125)
        min_payment = c6.number_input("Monthly P&I ($)", min_value=0.0, step=100.0)
        months_remaining = int(c7.number_input("Months remaining", min_value=0, max_value=480, step=1))
        if balance > 0 and orig_balance > 0:
            paid = orig_balance - balance
            st.caption(f"Principal paid: ${paid:,.0f} ({paid/orig_balance*100:.1f}%)")

    # ── HELOC ────────────────────────────────────────────────────────────────
    elif category == "Home Equity Loan / HELOC":
        debt_type = "home_equity"
        heloc_type = st.selectbox("Type", ["Home Equity Loan (fixed)", "HELOC (variable)"])
        c1, c2 = st.columns(2)
        prop = c1.text_input("Property", placeholder="e.g. 123 Main St")
        lender = c2.text_input("Lender")
        name = heloc_type + (f" — {prop}" if prop else "")
        c3, c4 = st.columns(2)
        balance = c3.number_input("Current balance ($)", min_value=0.0, step=100.0)
        if heloc_type == "HELOC (variable)":
            credit_line = c4.number_input("Total credit line ($)", min_value=0.0, step=1000.0)
            if credit_line > balance:
                st.caption(f"Available to draw: ${credit_line - balance:,.0f}")
        apr_pct = st.number_input("Interest rate (%)", min_value=0.0, max_value=25.0, step=0.1)
        min_payment = st.number_input("Minimum monthly payment ($)", min_value=0.0, step=25.0)

    # ── Personal Loan ────────────────────────────────────────────────────────
    elif category == "Personal Loan":
        debt_type = "personal"
        c1, c2 = st.columns(2)
        lender = c1.text_input("Lender", placeholder="e.g. SoFi, LightStream, Marcus")
        purpose = c2.text_input("Purpose", placeholder="e.g. Home improvement, Debt consolidation")
        name = (f"Personal Loan — {lender}" if lender else "Personal Loan") + (f" ({purpose})" if purpose else "")
        c3, c4, c5 = st.columns(3)
        balance = c3.number_input("Remaining balance ($)", min_value=0.0, step=100.0)
        apr_pct = c4.number_input("APR (%)", min_value=0.0, max_value=40.0, step=0.1)
        min_payment = c5.number_input("Monthly payment ($)", min_value=0.0, step=10.0)
        months_remaining = int(st.number_input("Months remaining", min_value=0, max_value=360, step=1))

    # ── BNPL ─────────────────────────────────────────────────────────────────
    elif category == "Buy Now Pay Later (BNPL)":
        debt_type = "bnpl"
        c1, c2 = st.columns(2)
        provider = c1.text_input("Provider", placeholder="e.g. Affirm, Klarna, Afterpay")
        lender = provider
        purchase = c2.text_input("Purchase description", placeholder="e.g. iPhone 16, Peloton")
        name = (f"BNPL — {purchase}" if purchase else "BNPL") + (f" ({provider})" if provider else "")
        c3, c4 = st.columns(2)
        balance = c3.number_input("Remaining balance ($)", min_value=0.0, step=10.0)
        min_payment = c4.number_input("Per-installment payment ($)", min_value=0.0, step=5.0)
        apr_pct = st.number_input("APR if missed payment (%)", min_value=0.0, max_value=100.0, step=0.1, value=0.0,
                                  help="Many BNPL plans are 0% if paid on time; the penalty rate matters.")

    # ── Medical ──────────────────────────────────────────────────────────────
    elif category == "Medical Debt":
        debt_type = "medical"
        provider = st.text_input("Provider / facility", placeholder="e.g. City Hospital, Dr. Patel")
        in_collections = st.checkbox("In collections")
        name = (f"Medical — {provider}" if provider else "Medical Debt") + (" (Collections)" if in_collections else "")
        c1, c2, c3 = st.columns(3)
        balance = c1.number_input("Balance ($)", min_value=0.0, step=10.0)
        apr_pct = c2.number_input("Interest rate (%)", min_value=0.0, max_value=50.0, step=0.1, value=0.0)
        min_payment = c3.number_input("Monthly payment ($)", min_value=0.0, step=10.0)
        if balance > 0:
            st.info("Many providers offer 0% payment plans or discounts for financial hardship — worth calling.")

    # ── Tax ──────────────────────────────────────────────────────────────────
    elif category == "Tax Debt (IRS / State)":
        debt_type = "tax"
        c1, c2 = st.columns(2)
        tax_authority = c1.selectbox("Authority", ["IRS (Federal)", "State", "Local / Property", "Other"])
        tax_year = int(c2.number_input("Tax year", min_value=2000, max_value=date.today().year, step=1, value=date.today().year - 1))
        name = f"{tax_authority} {tax_year}"
        irs_plan = st.selectbox("Payment arrangement", ["None yet", "IRS Installment Agreement", "Offer in Compromise", "Currently Not Collectible", "State arrangement"])
        c3, c4, c5 = st.columns(3)
        balance = c3.number_input("Amount owed ($)", min_value=0.0, step=10.0)
        apr_pct = c4.number_input("Penalty+interest rate (%)", min_value=0.0, max_value=30.0, step=0.1, value=8.0)
        min_payment = c5.number_input("Monthly installment ($)", min_value=0.0, step=10.0)

    # ── Business ─────────────────────────────────────────────────────────────
    elif category == "Business Loan / Line of Credit":
        debt_type = "business"
        c1, c2 = st.columns(2)
        lender = c1.text_input("Lender", placeholder="e.g. SBA, local bank, investor, vendor")
        loan_type = c2.selectbox("Type", ["Term Loan", "Line of Credit (LOC)", "SBA Loan", "Equipment Financing", "Merchant Cash Advance", "Invoice Factoring", "Other"])
        name = (f"Biz — {loan_type} ({lender})" if lender else f"Business {loan_type}")
        c3, c4, c5 = st.columns(3)
        balance = c3.number_input("Current balance ($)", min_value=0.0, step=100.0)
        apr_pct = c4.number_input("APR / factor rate (%)", min_value=0.0, max_value=200.0, step=0.1)
        min_payment = c5.number_input("Monthly payment ($)", min_value=0.0, step=25.0)

    # ── Margin Loan ──────────────────────────────────────────────────────────
    elif category == "Margin Loan":
        debt_type = stats.MARGIN_DEBT_TYPE
        # The account picker + formula input are the shared widgets the Edit
        # dialog uses too (widgets.py), so the two can't drift. The account is a
        # plain datapoint over the DERIVED investment-account grouping (not a
        # record / link); the brokerage/lender is inferred from it. Required.
        margin_account, lender = margin_account_picker("axd_margin_")
        name = (f"Margin Loan — {margin_account}" if margin_account else "Margin Loan")
        balance = st.number_input("Margin balance owed ($)", min_value=0.0, step=100.0)

        # APR as a live formula over the economic variables (re-derived each run).
        st.markdown("**Variable APR** — a formula over the economic variables")
        apr_formula, _margin_apr = margin_apr_formula_input("axd_margin_", balance)
        apr_pct = (_margin_apr or 0.0) * 100.0

    # ── Family / Friend ──────────────────────────────────────────────────────
    elif category == "Loan from Family or Friend":
        debt_type = "personal_informal"
        c1, c2 = st.columns(2)
        person = c1.text_input("Lender (first name or initials)", placeholder="e.g. Mom, J.S.")
        lender = person
        name = f"Loan from {person}" if person else "Informal Loan"
        balance = c2.number_input("Amount owed ($)", min_value=0.0, step=50.0)
        c3, c4 = st.columns(2)
        apr_pct = c3.number_input("Agreed interest rate (% — often 0)", min_value=0.0, max_value=30.0, step=0.1, value=0.0)
        min_payment = c4.number_input("Agreed monthly payment ($)", min_value=0.0, step=25.0)

    # ── Other ────────────────────────────────────────────────────────────────
    else:
        name = st.text_input("Description")
        lender = st.text_input("Lender / creditor (optional)")
        c1, c2, c3 = st.columns(3)
        balance = c1.number_input("Balance ($)", min_value=0.0, step=10.0)
        apr_pct = c2.number_input("APR (%)", min_value=0.0, max_value=100.0, step=0.1)
        min_payment = c3.number_input("Monthly payment ($)", min_value=0.0, step=10.0)

    apr = apr_pct / 100.0

    # Margin loans have no scheduled payment, so no payoff preview and no due day.
    if debt_type != stats.MARGIN_DEBT_TYPE:
        # Payoff preview — simulated, so a percent-of-balance minimum is handled too.
        _eff_min = stats.min_payment_due(balance, mp_type, mp_pct, min_payment, apr=apr)
        if balance > 0 and _eff_min > 0:
            _mos, _int = stats.months_to_payoff(balance, apr, mp_type, mp_pct, min_payment)
            if _mos is None:
                st.warning("At the minimum payment this never fully pays off — the minimum "
                           "barely outruns the interest.")
            else:
                st.info(f"At minimum payment: paid off in **{_mos} months**"
                        + (f" · **${_int:,.0f}** total interest." if apr > 0 else " (0% interest)."))
        due_day_raw = st.selectbox(
            "Payment due day", [""] + [str(i) for i in range(1, 32)], index=0,
            help="Day of month the payment is due (e.g. 15 = 15th of each month)")
        due_day = int(due_day_raw) if due_day_raw else None
    else:
        due_day = None

    # A margin loan records its investment account as a plain datapoint (no link
    # group); every other debt offers the optional link picker.
    link_spec = None if category == "Margin Loan" else link_picker("lnk_debts_")

    st.divider()
    c1, c2 = st.columns(2)
    if c1.button("Save", type="primary", width="stretch"):
        if not name:
            st.error("Please provide a name.")
            st.stop()
        if category == "Margin Loan":
            if not margin_account:
                st.error("Select the investment account this margin loan is borrowed against.")
                st.stop()
            # The live preview above already evaluated the formula THIS run —
            # apr is None iff it failed (the error is on screen).
            if _margin_apr is None:
                st.error("Fix the APR formula — it doesn't evaluate (see above).")
                st.stop()
        _lerr = link_spec_error(link_spec)
        if _lerr:
            st.error(_lerr)
            st.stop()
        new_id = _append("debts", {
            "name": name, "balance": balance, "apr": apr,
            "min_payment": min_payment, "type": debt_type,
            "min_payment_type": mp_type, "min_payment_pct": mp_pct,
            "credit_limit": credit_limit, **stmt,
            "apr_formula": apr_formula, "margin_account": margin_account,
            "lender": lender or None,
            "original_balance": orig_balance or None,
            "months_remaining": months_remaining or None,
            "due_day": due_day,
        })
        apply_new_links("debts", int(new_id), link_spec)
        st.rerun()
    if c2.button("Cancel", width="stretch"):
        st.rerun()


# ---------------------------------------------------------------------------
# Income
# ---------------------------------------------------------------------------

@st.dialog("Add Income", width="large")
def add_income():
    CATEGORIES = [
        "Employment (W-2 / Salary)",
        "Self-Employment / Freelance (1099)",
        "Investment Income",
        "Rental Income",
        "Government Benefits",
        "Side Business / Gig",
        "Royalties / Licensing",
        "Pension / Annuity",
        "Gift / Inheritance",
        "Other",
    ]
    category = st.selectbox("Income type", CATEGORIES)

    source = ""
    amount = 0.0
    income_type = "other"
    # False on the branches that DERIVE the annual amount from their own fields
    # (hourly wage, monthly rent) — there's no keyed annual-amount input there for
    # the linked-record import to fill, so its button must say so.
    annual_amount_importable = True

    # ── Employment ───────────────────────────────────────────────────────────
    if category == "Employment (W-2 / Salary)":
        income_type = "wages"
        c1, c2 = st.columns(2)
        employer = c1.text_input("Employer", placeholder="e.g. Google, Acme Corp")
        pay_type = c2.selectbox("Compensation type", ["Salary", "Hourly", "Commission", "Bonus", "RSU Vesting", "Overtime", "Other"])
        source = (employer or "Employment") + (f" — {pay_type}" if pay_type not in ("Salary", "Other") else "")
        if pay_type == "Hourly":
            annual_amount_importable = False
            c3, c4, c5 = st.columns(3)
            rate = c3.number_input("Hourly rate ($)", min_value=0.0, step=0.25)
            hrs = c4.number_input("Hours / week", min_value=0.0, step=0.5, value=40.0)
            wks = c5.number_input("Weeks / year", min_value=0, max_value=53, step=1,
                                  value=52)
            amount = rate * hrs * wks
            if amount:
                st.caption(f"Annual: ${amount:,.0f}")
        else:
            amount = st.number_input("Annual amount ($)", min_value=0.0, step=100.0,
                                     help="Full-year expected total for this stream.",
                                     key="axi_amount")

    # ── Freelance ────────────────────────────────────────────────────────────
    elif category == "Self-Employment / Freelance (1099)":
        income_type = "self_employment"
        c1, c2 = st.columns(2)
        client = c1.text_input("Client / project", placeholder="e.g. Acme Corp, Contract design work")
        net_gross = c2.radio("Amount basis", ["Net (after expenses)", "Gross (before expenses)"], horizontal=True)
        source = "Freelance" + (f" — {client}" if client else "")
        amount = st.number_input(f"Amount ({net_gross.split('(')[0].strip()}, $)", min_value=0.0,
                                 step=100.0, key="axi_amount")
        if net_gross.startswith("Gross"):
            est_expense_pct = st.slider("Estimated business expense %", 0, 80, 20)
            net = amount * (1 - est_expense_pct / 100)
            st.caption(f"Estimated net after expenses: ${net:,.0f}. Note: the tax "
                       "estimate models income tax only — not self-employment / payroll tax.")

    # ── Investment Income ────────────────────────────────────────────────────
    elif category == "Investment Income":
        income_type = "capital"
        c1, c2 = st.columns(2)
        inv_sub = c1.selectbox("Sub-type", ["Qualified Dividends", "Ordinary Dividends", "Interest (taxable)", "Interest (tax-exempt)", "Short-term Capital Gains", "Long-term Capital Gains", "Options Premium", "Crypto Gains", "Other"])
        account = c2.text_input("Account / source", placeholder="e.g. Fidelity brokerage, savings account")
        source = inv_sub + (f" — {account}" if account else "")
        amount = st.number_input("Amount ($)", min_value=0.0, step=50.0, key="axi_amount")
        if "Long-term" in inv_sub:
            st.caption("Long-term capital gains are taxed at 0%, 15%, or 20% depending on your income.")

    # ── Rental ───────────────────────────────────────────────────────────────
    elif category == "Rental Income":
        income_type = "rental"
        c1, c2 = st.columns(2)
        prop = c1.text_input("Property", placeholder="e.g. 123 Main St, Airbnb cabin")
        rental_type = c2.selectbox("Rental type", ["Long-term tenant", "Short-term / Airbnb", "Commercial tenant", "Room rental", "Storage / parking", "Other"])
        source = f"Rental — {prop}" if prop else f"Rental ({rental_type})"
        entry_mode = st.radio("Enter as", ["Monthly (auto-calculate total)", "Total for this period"], horizontal=True)
        if entry_mode == "Monthly (auto-calculate total)":
            annual_amount_importable = False
            c3, c4 = st.columns(2)
            monthly = c3.number_input("Monthly rent ($)", min_value=0.0, step=100.0)
            vacancy_pct = c4.slider("Vacancy / expense % to subtract", 0, 50, 0)
            net_monthly = monthly * (1 - vacancy_pct / 100)
            amount = net_monthly * 12
            st.caption(f"Annual (12 months): ${amount:,.0f}")
        else:
            amount = st.number_input("Annual total ($)", min_value=0.0, step=100.0, key="axi_amount")

    # ── Benefits ─────────────────────────────────────────────────────────────
    elif category == "Government Benefits":
        income_type = "benefits"
        program = st.selectbox("Program", ["Social Security Retirement", "Social Security Disability (SSDI)", "SSI", "Unemployment Insurance", "Workers' Compensation", "Veterans Benefits (VA)", "SNAP / EBT", "WIC", "Housing Assistance", "Other"])
        source = program
        amount = st.number_input("Amount ($)", min_value=0.0, step=50.0, key="axi_amount")

    # ── Side Gig ─────────────────────────────────────────────────────────────
    elif category == "Side Business / Gig":
        income_type = "gig"
        c1, c2 = st.columns(2)
        biz = c1.text_input("Business / platform", placeholder="e.g. Etsy shop, DoorDash, lawn care")
        basis = c2.radio("Amount basis", ["Net profit", "Gross revenue"], horizontal=True)
        source = biz or "Side Gig"
        amount = st.number_input(f"{basis} ($)", min_value=0.0, step=50.0, key="axi_amount")

    # ── Royalties ────────────────────────────────────────────────────────────
    elif category == "Royalties / Licensing":
        income_type = "royalties"
        c1, c2 = st.columns(2)
        royalty_type = c1.selectbox("Type", ["Book / Writing", "Music", "Patent / IP", "Software License", "Photography / Video", "Affiliate / Referral", "Other"])
        platform = c2.text_input("Platform / payer", placeholder="e.g. Amazon KDP, ASCAP, Getty")
        source = royalty_type + (f" — {platform}" if platform else "")
        amount = st.number_input("Amount ($)", min_value=0.0, step=25.0, key="axi_amount")

    # ── Pension ──────────────────────────────────────────────────────────────
    elif category == "Pension / Annuity":
        income_type = "pension"
        c1, c2 = st.columns(2)
        payer = c1.text_input("Payer / plan name", placeholder="e.g. CALPERS, former employer, insurance co")
        pension_type = c2.selectbox("Type", ["Defined Benefit Pension", "Annuity (fixed)", "Annuity (variable)", "Other"])
        source = payer or pension_type
        amount = st.number_input("Amount ($)", min_value=0.0, step=50.0, key="axi_amount")

    # ── Gift ─────────────────────────────────────────────────────────────────
    elif category == "Gift / Inheritance":
        income_type = "gift"
        c1, c2 = st.columns(2)
        giver = c1.text_input("From (optional)", placeholder="e.g. Family, Estate")
        gift_type = c2.selectbox("Type", ["Cash Gift", "Inheritance", "Trust Distribution", "Other"])
        source = (giver or gift_type)
        amount = st.number_input("Amount ($)", min_value=0.0, step=100.0, key="axi_amount")
        st.caption(f"Gifts ≤ ${GIFT_TAX_ANNUAL_EXCLUSION:,}/year ({LIMITS_YEAR}) from a "
                   "single person are not taxable income to you.")

    # ── Other ────────────────────────────────────────────────────────────────
    else:
        source = st.text_input("Source")
        amount = st.number_input("Annual amount ($)", min_value=0.0, step=50.0, key="axi_amount")

    received_ytd = st.number_input(
        "Received so far this year ($)", min_value=0.0, step=100.0, value=0.0,
        help="How much of the annual amount above is already in hand this year. The "
             "rest is what's still expected; the schedule below projects future arrivals.",
    )

    _default_tc = taxes.default_tax_class(income_type)
    # Keyed + seed_tracked ("axi_" keys reset on each dialog open): an unkeyed
    # box's identity changed with its index= whenever the category changed,
    # silently resetting a hand-picked treatment. While untouched it still
    # follows the category's default.
    seed_tracked("axi_taxclass", _default_tc)
    tax_class = st.selectbox(
        "Tax treatment", taxes.TAX_CLASS_OPTIONS, key="axi_taxclass",
        format_func=lambda k: taxes.TAX_CLASS_LABEL[k],
        help="How this income is taxed — drives the tax estimate on the Taxes page. "
             "Long-term gains / qualified dividends get preferential rates; interest and "
             "short-term gains are ordinary-rate investment income (subject to NIIT).")

    st.divider()
    auto_deposit = st.checkbox(
        "Auto-deposited", help="This income lands in an account automatically "
        "(direct deposit / ACH) — the mirror of an auto-drafted expense.")
    deposit_target = None
    if auto_deposit:
        try:
            _adf = db.load_df("assets")
            _accts = _adf[_adf["asset_type"].apply(is_cash)
                          & ~_adf["account_type"].apply(is_distribution)]["name"].tolist()
        except Exception:
            _accts = []
        if _accts:
            _choice = st.selectbox("Deposits to", ["— enter manually —"] + _accts)
            deposit_target = (_choice if _choice != "— enter manually —"
                              else st.text_input("Account name"))
        else:
            deposit_target = st.text_input(
                "Deposits to", placeholder="e.g. Chase Checking, Ally Savings")

    st.divider()
    st.markdown("**Calendar scheduling** — when it arrives, so it lands on the right dates")
    sched_fields = schedule_widget(None, key_prefix="add_inc")
    _pa = st.number_input(
        "Amount per occurrence ($)", min_value=0.0, step=100.0, key="axi_payamt",
        help="Per-paycheck or per-deposit amount — not the annual total. Drives calendar display.",
    )
    sched_fields["pay_amount"] = _pa if _pa > 0 else None

    link_spec = link_picker("lnk_income_")
    income_import_buttons(link_spec, annual_lands=annual_amount_importable)

    st.divider()
    c1, c2 = st.columns(2)
    if c1.button("Save", type="primary", width="stretch"):
        if not source:
            st.error("Please provide a source.")
            st.stop()
        _lerr = link_spec_error(link_spec)
        if _lerr:
            st.error(_lerr)
            st.stop()
        new_id = _append("income", {
            "source": source, "amount": amount,
            "received_ytd": received_ytd, "type": income_type,
            "tax_class": tax_class,
            "auto_deposit": 1 if auto_deposit else 0,
            "deposit_target": deposit_target or None,
            **sched_fields,
        })
        apply_new_links("income", int(new_id), link_spec)
        st.rerun()
    if c2.button("Cancel", width="stretch"):
        st.rerun()


# ---------------------------------------------------------------------------
# Expenses
# ---------------------------------------------------------------------------

@st.dialog("Add Expense", width="large")
def add_expense():
    CATEGORIES = [
        "Housing",
        "Transportation",
        "Food & Dining",
        "Healthcare & Medical",
        "Insurance",
        "Subscriptions & Software",
        "Entertainment & Leisure",
        "Education & Self-Development",
        "Personal Care & Family",
        "Credit Card Minimum Payment",
        "Savings / Investment Contributions",
        "Business / Side-Hustle Expense",
        "Other",
    ]
    category_top = st.selectbox("Expense category", CATEGORIES)

    category = subcategory = ""
    _step = 5.0          # category-specific step for the amount input
    _cc_pick = None      # set by the CC-minimum branch → everything derives from the card

    if category_top == "Housing":
        sub = st.selectbox("Type", ["Rent", "Mortgage (P&I)", "HOA Fees", "Property Tax", "Renter's Insurance", "Homeowner's Insurance", "Utilities — Electric", "Utilities — Gas / Heat", "Utilities — Water / Sewer", "Internet", "Cable / Streaming bundle", "Phone / Cell", "Home Maintenance / Repairs", "Lawn / Snow / Pest", "Cleaning Service", "Storage Unit", "Other"])
        category, subcategory, _step = "Housing", sub, 10.0

    elif category_top == "Transportation":
        sub = st.selectbox("Type", ["Car Payment", "Car Insurance", "Gas / Fuel", "Public Transit / Metro pass", "Parking / Tolls", "Ride Share (Uber/Lyft)", "Vehicle Maintenance", "Registration / DMV fees", "EV Charging", "Bike / Scooter share", "Other"])
        category, subcategory = "Transportation", sub

    elif category_top == "Food & Dining":
        sub = st.selectbox("Type", ["Groceries", "Dining Out (restaurants)", "Fast Food / Quick Service", "Meal Kit Delivery (HelloFresh, etc.)", "Delivery Apps (DoorDash, Uber Eats)", "Coffee & Cafes", "Work Lunches", "Other"])
        category, subcategory = "Food & Dining", sub

    elif category_top == "Healthcare & Medical":
        sub = st.selectbox("Type", ["Health Insurance Premium (if paid out-of-pocket)", "Dental Insurance", "Vision Insurance", "HSA Contribution", "Prescriptions", "Primary Care / Specialist visits", "Therapy / Counseling", "Chiropractic / PT", "Dental work", "Vision / Glasses", "Gym / Fitness membership", "Supplements / OTC", "Other"])
        category, subcategory = "Healthcare", sub

    elif category_top == "Insurance":
        sub = st.selectbox("Type", ["Life Insurance (term)", "Life Insurance (whole)", "Disability Insurance (LTD)", "Disability Insurance (STD)", "Long-Term Care Insurance", "Umbrella Policy", "Pet Insurance", "ID Theft Protection", "Other"])
        provider = st.text_input("Provider (optional)", placeholder="e.g. State Farm, Northwestern Mutual")
        category = "Insurance"
        subcategory = sub + (f" — {provider}" if provider else "")
        _step = 10.0

    elif category_top == "Subscriptions & Software":
        sub_type = st.selectbox("Category", ["Video Streaming", "Music Streaming", "News / Media", "Gaming", "Cloud Storage", "Productivity / Office", "Security / VPN", "Developer / AI tools", "Financial tools", "Other"])
        service = st.text_input("Service name", placeholder="e.g. Netflix, Spotify, Adobe CC, ChatGPT Plus")
        category = "Subscriptions"
        subcategory = service or sub_type
        _step = 1.0

    elif category_top == "Entertainment & Leisure":
        sub = st.selectbox("Type", ["Concerts / Live Events / Sports tickets", "Hobbies (gear, supplies, fees)", "Travel & Vacation", "Hotels & Lodging", "Flights", "Books, Games & Media", "Bars & Nightlife", "Date nights / Social spending", "Theme parks / Attractions", "Other"])
        category, subcategory = "Entertainment", sub

    elif category_top == "Education & Self-Development":
        sub = st.selectbox("Type", ["College Tuition", "Student Loan Payment", "Books / Textbooks / Supplies", "Online Course / MOOC", "Professional Certification / Exam", "Conference / Workshop", "Childcare / Daycare", "K-12 Private School / Tutoring", "529 Contribution", "Other"])
        category, subcategory, _step = "Education", sub, 10.0

    elif category_top == "Personal Care & Family":
        sub = st.selectbox("Type", ["Clothing & Apparel", "Haircuts / Salon / Spa", "Cosmetics & Personal Care", "Gifts (birthdays, holidays)", "Child Support / Alimony", "Childcare (babysitter, nanny)", "Pet Food & Supplies", "Veterinary Care", "Charitable Donations", "Religious / Tithing", "Other"])
        category, subcategory = "Personal & Family", sub

    elif category_top == "Credit Card Minimum Payment":
        # The recurring minimum on a revolving card. This expense type is FORCED
        # to mirror a card's debt record — the picker below is required, and the
        # amount / schedule / name derive from the card and stay synced to it on
        # every card edit and each statement close (db.sync_cc_min_expenses).
        category, _step = "Debt Payments", 10.0
        _dd_df = db.load_df("debts")
        _ccs = (_dd_df[_dd_df["type"] == "revolving"]
                if not _dd_df.empty and "type" in _dd_df.columns
                else _dd_df.iloc[0:0])
        if _ccs.empty:
            st.warning("No credit cards on the Debts page yet — this expense "
                       "type pulls everything from a card's debt record, so add "
                       "the card first.")
            st.stop()
        _cc_opts = [(int(r["id"]), safe_str(r.get("name")) or "Card")
                    for _, r in _ccs.iterrows()]
        _pick_id, _pick_name = st.selectbox(
            "Credit card", _cc_opts, format_func=lambda o: o[1],
            help="The card whose minimum this expense IS. Its amount, schedule, "
                 "and name stay synced to the card's debt record automatically.")
        _cc_pick = _ccs[_ccs["id"] == _pick_id].iloc[0].to_dict()
        subcategory = _pick_name

    elif category_top == "Savings / Investment Contributions":
        sub = st.selectbox("Contribution type", ["401(k) / 403(b) — pre-tax", "401(k) Roth — post-tax", "IRA Contribution", "Roth IRA Contribution", "HSA Contribution", "Brokerage Transfer", "Emergency Fund", "529 / Education Savings", "Sinking Fund (vacation, car, etc.)", "Other"])
        category, subcategory, _step = "Savings", sub, 25.0

    elif category_top == "Business / Side-Hustle Expense":
        sub = st.selectbox("Type", ["Software / SaaS tools", "Contractor / Freelancer payments", "Advertising / Marketing", "Office supplies / equipment", "Home office deduction", "Professional services (legal, CPA)", "Business insurance", "Business travel", "Inventory / COGS", "Other"])
        biz_name = st.text_input("Business name (optional)", placeholder="e.g. My Etsy shop, Consulting LLC")
        category = "Business Expense"
        subcategory = sub + (f" — {biz_name}" if biz_name else "")
        _step = 10.0

    else:
        category = st.text_input("Description")
        subcategory = st.text_input("Sub-category (optional)")

    st.divider()
    if _cc_pick is not None:
        # Amount, schedule, and name are the card's — shown, not asked for.
        _ccf = stats.cc_min_expense_fields(_cc_pick)
        amount, _amt_err = _ccf["amount"], None
        sched_fields = {k: _ccf[k] for k in
                        ("schedule_type", "weekday", "week_ordinal", "anchor_date",
                         "pay_days", "months", "frequency", "pay_day")}
        var_fields = {k: _ccf[k] for k in
                      ("amount_mode", "variable_method", "variable_amounts",
                       "variable_years")}
        _dd = safe_float(_cc_pick.get("due_day"))
        st.markdown(f"**Synced from the card:** \\${amount:,.2f}/mo"
                    + (f" · due the {ordinal(int(_dd))}" if _dd > 0 else ""))
        st.caption("Kept up to date automatically — every card edit and each "
                   "statement close re-derive the amount, schedule, and name "
                   "from the card's debt record.")
        if _dd <= 0:
            st.caption(":orange[This card has no due day set, so the payment "
                       "can't land on the calendar — add one on the Debts page.]")
    else:
        st.markdown("**Calendar scheduling** — when it's due, so it lands on the right "
                    "dates and the auto-draft forecast is accurate")
        sched_fields = schedule_widget(None, key_prefix="add_exp")

        st.divider()
        # ── Amount: a fixed figure, or a variable amount tracked per period ───
        amount, var_fields, _amt_err = expense_amount_widget(
            sched_fields, "axe_", defaults=None, step=_step)

    st.divider()

    # ── Auto-draft ────────────────────────────────────────────────────────────
    auto_draft = st.checkbox("Auto-drafted payment")
    draft_source = None
    if auto_draft:
        try:
            _adf = db.load_df("assets")
            _cash  = _adf[_adf["asset_type"].apply(is_cash)
                          & ~_adf["account_type"].apply(is_distribution)]["name"].tolist()
            # A debt payment can't draft from another credit card — cash only.
            _cards = ([] if category == "Debt Payments" else
                      db.load_df("debts").query("type == 'revolving'")["name"].tolist())
            _accts = _cash + _cards
        except Exception:
            _accts = []
        if _accts:
            _choice = st.selectbox("Drafts from", ["— enter manually —"] + _accts)
            draft_source = (_choice if _choice != "— enter manually —"
                            else st.text_input("Account name"))
        else:
            draft_source = st.text_input("Drafts from",
                                         placeholder="e.g. Chase Checking, Amex Blue Cash")

    st.divider()
    ded = deductible_widgets()

    link_spec = link_picker("lnk_expenses_")
    expense_import_buttons(link_spec)

    st.divider()
    c1, c2 = st.columns(2)
    if c1.button("Save", type="primary", width="stretch"):
        if not category:
            st.error("Please provide a description.")
            st.stop()
        if ded["deductible"] and not (ded["deduct_federal"] or ded["deduct_state"]):
            st.error("A deductible expense must apply to Federal and/or State.")
            st.stop()
        if _amt_err:
            st.error(f"Finish the variable amounts — {_amt_err}.")
            st.stop()
        _lerr = link_spec_error(link_spec)
        if _lerr:
            st.error(_lerr)
            st.stop()
        # Carry the imported "pays off this debt" pairing through, but only if the
        # amount still matches that debt's payment (guards stale/overridden state).
        _pays = st.session_state.get("axe_pays_debt")
        if _pays and abs(_debt_min_by_id(_pays) - amount) > 0.01:
            _pays = None
        new_id = _append("expenses", {
            "category": category, "amount": amount,
            "subcategory": subcategory or None,
            "auto_draft": 1 if auto_draft else 0,
            "draft_source": draft_source or None,
            "pays_debt_id": _pays,
            **sched_fields,
            **var_fields,
            **ded,
            # A CC-minimum expense re-derives everything from its card at save,
            # so a stale rerun can't store drifted values or drop the link.
            **(stats.cc_min_expense_fields(_cc_pick) if _cc_pick is not None else {}),
        })
        apply_new_links("expenses", int(new_id), link_spec)
        st.session_state.pop("axe_pays_debt", None)
        st.rerun()
    if c2.button("Cancel", width="stretch"):
        st.rerun()
