"""
prices.py — the market-data layer.

Pulls live prices from Yahoo Finance via yfinance and writes refreshed values
back through db.py (so the database stays the single source of truth). Every
fetch is wrapped so a network failure, a delisted ticker, or a missing
yfinance install degrades gracefully: the position keeps its last known price
instead of crashing the dashboard.

yfinance is imported lazily inside fetch_price, so the rest of the app runs
even if the package isn't installed, and importing this module never reaches
out to the network.
"""

from datetime import datetime, timezone

import pandas as pd

import db
import utils


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def yfinance_available():
    """Whether the yfinance package is importable — lets the refresh summary
    distinguish 'not installed' (every stock fetch is doomed; tell the user to
    install it) from ordinary per-ticker network/symbol failures."""
    try:
        import yfinance  # noqa: F401
        return True
    except ImportError:
        return False


def fetch_price(ticker):
    """Return the latest price for one ticker, or None if it can't be had.
    Tries the fast quote first, then falls back to the last daily close."""
    try:
        import yfinance as yf
    except ImportError:
        return None

    try:
        t = yf.Ticker(ticker)
        # fast_info is the cheap path; key name has varied across versions.
        info = getattr(t, "fast_info", None)
        if info is not None:
            for key in ("last_price", "lastPrice"):
                try:
                    p = info[key]
                except Exception:
                    p = None
                if p:
                    return float(p)
        # Fall back to the most recent close.
        hist = t.history(period="1d")
        if not hist.empty:
            return float(hist["Close"].iloc[-1])
    except Exception:
        return None
    return None


def refresh_summary_msg(result):
    """One line describing a refresh_asset_prices() summary dict, shared by every
    surface that triggers a refresh — failures are always mentioned, never
    silently folded into a success message. Lives here (not dashboard.py) so the
    launch sequence in data_management can use it without an import cycle."""
    msg = f"Updated {result['updated']} priced position(s)."
    if result.get("repriced_only"):
        msg += f" {result['repriced_only']} repriced (no share count, value unchanged)."
    if result["failed"]:
        msg += f" ⚠️ {result['failed']} could not be fetched (cached prices kept)."
    if result.get("yfinance_missing"):
        msg += " ⚠️ yfinance isn't installed, so stock/ETF prices can't be fetched."
    return msg


# Symbol → CoinGecko coin id for the common coins (CoinGecko's free price API is
# keyed by id, not ticker). Anything not here falls back to yfinance (which also
# covers crypto ETFs like GBTC/IBIT that trade under a normal stock symbol).
_COINGECKO_IDS = {
    "BTC": "bitcoin", "ETH": "ethereum", "USDT": "tether", "BNB": "binancecoin",
    "SOL": "solana", "USDC": "usd-coin", "XRP": "ripple", "ADA": "cardano",
    "AVAX": "avalanche-2", "DOGE": "dogecoin", "TRX": "tron", "DOT": "polkadot",
    "MATIC": "matic-network", "POL": "polygon-ecosystem-token", "LTC": "litecoin",
    "SHIB": "shiba-inu", "LINK": "chainlink", "BCH": "bitcoin-cash", "XLM": "stellar",
    "ATOM": "cosmos", "UNI": "uniswap", "ETC": "ethereum-classic", "XMR": "monero",
    "APT": "aptos", "ARB": "arbitrum", "OP": "optimism", "NEAR": "near",
    "FIL": "filecoin", "ICP": "internet-computer", "HBAR": "hedera-hashgraph",
    "VET": "vechain", "ALGO": "algorand", "AAVE": "aave", "GRT": "the-graph",
    "SUI": "sui", "INJ": "injective-protocol", "RNDR": "render-token", "TON": "the-open-network",
}


def _coingecko_price(coin_id):
    """Spot USD price for a CoinGecko coin id, or None on any failure/timeout."""
    import json
    import urllib.request
    url = ("https://api.coingecko.com/api/v3/simple/price"
           f"?ids={coin_id}&vs_currencies=usd")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "wallet-dashboard"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            data = json.load(resp)
        price = data.get(coin_id, {}).get("usd")
        return float(price) if price else None
    except Exception:
        return None


def fetch_crypto_price(ticker):
    """Price a crypto holding. Tries CoinGecko first (covers the long tail of
    coins yfinance misses), then falls back to yfinance for crypto ETFs and
    anything CoinGecko can't resolve.

    The yfinance fallback never sees a bare coin symbol: on Yahoo, 'BTC', 'ETH',
    and 'SOL' resolve as EQUITIES (Grayscale mini-trusts, Emeren Group…), which
    would silently revalue the holding at the wrong instrument's price — so a
    symbol without a pair suffix is quoted as its '-USD' crypto pair instead."""
    tk = str(ticker).strip().upper()
    sym = tk.split("-")[0]                                # 'BTC-USD' → 'BTC'
    coin_id = _COINGECKO_IDS.get(sym)
    if coin_id:
        price = _coingecko_price(coin_id)
        if price:
            return price
        return fetch_price(tk if "-" in tk else f"{sym}-USD")
    if "-" in tk:
        return fetch_price(tk)                            # explicit pair as-is
    # Unknown bare symbol: try the crypto pair first, then the symbol itself
    # (crypto ETFs like GBTC/IBIT trade under a normal stock symbol).
    return fetch_price(f"{sym}-USD") or fetch_price(tk)


def refresh_asset_prices(only_id=None):
    """Re-price every asset that has a ticker — or just one when `only_id` is
    given (an add/edit save shouldn't re-fetch the whole portfolio). For each,
    value = shares x price and last_price is cached. Tickerless assets (cash,
    high-value items) are left untouched. Each unique ticker is fetched ONCE
    and applied to every row holding it (the same fund in two accounts used to
    cost two round trips). Each updated position is written back individually
    by id, so row identity is preserved. Returns a summary dict for the UI.

    `updated` counts positions whose value was actually recomputed (price *and*
    shares present); `repriced_only` counts tickered lump-sum holdings that got
    a fresh last_price but no value change because no share count is tracked."""
    yf_missing = not yfinance_available()
    df = db.load_df("assets")
    if only_id is not None and not df.empty:
        df = df[df["id"] == int(only_id)]
    if df.empty:
        return {"updated": 0, "failed": 0, "skipped": 0, "repriced_only": 0,
                "yfinance_missing": yf_missing}

    updated = failed = skipped = repriced_only = 0
    quotes = {}                  # (TICKER, is_crypto) → price or None
    for _, row in df.iterrows():
        ticker = row.get("ticker")
        if ticker is None or (isinstance(ticker, float) and pd.isna(ticker)) or str(ticker).strip() == "":
            skipped += 1
            continue

        tk = str(ticker).strip()
        key = (tk.upper(), utils.asset_family(row.get("asset_type")) == "crypto")
        if key not in quotes:
            quotes[key] = (fetch_crypto_price(tk) if key[1] else fetch_price(tk))
        price = quotes[key]
        if price is None:
            failed += 1          # keep the cached last_price as the fallback
            continue

        changes = {"last_price": price, "updated_at": _now()}
        shares = row.get("shares")
        if shares is not None and not (isinstance(shares, float) and pd.isna(shares)):
            changes["value"] = float(shares) * price
            updated += 1
        else:
            repriced_only += 1   # tickered lump sum: new price, value unchanged

        db.update_row("assets", int(row["id"]), changes)

    return {"updated": updated, "failed": failed,
            "skipped": skipped, "repriced_only": repriced_only,
            "yfinance_missing": yf_missing}


def snapshot_with_refresh(label=None):
    """Refresh market prices (best-effort), then record a net-worth snapshot so
    it always reflects current values. A pricing failure (e.g. no network) is
    swallowed so the snapshot is still taken — but reported, not hidden:
    returns (snapshot_id, refresh_summary), summary None when the refresh
    itself crashed, so callers can say 'snapshot taken at stale prices'
    instead of claiming everything succeeded.

    Note: this does NOT consult db.snapshot_due() — duplicate-snapshot gating is
    deliberately the caller's job, so the manual 'Take snapshot' button always
    works while the launch sequence applies its own once-per-hour gate."""
    try:
        summary = refresh_asset_prices()
    except Exception:
        summary = None
    return db.take_snapshot(label=label), summary
