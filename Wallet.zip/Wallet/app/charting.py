"""
charting.py — chart-support helpers shared by the Overview and Investment
Accounts pages (both render a time-range picker over snapshot history).
"""


import pandas as pd
import streamlit as st


def range_picker(prefix, hist, default="1Y"):
    """A preset time-range button row (1D…All + Custom date inputs), shared by the
    net-worth chart and the Overview metric deltas. Renders at the call site and
    returns (dom_start, dom_end, tf) as naive-UTC pd.Timestamps. Session keys are
    namespaced by `prefix` so multiple pickers coexist.

    Snapshots are stored UTC and compared naive-UTC, so the bounds are naive-UTC
    too — otherwise a snapshot taken "just now" can sort ahead of a local-clock
    `now` and vanish. A Custom end date covers its WHOLE day (a midnight bound
    would drop snapshots taken later that same day)."""
    PRESETS = ["1D", "1W", "1M", "3M", "6M", "YTD", "1Y", "All", "Custom"]
    key = f"{prefix}_tf"
    if key not in st.session_state:
        st.session_state[key] = default

    btn_cols = st.columns(len(PRESETS))
    for i, label in enumerate(PRESETS):
        active = st.session_state[key] == label
        if btn_cols[i].button(
            label, key=f"{prefix}_tf_{label}",
            type="primary" if active else "secondary",
            width="stretch",
        ):
            st.session_state[key] = label
            st.rerun()

    tf = st.session_state[key]
    now = pd.Timestamp.now(tz="UTC").tz_localize(None)
    hist_min = hist["taken_at"].min() if not hist.empty else now

    if tf == "Custom":
        all_min = hist_min.date()
        all_max = max(now.date(), all_min)

        def _clamp(d, lo, hi):
            return min(max(d, lo), hi)

        start_default = _clamp(st.session_state.get(f"{prefix}_start", all_min),
                               all_min, all_max)
        end_default = _clamp(st.session_state.get(f"{prefix}_end", all_max),
                             all_min, all_max)
        c1, c2 = st.columns(2)
        start_d = c1.date_input("From", value=start_default, format="MM/DD/YYYY",
                                min_value=all_min, max_value=all_max,
                                key=f"{prefix}_from")
        end_d = c2.date_input("To", value=end_default, format="MM/DD/YYYY",
                              min_value=all_min, max_value=all_max,
                              key=f"{prefix}_to")
        if start_d > end_d:
            start_d, end_d = end_d, start_d
        st.session_state[f"{prefix}_start"] = start_d
        st.session_state[f"{prefix}_end"] = end_d
        dom_start = pd.Timestamp(start_d)
        dom_end = (pd.Timestamp(end_d) + pd.Timedelta(days=1)
                   - pd.Timedelta(microseconds=1))
    else:
        _offset = {"1M": 1, "3M": 3, "6M": 6, "1Y": 12}
        if tf == "YTD":
            dom_start = pd.Timestamp(now.year, 1, 1)
        elif tf == "All":
            dom_start = hist_min
        elif tf in ("1D", "1W"):
            dom_start = now - pd.Timedelta(days=1 if tf == "1D" else 7)
        else:
            dom_start = now - pd.DateOffset(months=_offset[tf])
        dom_end = now
    return dom_start, dom_end, tf
