"""
cards.py — static card-based display for all four tables.

Each table is rendered as a grouped grid of bordered cards. Cards are read-only;
data is changed via Edit dialogs (pre-populated) or deleted inline. The Add flow
stays in forms.py.
"""

import math
from datetime import date

import streamlit as st

import accounts
import db
import ui
import widgets
import recurrence
import stats
import taxes
from utils import (asset_family, coingecko_url, days_since,
                   esc as _esc, fmt_date, fmt_datetime, format_address,
                   is_capital_asset, is_distribution, is_inherited_account,
                   is_investment_holding, is_tax_advantaged_account, md_escape, money,
                   ordinal, parse_vehicle_name, safe_eval_formula, safe_float,
                   safe_str, utilization_color, vehicle_value_url,
                   zillow_search_url)

STALE_DAYS = 90   # a manually-entered value older than this shows a "stale" nudge

# ---------------------------------------------------------------------------
# Group label mappings
# ---------------------------------------------------------------------------

# Section label per asset-type family (utils.asset_family). Securities and crypto
# don't appear here — they group into the "Investment Accounts" section instead.
ASSET_SECTION_LABEL = {
    "cash":        "Cash & Bank Accounts",
    "real_estate": "Real Estate",
    "vehicle":     "Vehicles",
    "business":    "Business Interests",
    "receivable":  "Receivables",
    "collectible": "Collectibles & Valuables",
    "other":       "Other Assets",
}

ASSET_SECTION_ORDER = [
    "Cash & Bank Accounts",
    "Real Estate",
    "Vehicles",
    "Business Interests",
    "Receivables",
    "Collectibles & Valuables",
    "Other Assets",
]

# Readable label per asset-type family (allocation chart, the record "type" shown
# and searched on the cards). Unmapped → title-cased.
FAMILY_LABEL = {
    "security": "Securities", "crypto": "Crypto", "cash": "Cash",
    "real_estate": "Real Estate", "vehicle": "Vehicle", "business": "Business",
    "receivable": "Receivable", "collectible": "Collectible", "other": "Other",
}


def family_label(fam):
    """Readable label for an asset-type family — capitalized and spaced."""
    return FAMILY_LABEL.get(fam, str(fam).replace("_", " ").title())


def _investment_account_key(data):
    """Subheader label that groups investment holdings by account — institution +
    account type (e.g. 'Fidelity — Brokerage', 'Vanguard — Roth IRA')."""
    institution = _s(data, "institution")
    account = _s(data, "account_type")
    name = _s(data, "name")
    return " — ".join(p for p in (institution, account) if p) or name or "Investment Account"

DEBT_GROUP_ORDER = [
    "Credit Cards",
    "Student Loans",
    "Auto Loans",
    "Mortgages",
    "Home Equity",
    "Personal Loans",
    "Buy Now Pay Later",
    "Medical Debt",
    "Tax Debt",
    "Business Loans",
    "Margin Loans",
    "Informal Loans",
    "Other Debts",
]

DEBT_TYPE_LABEL = {
    "revolving":        "Credit Cards",
    "education":        "Student Loans",
    "auto":             "Auto Loans",
    "mortgage":         "Mortgages",
    "home_equity":      "Home Equity",
    "personal":         "Personal Loans",
    "bnpl":             "Buy Now Pay Later",
    "medical":          "Medical Debt",
    "tax":              "Tax Debt",
    "business":         "Business Loans",
    "margin":           "Margin Loans",
    "personal_informal":"Informal Loans",
    "other":            "Other Debts",
}

# Expense category created when deleting an asset records its realized capital
# LOSS (the mirror of the realized-gain income row). The Overview income/expense
# chart nets this category against "Investment income" so only one ever shows.
INVESTMENT_LOSS_CATEGORY = "Investment Losses"

EXPENSE_GROUP_ORDER = [
    "Housing", "Transportation", "Food & Dining", "Healthcare",
    "Insurance", "Subscriptions", "Entertainment", "Education",
    "Personal & Family", "Debt Payments", "Savings", "Business Expense",
    INVESTMENT_LOSS_CATEGORY, "Other",
]

MONTH_NAMES = recurrence.MONTH_NAMES    # single source for month names

# Edit-dialog dropdown options (match the values the Add forms store). DEBT_TYPE_LABEL
# above already serves as the debt-type picker labels.
INCOME_TYPE_LABEL = {
    "wages":           "Employment (wages / salary)",
    "self_employment": "Self-employment / freelance",
    "capital":         "Investment income",
    "rental":          "Rental income",
    "benefits":        "Government benefits",
    "gig":             "Side business / gig",
    "royalties":       "Royalties / licensing",
    "pension":         "Pension / annuity",
    "gift":            "Gift / inheritance",
    "other":           "Other",
}

# Display order for income-type groups on the Income page, so its subheaders carry
# the same scope as the Debts (by type) and Expenses (by category) pages.
INCOME_TYPE_ORDER = [
    "wages", "self_employment", "gig", "rental", "capital",
    "royalties", "pension", "benefits", "gift", "other",
]

EXPENSE_CATEGORY_OPTIONS = [
    "Housing", "Transportation", "Food & Dining", "Healthcare", "Insurance",
    "Subscriptions", "Entertainment", "Education", "Personal & Family",
    "Debt Payments", "Savings", "Business Expense", INVESTMENT_LOSS_CATEGORY,
    "Other",
]


def _dropdown_index(options, current, fallback=0):
    """Return (options_with_current_preserved, index). If `current` isn't one of
    the options it's prepended so a legacy/custom value is never silently lost."""
    opts = list(options)
    if current and current not in opts:
        opts = [current] + opts
    return opts, (opts.index(current) if current in opts else fallback)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

# Shared coercion/formatting helpers, re-exported under the short local names the
# whole module uses. _s/_n are dict-key accessors over utils' NaN-safe coercers.
_ordinal = ordinal


def _s(data, key, default=""):
    """Safe string for a dict key that may hold None/NaN (see utils.safe_str)."""
    return safe_str(data.get(key), default)


def _n(data, key, default=0.0):
    """Safe float for a dict key that may hold None/NaN (see utils.safe_float)."""
    return safe_float(data.get(key), default)


def _to_date(s):
    """Parse a stored ISO date string into a date for st.date_input, or None."""
    s = (s or "").strip()
    if not s:
        return None
    try:
        return date.fromisoformat(s[:10])
    except ValueError:
        return None


def _field(label, value, col_ratio=(1.4, 2.6), color=None):
    """Render a single label: value row inside a card. `color` (e.g. 'green'
    or 'red') tints the value via Streamlit's colored-text markdown."""
    c1, c2 = st.columns(col_ratio)
    c1.caption(label)
    value = str(value).replace("$", "\\$")   # avoid $…$ being parsed as LaTeX math
    if color:
        c2.markdown(f":{color}[**{value}**]")
    else:
        c2.markdown(f"**{value}**")


def _updated(data):
    """Footer caption showing when this row was last saved, to the second."""
    ts = _s(data, "updated_at")
    if ts:
        st.caption(f"🕑 Updated {fmt_datetime(ts)}")


def _pct(v):
    return f"{v * 100:.2f}%"


def _money(v):
    """Card line items show cents — utils.money with decimals=2."""
    return money(v, decimals=2)


# Record cards carry a `reccard_*` key, so this scopes the tightening to them (not
# the cash/credit account containers). The inter-element gap is set via the
# container's gap="xsmall"; this trims the remaining whitespace — the header→body
# divider and the Edit/Delete (and link) button height.
#
# Divider spacing: the rule should hug the subtitle ABOVE it and leave the gap
# BELOW (before the first data row) — not the reverse. Its element container is a
# flex item, so a negative top / small bottom margin (which combine with the card's
# gap) pull the rule up to the subtitle and push the first field down. `:has(hr)`
# scopes that to the divider's own container.
_CARD_CSS = """
<style>
[class*="st-key-reccard_"] hr { margin: 0 !important; }
[class*="st-key-reccard_"] [data-testid="stElementContainer"]:has(hr) {
    margin-top: -0.35rem !important;
    margin-bottom: 0.15rem !important;
}
[class*="st-key-reccard_"] .stButton button {
    min-height: 0 !important;
    padding-top: 0.1rem !important;
    padding-bottom: 0.1rem !important;
}
/* streamlit-keyup's frontend always sets its iframe to 73px tall (its
   collapsed-label height of 45px is immediately overridden by an unconditional
   setFrameHeight(73)), and its input is absolutely positioned to FILL the
   frame — so the search boxes render far taller than the 40px widgets beside
   them. Fix the geometry from the host side (!important beats the inline
   height the component sets):
   - height 42px → the inner input (which keeps a fixed 2px gap at the frame
     bottom) comes out exactly 40px, the native button height;
   - display:block → kills the inline-baseline whitespace under the iframe
     that floated the input a few px high in a centered row;
   - margin-bottom:-2px → the iframe's LAYOUT height is 40px (the empty 2px
     frame strip paints harmlessly past it), so the row is button-height from
     the first paint and nothing drops when the component mounts. */
iframe[title="st_keyup.st_keyup"] {
    height: 42px !important;
    display: block;
    margin-bottom: -2px;
}
</style>
"""


def inject_card_css():
    """Emit the record-card spacing styles once per run (call from the router)."""
    st.markdown(_CARD_CSS, unsafe_allow_html=True)


def _effective_value(data):
    """A row's value scaled by ownership fraction — the stake that counts toward
    net worth. Assets with no ownership_pct (the usual case) count fully. Mirrors
    stats.effective_asset_values so card totals match the Overview net-worth math."""
    v = _n(data, "value")
    own = _n(data, "ownership_pct") if _s(data, "ownership_pct") else 0.0
    return v * own if own > 0 else v


# Per-row widget-key namespace each table's Edit dialog uses (every input widget
# in the dialog is keyed under it, including the vehicle and schedule sub-widgets).
_EDIT_WIDGET_PREFIX = {"assets": "ea_", "debts": "edt_", "income": "ei_", "expenses": "ex_"}


def _edit_ver(table, row_id):
    """Per-open version for a row's Edit dialog. Bumped each time the dialog
    opens, and woven into every widget key, so each open uses brand-new keys —
    which forces the widgets to start from the database value. (Deleting a keyed
    widget's session_state entry does NOT reliably reset it, so simply clearing
    isn't enough; giving the widget a key it has never had before is.)"""
    return int(st.session_state.get(f"ev_{table}_{row_id}", 0))


# ---------------------------------------------------------------------------
# Cross-card links + cross-dialog navigation
# ---------------------------------------------------------------------------

TABLE_LABEL = {"assets": "Asset", "debts": "Debt", "income": "Income", "expenses": "Expense"}
LINK_TABLES = ["assets", "debts", "income", "expenses"]


def _row_label(table, d):
    """Readable label for a row dict (used when building the add-link picker)."""
    if table == "income":
        return _s(d, "source") or "Income"
    if table == "expenses":
        cat, sub = _s(d, "category"), _s(d, "subcategory")
        return (f"{cat} — {sub}" if sub else cat) or "Expense"
    return _s(d, "name") or TABLE_LABEL.get(table, "Item")


def record_type_label(table, d):
    """A record's granular type — the human label shown on the cards and in the
    Data Management manager, and matched by the search alongside the name. Assets
    read as "Asset type · Account type" (e.g. "ETF / Index Fund · Roth IRA"), or
    just the asset type when held directly ("Car"); debts and income use their
    type maps; expenses use their category."""
    if table == "assets":
        atype = _s(d, "asset_type") or family_label(asset_family(_s(d, "asset_type")))
        acct = _s(d, "account_type")
        return f"{atype} · {acct}" if acct else atype
    if table == "debts":
        return DEBT_TYPE_LABEL.get(_s(d, "type", "other"), "Other Debts")
    if table == "income":
        return INCOME_TYPE_LABEL.get(_s(d, "type", "other") or "other",
                                     INCOME_TYPE_LABEL["other"])
    if table == "expenses":
        return _s(d, "category", "Other")
    return ""


def search_text(table, d):
    """The text a record is matched against by the search boxes: its card label
    plus its granular type, lower-cased — so typing a name OR a type (e.g.
    "brokerage", "mortgage", "rental") finds the record."""
    return f"{_row_label(table, d)} {record_type_label(table, d)}".lower()


def _linked_records(table, row_id, other_table):
    """Full row dicts of records in `other_table` that share a group with
    (table, row_id). Used by the derived displays (equity from linked debts,
    interest prefill from a linked cash account, payment prefill from a linked
    debt) — so a record only pulls from things in one of its groups."""
    ids = {l["id"] for l in db.linked_records(table, row_id) if l["table"] == other_table}
    if not ids:
        return []
    df = db.load_df(other_table)
    if df.empty:
        return []
    return [r.to_dict() for _, r in df.iterrows() if int(r["id"]) in ids]


def _seedk(P, field, default):
    """Seed a versioned widget's session_state once and return its key. Lets a
    field be prefilled from a linked record (the callback just writes the key)
    without the value=/Session-State clash — these widgets pass no value=."""
    k = f"{P}{field}"
    if k not in st.session_state:
        st.session_state[k] = default
    return k


def _begin_edit(table, row_id):
    """Reset a row's Edit-dialog widget state and bump its version (see
    _edit_ver) so it opens fresh. Shared by the card Edit button and the
    cross-dialog 'Edit ↗' jump."""
    pfx = _EDIT_WIDGET_PREFIX.get(table)
    if pfx:
        widgets.clear_widget_state(f"{pfx}{row_id}_")
    st.session_state[f"ev_{table}_{row_id}"] = _edit_ver(table, row_id) + 1


def request_edit(table, row_id):
    """Queue a different row to be edited. The current dialog closes on the
    st.rerun the caller issues; consume_pending_edit() then opens the target."""
    st.session_state["_pending_edit"] = (table, int(row_id))


def request_view(table, row_id):
    """Queue a record to be shown in a card pop-up. The caller issues st.rerun,
    which closes any dialog currently open; consume_pending_view() then opens the
    target — so clicking a linked record inside a pop-up swaps it out instead of
    stacking a second pop-up on top of the first."""
    st.session_state["_pending_view"] = (table, int(row_id))


def consume_pending_view():
    """Open a queued record pop-up. Call once at the very top of the app (before the
    page renders) so the pop-up replaces the dialog the click closed, and so its
    widget keys get namespaced (see _kctx) before the page draws the same card."""
    pv = st.session_state.pop("_pending_view", None)
    if not pv:
        return
    table, row_id = pv
    if table not in TABLE_LABEL:
        return
    df = db.load_df(table)
    match = df[df["id"] == int(row_id)] if not df.empty else df
    if match.empty:
        return
    # A confirm left from a previously dismissed pop-up would otherwise reopen
    # this card straight on its delete confirmation.
    clear_delete_confirms(popup_only=True)
    view_record(table, int(row_id))


def _kctx():
    """Key suffix distinguishing a card rendered inside a view pop-up from the same
    card on its page. view_record sets _in_view_popup while it renders (which happens
    before the page draws), so the two never collide on a shared widget key even when
    the popped record also appears on the current page."""
    return "_pop" if st.session_state.get("_in_view_popup") else ""


def _linked_links(table, row_id):
    """Clickable linked records shown on a card, organised by group (a record can
    be in several). Each member is a link-styled button that opens that record's
    own card pop-up. Clicks route through the view queue + rerun (request_view), so
    clicking a link from inside a pop-up closes the current pop-up and opens the new
    one rather than layering a second one on top."""
    groups = db.groups_for(table, row_id)
    if not groups:
        return
    sfx = _kctx()

    def _member_button(g, m):
        lbl = db.row_label(m["table"], m["id"])
        role = _s(m, "role")
        face = f"{TABLE_LABEL[m['table']]}: {lbl}" + (f"  ·  {role}" if role else "")
        if st.button(face, key=f"lk_{table}_{row_id}_{g['group_id']}_{m['member_id']}{sfx}",
                     type="tertiary", width="stretch",
                     help="Open this linked record's card pop-up"):
            request_view(m["table"], int(m["id"]))
            st.rerun()

    for g in groups:
        members = [m for m in db.group_members(g["group_id"], exclude=(table, row_id))
                   if db.row_label(m["table"], m["id"]) is not None]
        if not members:
            continue
        name = g["name"] or "Linked"
        # A big group collapses behind an expander so the card isn't a wall of links.
        if len(members) >= 6:
            with st.expander(f"🔗 {name} ({len(members)} linked)"):
                for m in members:
                    _member_button(g, m)
        else:
            st.caption(f"🔗 {name}")
            for m in members:
                _member_button(g, m)


def _filing_status():
    """The saved filing status (Taxes page), defaulting to single."""
    idx = int(db.get_constant("filing_status", 0))
    return taxes.FILING_STATUSES[idx] if 0 <= idx < len(taxes.FILING_STATUSES) else "single"


def is_taxable_capital_account(asset_type, account_type):
    """True if disposing of (selling from) this holding is a taxable capital event:
    the asset is a capital asset (security/crypto/property/collectible/business) AND
    its account isn't a tax-advantaged wrapper. Tax-advantaged accounts — every
    retirement / IRA / HSA, and inherited retirement accounts / annuities (their
    distributions are ordinary income, not capital gains) — are excluded; inherited
    TAXABLE property still qualifies (stepped-up basis, long-term). Shared by the
    delete-asset flow and the Buy/Sell tool so the two classify trades identically."""
    return is_capital_asset(asset_type) and not is_tax_advantaged_account(account_type)


def _capital_asset_basis(data):
    """(value, cost_basis) for an asset whose disposal gets capital-gain/loss
    treatment, or None — the screening shared by the gain and loss recorders.
    See is_taxable_capital_account for which accounts qualify."""
    if not is_taxable_capital_account(_s(data, "asset_type"), _s(data, "account_type")):
        return None
    cb = _n(data, "cost_basis") if _s(data, "cost_basis") else None
    if not cb or cb <= 0:
        return None
    return _n(data, "value"), cb


def _asset_gain_info(data):
    """If a taxable-gain asset has an unrealized gain (cost basis set and value above it),
    return {gain, value, cost_basis, asset_type, account_type}; else None."""
    vb = _capital_asset_basis(data)
    if not vb:
        return None
    value, cb = vb
    gain = value - cb
    if gain <= 0:
        return None
    return {"gain": gain, "value": value, "cost_basis": cb,
            "asset_type": _s(data, "asset_type"), "account_type": _s(data, "account_type")}


def _asset_loss_info(data):
    """Mirror of _asset_gain_info for the loss side: if the asset's value sits BELOW
    its cost basis, return {loss, value, cost_basis, asset_type, account_type}; else None."""
    vb = _capital_asset_basis(data)
    if not vb:
        return None
    value, cb = vb
    loss = cb - value
    if loss <= 0:
        return None
    return {"loss": loss, "value": value, "cost_basis": cb,
            "asset_type": _s(data, "asset_type"), "account_type": _s(data, "account_type")}


def gain_income_row(name, taxable, tax_class):
    """The income row a realized capital gain records. Shared by the delete-asset
    flow and the Buy/Sell tool so the two can't drift. `taxable` is the gain after
    any exclusions; it lands as fully-received capital income."""
    return {"source": f"Realized gain — {name}", "amount": round(taxable, 2),
            "received_ytd": round(taxable, 2), "type": "capital", "tax_class": tax_class}


def loss_expense_row(name, loss, term, acat, basis, proceeds):
    """The deductible-expense row a realized capital loss records. Shared by the
    delete-asset flow and the Buy/Sell tool. `term` is 'long-term'/'short-term';
    `basis`/`proceeds` annotate the note (cost basis sold vs sale proceeds)."""
    return {
        "category": INVESTMENT_LOSS_CATEGORY,
        "subcategory": f"Realized loss — {name}",
        # A realized loss is a one-off, not a recurring bill: schedule 'none' keeps
        # it off the calendar/auto-draft and out of the recurring burn run-rate,
        # while it's still tracked as a deductible below.
        "amount": round(loss, 2),
        "frequency": recurrence.frequency_label(recurrence.NONE),
        "schedule_type": recurrence.NONE,
        "auto_draft": 0, "draft_source": None,
        "deductible": 1, "deduction_category": "Other",
        "deductible_ytd": round(loss, 2), "deductible_expected": 0,
        # NJ can't take a capital loss against ordinary income, so only the
        # federal flag is set; see the on-screen note about the federal limits.
        "deduct_federal": 1, "deduct_state": 0,
        "deduction_notes": (f"Realized {term} capital loss on {name} ({acat}): "
                            f"{basis:,.2f} basis − {proceeds:,.2f} sale price. Federal "
                            "offset limits (§1211(b)) and wash-sale rules are not "
                            "applied by the itemized-deduction pull — review before "
                            "filing."),
    }


def _record_gain_widget(row_id, data, gain, sfx):
    """Render the 'record realized gain as taxable income' options inside an asset's
    delete confirm, applying the asset's special capital-gains rules. Returns the income
    row dict to insert on delete, or None if nothing should be recorded."""
    P = f"rg_{row_id}{sfx}_"
    g, value, cb = gain["gain"], gain["value"], gain["cost_basis"]
    asset_type, account_type = gain["asset_type"], gain["account_type"]
    fam = asset_family(asset_type)
    name = _s(data, "name", "asset")

    st.markdown(_esc(f"💰 Unrealized gain **{_money(g)}**  ·  {_money(value)} value "
                     f"− {_money(cb)} basis."))
    if not st.checkbox("Record this gain as realized taxable income on delete", key=f"{P}on"):
        return None

    # The tracked value is only an estimate of what the sale brings in — even a
    # live-priced holding's last quote lags the actual fill, and the sale isn't
    # recorded the instant it happens — so realize the gain against the REAL
    # proceeds the user enters, not the on-screen value. Defaults to that value.
    sell = st.number_input(
        "Actual sell price ($)", min_value=0.0, value=float(round(value, 2)),
        step=100.0, key=f"{P}sell",
        help="What the sale actually brought in. The realized gain is this minus "
             "your cost basis, and can differ from the estimated value above.")
    g = sell - cb
    if g <= 0:
        st.info(_esc(f"At {_money(sell)} this isn't a gain ({_money(sell)} ≤ "
                     f"{_money(cb)} basis) — no taxable income will be recorded. "
                     "Cancel and reopen to record it as a loss instead."))
        return None
    if abs(sell - value) >= 0.005:
        st.caption(_esc(f"Realized gain at this price: **{_money(g)}** "
                        f"({_money(sell)} − {_money(cb)} basis)."))

    # Holding period — inherited property is always long-term (stepped-up basis).
    if is_inherited_account(account_type):
        st.caption("ℹ️ Inherited property is treated as **long-term** regardless of how long "
                   "you held it (stepped-up basis).")
        long_term = True
    else:
        long_term = st.radio(
            "Holding period", [True, False],
            format_func=lambda lt: ("Long-term (held > 1 year)" if lt
                                    else "Short-term (held ≤ 1 year)"),
            key=f"{P}lt", horizontal=True)

    taxable = g
    notes = []

    # Primary residence: Section 121 exclusion (up to $250k single / $500k MFJ) —
    # it requires 2 of the last 5 years of ownership AND use, which a short-term
    # (≤ 1 year) holding can't meet, so the option only appears for long-term.
    if asset_type == "Primary Residence" and long_term:
        if st.checkbox("Primary residence — exclude gain under Section 121", key=f"{P}s121"):
            status = _filing_status()
            limit = 500_000.0 if status == "married_joint" else 250_000.0
            excluded = min(taxable, limit)
            taxable = max(taxable - limit, 0.0)
            notes.append(f"Section 121: {_money(excluded)} excluded "
                         f"(up to {_money(limit)} for {taxes.FILING_LABELS[status]}).")

    # Classify the taxable gain by holding period + asset type.
    if not long_term:
        tax_class = "ordinary_investment"
        notes.append("Short-term gains are taxed at ordinary rates (plus 3.8% NIIT).")
    elif fam == "collectible":
        tax_class = "collectible"
        notes.append("Collectible long-term gains are taxed at up to a 28% rate (plus NIIT).")
    else:
        tax_class = "preferential"
        notes.append("Long-term gains are taxed at preferential 0/15/20% rates (plus NIIT).")
        if fam == "real_estate":
            notes.append("Depreciation taken on a rental is recaptured at up to 25% (not modeled).")

    for n in notes:
        st.caption(_esc("• " + n))

    if taxable <= 0:
        st.success("Entire gain excluded — no taxable income recorded.")
        return None

    st.caption(_esc(f"➕ Records income **{_money(taxable)}** as "
                    f"_{taxes.TAX_CLASS_LABEL[tax_class]}_."))
    return gain_income_row(name, taxable, tax_class)


def _record_loss_widget(row_id, data, loss, sfx):
    """The loss-side mirror of _record_gain_widget: render the 'record realized loss
    as a tax-deductible expense' options inside an asset's delete confirm. Returns the
    expense row dict to insert on delete, or None if nothing should be recorded."""
    P = f"rl_{row_id}{sfx}_"
    l, value, cb = loss["loss"], loss["value"], loss["cost_basis"]
    asset_type, account_type = loss["asset_type"], loss["account_type"]
    fam = asset_family(asset_type)
    name = _s(data, "name", "asset")

    st.markdown(_esc(f"📉 Unrealized loss **{_money(l)}**  ·  {_money(cb)} basis "
                     f"− {_money(value)} value."))

    # A loss on personal-use property is never deductible — the primary residence
    # is the big one (the gain side gets Section 121; the loss side gets nothing).
    if asset_type == "Primary Residence":
        st.caption("• A loss on your primary residence is a personal loss — not "
                   "deductible, so there is nothing to record.")
        return None

    if not st.checkbox("Record this loss as a tax-deductible expense on delete",
                       key=f"{P}on"):
        return None

    # The tracked value is only an estimate of the sale proceeds (even a live quote
    # lags the actual fill, and the sale isn't recorded the instant it happens), so
    # realize the loss against the REAL proceeds the user enters. Defaults to value.
    sell = st.number_input(
        "Actual sell price ($)", min_value=0.0, value=float(round(value, 2)),
        step=100.0, key=f"{P}sell",
        help="What the sale actually brought in. The realized loss is your cost "
             "basis minus this, and can differ from the estimated value above.")
    l = cb - sell
    if l <= 0:
        st.info(_esc(f"At {_money(sell)} this isn't a loss ({_money(sell)} ≥ "
                     f"{_money(cb)} basis) — nothing to record. Cancel and reopen "
                     "to record it as a gain instead."))
        return None
    if abs(sell - value) >= 0.005:
        st.caption(_esc(f"Realized loss at this price: **{_money(l)}** "
                        f"({_money(cb)} basis − {_money(sell)})."))

    # Holding period — inherited property is always long-term (stepped-up basis).
    if is_inherited_account(account_type):
        st.caption("ℹ️ Inherited property is treated as **long-term** regardless of how "
                   "long you held it (stepped-up basis).")
        long_term = True
    else:
        long_term = st.radio(
            "Holding period", [True, False],
            format_func=lambda lt: ("Long-term (held > 1 year)" if lt
                                    else "Short-term (held ≤ 1 year)"),
            key=f"{P}lt", horizontal=True)

    if fam == "collectible":
        st.caption("• Collectible losses are deductible only if the item was held for "
                   "**investment** — a personal-use collectible's loss is not.")
    if fam in ("security", "crypto"):
        st.caption("• Wash-sale rule: the loss is disallowed if you rebuy a "
                   "substantially identical position within 30 days (not modeled).")
    st.caption(_esc("• Capital losses offset capital gains first, then up to $3,000/yr "
                    "of ordinary income ($1,500 married-separate); the excess carries "
                    "over. The itemized-deduction pull on the Taxes page does **not** "
                    "apply these limits, and NJ allows capital losses against capital "
                    "gains only."))

    st.caption(_esc(f"➖ Records a **{_money(l)}** deductible expense under "
                    f"_{INVESTMENT_LOSS_CATEGORY}_."))
    term = "long-term" if long_term else "short-term"
    return loss_expense_row(name, l, term, acat, cb, sell)


def _open_delete_confirm(key):
    """on_click: show a card's inline delete confirmation. Flipping the flag in a callback
    (which runs before the rerun) makes the confirm appear on the FIRST click, and avoids
    an explicit st.rerun() that would close a card shown inside a pop-up dialog."""
    st.session_state[key] = True


def _close_delete_confirm(key):
    """on_click: dismiss a card's inline delete confirmation (first-click, pop-up-safe)."""
    st.session_state.pop(key, None)


def clear_delete_confirms(popup_only=False):
    """Drop lingering inline delete-confirm flags. A confirm opened in a view pop-up
    that was dismissed — or on a page that was navigated away from — would otherwise
    sit in session state and reopen that card straight on the confirmation the next
    time it renders. popup_only limits the sweep to pop-up-suffixed keys."""
    for k in list(st.session_state):
        if k.startswith("_del_") and (k.endswith("_pop") or not popup_only):
            st.session_state.pop(k, None)


def _card_header(label, row_id, table, data):
    """Render the card title row with Edit and Delete, working both on a page and
    inside a pop-up dialog (e.g. the calendar):

      • Edit routes through the cross-dialog queue (request_edit + rerun) — you
        can't open a dialog from within a dialog, so it closes first and the app
        opens the editor on the next run.
      • Delete and Cancel set / clear the confirm flag via on_click callbacks, so the
        flip happens before the rerun and the inline confirm appears (or dismisses) on
        the first click — even inside a pop-up, with no explicit rerun that would close
        it. Only the final 'Yes' reruns."""
    # _kctx() namespaces these keys so a card shown in a view pop-up doesn't collide
    # with the same record's card on the page behind it (linked-record viewing can
    # surface a record that also appears on the current page).
    sfx = _kctx()
    confirm_key = f"_del_{table}_{row_id}{sfx}"
    if st.session_state.get(confirm_key):
        st.warning(f"Delete **{label}**?")
        # An appreciated taxable asset can record its realized gain as income on
        # delete; a depreciated one can record its realized loss as a deductible
        # expense (the mirror).
        gain_income = loss_expense = None
        if table == "assets":
            _gi = _asset_gain_info(data)
            if _gi:
                gain_income = _record_gain_widget(row_id, data, _gi, sfx)
            else:
                _li = _asset_loss_info(data)
                if _li:
                    loss_expense = _record_loss_widget(row_id, data, _li, sfx)
        c1, c2 = st.columns(2)
        if c1.button("Yes, delete", key=f"yes_{confirm_key}", type="primary", width="stretch"):
            if gain_income:
                # One transaction for both: a failure can't leave a phantom gain
                # row behind (or duplicate it when the delete is retried).
                db.delete_row_recording_income(table, row_id, gain_income)
            elif loss_expense:
                db.delete_row_recording_expense(table, row_id, loss_expense)
            else:
                db.delete_row(table, row_id)
            del st.session_state[confirm_key]
            st.rerun()
        c2.button("Cancel", key=f"no_{confirm_key}", width="stretch",
                  on_click=_close_delete_confirm, args=(confirm_key,))
    else:
        hc, ec, dc = st.columns([4.5, 1.2, 0.8])
        hc.markdown(f"**{label}**")
        if ec.button("Edit", key=f"edit_{table}_{row_id}{sfx}", width="stretch"):
            request_edit(table, row_id)
            st.rerun()
        dc.button("🗑", key=f"del_{table}_{row_id}{sfx}", width="stretch",
                  on_click=_open_delete_confirm, args=(confirm_key,))


# ---------------------------------------------------------------------------
# Card renderers
# ---------------------------------------------------------------------------

def _asset_card(row):
    data = row.to_dict()
    row_id     = int(data["id"])
    account    = _s(data, "account_type")
    asset_type = _s(data, "asset_type")
    fam        = asset_family(asset_type)
    name       = _s(data, "name", "Unnamed")
    institution = _s(data, "institution")
    value      = _n(data, "value")
    liquid     = bool(int(_n(data, "liquid")))
    ticker     = _s(data, "ticker")
    shares     = _n(data, "shares") if _s(data, "shares") else None
    last_price = _n(data, "last_price") if _s(data, "last_price") else None
    updated_at = _s(data, "updated_at")

    # Title / subtitle:
    # - a tickered security position → ticker as the title, account type beneath
    # - crypto → coin name, ticker (or account) beneath
    # - cash / pending distribution → account type as the title, institution beneath
    # - held directly (real estate, vehicle, …) → the name, asset type beneath
    is_position = bool(ticker) and is_investment_holding(asset_type)

    if fam == "security":
        title    = ticker if ticker else name
        subtitle = account
    elif fam == "crypto":
        title    = name if name else (ticker or "Crypto")
        subtitle = ticker if (ticker and ticker.upper() != name.upper()) else account
    elif fam == "cash":
        title    = account if account else name
        subtitle = institution             # which bank — otherwise indistinguishable
    else:
        title    = name
        subtitle = asset_type or ""

    with st.container(border=True, key=f"reccard_assets_{row_id}{_kctx()}", gap="xsmall"):
        _card_header(title, row_id, "assets", data)
        if subtitle:
            st.caption(subtitle)
        st.divider()

        _field("Value", _money(value))

        # Holdings (shares/units + live price) — only for tickered positions.
        if is_position:
            if shares is not None:
                units_label = "Units" if fam == "crypto" else "Shares"
                _field(units_label, f"{shares:,.6f}".rstrip("0").rstrip("."))
            if last_price:
                _field("Last Price", _money(last_price))

        # Cost basis / unrealized G/L — for ANY asset that tracks a cost basis
        # (held positions and manually-valued holdings like real estate or
        # collectibles alike), not just ticker positions.
        cost_basis = _n(data, "cost_basis") if _s(data, "cost_basis") else None
        if cost_basis:
            gl = value - cost_basis
            sign = "+" if gl >= 0 else ""
            gl_pct = gl / cost_basis * 100
            _field("Cost Basis", _money(cost_basis))
            _field("Unrealized G/L", f"{sign}{_money(gl)} ({sign}{gl_pct:.1f}%)",
                   color="green" if gl >= 0 else "red")

        # APY on interest-bearing cash accounts, plus when that interest posts.
        apy = _n(data, "apy") if _s(data, "apy") else None
        if fam == "cash" and apy:
            _field("APY", f"{apy * 100:.2f}%")
            _isched = accounts.asset_interest_sched(data)
            _idesc = recurrence.describe(_isched)
            if _idesc:
                _field("Interest paid", _idesc)
            nxt = accounts.next_interest_payout(value, apy, _isched)
            if nxt:
                _field("Next interest", f"{_money(nxt['amount'])} on {fmt_date(nxt['date'])}")

        # Cash: CD/treasury maturity + an APY-projected "balance today".
        if fam == "cash":
            mat = _to_date(_s(data, "maturity_date"))
            if mat:
                d_left = (mat - date.today()).days
                _field("Matures", fmt_date(mat) +
                       (f" (in {d_left}d)" if d_left >= 0 else " (matured)"))
            if apy and value:
                age = days_since(_s(data, "updated_at"))
                if age and age > 0:
                    projected = value * (1 + apy) ** (age / 365.0)
                    _field("Est. today", f"{_money(projected)} · APY-projected")

        # Business: ownership stake (value is the whole business; your stake is
        # value × ownership and is what counts toward net worth).
        if fam == "business":
            op = _n(data, "ownership_pct") if _s(data, "ownership_pct") else None
            if op:
                _field("Ownership", f"{op * 100:g}%")
                if op < 1:
                    _field("Your stake", _money(value * op))

        # Receivable: who owes, when, collection likelihood + risk-adjusted value.
        if fam == "receivable":
            if institution:
                _field("Owed by", institution)
            cdt = _to_date(_s(data, "collection_date"))
            if cdt:
                d_left = (cdt - date.today()).days
                _field("Expected", fmt_date(cdt) +
                       (f" (in {d_left}d)" if d_left >= 0 else f" ({-d_left}d overdue)"))
            prob = _n(data, "collection_prob") if _s(data, "collection_prob") else None
            if prob is not None and prob < 1.0:
                _field("Likelihood", f"{int(prob * 100)}%")
                _field("Risk-adjusted", _money(value * prob), color="red")
            rapy = _n(data, "apy") if _s(data, "apy") else None
            if rapy:
                _field("Interest", f"{rapy * 100:.2f}% APR")

        mileage = _n(data, "mileage") if _s(data, "mileage") else None
        vin = _s(data, "vin")
        addr = format_address(_s(data, "street"), _s(data, "city"),
                              _s(data, "state"), _s(data, "zip_code"))
        if fam == "vehicle":
            tr, cond = _s(data, "trim"), _s(data, "condition")
            if tr:
                _field("Trim", tr)
            if mileage:
                _field("Mileage", f"{int(mileage):,} mi")
            if cond:
                _field("Condition", cond)
            if vin:
                _field("VIN", vin)
        elif fam == "real_estate":
            if addr and addr != name:
                _field("Address", addr)
            beds, baths, sqft = _n(data, "beds"), _n(data, "baths"), _n(data, "sqft")
            specs = []
            if beds:
                specs.append(f"{beds:g} bd")
            if baths:
                specs.append(f"{baths:g} ba")
            if sqft:
                specs.append(f"{int(sqft):,} sqft")
            if specs:
                _field("Details", " · ".join(specs))
            year_built = _n(data, "year_built")
            if year_built:
                _field("Year built", str(int(year_built)))

        # Derived equity: your stake (value × ownership %) minus linked loans.
        if fam in ("real_estate", "vehicle", "business"):
            loan_total = sum(_n(d, "balance") for d in _linked_records("assets", row_id, "debts"))
            if loan_total > 0:
                own = _n(data, "ownership_pct") if _s(data, "ownership_pct") else 1.0
                eq = value * own - loan_total
                basis = (f"{own * 100:g}% of {_money(value)} − {_money(loan_total)} loan"
                         if own < 1 else f"after {_money(loan_total)} loan")
                _field("Equity", f"{_money(eq)} · {basis}",
                       color="green" if eq >= 0 else "red")

        _field("Liquid", "✓ Yes" if liquid else "✗ No")

        if fam == "vehicle":
            _mk, _md = _s(data, "make"), _s(data, "model")
            _yr = str(int(_n(data, "model_year"))) if _s(data, "model_year") else ""
            if not (_mk and _md and _yr):
                p_yr, p_mk, p_md = parse_vehicle_name(name)
                _mk, _md, _yr = _mk or p_mk, _md or p_md, _yr or p_yr
            st.caption(f"[🔗 Look up this vehicle's value ↗]({vehicle_value_url(_mk, _md, _yr, asset_type)})")
        elif fam == "real_estate" and addr:
            # Only a real street address gives a useful Zestimate (a REIT / fund
            # has no address, so no link).
            st.caption(f"[🔗 Zestimate on Zillow ↗]({zillow_search_url(addr)})")
        elif fam == "crypto":
            st.caption(f"[🔗 Price on CoinGecko ↗]({coingecko_url(name or ticker)})")

        # Stale-value nudge for manually-tracked assets (tickered positions
        # re-price automatically, so skip those).
        if not ticker:
            age = days_since(updated_at)
            if age is not None and age >= STALE_DAYS:
                st.caption(f":orange[⚠️ Value may be stale — last set {age} days ago.]")

        _linked_links("assets", row_id)
        _updated(data)


def _debt_card(row):
    data = row.to_dict()
    row_id = int(data["id"])
    name = _s(data, "name", "Unnamed")
    balance = _n(data, "balance")
    apr = _n(data, "apr")
    min_payment = _n(data, "min_payment")
    mp_type = _s(data, "min_payment_type") or "fixed"
    mp_pct = _n(data, "min_payment_pct")
    credit_limit = _n(data, "credit_limit") if _s(data, "credit_limit") else None
    eff_min = stats.min_payment_due(balance, mp_type, mp_pct, min_payment, apr=apr)
    is_margin = _s(data, "type") == stats.MARGIN_DEBT_TYPE
    apr_formula = _s(data, "apr_formula")
    margin_account = _s(data, "margin_account")
    lender = _s(data, "lender")
    orig_balance = _n(data, "original_balance") if _s(data, "original_balance") else None
    months_rem = int(_n(data, "months_remaining")) if _s(data, "months_remaining") else None

    with st.container(border=True, key=f"reccard_debts_{row_id}{_kctx()}", gap="xsmall"):
        _card_header(name, row_id, "debts", data)
        if lender:
            st.caption(lender)
        st.divider()

        _field("Balance", _money(balance))
        _field("APR", _pct(apr))
        if is_margin:
            if apr_formula:
                # md_escape the formula so its underscores/operators render LITERALLY.
                # (Neither a :gray[…] directive nor backticks reliably protect it —
                # see utils.md_escape.)
                st.caption(f"APR formula: {md_escape(apr_formula)} "
                           "(over the economic variables)")
                # A formula that stopped evaluating (e.g. restored from an old
                # backup) freezes the APR at its last good value — say so instead
                # of letting the card look healthy.
                try:
                    safe_eval_formula(apr_formula, db.economic_variables())
                except ValueError as exc:
                    st.caption(":red[⚠️ " + md_escape(
                        f"The formula no longer evaluates ({exc}) — the APR shown "
                        "is its last good value. Fix it in Edit.") + "]")
            if margin_account:
                _field("Borrowed against", margin_account)
                # The label is a plain copy of a DERIVED account name — if no
                # account matches anymore (renamed / emptied), the loan isn't
                # netted from any account's equity; don't let that stay silent.
                _labels = {a["label"]
                           for a in stats.investment_accounts(db.load_df("assets"))}
                if margin_account not in _labels:
                    st.caption(":red[⚠️ No investment account matches this label "
                               "anymore — the loan isn't netted from any account's "
                               "equity. Re-link it in Edit.]")
            st.caption(":orange[Margin loan — counts as negative liquidity.]")
        if credit_limit:
            _field("Credit limit", _money(credit_limit))
            util = balance / credit_limit * 100
            over = balance > credit_limit
            _field("Utilization", f"{util:.0f}%", color=utilization_color(util))
            if over:
                st.caption(":red[⚠️ Over the credit limit.]")
        if eff_min > 0:
            if mp_type == "percent":
                _field("Min Payment", f"${eff_min:,.2f} ({mp_pct * 100:.1f}% of balance)")
            elif mp_type == "percent_floor":
                _field("Min Payment",
                       f"${eff_min:,.2f} ({mp_pct * 100:.1f}%, ≥ ${min_payment:,.0f})")
            elif mp_type == "percent_interest":
                _field("Min Payment",
                       f"${eff_min:,.2f} ({mp_pct * 100:.1f}% + interest)")
            elif mp_type == "percent_interest_floor":
                _field("Min Payment",
                       f"${eff_min:,.2f} ({mp_pct * 100:.1f}% + interest, ≥ ${min_payment:,.0f})")
            else:
                _field("Min Payment", f"${eff_min:,.2f} / mo")
        if orig_balance and orig_balance > balance:
            paid_pct = (orig_balance - balance) / orig_balance * 100
            _field("Paid Off", f"{paid_pct:.1f}%")
        if months_rem:
            _field("Remaining", f"{months_rem} months")

        stmt_desc = recurrence.describe(accounts.statement_sched(data))
        if stmt_desc:
            _field("Statement", f"Closes {stmt_desc}")
        due_day = int(_n(data, "due_day")) if _s(data, "due_day") else None
        if due_day:
            _field("Due", f"{_ordinal(due_day)} of month")

        if balance > 0 and eff_min > 0:
            mos, interest = stats.months_to_payoff(balance, apr, mp_type, mp_pct, min_payment)
            if mos is None:
                st.caption(":orange[Never pays off at the minimum payment]")
            elif apr > 0:
                st.caption(f"Payoff in ~{mos} mo · ${interest:,.0f} interest")
            else:
                st.caption(f"Payoff in ~{mos} mo (0% interest)")

        _linked_links("debts", row_id)
        _updated(data)


def _income_card(row):
    data = row.to_dict()
    row_id = int(data["id"])
    source = _s(data, "source", "Unknown")
    amount = _n(data, "amount")
    received = _n(data, "received_ytd")
    remaining = max(0.0, amount - received)
    income_type = _s(data, "type")
    type_label = (INCOME_TYPE_LABEL.get(income_type, income_type.replace("_", " ").title())
                  if income_type else "")
    frequency = _s(data, "frequency")

    with st.container(border=True, key=f"reccard_income_{row_id}{_kctx()}", gap="xsmall"):
        _card_header(source, row_id, "income", data)
        label_parts = [p for p in [type_label, frequency] if p]
        if label_parts:
            st.caption(" · ".join(label_parts))
        st.divider()

        _field("Annual (expected)", _money(amount))
        # Money already in hand is a data point on the stream, not a separate
        # record — so the schedule below only ever projects this one stream forward.
        _field("Received Year-to-Date", _money(received))
        _field("Still expected", _money(remaining),
               color="green" if remaining > 0 else None)
        pay_amount = _n(data, "pay_amount") if _s(data, "pay_amount") else None
        if pay_amount:
            _field("Per occurrence", _money(pay_amount))
        pay_day = _s(data, "pay_day")
        if pay_day:
            _field("Schedule", pay_day)
        tax_class = _s(data, "tax_class") or taxes.default_tax_class(income_type)
        _field("Tax treatment", taxes.TAX_CLASS_LABEL.get(tax_class, tax_class))

        if bool(int(_n(data, "auto_deposit"))):
            deposit_target = _s(data, "deposit_target")
            _field("Auto-deposit", f"✓ {deposit_target}" if deposit_target else "✓ Yes")

        _linked_links("income", row_id)
        _updated(data)


def _expense_card(row):
    data = row.to_dict()
    row_id = int(data["id"])
    category = _s(data, "category", "Unknown")
    subcategory = _s(data, "subcategory")
    amount = _n(data, "amount")
    sched = recurrence.from_row(data)
    occ = recurrence.occurrences_per_year(sched)
    freq_label = _s(data, "frequency") or recurrence.frequency_label(sched.get("type"))
    variable = stats.is_variable(data)
    annual = stats.expense_annual_amount(data)

    with st.container(border=True, key=f"reccard_expenses_{row_id}{_kctx()}", gap="xsmall"):
        _card_header(category, row_id, "expenses", data)
        if subcategory:
            st.caption(subcategory)
        # A credit-card-minimum expense mirrors its card's debt record (amount,
        # schedule, and name re-derive on every card edit and at statement close).
        _ccid = _n(data, "cc_min_debt_id")
        if _ccid > 0:
            _cdf = db.load_df("debts")
            _cm = _cdf[_cdf["id"] == int(_ccid)] if not _cdf.empty else _cdf
            _crow = _cm.iloc[0].to_dict() if not _cm.empty else {}
            if _s(_crow, "type") == "revolving":
                st.caption(f"🔗 Synced from **{_s(_crow, 'name') or 'Card'}** — "
                           "follows the card's minimum and due day")
            else:
                st.caption(":orange[🔗 The linked credit card is gone — this "
                           "expense no longer syncs.]")
        st.divider()

        if variable:
            obs = stats.parse_variable_amounts(data)
            method = {"by_period": "by period", "seasonal": "seasonal average"}.get(
                _s(data, "variable_method"), "average")
            # Don't overstate the history: a schedule younger than the requested
            # window records fewer occurrences than variable_years implies.
            yrs = stats.variable_years_of(data)
            if occ > 0:
                yrs = min(yrs, max(1, int(round(len(obs) / occ))))
            _field("Amount", f"Variable · {len(obs)} recorded over "
                             f"{yrs} year{'s' if yrs > 1 else ''} · "
                             f"projected by {method}")
            if obs:
                _field("Avg / occurrence", _money(sum(obs.values()) / len(obs)))
        else:
            _field("Amount", f"${amount:,.2f} / occurrence")
        if annual:
            _field("Annual", _money(annual))
            _field("Monthly equiv.", _money(annual / 12))
        # Schedule summary (e.g. "1st of the month", "Every other Friday", "15th of
        # Mar, Sep") — the human description the calendar/auto-draft place it by.
        desc = _s(data, "pay_day") or recurrence.describe(sched)
        if desc:
            _field("Schedule", f"{freq_label} · {desc}" if freq_label else desc)
        elif freq_label:
            _field("Schedule", freq_label)
        auto_draft = bool(int(_n(data, "auto_draft")))
        draft_source = _s(data, "draft_source")
        if auto_draft:
            _field("Auto-draft", f"✓ {draft_source}" if draft_source else "✓ Yes")

        # Tax-deductible details (shown only when the expense is flagged deductible).
        if bool(int(_n(data, "deductible"))):
            ded_ytd = _n(data, "deductible_ytd")
            ded_exp = _n(data, "deductible_expected")
            scope = [s for s, on in (("Federal", bool(int(_n(data, "deduct_federal", 1)))),
                                     ("State", bool(int(_n(data, "deduct_state", 1))))) if on]
            notes = _s(data, "deduction_notes")
            st.caption("🧾 **Tax-deductible**"
                       + (f" · {_s(data, 'deduction_category')}" if _s(data, "deduction_category") else ""))
            _field("Deductible Year-to-Date", _money(ded_ytd), color="green" if ded_ytd else None)
            _field("Deductible expected", _money(ded_exp))
            _field("Deduction total", _money(ded_ytd + ded_exp))
            _field("Applies to", " + ".join(scope) if scope else "—")
            if notes:
                _field("Notes", notes)

        _linked_links("expenses", row_id)
        _updated(data)


def _on_view_popup_dismiss():
    """on_dismiss for the record pop-up: drop any delete-confirm opened inside it,
    so reopening the record doesn't land straight on the confirmation."""
    clear_delete_confirms(popup_only=True)


@st.dialog("Record", width="large", on_dismiss=_on_view_popup_dismiss)
def view_record(table, row_id):
    """Pop-up showing a record's card (exactly as it appears on its page) with
    working Edit/Delete and clickable linked records — used by the calendar's
    clickable items and by the linked-record links on every card. Edit closes this
    pop-up and opens the editor via the cross-dialog queue (Streamlit does not allow
    opening a dialog from within a dialog); clicking a linked record swaps this
    pop-up for that record's (request_view + rerun) rather than layering a new one.

    _in_view_popup is set while the card renders (which happens before the page
    draws) so its widget keys are namespaced apart from the same card on the page."""
    st.session_state["_in_view_popup"] = True
    try:
        df = db.load_df(table)
        match = df[df["id"] == int(row_id)] if not df.empty else df
        if match.empty:
            st.error("This record no longer exists.")
            return
        renderer = {"assets": _asset_card, "debts": _debt_card,
                    "income": _income_card, "expenses": _expense_card}.get(table)
        if renderer:
            renderer(match.iloc[0])
        else:
            st.error("Unknown record type.")
    finally:
        st.session_state["_in_view_popup"] = False


# ---------------------------------------------------------------------------
# Grouped page renderers
# ---------------------------------------------------------------------------

def _group_header(title, total_label, total_value):
    c1, c2 = st.columns([3, 1])
    c1.subheader(title)
    c2.metric(total_label, total_value)


def _search_filter(df, table, key, noun, placeholder, slot=None):
    """Render a per-page search box and return `df` narrowed to rows that match
    the query by name OR granular type (see search_text) — same behaviour as the
    Data Management records search. Returns the full df when the box is empty;
    when a query matches nothing it shows a caption and returns an empty df, so
    the metrics and cards below reflect only what's shown. `slot` (a column from
    the page's top button row) renders the box inline with those buttons instead
    of in the flow; the no-match caption stays in the flow either way."""
    with (slot if slot is not None else st.container()):
        query = ui.search_box(f"Search {noun}", key=key, placeholder=placeholder)
    if not query:
        return df
    mask = [query in search_text(table, r.to_dict()) for _, r in df.iterrows()]
    out = df[mask]
    if out.empty:
        st.caption(f"No {noun} match “{query}”.")
    return out


def asset_cards(search_slot=None):
    df = db.load_df("assets")
    if df.empty:
        st.info("No assets yet. Click **+ Add Asset** above to get started.")
        return
    df = _search_filter(df, "assets", "assets_search", "assets",
                        "Search by name or type — e.g. brokerage, checking",
                        slot=search_slot)
    if df.empty:
        return

    grand_total = sum(_effective_value(r.to_dict()) for _, r in df.iterrows())
    st.metric("Total Assets", _money(grand_total))
    st.write("")

    # Split rows into investment vs all other sections
    inv_rows: list = []
    other_sections: dict[str, list] = {}

    for _, row in df.iterrows():
        data = row.to_dict()
        asset_type = _s(data, "asset_type")
        # A pending estate/trust distribution is really money owed to you, not a
        # holding — group it with receivables, not the investment accounts.
        if is_distribution(_s(data, "account_type")):
            other_sections.setdefault("Receivables", []).append(row)
        elif is_investment_holding(asset_type):
            inv_rows.append(row)
        else:
            section = ASSET_SECTION_LABEL.get(asset_family(asset_type), "Other Assets")
            other_sections.setdefault(section, []).append(row)

    # ── Investment Accounts (two-level: section → account subheader → cards) ─
    if inv_rows:
        inv_total = sum(_effective_value(r.to_dict()) for r in inv_rows)
        _group_header("Investment Accounts", "Total", _money(inv_total))

        # Group by account/institution key
        account_groups: dict[str, list] = {}
        for row in inv_rows:
            key = _investment_account_key(row.to_dict())
            account_groups.setdefault(key, []).append(row)

        for acct_name in sorted(account_groups.keys()):
            acct_rows = account_groups[acct_name]
            acct_total = sum(_effective_value(r.to_dict()) for r in acct_rows)

            sc1, sc2 = st.columns([3, 1])
            sc1.markdown(f"##### {acct_name}")
            sc2.caption(_money(acct_total))

            cols = st.columns(2)
            for i, row in enumerate(
                sorted(acct_rows, key=lambda r: _effective_value(r.to_dict()), reverse=True)
            ):
                with cols[i % 2]:
                    _asset_card(row)
            st.write("")

        st.write("")

    # ── Non-investment sections (single-level) ────────────────────────────────
    all_sections = ASSET_SECTION_ORDER + [s for s in other_sections if s not in ASSET_SECTION_ORDER]
    for section_name in all_sections:
        rows = other_sections.get(section_name)
        if not rows:
            continue
        total = sum(_effective_value(r.to_dict()) for r in rows)
        _group_header(section_name, "Total", _money(total))
        cols = st.columns(2)
        for i, row in enumerate(
            sorted(rows, key=lambda r: _effective_value(r.to_dict()), reverse=True)
        ):
            with cols[i % 2]:
                _asset_card(row)
        st.write("")


def debt_cards(search_slot=None):
    df = db.load_df("debts")
    if df.empty:
        st.info("No debts yet. Click **+ Add Debt** above to get started.")
        return
    df = _search_filter(df, "debts", "debts_search", "debts",
                        "Search by name or type — e.g. mortgage, visa",
                        slot=search_slot)
    if df.empty:
        return

    groups: dict[str, list] = {}
    for _, row in df.iterrows():
        label = DEBT_TYPE_LABEL.get(_s(row.to_dict(), "type", "other"), "Other Debts")
        groups.setdefault(label, []).append(row)

    grand_total = float(df["balance"].sum())
    st.metric("Total Debt", _money(grand_total))
    st.write("")

    # Any group label missing from the order list still renders (appended at the
    # end) instead of silently vanishing — a DEBT_TYPE_LABEL entry without a
    # matching DEBT_GROUP_ORDER entry hid the margin cards once already.
    _extra = sorted(g for g in groups if g not in DEBT_GROUP_ORDER)
    for group_name in DEBT_GROUP_ORDER + _extra:
        rows = groups.get(group_name)
        if not rows:
            continue
        total = sum(_n(r.to_dict(), "balance") for r in rows)
        _group_header(group_name, "Group Balance", _money(total))
        cols = st.columns(2)
        for i, row in enumerate(sorted(rows, key=lambda r: _n(r.to_dict(), "balance"), reverse=True)):
            with cols[i % 2]:
                _debt_card(row)
        st.write("")


def income_cards(search_slot=None):
    df = db.load_df("income")
    if df.empty:
        st.info("No income yet. Click **+ Add Income** above to get started.")
        return
    df = _search_filter(df, "income", "income_search", "income",
                        "Search by source or type — e.g. rental, salary",
                        slot=search_slot)
    if df.empty:
        return

    # One row per stream now (no ytd/expected split): YTD realised and what's still
    # expected are derived per stream from amount vs received_ytd.
    annual_total = sum(_n(r.to_dict(), "amount") for _, r in df.iterrows())
    ytd_total = sum(_n(r.to_dict(), "received_ytd") for _, r in df.iterrows())
    exp_total = sum(max(0.0, _n(r.to_dict(), "amount") - _n(r.to_dict(), "received_ytd"))
                    for _, r in df.iterrows())

    c1, c2, c3 = st.columns(3)
    c1.metric("Received Year-to-Date", _money(ytd_total))
    c2.metric("Still expected (rest of year)", _money(exp_total))
    c3.metric("Projected EOY Total", _money(annual_total))
    st.write("")

    # Group streams by income type so each subheader is scoped (Employment,
    # Investment income, Rental…), mirroring the Debts and Expenses pages.
    groups: dict[str, list] = {}
    for _, row in df.iterrows():
        itype = _s(row.to_dict(), "type", "other") or "other"
        label = INCOME_TYPE_LABEL.get(itype, INCOME_TYPE_LABEL["other"])
        groups.setdefault(label, []).append(row)

    ordered = [INCOME_TYPE_LABEL[t] for t in INCOME_TYPE_ORDER]
    all_group_names = ordered + [g for g in groups if g not in ordered]

    for group_name in all_group_names:
        rows = groups.get(group_name)
        if not rows:
            continue
        group_annual = sum(_n(r.to_dict(), "amount") for r in rows)
        _group_header(group_name, "Annual", _money(group_annual))
        cols = st.columns(2)
        for i, row in enumerate(sorted(rows, key=lambda r: _n(r.to_dict(), "amount"), reverse=True)):
            with cols[i % 2]:
                _income_card(row)
        st.write("")


def expense_cards(search_slot=None):
    df = db.load_df("expenses")
    if df.empty:
        st.info("No expenses yet. Click **+ Add Expense** above to get started.")
        return
    df = _search_filter(df, "expenses", "expenses_search", "expenses",
                        "Search by category or name — e.g. housing, rent",
                        slot=search_slot)
    if df.empty:
        return

    def monthly_equiv(row_data):
        return stats.expense_annual_amount(row_data) / 12.0     # set or variable

    groups: dict[str, list] = {}
    # Group by the exact category name (case-insensitively) only. The old
    # first-word prefix match folded custom categories into unrelated groups —
    # "Investment property upkeep" was headed "Investment Losses", "Personal
    # training" became "Personal & Family". Unknown categories now get their
    # own group header (appended after the known ones below).
    _known = {g.lower(): g for g in EXPENSE_GROUP_ORDER}
    for _, row in df.iterrows():
        label = _s(row.to_dict(), "category", "Other")
        label = _known.get(label.strip().lower(), label)
        groups.setdefault(label, []).append(row)

    total_monthly = sum(monthly_equiv(r.to_dict()) for _, r in df.iterrows())
    c1, c2 = st.columns(2)
    c1.metric("Monthly Recurring", _money(total_monthly))
    c2.metric("Annual Recurring", _money(total_monthly * 12))
    st.write("")

    all_group_names = EXPENSE_GROUP_ORDER + [g for g in groups if g not in EXPENSE_GROUP_ORDER]

    for group_name in all_group_names:
        rows = groups.get(group_name)
        if not rows:
            continue
        group_monthly = sum(monthly_equiv(r.to_dict()) for r in rows)
        _group_header(group_name, "Monthly", _money(group_monthly))
        cols = st.columns(2)
        for i, row in enumerate(sorted(rows, key=lambda r: monthly_equiv(r.to_dict()), reverse=True)):
            with cols[i % 2]:
                _expense_card(row)
        st.write("")


