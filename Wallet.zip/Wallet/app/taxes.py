"""
taxes.py — federal and New Jersey income tax bracket reference data + the pure
math for applying it.

Like stats.py, everything here is pure: bracket tables in, a number or a list
of display rows out. No database, no Streamlit. Brackets are statutory values
for the tax year named in TAX_YEAR — update them when the IRS / NJ Division of
Taxation publish new figures.

A bracket table is a list of (lower_bound, upper_bound, rate) tuples, ordered
from lowest income to highest. `upper_bound` is None for the top bracket
(everything above `lower_bound`). Rates are decimals (0.22 == 22%).
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

if TYPE_CHECKING:                     # pandas is only needed for type hints --
    import pandas as pd               # this module stays pandas-free at runtime


TAX_YEAR = 2026

# Filing statuses used as keys throughout.
FILING_STATUSES = ["single", "married_joint", "married_separate", "head_of_household"]

FILING_LABELS = {
    "single":            "Single",
    "married_joint":     "Married filing jointly",
    "married_separate":  "Married filing separately",
    "head_of_household": "Head of household",
}


# ---------------------------------------------------------------------------
# Federal income tax brackets — tax year 2026 (IRS Rev. Proc. 2025-32).
# TCJA rates (10–37%) were made permanent by the 2025 OBBBA; these are the
# 2026 inflation-adjusted thresholds.
# ---------------------------------------------------------------------------

FEDERAL_BRACKETS = {
    "single": [
        (0,        12400,   0.10),
        (12400,    50400,   0.12),
        (50400,    105700,  0.22),
        (105700,   201775,  0.24),
        (201775,   256225,  0.32),
        (256225,   640600,  0.35),
        (640600,   None,    0.37),
    ],
    "married_joint": [
        (0,        24800,   0.10),
        (24800,    100800,  0.12),
        (100800,   211400,  0.22),
        (211400,   403550,  0.24),
        (403550,   512450,  0.32),
        (512450,   768700,  0.35),
        (768700,   None,    0.37),
    ],
    "married_separate": [
        (0,        12400,   0.10),
        (12400,    50400,   0.12),
        (50400,    105700,  0.22),
        (105700,   201775,  0.24),
        (201775,   256225,  0.32),
        (256225,   384350,  0.35),
        (384350,   None,    0.37),
    ],
    "head_of_household": [
        (0,        17700,   0.10),
        (17700,    67450,   0.12),
        (67450,    105700,  0.22),
        (105700,   201775,  0.24),
        (201775,   256200,  0.32),
        (256200,   640600,  0.35),
        (640600,   None,    0.37),
    ],
}

# Federal standard deduction — tax year 2026 (Rev. Proc. 2025-32). Used to turn
# gross income into federal taxable income; editable in the UI for itemizers.
STANDARD_DEDUCTION = {
    "single":            16100,
    "married_joint":     32200,
    "married_separate":  16100,
    "head_of_household": 24150,
}


# ---------------------------------------------------------------------------
# New Jersey income tax brackets (NJ Division of Taxation). NJ does NOT
# inflation-index its brackets — these are statutory and unchanged for 2026
# (the 10.75% top rate on income over $1M has applied since 2020).
#   Schedule A: Single, Married/CU partner filing separately
#   Schedule B: Married/CU couple filing jointly, Head of household, Surviving
#               spouse
# ---------------------------------------------------------------------------

_NJ_SCHEDULE_A = [
    (0,         20000,    0.014),
    (20000,     35000,    0.0175),
    (35000,     40000,    0.035),
    (40000,     75000,    0.05525),
    (75000,     500000,   0.0637),
    (500000,    1000000,  0.0897),
    (1000000,   None,     0.1075),
]

_NJ_SCHEDULE_B = [
    (0,         20000,    0.014),
    (20000,     50000,    0.0175),
    (50000,     70000,    0.0245),
    (70000,     80000,    0.035),
    (80000,     150000,   0.05525),
    (150000,    500000,   0.0637),
    (500000,    1000000,  0.0897),
    (1000000,   None,     0.1075),
]

NJ_BRACKETS = {
    "single":            _NJ_SCHEDULE_A,
    "married_separate":  _NJ_SCHEDULE_A,
    "married_joint":     _NJ_SCHEDULE_B,
    "head_of_household": _NJ_SCHEDULE_B,
}

NJ_SCHEDULE_LABEL = {
    "single":            "Schedule A (Single / MFS)",
    "married_separate":  "Schedule A (Single / MFS)",
    "married_joint":     "Schedule B (MFJ / HoH)",
    "head_of_household": "Schedule B (MFJ / HoH)",
}

# New Jersey: no income tax at or below the filing threshold, plus the
# $1,000-per-person personal exemption (statutory).
NJ_FILING_THRESHOLD = {
    "single": 10_000, "married_separate": 10_000,
    "married_joint": 20_000, "head_of_household": 20_000,
}
NJ_PERSONAL_EXEMPTION = 1_000


def nj_default_deduction(status: str) -> float:
    """Default NJ deduction when the user hasn't entered one: the regular
    personal exemption is $1,000 PER PERSON, so a joint return gets $2,000
    (taxpayer + spouse); every other status gets $1,000."""
    return float(NJ_PERSONAL_EXEMPTION) * (2.0 if status == "married_joint" else 1.0)


# ---------------------------------------------------------------------------
# Income classification + extra federal tax for someone LIVING OFF INVESTMENTS
# (an investor / trader with no self-employment earnings).
#
#   • Investment & trading gains are capital gains: short-term holdings are
#     taxed at ORDINARY rates, long-term gains & qualified dividends at the
#     preferential 0/15/20% rates. They are NOT earned income, so there is no
#     Social Security / Medicare / self-employment tax on them.
#   • NIIT (3.8%) applies to net investment income above a statutory,
#     non-inflation-indexed MAGI threshold.
#   • New Jersey taxes all income at its ordinary brackets (no preferential
#     capital-gains rate, no NIIT).
# ---------------------------------------------------------------------------

# Net Investment Income Tax — 3.8% on net investment income above the MAGI
# threshold (statutory, not inflation-indexed).
NIIT_RATE = 0.038
NIIT_THRESHOLD = {
    "single": 200_000, "married_joint": 250_000,
    "married_separate": 125_000, "head_of_household": 200_000,
}

# Long-term capital gains / qualified dividends — 2026 breakpoints (estimated;
# update annually). Each entry is (upper_taxable_income, rate); the gains stack
# on top of ordinary taxable income to land in the 0% / 15% / 20% bands.
LTCG_BRACKETS = {
    "single":            [(49_450, 0.0), (545_500, 0.15), (None, 0.20)],
    "married_joint":     [(98_900, 0.0), (613_700, 0.15), (None, 0.20)],
    "married_separate":  [(49_450, 0.0), (306_850, 0.15), (None, 0.20)],
    "head_of_household": [(66_200, 0.0), (579_600, 0.15), (None, 0.20)],
}

# Tax treatment a user assigns to each income row (the dropdown on the income
# form). How each bucket is taxed in `estimate`:
#   ordinary             — wages / rent / pension / etc.: ordinary rates, no NIIT
#   ordinary_investment  — interest / short-term gains / non-qualified dividends:
#                          ordinary rates AND net investment income (NIIT applies)
#   preferential         — long-term capital gains / qualified dividends: 0/15/20%
#                          preferential rates AND net investment income (NIIT)
#   excluded             — gifts / inheritance: not taxable
TAX_CLASS_OPTIONS = ["ordinary", "ordinary_investment", "preferential",
                     "collectible", "excluded"]

TAX_CLASS_LABEL = {
    "ordinary":            "Ordinary income (wages, rent, etc.)",
    "ordinary_investment": "Interest / short-term gains / ordinary dividends",
    "preferential":        "Long-term gains / qualified dividends",
    "collectible":         "Collectible long-term gain (28% max rate)",
    "excluded":            "Not taxable (gift, inheritance)",
}

# Maximum federal rate on long-term gains from collectibles (art, coins, etc.).
COLLECTIBLE_MAX_RATE = 0.28

# Default tax class derived from an income row's `type` — used to seed the dropdown
# and backfill rows that predate it. `capital` defaults to ordinary investment
# income (no preferential benefit until the user marks it long-term/qualified).
DEFAULT_TAX_CLASS = {
    "wages": "ordinary", "self_employment": "ordinary", "gig": "ordinary",
    "rental": "ordinary", "royalties": "ordinary", "pension": "ordinary",
    "benefits": "ordinary", "other": "ordinary",
    "capital": "ordinary_investment",
    "gift": "excluded",
}


def default_tax_class(income_type: str | None) -> str:
    """Tax class to assume for an income row with the given `type`."""
    return DEFAULT_TAX_CLASS.get(str(income_type or "other").strip().lower(), "ordinary")


# ---------------------------------------------------------------------------
# Math
# ---------------------------------------------------------------------------

def progressive_tax(taxable_income: float,
                    brackets: list[tuple[float | None, float]]) -> float:
    """Total tax owed on `taxable_income` under a progressive bracket table."""
    income = max(float(taxable_income), 0.0)
    tax = 0.0
    for lower, upper, rate in brackets:
        if income <= lower:
            break
        top = income if upper is None else min(income, upper)
        tax += (top - lower) * rate
    return tax


# ---------------------------------------------------------------------------
# Income categorization + the full federal/NJ estimate for an investor
# ---------------------------------------------------------------------------

def categorize_income(income_df: pd.DataFrame | None,
                      basis: str = "fy") -> dict[str, float]:
    """Sum income into tax buckets using each row's `tax_class` (the dropdown on the
    income form), falling back to a default derived from `type` for rows that predate
    it. `basis` selects the dollar figure: 'ytd' uses `received_ytd` (realised so far),
    'fy' (default) uses `amount` (full-year expected). Buckets: ordinary,
    ordinary_investment, preferential, collectible, excluded."""
    buckets = {"ordinary": 0.0, "ordinary_investment": 0.0,
               "preferential": 0.0, "collectible": 0.0, "excluded": 0.0}
    if income_df is None or getattr(income_df, "empty", True):
        return buckets
    col = "received_ytd" if basis == "ytd" else "amount"
    for _, row in income_df.iterrows():
        tc = str(row.get("tax_class") or "").strip()
        if tc not in buckets:
            tc = default_tax_class(row.get("type"))
        try:
            v = float(row.get(col) or 0.0)
        except (TypeError, ValueError):
            continue
        if v == v:                # NaN is truthy, so `or 0.0` doesn't catch it —
            buckets[tc] += v      # one NaN row would poison every bucket, the
    return buckets                # whole estimate, and snapshot capture


def ltcg_tax(long_term_gains: float, ordinary_taxable: float,
             brackets: list[tuple[float | None, float]]) -> float:
    """Tax on long-term gains / qualified dividends, stacked on top of ordinary
    taxable income to determine which 0/15/20% bands they fall in."""
    gains = max(float(long_term_gains), 0.0)
    start = max(float(ordinary_taxable), 0.0)
    end = start + gains
    tax = 0.0
    prev = 0.0
    for upper, rate in brackets:
        top = end if upper is None else min(end, upper)
        bot = max(start, prev)
        if top > bot:
            tax += (top - bot) * rate
        if upper is None:
            break
        prev = upper
        if end <= upper:
            break
    return tax


# Net capital losses can offset at most this much ordinary income per year
# (IRC §1211(b)): $3,000 — halved to $1,500 for married filing separately. The
# excess carries over to later years, which this estimator does not model.
CAPITAL_LOSS_LIMIT = {
    "single": 3_000.0, "married_joint": 3_000.0,
    "married_separate": 1_500.0, "head_of_household": 3_000.0,
}


def net_capital_losses(buckets: dict[str, float], status: str = "single",
                       ordinary_offset: bool = True) -> dict[str, float]:
    """Net negative investment buckets (capital losses) against gains, returning a
    new buckets dict with no negative investment values.

    Losses absorb the highest-taxed gains first, mirroring the IRS netting order:
    long-term losses offset collectible (28%-group) gains, then preferential, then
    short-term; short-term losses offset collectible, then preferential. Any
    remaining net loss then offsets ordinary income up to the §1211(b) limit for
    `status` ($3,000; $1,500 married-separate) — unless `ordinary_offset` is
    False, which models New Jersey's rule: capital losses net only against
    capital gains, never against wages/interest, with no carryover. Other
    approximations: the ordinary_investment bucket mixes interest with
    short-term gains (a negative bucket is treated as a net short-term loss),
    and loss carryovers to other years aren't modeled — excess loss beyond the
    limit is simply dropped."""
    out = dict(buckets)
    st_g = float(out.get("ordinary_investment", 0.0) or 0.0)
    ltp = float(out.get("preferential", 0.0) or 0.0)
    ltc = float(out.get("collectible", 0.0) or 0.0)

    def _absorb(loss, gain):
        """Move as much of `loss` (≤0) into `gain` (≥0) as fits; returns both."""
        move = min(-loss, gain)
        return loss + move, gain - move

    # Net within long-term character first (28% group vs regular LT)…
    if ltc < 0 < ltp:
        ltc, ltp = _absorb(ltc, ltp)
    elif ltp < 0 < ltc:
        ltp, ltc = _absorb(ltp, ltc)
    # …then across ST/LT, losses eating the highest-rate gains first.
    if st_g < 0:
        if ltc > 0:
            st_g, ltc = _absorb(st_g, ltc)
        if st_g < 0 < ltp:
            st_g, ltp = _absorb(st_g, ltp)
    else:
        for _ in range(2):                     # an LT loss may remain in either slot
            if ltc < 0 < st_g:
                ltc, st_g = _absorb(ltc, st_g)
            if ltp < 0 < st_g:
                ltp, st_g = _absorb(ltp, st_g)

    # Remaining net loss: up to the §1211(b) limit against ordinary income, the
    # rest dropped (no carryover modeling).
    net_loss = -(min(st_g, 0.0) + min(ltp, 0.0) + min(ltc, 0.0))
    if net_loss > 0 and ordinary_offset:
        limit = CAPITAL_LOSS_LIMIT.get(status, 3_000.0)
        ordinary = float(out.get("ordinary", 0.0) or 0.0)
        out["ordinary"] = max(ordinary - min(net_loss, limit), 0.0)
    out["ordinary_investment"] = max(st_g, 0.0)
    out["preferential"] = max(ltp, 0.0)
    out["collectible"] = max(ltc, 0.0)
    return out


def estimate(buckets: dict[str, float], status: str, federal_deduction: float,
             nj_deduction: float) -> dict[str, float]:
    """Federal + NJ income-tax estimate from the tax buckets (see categorize_income).

    Capital losses (negative investment buckets) are netted against gains first —
    see net_capital_losses for the rules and limits. Preferential income (long-term
    gains / qualified dividends) is taxed at the 0/15/20% rates stacked on ordinary
    taxable income; ordinary and ordinary-investment income are taxed at ordinary
    rates; investment income is subject to NIIT. NJ taxes everything at its
    ordinary rates, but on its OWN netting: NJ allows capital losses only against
    capital gains (no §1211(b) $3,000 offset against ordinary income, no
    carryover), so a net-loss year reduces federal ordinary income without
    reducing NJ gross. No self-employment / Social Security / Medicare tax.
    Returns a breakdown dict.
    """
    fed_b = FEDERAL_BRACKETS[status]
    nj_b = NJ_BRACKETS[status]
    raw_buckets = buckets
    buckets = net_capital_losses(buckets, status)
    ordinary_basic = max(buckets.get("ordinary", 0.0), 0.0)
    ordinary_inv = max(buckets.get("ordinary_investment", 0.0), 0.0)
    preferential = max(buckets.get("preferential", 0.0), 0.0)
    collectible = max(buckets.get("collectible", 0.0), 0.0)

    # Federal ordinary tax (wages etc. + ordinary investment income), after the
    # deduction.
    ordinary_income = ordinary_basic + ordinary_inv
    fed_ord_taxable = max(ordinary_income - federal_deduction, 0.0)
    fed_ordinary = progressive_tax(fed_ord_taxable, fed_b)

    # Any deduction left over after wiping out ordinary income reduces the gains that are
    # actually taxed (mirrors the IRS Qualified Dividends & Cap-Gain Worksheet). Apply it
    # to collectible gain first (taxed higher), then preferential.
    leftover_deduction = max(federal_deduction - ordinary_income, 0.0)
    taxable_collectible = max(collectible - leftover_deduction, 0.0)
    leftover_after_coll = max(leftover_deduction - collectible, 0.0)
    taxable_preferential = max(preferential - leftover_after_coll, 0.0)

    # Preferential income at 0/15/20%, stacked on ordinary taxable income.
    fed_ltcg = ltcg_tax(taxable_preferential, fed_ord_taxable, LTCG_BRACKETS[status])

    # Collectible long-term gains (the 28%-rate group): the Schedule D Tax Worksheet
    # stacks them at the TOP of the pile (above preferential income) at a flat 28%,
    # then caps the WHOLE tax at what ordinary rates on all taxable income would
    # charge — so low-bracket payers pay their ordinary rate, but the gain can't
    # slide into bracket room that preferential income already used (stacking it
    # directly on ordinary income, the old approach, under-taxed by up to 16 points).
    if taxable_collectible > 0:
        worksheet = fed_ordinary + fed_ltcg + COLLECTIBLE_MAX_RATE * taxable_collectible
        all_ordinary = progressive_tax(
            fed_ord_taxable + taxable_preferential + taxable_collectible, fed_b)
        fed_collectible = max(min(worksheet, all_ordinary) - fed_ordinary - fed_ltcg, 0.0)
    else:
        fed_collectible = 0.0

    # NIIT (3.8%) on net investment income above the MAGI threshold.
    nii = ordinary_inv + preferential + collectible
    magi = ordinary_income + preferential + collectible
    niit = NIIT_RATE * min(nii, max(magi - NIIT_THRESHOLD[status], 0.0))

    federal = fed_ordinary + fed_ltcg + fed_collectible + niit

    # New Jersey: all taxable income at ordinary NJ rates (no preferential / collectible
    # rate, no NIIT), its own deduction, and a filing-threshold floor. Built from a
    # SEPARATE netting pass that stops before the federal §1211(b) ordinary-income
    # offset — letting that $3,000 leak in understated NJ tax in loss years.
    njb = net_capital_losses(raw_buckets, status, ordinary_offset=False)
    nj_gross = (max(njb.get("ordinary", 0.0), 0.0)
                + max(njb.get("ordinary_investment", 0.0), 0.0)
                + max(njb.get("preferential", 0.0), 0.0)
                + max(njb.get("collectible", 0.0), 0.0))
    if nj_gross <= NJ_FILING_THRESHOLD[status]:
        nj = 0.0
    else:
        nj = progressive_tax(max(nj_gross - nj_deduction, 0.0), nj_b)

    return {
        "fed_ordinary": fed_ordinary, "fed_ltcg": fed_ltcg,
        "fed_collectible": fed_collectible, "niit": niit,
        "federal": federal, "nj": nj, "total": federal + nj,
        "fed_ord_taxable": fed_ord_taxable, "nj_gross": nj_gross,
        "ordinary_income": ordinary_income, "preferential": taxable_preferential,
        "collectible": taxable_collectible,
    }


def ytd_tax_debt_net(income_df: pd.DataFrame,
                     get_constant: Callable) -> float:
    """Year-to-date income tax (federal + NJ) minus tax already withheld — the
    'tax debt YTD' headline shared by the Taxes page, the Overview band, and
    snapshot capture, so all three always agree. `get_constant(key, default)`
    reads stored values: hand-edited bucket boxes win over the classified income
    totals, and the YTD deduction/withholding boxes feed the rest."""
    idx = int(get_constant("filing_status", 0))
    status = FILING_STATUSES[idx] if 0 <= idx < len(FILING_STATUSES) else "single"
    auto = categorize_income(income_df, basis="ytd")
    buckets = {"excluded": 0.0}
    for bk in TAX_CLASS_OPTIONS:
        if bk == "excluded":
            continue
        stored = get_constant(f"tax_income_ytd_{bk}", None)
        buckets[bk] = float(stored) if stored is not None else float(auto[bk])
    ded = max(STANDARD_DEDUCTION[status],
              float(get_constant("itemized_deductions_ytd", 0.0)))
    njd = float(get_constant("nj_deductions_ytd", nj_default_deduction(status)))
    est = estimate(buckets, status, ded, njd)
    return est["total"] - (float(get_constant("fed_withheld_ytd", 0.0))
                           + float(get_constant("nj_withheld_ytd", 0.0)))


def future_distribution_tax(value: float, status: str, growth: float = 0.0,
                            years: int | None = None,
                            annual_amount: float | None = None,
                            schedule: str = "level", other_income: float = 0.0,
                            income_growth: float = 0.0, deduction: float = 0.0,
                            deduction_growth: float = 0.0,
                            nj_deduction: float | None = None,
                            max_years: int = 100) -> dict:
    """Estimate the total income tax a tax-deferred account's FUTURE distributions
    will incur — the hidden liability that makes a traditional/inherited IRA's raw
    value an overstatement of net worth.

    Model (everything in today's dollars): the balance grows at `growth` each
    year, then pays one end-of-year distribution per `schedule`:
      • "level"    — equal payments that empty it over `years`: the annuity
                     V·g/(1−(1+g)^−N) (V/N when g=0) — with growth, each payment
                     deliberately exceeds V/N so the final payment lands at $0;
      • "fraction" — each year takes 1/m of the (grown) balance, where m is the
                     years left on the schedule; m=1 distributes everything;
      • "fixed"    — `annual_amount` per year until depleted (capped at
                     `max_years`; inferred when annual_amount is passed).
    Each distribution is taxed as ORDINARY income stacked on that year's other
    income — `other_income` growing at `income_growth` — i.e. the marginal
    federal + NJ tax of adding it. The federal deduction applied each year is
    the LARGER of the standard deduction and `deduction` grown at
    `deduction_growth` (itemizers); NJ applies its personal exemption and
    filing-threshold cliff. Brackets are assumed to keep pace with flat
    inflation, so applying TODAY's brackets every year is exact in real terms —
    all growth rates should therefore be REAL (after-inflation) rates. Not
    modeled: NIIT (retirement distributions aren't net investment income),
    early-withdrawal penalties, RMD rules, Social Security interactions, and
    NJ's retirement-income exclusions (NJ figures can run high).

    Returns {"rows": [{year, distribution, other_income, fed_tax, nj_tax,
    end_balance}…], "fed_tax", "nj_tax", "total_tax", "total_distributed",
    "effective_rate"}."""
    fed_b = FEDERAL_BRACKETS[status]
    nj_b = NJ_BRACKETS[status]
    std_ded = STANDARD_DEDUCTION[status]
    nj_ded = nj_default_deduction(status) if nj_deduction is None else nj_deduction
    nj_thr = NJ_FILING_THRESHOLD[status]

    value = max(float(value), 0.0)
    g = float(growth)
    gi = float(income_growth)
    gd = float(deduction_growth)
    other0 = max(float(other_income), 0.0)
    ded0 = max(float(deduction), 0.0)

    if annual_amount is not None and schedule == "level":
        schedule = "fixed"                  # backward-compatible inference
    n = max(int(years), 1) if years is not None else None
    level = None
    if schedule == "level":
        if n is None:
            raise ValueError("schedule='level' needs years=")
        level = value / n if abs(g) < 1e-12 else value * g / (1 - (1 + g) ** (-n))
    elif schedule == "fixed":
        if annual_amount is None:
            raise ValueError("schedule='fixed' needs annual_amount=")
        level = max(float(annual_amount), 0.0)
    elif schedule == "fraction":
        if n is None:
            raise ValueError("schedule='fraction' needs years=")
    else:
        raise ValueError(f"unknown schedule {schedule!r}")

    def _fed(ti, ded):
        return progressive_tax(max(ti - ded, 0.0), fed_b)

    def _nj(ti):
        return 0.0 if ti <= nj_thr else progressive_tax(max(ti - nj_ded, 0.0), nj_b)

    rows, bal = [], value
    fed_total = nj_total = dist_total = 0.0
    year = 0
    while bal > 0.005 and year < max_years:
        year += 1
        bal *= (1 + g)
        if schedule == "fraction":
            m = n - year + 1                # years left, this one included
            d = bal if m <= 1 else bal / m
        else:
            if level <= 0:
                break
            d = min(level, bal)
        bal -= d
        # This year's other income and itemized deduction, on their own paths.
        oy = other0 * (1 + gi) ** (year - 1)
        fed_ded_y = max(std_ded, ded0 * (1 + gd) ** (year - 1))
        fed_t = max(_fed(oy + d, fed_ded_y) - _fed(oy, fed_ded_y), 0.0)
        nj_t = max(_nj(oy + d) - _nj(oy), 0.0)
        rows.append({"year": year, "distribution": d, "other_income": oy,
                     "fed_tax": fed_t, "nj_tax": nj_t, "end_balance": bal})
        fed_total += fed_t
        nj_total += nj_t
        dist_total += d
    total = fed_total + nj_total
    return {"rows": rows, "fed_tax": fed_total, "nj_tax": nj_total,
            "total_tax": total, "total_distributed": dist_total,
            "effective_rate": (total / dist_total) if dist_total > 0 else 0.0}


# ---------------------------------------------------------------------------
# Display helpers (formatting reference data, still UI-framework-agnostic)
# ---------------------------------------------------------------------------

def _fmt_pct(rate: float) -> str:
    return f"{rate * 100:g}%"


def _fmt_range(lower: float, upper: float | None) -> str:
    if upper is None:
        return f"Over ${lower:,.0f}"
    return f"${lower:,.0f} – ${upper:,.0f}"


def bracket_rows(brackets: list[tuple[float, float | None, float]]) -> list[dict]:
    """Return the table as a list of {"Rate", "Taxable income"} dicts, ready to
    drop into a DataFrame for display."""
    return [
        {"Rate": _fmt_pct(rate), "Taxable income": _fmt_range(lower, upper)}
        for lower, upper, rate in brackets
    ]
