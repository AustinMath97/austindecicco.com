"""
edit_dialogs.py — the four record Edit dialogs (asset/debt/income/expense),
the links editor they embed, and consume_pending_edit(), the single dispatcher
that opens them (called once per run from dashboard.main, so an "Edit" jump
works from any page or dialog). Split out of cards.py, which keeps the shared
row helpers and the card renderers; the import is one-way (this module imports
cards, never the reverse).
"""

from datetime import date

import streamlit as st

import accounts
import db
import prices
import recurrence
import stats
import taxes
import widgets
from cards import (
    DEBT_TYPE_LABEL, EXPENSE_CATEGORY_OPTIONS, INCOME_TYPE_LABEL, LINK_TABLES,
    MONTH_NAMES, TABLE_LABEL, _begin_edit, _dropdown_index, _edit_ver,
    _linked_records, _money, _n, _ordinal, _row_label, _s, _seedk, _to_date,
    request_edit, request_view,
)
from utils import (ACCOUNT_TYPE_GROUPS, ACCOUNT_TYPE_OPTIONS, ASSET_TYPES_BY_FAMILY,
                   SECURITY_ASSET_TYPES, asset_family, format_address, is_cash,
                   is_distribution, is_investment_holding, parse_vehicle_name,
                   zillow_search_url)


def consume_pending_edit():
    """If an 'Edit ↗' jump is queued, open that row's Edit dialog. Call once at
    the top of the app so the jump works from any page or dialog."""
    pe = st.session_state.pop("_pending_edit", None)
    if not pe:
        return
    table, row_id = pe
    if table not in TABLE_LABEL:
        return
    df = db.load_df(table)
    match = df[df["id"] == row_id] if not df.empty else df
    if match.empty:
        return
    _begin_edit(table, row_id)
    fn = {"assets": edit_asset, "debts": edit_debt,
          "income": edit_income, "expenses": edit_expense}[table]
    fn(row_id, match.iloc[0].to_dict())


def _do_add_link(src_table, src_id, P):
    """on_click handler for the Add-link button. Reads the picker selections and
    either starts a NEW group containing this record + the target, or adds the
    target to one of this record's EXISTING groups. Runs before the dialog
    re-renders, so the new link shows immediately without closing the dialog."""
    tgt = st.session_state.get(f"{P}lnk_t")
    if not tgt:
        return
    rid = st.session_state.get(f"{P}lnk_r_{tgt}")
    if rid is None:
        return
    role = (st.session_state.get(f"{P}lnk_k") or "").strip() or None
    grp = st.session_state.get(f"{P}lnk_grp")
    if grp in (None, "__new__"):
        name = (st.session_state.get(f"{P}lnk_gname") or "").strip() or None
        if not name:
            return                       # a new group must be named (button is disabled)
        gid = db.create_group(name)
        db.add_to_group(gid, src_table, src_id)        # this record (no role)
        db.add_to_group(gid, tgt, int(rid), role)       # the target
    else:
        db.add_to_group(int(grp), tgt, int(rid), role)


def _do_join_group(table, row_id, P):
    """on_click for 'Join group': add the record being edited to an existing group it
    isn't in yet, so it links to that group's current members. The complement of
    _do_add_link (which brings OTHER records in). Runs before the dialog re-renders,
    so the new membership shows immediately."""
    gid = st.session_state.get(f"{P}joingrp")
    if gid is None:
        return
    role = (st.session_state.get(f"{P}joinrole") or "").strip() or None
    db.add_to_group(int(gid), table, int(row_id), role)


def _prefill_expense_from_debt(P, debt):
    """on_click: fill a payment expense's amount + schedule from the linked debt's
    minimum payment and due day (a debt pays monthly on its due day)."""
    mp = _n(debt, "min_payment")
    if mp > 0:
        st.session_state[f"{P}amount"] = float(mp)
        st.session_state[f"{P}mode"] = "Set"     # a debt payment is a set amount
    # Remember this expense IS the debt's payment (group stats de-dup the pair).
    st.session_state[f"{P}pays_debt"] = int(debt["id"])
    dd = _n(debt, "due_day")
    sched = {"type": recurrence.MONTHLY, "month_days": [int(dd)] if dd > 0 else []}
    widgets.set_schedule_widget_keys(f"{P}sch", sched)


def _prefill_income_from_cash(P, asset):
    """on_click: import a linked cash account's interest as this income — copies the
    account's full interest payout schedule (dates) and sets the amount (annual +
    per-payment) from its APY. The schedule widgets are cleared and the imported
    schedule queued so they re-seed from it on the next render."""
    value, apy = _n(asset, "value"), _n(asset, "apy")
    if value <= 0 or apy <= 0:
        return
    sched = accounts.asset_interest_sched(asset)
    if sched.get("type") in (None, "", recurrence.NONE):
        sched = accounts.DEFAULT_INTEREST_SCHED
    annual, per = accounts.interest_income_amounts(value, apy, sched)
    st.session_state[f"{P}amount"] = float(round(annual, 2))
    st.session_state[f"{P}payamt"] = float(round(per, 2))
    # Directly set the schedule widget's keys to the imported schedule (the widgets are
    # seed-once, so they reflect these without a default/state clash).
    widgets.set_schedule_widget_keys(f"{P}sch", sched)


def _links_editor(P, table, row_id):
    """Link-groups section for an Edit dialog. Lists each group this record is in
    with its members (view / jump-to-edit / remove), a 'Leave' for the whole group,
    and an add-link picker that either starts a new group or adds a record to one of
    this record's existing groups. Mutations use on_click callbacks so they refresh
    in place; the 'Edit ↗' jump closes this dialog and opens the linked one."""
    st.divider()
    st.markdown("**🔗 Link groups**")
    st.caption("A record can belong to several groups; everyone in a group is linked "
               "to everyone else in it. A record can bridge groups that aren't linked "
               "to each other (e.g. a property in both a mortgage group and a "
               "household-bills group). Use **Add a link** to start a new group or add "
               "a record to one this record is already in.")

    groups = db.groups_for(table, row_id)
    if not groups:
        st.caption("Not in any group yet.")
    for g in groups:
        gid = g["group_id"]
        gname = g["name"] or "Unnamed group"
        hc, lc = st.columns([4.2, 1.3])
        hc.markdown(f"**{gname}**")
        lc.button("Leave", key=f"{P}grpleave_{gid}", width="stretch",
                  help="Remove this record from this group.",
                  on_click=db.remove_from_group, args=(gid, table, row_id))
        members = [m for m in db.group_members(gid, exclude=(table, row_id))
                   if db.row_label(m["table"], m["id"]) is not None]
        for m in members:
            lbl = db.row_label(m["table"], m["id"])
            role = _s(m, "role")
            face = f"{TABLE_LABEL[m['table']]}: {lbl}" + (f"  ·  {role}" if role else "")
            cc = st.columns([4.4, 1.2, 1.2])
            if cc[0].button(face, key=f"{P}grpview_{m['member_id']}", type="tertiary",
                            width="stretch", help="Open this linked record's card pop-up"):
                request_view(m["table"], int(m["id"]))
                st.rerun()
            if cc[1].button("Edit ↗", key=f"{P}grpgo_{m['member_id']}", width="stretch"):
                request_edit(m["table"], int(m["id"]))
                st.rerun()
            cc[2].button("Remove", key=f"{P}grprm_{m['member_id']}", width="stretch",
                         help="Remove this record from this group.",
                         on_click=db.remove_member, args=(m["member_id"],))
        st.write("")

    with st.expander("➕ Add a link"):
        st.caption("Bring **another** record into a group with this one — start a new "
                   "group, or add it to one of this record's groups above.")
        tgt = st.selectbox("Record type", LINK_TABLES,
                           format_func=lambda t: TABLE_LABEL[t], key=f"{P}lnk_t")
        df = db.load_df(tgt)
        cands = []
        if not df.empty:
            for _, r in df.iterrows():
                rid = int(r["id"])
                if tgt == table and rid == row_id:
                    continue
                cands.append((rid, _row_label(tgt, r.to_dict())))
        if cands:
            label_map = {rid: lbl for rid, lbl in cands}
            st.selectbox("Record", [rid for rid, _ in cands],
                         format_func=lambda rid: label_map.get(rid, str(rid)),
                         key=f"{P}lnk_r_{tgt}")

            grp_opts = ["__new__"] + [g["group_id"] for g in groups]

            def _gfmt(v):
                if v == "__new__":
                    return "➕ New group"
                gg = next((x for x in groups if x["group_id"] == v), None)
                return (gg["name"] if gg and gg["name"] else "Unnamed group")

            grp_choice = st.selectbox("Group", grp_opts, format_func=_gfmt, key=f"{P}lnk_grp")
            new_name = ""
            if grp_choice == "__new__":
                new_name = st.text_input("New group name", key=f"{P}lnk_gname",
                              placeholder="e.g. 123 Oak Lane — household bills")
            st.text_input("Relationship (optional)", key=f"{P}lnk_k",
                          placeholder="e.g. mortgage, utility, interest, secured by")
            needs_name = grp_choice == "__new__" and not new_name.strip()
            st.button("Link", key=f"{P}lnk_add", type="primary", disabled=needs_name,
                      help="Name the new group first." if needs_name else None,
                      on_click=_do_add_link, args=(table, row_id, P))
        else:
            st.caption("Nothing available to link of this type.")

    # Put THIS record into an existing group it isn't a member of yet — the complement
    # of "Add a link" (which brings OTHER records in). Hidden when there's no other
    # group left to join.
    my_gids = {g["group_id"] for g in groups}
    other_groups = [g for g in db.all_groups() if g["id"] not in my_gids]
    if other_groups:
        with st.expander("➕ Join an existing group"):
            st.caption("Add **this** record to a group it isn't in yet — it becomes "
                       "linked to every current member of that group.")
            gmap = {g["id"]: (g["name"] or "Unnamed group") for g in other_groups}
            gid_choice = st.selectbox(
                "Group to join", [g["id"] for g in other_groups],
                format_func=lambda i: gmap[i], key=f"{P}joingrp")
            preview = [m for m in db.group_members(gid_choice)
                       if db.row_label(m["table"], m["id"]) is not None]
            if preview:
                st.caption("Members: " + ", ".join(
                    f"{TABLE_LABEL[m['table']]}: {db.row_label(m['table'], m['id'])}"
                    for m in preview))
            st.text_input("Relationship (optional)", key=f"{P}joinrole",
                          placeholder="e.g. utility, secured by, contribution")
            st.button("Join group", key=f"{P}joinadd", type="primary",
                      on_click=_do_join_group, args=(table, row_id, P))


# ---------------------------------------------------------------------------
# Edit dialogs
# ---------------------------------------------------------------------------

@st.dialog("Edit Asset", width="large", on_dismiss="rerun")
def edit_asset(asset_id, data):
    account_type = _s(data, "account_type") or None
    asset_type = _s(data, "asset_type")
    fam = asset_family(asset_type)
    is_dist = is_distribution(account_type)
    P = f"ea_{asset_id}_{_edit_ver('assets', asset_id)}_"   # fresh keys per open

    # Vehicles derive their name from year/make/model below (like the Add form),
    # so decoding a VIN re-labels the vehicle. Other types keep a free-text name.
    if fam == "vehicle":
        name = _s(data, "name")
    else:
        name = st.text_input("Name", value=_s(data, "name"), key=f"{P}name")
    def _pick(col, label, options, current, key):
        """A selectbox that preselects (and preserves) the current value."""
        opts = list(options)
        if current and current not in opts:
            opts = [current] + opts
        return col.selectbox(label, opts,
                             index=opts.index(current) if current in opts else 0, key=key)

    # Institution / Platform + Account type — only for account-held assets
    # (securities, crypto, cash). A receivable instead names who owes you;
    # everything else is held directly, with neither field. A security can move
    # between any account, so it gets the full account list; cash and crypto are
    # constrained to their own groups.
    _acct_opts = {"security": ACCOUNT_TYPE_OPTIONS, "crypto": ACCOUNT_TYPE_GROUPS["Crypto"],
                  "cash": ACCOUNT_TYPE_GROUPS["Cash / Bank"]}.get(fam)
    if _acct_opts:
        c1, c2 = st.columns(2)
        institution = c1.text_input("Institution / Platform", value=_s(data, "institution"),
                                    key=f"{P}inst") or None
        account_type = _pick(c2, "Account type", _acct_opts, account_type, f"{P}acct")
    elif fam == "receivable":
        institution = st.text_input("Owed by (person, company, agency)",
                                    value=_s(data, "institution"), key=f"{P}inst") or None
        account_type = None
    else:
        institution, account_type = None, None

    # Asset type (what the holding is) — fixed for cash/crypto, a dropdown for
    # securities and physical assets, free text for "other".
    if is_dist:
        asset_type = "Cash"
    elif fam == "cash":
        asset_type = "Cash"
    elif fam == "crypto":
        asset_type = "Cryptocurrency"
    elif fam == "security":
        asset_type = _pick(st, "Asset type", SECURITY_ASSET_TYPES, asset_type, f"{P}atype")
    elif fam in ASSET_TYPES_BY_FAMILY and fam != "other":
        asset_type = _pick(st, "Asset type", ASSET_TYPES_BY_FAMILY[fam], asset_type, f"{P}atype")
    else:
        asset_type = st.text_input("Asset type", value=asset_type, key=f"{P}atype") or "Other"

    ticker = None
    shares = None
    # Pending estate/trust distributions are a cash amount, not a holding, so
    # they get no ticker/shares (matching the Add form).
    supports_positions = is_investment_holding(asset_type) and not is_dist

    if supports_positions:
        c3, c4 = st.columns(2)
        ticker_raw = c3.text_input("Ticker symbol", value=_s(data, "ticker"), key=f"{P}ticker")
        ticker = ticker_raw.upper().strip() or None
        units_label = "Units / coins" if fam == "crypto" else "Shares / units"
        shares = c4.number_input(units_label, value=_n(data, "shares"),
                                 min_value=0.0, step=0.0001, format="%.4f", key=f"{P}shares")
        if ticker:
            st.caption(f"Price for **{ticker}** will be refreshed on save.")
        value = st.number_input("Current value ($)", value=_n(data, "value"),
                                min_value=0.0, step=100.0, key=f"{P}value")
    else:
        value = st.number_input("Estimated value ($)", value=_n(data, "value"),
                                min_value=0.0, step=100.0, key=f"{P}value")

    # Cost basis only for the families the Add form collects it for (mirrors
    # forms.add_asset): positions, lump-sum accounts, collectibles, and "other".
    # Cash / vehicle / real estate / business / receivable / pending distribution
    # have no cost basis, so don't surface the field. The existing value is
    # preserved on save for any family that doesn't show it.
    supports_cost_basis = (fam in ("security", "crypto", "collectible", "real_estate",
                                   "other") and not is_dist)
    cost_basis = _n(data, "cost_basis")
    if supports_cost_basis:
        cost_basis = st.number_input(
            "Cost basis ($)", value=_n(data, "cost_basis"),
            min_value=0.0, step=100.0, key=f"{P}cost",
            help="Total amount paid for this position. Leave 0 if not tracking."
        )
        if cost_basis > 0 and value > 0:
            gl = value - cost_basis
            st.caption(f":{'green' if gl >= 0 else 'red'}[Unrealized {'gain' if gl >= 0 else 'loss'}: "
                       f"**{'+$' if gl >= 0 else '-$'}{abs(gl):,.2f}** ({gl/cost_basis*100:+.1f}%)]")

    mileage = vin = apy = None
    # Interest payout schedule columns are written on EVERY save: populated for an
    # interest-bearing cash account, explicitly NULLed otherwise — so zeroing the
    # APY (or moving the asset off cash) can't strand a stale schedule that the
    # Accounts projection would keep paying out.
    interest_sched = {
        "interest_schedule_type": None, "interest_weekday": None,
        "interest_week_ordinal": None, "interest_anchor_date": None,
        "interest_pay_days": None, "interest_months": None,
    }
    street = city = state = zip_code = None
    beds = baths = sqft = year_built = None
    maturity_date = trim = condition = None
    ownership_pct = collection_date = collection_prob = None
    make = model = model_year = None
    if fam == "cash":
        apy_pct = st.number_input("APY (%)", value=_n(data, "apy") * 100,
                                  min_value=0.0, step=0.01, key=f"{P}apy",
                                  help="Annual percentage yield, if interest-bearing.")
        apy = apy_pct / 100 if apy_pct > 0 else None
        if apy:
            st.markdown("**Interest payout** — when the interest is paid out")
            _idef = accounts.asset_interest_sched(data)
            if _idef.get("type") in (None, "", recurrence.NONE):
                _idef = accounts.DEFAULT_INTEREST_SCHED
            _isf = widgets.schedule_widget(_idef, key_prefix=f"{P}intsch")
            interest_sched = {
                "interest_schedule_type": _isf["schedule_type"],
                "interest_weekday":       _isf["weekday"],
                "interest_week_ordinal":  _isf["week_ordinal"],
                "interest_anchor_date":   _isf["anchor_date"],
                "interest_pay_days":      _isf["pay_days"],
                "interest_months":        _isf["months"],
            }
        if (account_type or "").startswith("CD") or "Treasury" in (account_type or ""):
            md = st.date_input("Maturity date", value=_to_date(_s(data, "maturity_date")),
                               key=f"{P}maturity",
                               help="When the CD / treasury matures and becomes liquid.")
            maturity_date = md.isoformat() if md else None
    elif fam == "vehicle":
        # Seed make/model/year from their own columns, falling back to parsing
        # the legacy display name for rows saved before those fields existed.
        _yr, _mk, _md = parse_vehicle_name(_s(data, "name"))
        vf = widgets.vehicle_fields(
            {"year": (int(_n(data, "model_year")) if _s(data, "model_year") else _yr),
             "make": _s(data, "make") or _mk,
             "model": _s(data, "model") or _md,
             "trim": _s(data, "trim"), "condition": _s(data, "condition"),
             "zip_code": _s(data, "zip_code"), "vin": _s(data, "vin"),
             "mileage": _n(data, "mileage")},
            key_prefix=f"{P}veh", vehicle_type=asset_type)
        make, model, model_year = vf["make"], vf["model"], vf["model_year"]
        trim, condition, zip_code = vf["trim"], vf["condition"], vf["zip_code"]
        mileage, vin = vf["mileage"], vf["vin"]
        # Re-label from the (possibly VIN-decoded) year/make/model.
        name = vf["display_name"] or _s(data, "name")
    elif fam == "business":
        # Ownership 0 / NULL means "unset" app-wide — snapshots treat 0 as wholly
        # owned (NULLIF(ownership_pct, 0)) — so an unset stake surfaces here as 100%.
        op = st.number_input("Ownership %",
                             value=(_n(data, "ownership_pct") * 100) or 100.0,
                             min_value=0.0, max_value=100.0, step=1.0, key=f"{P}own")
        ownership_pct = op / 100.0
        if op != 100 and value > 0:
            st.caption(f"Your stake: ${value * op / 100:,.0f} (counts toward net worth)")
    elif fam == "receivable":
        cd = st.date_input("Expected collection date",
                           value=_to_date(_s(data, "collection_date")), key=f"{P}coll_date",
                           help="When you expect payment.")
        collection_date = cd.isoformat() if cd else None
        cur_prob = _n(data, "collection_prob") if _s(data, "collection_prob") else 1.0
        collection_prob = st.number_input(
            "Likelihood of collecting (0–1)", min_value=0.0, max_value=1.0,
            value=cur_prob, step=0.05, key=f"{P}coll_prob",
            help="Probability you'll actually collect: 1.0 = certain, 0.0 = written off.")
        if value > 0 and collection_prob < 1.0:
            st.caption(f"Risk-adjusted value: ${value * collection_prob:,.0f} "
                       f"({int(collection_prob * 100)}% likely).")
        if asset_type == "Personal Loan to Someone":
            apy_pct = st.number_input("Agreed interest rate (% APR)",
                                      value=_n(data, "apy") * 100, min_value=0.0, step=0.1,
                                      key=f"{P}rapy")
            apy = apy_pct / 100 if apy_pct > 0 else None
    elif fam == "real_estate":
        street_in = st.text_input("Street address", value=_s(data, "street"), key=f"{P}street")
        ac1, ac2, ac3 = st.columns([2, 1, 1])
        city_in = ac1.text_input("City", value=_s(data, "city"), key=f"{P}city")
        state_in = ac2.text_input("State", value=_s(data, "state"), max_chars=2, key=f"{P}state")
        zip_in = ac3.text_input("ZIP", value=_s(data, "zip_code"), max_chars=10, key=f"{P}rezip")
        pc1, pc2, pc3, pc4 = st.columns(4)
        beds = pc1.number_input("Beds", value=_n(data, "beds"), min_value=0.0, step=1.0,
                                key=f"{P}beds") or None
        baths = pc2.number_input("Baths", value=_n(data, "baths"), min_value=0.0, step=0.5,
                                 key=f"{P}baths") or None
        sqft = int(pc3.number_input("Sq ft", value=int(_n(data, "sqft")), min_value=0, step=50,
                                    key=f"{P}sqft")) or None
        year_built = int(pc4.number_input("Year built", value=int(_n(data, "year_built")),
                                          min_value=0, max_value=date.today().year, step=1,
                                          key=f"{P}ybuilt")) or None
        addr = format_address(street_in, city_in, state_in, zip_in)
        if addr:
            st.markdown(f"[🔗 Check the Zestimate on Zillow ↗]({zillow_search_url(addr)})")
        street = street_in.strip() or None
        city = city_in.strip() or None
        state = state_in.strip().upper() or None
        zip_code = zip_in.strip() or None

    liquid = st.checkbox("Liquid (quickly convertible to cash)",
                         value=bool(int(_n(data, "liquid"))), key=f"{P}liquid")

    _links_editor(P, "assets", asset_id)

    st.divider()
    c1, c2 = st.columns(2)
    if c1.button("Save changes", type="primary", width="stretch"):
        if not name:
            st.error("Name is required.")
            st.stop()
        # Every column is written on save: fields an asset type/account doesn't
        # show are deliberately cleared (they no longer apply), not silently kept.
        db.update_row("assets", asset_id, {
            "name": name,
            "institution": institution or None,
            "account_type": account_type or None,
            "asset_type": asset_type or None,
            "ticker": ticker,
            # 0 shares means "no share count tracked" (a lump-sum holding) — store
            # NULL so it isn't mistaken for a real zero position.
            "shares": shares if shares else None,
            "value": value,
            "liquid": 1 if liquid else 0,
            "cost_basis": cost_basis if cost_basis > 0 else None,
            "mileage": mileage,
            "vin": vin,
            "street": street, "city": city, "state": state, "zip_code": zip_code,
            "beds": beds, "baths": baths, "sqft": sqft, "year_built": year_built,
            "apy": apy, "ownership_pct": ownership_pct, "maturity_date": maturity_date,
            "trim": trim, "condition": condition,
            "collection_date": collection_date, "collection_prob": collection_prob,
            "make": make, "model": model, "model_year": model_year,
            **interest_sched,
        })
        # A margin loan references its account by the DERIVED label (institution
        # — account type). If this edit renamed the account label out of existence
        # (all its holdings moved with it), follow it so the loans don't orphan.
        # When only SOME holdings moved (the old label still exists) the split is
        # ambiguous and the loans stay put.
        _old_label = " — ".join(p for p in ((_s(data, "institution") or "").strip(),
                                            (_s(data, "account_type") or "").strip()) if p)
        _new_label = " — ".join(p for p in ((institution or "").strip(),
                                            (account_type or "").strip()) if p)
        if _old_label and _new_label and _new_label != _old_label:
            _labels_now = {a["label"]
                           for a in stats.investment_accounts(db.load_df("assets"))}
            if _old_label not in _labels_now and _new_label in _labels_now:
                _moved = db.repoint_margin_account(_old_label, _new_label)
                if _moved:
                    st.toast(f"Re-pointed {_moved} margin loan(s) to {_new_label}.")
        if ticker:
            # Price just this asset — not the whole portfolio (one network call,
            # not one per holding). A tickered lump sum still caches last_price.
            with st.spinner(f"Fetching price for {ticker}…"):
                prices.refresh_asset_prices(only_id=asset_id)
        st.rerun()
    if c2.button("Cancel", width="stretch"):
        st.rerun()


@st.dialog("Edit Debt", width="large", on_dismiss="rerun")
def edit_debt(debt_id, data):
    P = f"edt_{debt_id}_{_edit_ver('debts', debt_id)}_"   # fresh keys per open
    name = st.text_input("Name", value=_s(data, "name"), key=f"{P}name")
    _opts, _idx = _dropdown_index(list(DEBT_TYPE_LABEL), _s(data, "type") or "other",
                                  fallback=list(DEBT_TYPE_LABEL).index("other"))
    debt_type = st.selectbox("Debt type", _opts, index=_idx, key=f"{P}type",
                             format_func=lambda c: DEBT_TYPE_LABEL.get(c, c.replace("_", " ").title()))
    is_margin = debt_type == stats.MARGIN_DEBT_TYPE
    _was_margin = _s(data, "type") == stats.MARGIN_DEBT_TYPE
    if is_margin and not _was_margin:
        st.warning("Switching to a margin loan **clears** this debt's monthly "
                   "payment, original balance, months remaining, and due day on "
                   "save — margin loans have no payment schedule.")

    # A margin loan records the investment account it's borrowed against (a plain
    # datapoint, not a link) and infers its brokerage/lender from it; every other
    # debt enters a lender by hand. Shared picker (widgets.py) — same one Add uses.
    if is_margin:
        _cur_acct = _s(data, "margin_account")
        margin_account, lender = widgets.margin_account_picker(
            P, current_account=_cur_acct or None)
        lender = lender or (_s(data, "lender") or None)
    else:
        margin_account = None
        lender = st.text_input("Lender / creditor", value=_s(data, "lender"), key=f"{P}lender")

    c1, c2 = st.columns(2)
    balance = c1.number_input("Current balance ($)", value=_n(data, "balance"),
                              min_value=0.0, step=10.0, key=f"{P}balance")
    # A margin loan's APR is a live formula over the economic variables; every other
    # debt enters a flat APR. apr_formula is persisted (and cleared) on save.
    if is_margin:
        apr_formula, _live_apr = widgets.margin_apr_formula_input(
            P, balance, current_formula=_s(data, "apr_formula") or None)
        apr = _live_apr if _live_apr is not None else _n(data, "apr")
    else:
        apr_formula = None
        apr_pct = c2.number_input("APR (%)", value=_n(data, "apr") * 100,
                                  min_value=0.0, max_value=200.0, step=0.01, key=f"{P}apr")
        apr = apr_pct / 100.0

    # A credit card carries a limit and a (possibly percent-based) minimum; a margin
    # loan has no scheduled payment; other debts keep the plain fixed monthly payment.
    if debt_type == "revolving":
        _mpf = widgets.min_payment_fields(data, f"{P}mp_", balance=balance, apr=apr)
        credit_limit = _mpf["credit_limit"]
        min_payment = _mpf["min_payment"]
        mp_type = _mpf["min_payment_type"]
        mp_pct = _mpf["min_payment_pct"]
        stmt = {k: _mpf[k] for k in
                ("statement_day", "statement_weekday", "statement_week_ordinal")}
    elif is_margin:
        min_payment, credit_limit, mp_type, mp_pct = 0.0, None, "fixed", None
        stmt = {"statement_day": None, "statement_weekday": None, "statement_week_ordinal": None}
    else:
        min_payment = st.number_input("Min monthly payment ($)", value=_n(data, "min_payment"),
                                      min_value=0.0, step=5.0, key=f"{P}minpay")
        credit_limit, mp_type, mp_pct = None, "fixed", None
        stmt = {"statement_day": None, "statement_weekday": None, "statement_week_ordinal": None}

    # Original balance / months remaining / due day, and the payoff preview, don't
    # apply to a margin loan (no scheduled payment).
    if is_margin:
        orig_balance, months_remaining, due_day = 0.0, 0, None
    else:
        c4, c5, c6 = st.columns(3)
        orig_balance = c4.number_input("Original balance ($)",
                                       value=_n(data, "original_balance"),
                                       min_value=0.0, step=100.0, key=f"{P}orig")
        months_remaining = int(c5.number_input("Months remaining",
                                               value=int(_n(data, "months_remaining")),
                                               min_value=0, step=1, key=f"{P}months"))
        due_day_opts = [""] + [str(i) for i in range(1, 32)]
        cur_due = str(int(_n(data, "due_day"))) if _s(data, "due_day") else ""
        due_day_raw = c6.selectbox("Due day", due_day_opts, key=f"{P}due",
                                   index=due_day_opts.index(cur_due) if cur_due in due_day_opts else 0)
        due_day = int(due_day_raw) if due_day_raw else None

        # Payoff preview — simulated, so a percent-of-balance minimum is handled too.
        _eff_min = stats.min_payment_due(balance, mp_type, mp_pct, min_payment, apr=apr)
        if balance > 0 and _eff_min > 0:
            _mos, _intp = stats.months_to_payoff(balance, apr, mp_type, mp_pct, min_payment)
            if _mos is None:
                st.warning("At the minimum this never fully pays off — it barely outruns the interest.")
            else:
                st.info(f"Paid off in **{_mos} months**"
                        + (f" · **${_intp:,.0f}** total interest." if apr > 0 else " (0% interest)."))

    _links_editor(P, "debts", debt_id)

    st.divider()
    c1, c2 = st.columns(2)
    if c1.button("Save changes", type="primary", width="stretch"):
        if not name:
            st.error("Name is required.")
            st.stop()
        if is_margin:
            if not margin_account:
                st.error("Select the investment account this margin loan is "
                         "borrowed against.")
                st.stop()
            # The live preview above already evaluated the formula THIS run —
            # _live_apr is None iff it failed (the error is on screen).
            if _live_apr is None:
                st.error("Fix the APR formula — it doesn't evaluate (see above).")
                st.stop()
            # An auto-generated name follows a re-pointed account; a hand-edited
            # name is the user's and stays put.
            if margin_account != _cur_acct and name == f"Margin Loan — {_cur_acct}":
                name = f"Margin Loan — {margin_account}"
        db.update_row("debts", debt_id, {
            "name": name, "lender": lender or None, "type": debt_type,
            "balance": balance, "apr": apr, "apr_formula": apr_formula,
            "margin_account": margin_account,
            "min_payment": min_payment,
            "min_payment_type": mp_type, "min_payment_pct": mp_pct,
            "credit_limit": credit_limit, **stmt,
            "original_balance": orig_balance or None,
            "months_remaining": months_remaining or None,
            "due_day": due_day,
        })
        st.rerun()
    if c2.button("Cancel", width="stretch"):
        st.rerun()


@st.dialog("Edit Income", width="large", on_dismiss="rerun")
def edit_income(income_id, data):
    P = f"ei_{income_id}_{_edit_ver('income', income_id)}_"   # fresh keys per open
    source = st.text_input("Source", value=_s(data, "source"), key=f"{P}source")

    c1, c2 = st.columns(2)
    amount = c1.number_input("Annual amount ($)", min_value=0.0, step=50.0,
                             key=_seedk(P, "amount", _n(data, "amount")),
                             help="Full-year expected total for this stream.")
    received_ytd = c2.number_input("Received so far this year ($)", min_value=0.0, step=50.0,
                                   key=_seedk(P, "rcvd", _n(data, "received_ytd")),
                                   help="How much of the annual amount is already in hand. "
                                        "The rest is what's still expected; the schedule below "
                                        "projects future arrivals.")

    _t_opts, _t_idx = _dropdown_index(list(INCOME_TYPE_LABEL), _s(data, "type") or "other",
                                      fallback=list(INCOME_TYPE_LABEL).index("other"))
    income_type = st.selectbox("Income type", _t_opts, index=_t_idx, key=f"{P}itype",
                               format_func=lambda c: INCOME_TYPE_LABEL.get(c, c.replace("_", " ").title()))

    _cur_tc = _s(data, "tax_class") or taxes.default_tax_class(_s(data, "type"))
    if _cur_tc not in taxes.TAX_CLASS_OPTIONS:
        _cur_tc = "ordinary"
    tax_class = st.selectbox(
        "Tax treatment", taxes.TAX_CLASS_OPTIONS,
        index=taxes.TAX_CLASS_OPTIONS.index(_cur_tc), key=f"{P}taxclass",
        format_func=lambda k: taxes.TAX_CLASS_LABEL[k],
        help="How this income is taxed — drives the tax estimate on the Taxes page. "
             "Long-term gains / qualified dividends get preferential rates; interest and "
             "short-term gains are ordinary-rate investment income (subject to NIIT).")

    st.divider()
    auto_deposit = st.checkbox(
        "Auto-deposited", value=bool(int(_n(data, "auto_deposit"))), key=f"{P}autodep",
        help="This income lands in an account automatically (direct deposit / ACH) — "
             "the mirror of an auto-drafted expense.")
    deposit_target = None
    if auto_deposit:
        try:
            _adf = db.load_df("assets")
            _accts = _adf[_adf["asset_type"].apply(is_cash)
                          & ~_adf["account_type"].apply(is_distribution)]["name"].tolist()
        except Exception:
            _accts = []
        cur_dt = _s(data, "deposit_target")
        if _accts:
            _opts = ["— enter manually —"] + _accts
            _idx = _opts.index(cur_dt) if cur_dt in _opts else 0
            _choice = st.selectbox("Deposits to", _opts, index=_idx, key=f"{P}depsel")
            deposit_target = (_choice if _choice != "— enter manually —"
                              else st.text_input("Account", value=cur_dt, key=f"{P}depman"))
        else:
            deposit_target = st.text_input("Deposits to", value=cur_dt, key=f"{P}deptext")

    st.divider()
    st.markdown("**Calendar scheduling** — when it arrives, so it lands on the right dates")
    # The "Import interest" button sets these widget keys directly (see
    # widgets.set_schedule_widget_keys), so the seeded saved schedule below is overridden.
    sched_fields = widgets.schedule_widget(recurrence.from_row(data), key_prefix=f"{P}sch")
    pay_amount = st.number_input("Amount per occurrence ($)", min_value=0.0, step=100.0,
                                 key=_seedk(P, "payamt", _n(data, "pay_amount")),
                                 help="Per-paycheck/per-deposit amount for calendar display.")
    sched_fields["pay_amount"] = pay_amount if pay_amount > 0 else None

    # Import interest from a linked cash account — both the payout dates (schedule) and
    # the amount, derived from the account's APY + interest payout frequency/day. An
    # income can be linked to several accounts (across groups), so show one button each.
    _cash_accts = [a for a in _linked_records("income", income_id, "assets")
                   if is_cash(_s(a, "asset_type")) and _n(a, "apy") > 0 and _n(a, "value") > 0]
    if _cash_accts:
        st.caption("Import interest (payout dates + amount) from a linked cash account:")
        for _a in sorted(_cash_accts, key=lambda a: _s(a, "name").lower()):
            _isched = accounts.asset_interest_sched(_a)
            if _isched.get("type") in (None, "", recurrence.NONE):
                _isched = accounts.DEFAULT_INTEREST_SCHED
            _annual, _per = accounts.interest_income_amounts(_n(_a, "value"), _n(_a, "apy"), _isched)
            _desc = recurrence.describe(_isched) or "schedule"
            st.button(
                f"↪ Import interest from {_s(_a, 'name')}: "
                f"{_money(_per)}/payout · {_desc} ({_money(_annual)}/yr)",
                key=f"{P}pf_cash_{int(_a['id'])}",
                on_click=_prefill_income_from_cash, args=(P, _a))

    _links_editor(P, "income", income_id)

    st.divider()
    c1, c2 = st.columns(2)
    if c1.button("Save changes", type="primary", width="stretch"):
        if not source:
            st.error("Source is required.")
            st.stop()
        db.update_row("income", income_id, {
            "source": source, "amount": amount,
            "received_ytd": received_ytd, "type": income_type or None,
            "tax_class": tax_class,
            "auto_deposit": 1 if auto_deposit else 0,
            "deposit_target": deposit_target or None,
            **sched_fields,
        })
        st.rerun()
    if c2.button("Cancel", width="stretch"):
        st.rerun()


@st.dialog("Edit Expense", width="large", on_dismiss="rerun")
def edit_expense(expense_id, data):
    P = f"ex_{expense_id}_{_edit_ver('expenses', expense_id)}_"   # fresh keys per open
    # A credit-card-minimum expense is FORCED to mirror its card's debt record:
    # category, name, amount, and schedule are shown (and re-derived at save),
    # not asked for. Editable here: which card, auto-draft, deductions, links.
    _cc_id = int(_n(data, "cc_min_debt_id")) if _s(data, "cc_min_debt_id") else None
    _cc_pick = None
    if _cc_id is not None:
        category = "Debt Payments"      # drives the cash-only draft rule below
        _ddf = db.load_df("debts")
        _ccs = (_ddf[_ddf["type"] == "revolving"]
                if not _ddf.empty and "type" in _ddf.columns else _ddf.iloc[0:0])
        if _ccs.empty:
            st.warning("No credit cards left on the Debts page — unlink this "
                       "expense to edit it by hand.")
        else:
            _opts = [(int(r["id"]), _s(r, "name") or "Card")
                     for _, r in _ccs.iterrows()]
            _ids = [i for i, _ in _opts]
            _pick_id, _pick_name = st.selectbox(
                "Credit card", _opts,
                index=_ids.index(_cc_id) if _cc_id in _ids else 0,
                key=f"{P}ccpick", format_func=lambda o: o[1],
                help="The card whose minimum this expense IS. Its amount, "
                     "schedule, and name stay synced to the card's debt record.")
            _cc_pick = _ccs[_ccs["id"] == _pick_id].iloc[0].to_dict()
            _ccf = stats.cc_min_expense_fields(_cc_pick)
            _dd = _n(_cc_pick, "due_day")
            st.markdown(f"**Synced from the card:** {_money(_ccf['amount'])}/mo"
                        + (f" · due the {_ordinal(int(_dd))}" if _dd > 0 else ""))
            st.caption("Kept up to date automatically — every card edit and each "
                       "statement close re-derive the amount, schedule, and name "
                       "from the card's debt record.")
            if _dd <= 0:
                st.caption(":orange[This card has no due day set, so the payment "
                           "can't land on the calendar — add one on the Debts page.]")
        if st.button("🔓 Unlink from the card", key=f"{P}ccunlink",
                     help="Stop syncing from the card. The expense keeps its current "
                          "amount, schedule, and name, and becomes freely editable."):
            db.update_row("expenses", expense_id, {"cc_min_debt_id": None})
            st.toast("Unlinked — this expense no longer follows the card; "
                     "reopen it to edit freely.")
            st.rerun()
    else:
        _c_opts, _c_idx = _dropdown_index(EXPENSE_CATEGORY_OPTIONS, _s(data, "category"))
        category = st.selectbox("Category", _c_opts, index=_c_idx, key=f"{P}cat")
        subcategory = st.text_input("Sub-category — optional", value=_s(data, "subcategory"),
                                    key=f"{P}subcat")

        st.divider()
        st.markdown("**Calendar scheduling** — when it's due, so it lands on the right "
                    "dates and the auto-draft forecast is accurate")
        # A debt-payment import (below) sets these widget keys directly (see
        # widgets.set_schedule_widget_keys), so the seeded saved schedule is overridden.
        sched_fields = widgets.schedule_widget(recurrence.from_row(data), key_prefix=f"{P}sch")

        st.divider()
        # Set (a fixed amount) or Variable (past-year amounts + how to project them).
        amount, var_fields, _amt_err = widgets.expense_amount_widget(
            sched_fields, P, defaults=data)

        # Prefill amount / schedule from a linked debt's payment (e.g. a mortgage). An
        # expense can be linked to several debts (possibly across different groups), so
        # show one button per linked debt that has a payment — each labeled with the debt
        # — and let the user pick exactly which to import instead of auto-choosing one.
        _pay_debts = [d for d in _linked_records("expenses", expense_id, "debts")
                      if _n(d, "min_payment") > 0]
        if _pay_debts:
            if len(_pay_debts) > 1:
                st.caption("Import a payment from a linked debt:")
            for _d in sorted(_pay_debts, key=lambda d: _s(d, "name").lower()):
                _mp, _dd = _n(_d, "min_payment"), _n(_d, "due_day")
                st.button(
                    f"↪ Use {_s(_d, 'name')} payment: {_money(_mp)}/mo"
                    + (f", due {_ordinal(int(_dd))}" if _dd > 0 else ""),
                    key=f"{P}pf_debt_{int(_d['id'])}",
                    on_click=_prefill_expense_from_debt, args=(P, _d))

    st.divider()
    auto_draft = st.checkbox("Auto-drafted", value=bool(int(_n(data, "auto_draft"))),
                             key=f"{P}auto")
    draft_source = None
    if auto_draft:
        try:
            import db as _db
            _adf = _db.load_df("assets")
            _cash  = _adf[_adf["asset_type"].apply(is_cash)
                          & ~_adf["account_type"].apply(is_distribution)]["name"].tolist()
            # A debt payment can't draft from another credit card — cash only.
            _cards = ([] if category == "Debt Payments" else
                      _db.load_df("debts").query("type == 'revolving'")["name"].tolist())
            _accts = _cash + _cards
        except Exception:
            _accts = []
        cur_ds = _s(data, "draft_source")
        if _accts:
            _opts = ["— enter manually —"] + _accts
            _idx = _opts.index(cur_ds) if cur_ds in _opts else 0
            _choice = st.selectbox("Drafts from", _opts, index=_idx, key=f"{P}draftsel")
            draft_source = (_choice if _choice != "— enter manually —"
                            else st.text_input("Account", value=cur_ds, key=f"{P}draftman"))
        else:
            draft_source = st.text_input("Drafts from", value=cur_ds, key=f"{P}drafttext")

    st.divider()
    ded = widgets.deductible_widgets(P, data)

    _links_editor(P, "expenses", expense_id)

    st.divider()
    c1, c2 = st.columns(2)
    if c1.button("Save changes", type="primary", width="stretch"):
        if ded["deductible"] and not (ded["deduct_federal"] or ded["deduct_state"]):
            st.error("A deductible expense must apply to Federal and/or State.")
            st.stop()
        if _cc_id is not None:
            # Everything but drafts/deductions re-derives from the picked card.
            if _cc_pick is None:
                st.error("No card to sync from — unlink this expense to edit "
                         "it by hand.")
                st.stop()
            db.update_row("expenses", expense_id, {
                **stats.cc_min_expense_fields(_cc_pick),
                "auto_draft": 1 if auto_draft else 0,
                "draft_source": draft_source or None,
                **ded,
            })
            st.rerun()
        if not category:
            st.error("Category is required.")
            st.stop()
        if _amt_err:
            st.error(f"Finish the variable amounts — {_amt_err}.")
            st.stop()
        # Keep the stored "pays off this debt" pairing, unless a debt payment was
        # just imported (which re-points it). The group manager edits it directly.
        _stored_pays = int(_n(data, "pays_debt_id")) if _s(data, "pays_debt_id") else None
        _pays = st.session_state.get(f"{P}pays_debt", _stored_pays)
        db.update_row("expenses", expense_id, {
            "category": category, "subcategory": subcategory or None,
            "amount": amount,
            "auto_draft": 1 if auto_draft else 0,
            "draft_source": draft_source or None,
            "pays_debt_id": _pays,
            **sched_fields,
            **var_fields,
            **ded,
        })
        st.rerun()
    if c2.button("Cancel", width="stretch"):
        st.rerun()
