"""
credit_page.py — the Credit Accounts page: a 30-day projection of every revolving
credit card's balance (what you owe), the mirror of the Cash Accounts page. New
charges (auto-drafted expenses on the card) and monthly interest raise the balance;
the minimum payment on the due day lowers it. The risk flag is going OVER the
credit limit (vs. a cash account dipping below $0).
"""

from itertools import groupby

import altair as alt
import pandas as pd
import streamlit as st

import accounts as accts
import cards
import db
from ui import pct
from utils import esc, fmt_date, money


@st.cache_data(show_spinner=False)
def cached_credit_projections(debts, expenses, start, end):
    """30-day projection of every credit card, cached per data-state (st.cache_data
    hashes the frames, so a plain rerun reuses it and only an edit recomputes)."""
    return accts.project_all_credit(debts, expenses, start, end)


def over_limit_alerts(debts, expenses):
    """Cards projected to exceed their credit limit in the rolling 30-day window —
    shared with the Overview banner."""
    start, end = accts.default_window()
    return [{"name": p["name"], "peak_balance": p["peak_balance"],
             "peak_date": p["peak_date"], "credit_limit": p["credit_limit"]}
            for p in cached_credit_projections(debts, expenses, start, end)
            if p["over_limit"]]


def credit_accounts_page():
    st.header("Credit Accounts")
    debts = db.load_df("debts")
    expenses = db.load_df("expenses")

    start, end = accts.default_window()
    projections = cached_credit_projections(debts, expenses, start, end)

    st.caption(esc(
        f"Projected daily balances for your credit cards over the next 30 days "
        f"({fmt_date(start)} → {fmt_date(end)}). New charges (auto-drafted bills on "
        "the card) and monthly interest raise the balance; the minimum payment — set "
        "by the balance when the statement closes — lowers it on the due day. A card "
        "projected to exceed its credit limit is flagged here and on the Overview page."))

    if not projections:
        st.info("No credit cards yet. Add a **Credit Card** on the Debts page "
                "(set its limit and minimum-payment rule) to project its balance.")
        return

    over = [p for p in projections if p["over_limit"]]
    if over:
        lines = " · ".join(
            f"**{p['name']}** peaks at {money(p['peak_balance'])} on "
            f"{fmt_date(p['peak_date'])} (limit {money(p['credit_limit'])})"
            for p in over)
        st.error(esc(f"⚠️ Over-limit alert — {lines}."))
    else:
        st.success("All credit cards stay within their limit through the projection window.")

    # Projections carry card NAMES (the identity auto-drafts match by); map them
    # back to their debt rows so each card can open its editor.
    _did = {str(r["name"]): int(r["id"]) for _, r in debts.iterrows()}

    for p in projections:
        with st.container(border=True):
            hc, he = st.columns([6, 1], vertical_alignment="center")
            hc.subheader(p["name"])
            _rid = _did.get(p["name"])
            if _rid is not None and he.button(
                    "Edit ↗", key=f"creditpg_edit_{_rid}", width="stretch",
                    help="Edit the underlying debt record"):
                cards.request_edit("debts", _rid)
                st.rerun()          # consume_pending_edit opens the editor
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Current balance", money(p["start_balance"]))
            c2.metric("Projected peak", money(p["peak_balance"]))
            c3.metric("End of window", money(p["end_balance"]))
            c4.metric("APR", pct(p["apr"], 2) if p["apr"] else "—")
            lim = p["credit_limit"]
            if lim:
                util = p["utilization"]
                avail = lim - p["end_balance"]
                m1, m2, m3 = st.columns(3)
                m1.metric("Credit limit", money(lim))
                m2.metric("Utilization (end)", f"{util * 100:.0f}%" if util is not None else "—")
                m3.metric("Available (end)", money(avail))
            if p["over_limit"]:
                st.error(esc(f"Projected to exceed the {money(lim)} limit — peaks at "
                             f"{money(p['peak_balance'])} on {fmt_date(p['peak_date'])} "
                             f"(${p['peak_balance'] - lim:,.0f} over)."))
            elif not lim:
                st.caption(":orange[No credit limit set — add one on the Debts page to "
                           "track utilization and get an over-limit warning.]")

            # Daily balance line, with the credit limit as a red baseline so a breach
            # is unmistakable (mirrors the $0 baseline on the cash page).
            chart_df = pd.DataFrame([{"Date": r["date"], "Balance": r["balance"]}
                                     for r in p["rows"]])
            base = alt.Chart(chart_df).encode(
                x=alt.X("Date:T", title="", axis=alt.Axis(format="%m/%d")),
                y=alt.Y("Balance:Q", title="", axis=alt.Axis(format="$,.0f"),
                        scale=alt.Scale(zero=True)),
                tooltip=[alt.Tooltip("Date:T", format="%m/%d/%Y"),
                         alt.Tooltip("Balance:Q", format="$,.2f")])
            area = base.mark_area(opacity=0.12, color="#d62728")
            line = base.mark_line(color="#d62728", strokeWidth=2)
            layers = [area, line]
            if lim:
                layers.append(alt.Chart(pd.DataFrame({"y": [lim]}))
                              .mark_rule(color="#d62728", strokeDash=[4, 4], size=1.5)
                              .encode(y="y:Q"))
            st.altair_chart(alt.layer(*layers), width="stretch")

            # Itemized ledger grouped per date: charges (+), interest (+), payments (−).
            ledger = p["ledger"]
            _FLOW = {"charge": "⬆ Charge", "payment": "⬇ Payment", "interest": "✦ Interest"}
            n_days = len({e["date"] for e in ledger})
            with st.expander(f"Balance detail — {len(ledger)} transaction(s) over {n_days} day(s)"):
                if ledger:
                    for dt, _grp in groupby(ledger, key=lambda e: e["date"]):
                        grp = list(_grp)
                        day_net = sum(e["amount"] for e in grp)
                        end_bal = grp[-1]["balance"]
                        net_str = f"+{money(day_net)}" if day_net > 0 else money(day_net)
                        # On a card, a balance INCREASE (positive net) is the bad direction.
                        color = "red" if day_net > 0 else "green"
                        st.markdown(
                            f"**{fmt_date(dt)}**  ·  net :{color}[{esc(net_str)}]  ·  "
                            f"balance {esc(money(end_bal))}")
                        tdf = pd.DataFrame([{
                            "Flow": _FLOW.get(e["kind"], e["kind"].title()),
                            "Item": e["label"],
                            "Description": e["detail"],
                            "Charge": e["amount"] if e["amount"] > 0 else None,
                            "Payment": -e["amount"] if e["amount"] < 0 else None,
                            "Balance": e["balance"],
                        } for e in grp])
                        st.dataframe(
                            tdf,
                            column_config={
                                "Charge":  st.column_config.NumberColumn("Charge", format="$%.2f"),
                                "Payment": st.column_config.NumberColumn("Payment", format="$%.2f"),
                                "Balance": st.column_config.NumberColumn("Balance", format="$%.2f"),
                            },
                            hide_index=True, width="stretch",
                            height=(len(grp) + 1) * 35 + 2)
                    st.caption("Grouped by date. On the due day interest posts, then the "
                               "minimum payment; each row's balance is after that transaction.")
                else:
                    st.caption("No charges, payments, or interest hit this card in the "
                               "window. Mark expenses auto-drafted to this card, and set "
                               "its due day, to project its balance.")
