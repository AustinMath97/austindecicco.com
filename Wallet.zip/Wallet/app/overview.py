"""
overview.py — the Overview page: net-worth metrics and chart, allocation and
class summaries, debt-payoff ranking, low-balance alerts, and the auto-draft /
auto-deposit sections. Split out of dashboard.py (which keeps the router).
"""

import calendar as _calendar
from datetime import date

import altair as alt
import pandas as pd
import streamlit as st

import accounts as accts
import cards
import cash_page
import charting
import credit_page
import data_management as datamgmt
import db
import prices
import recurrence
import stats
import taxes
from ui import flash, num, pct
from utils import (asset_family, esc, fmt_date, is_cash, is_investment_holding,
                   money, safe_str)


def months_remaining_in_year():
    today = date.today()
    return 12 - today.month  # whole months left after the current one


def _num_or_nan(v):
    """A cell as a float, keeping missing values (SQL NULL → None / NaN) as NaN
    instead of crashing on float(None). Used for assets/debts, which are unknown
    on net-worth-only (imported) snapshots and should gap the chart, not read 0."""
    return float(v) if pd.notna(v) else float("nan")




# --- overview page ---------------------------------------------------------

_MONTH_ABBR = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
               "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]


def autodraft_section(assets, debts, expenses):
    """Bottom-of-overview view of every debit/credit card and the bills that
    auto-draft from it, with a month-by-month outflow table (annual bills land
    in a single month, so each month's total differs)."""
    st.divider()
    st.subheader("Auto-draft outflows by Card")

    if expenses.empty or "auto_draft" not in expenses.columns:
        st.caption("No expenses yet.")
        return

    ad = expenses[expenses["auto_draft"] == 1].copy()
    ad["draft_source"] = ad["draft_source"].astype("string").fillna("").str.strip()
    ad = ad[ad["draft_source"] != ""]
    if ad.empty:
        st.caption("No bills are set to auto-draft. On the Expenses page, mark a "
                   "bill as auto-drafted and choose the account it drafts from.")
        return

    debit_names = (set(assets.loc[assets["asset_type"].apply(is_cash), "name"])
                   if not assets.empty else set())
    credit_names = (set(debts.loc[debts["type"] == "revolving", "name"])
                    if not debts.empty and "type" in debts.columns else set())

    def kind(name):
        if name in credit_names:
            return "Credit card"
        if name in debit_names:
            return "Debit / bank"
        return "Other account"

    accounts = sorted(ad["draft_source"].unique())
    matrix = {a: [0.0] * 12 for a in accounts}      # 12 monthly outflows per account
    unscheduled = {a: 0.0 for a in accounts}        # bills with a cost but no placement
    bills = {a: [] for a in accounts}

    # Place each bill on its real months via its recurrence schedule (a quarterly
    # bill only in its months, a weekly one 4–5×/month). A representative year
    # (this one) fixes weekday/biweekly counts; the matrix shows that typical year.
    _year = date.today().year
    _today = date.today()
    for _, r in ad.iterrows():
        acct = r["draft_source"]
        sub = safe_str(r.get("subcategory"))
        label = sub or safe_str(r.get("category")) or "Expense"
        sched = recurrence.from_row(r)
        placed = 0.0
        for mo in range(1, 13):
            mdays = _calendar.monthrange(_year, mo)[1]
            month_sum = sum(stats.occurrence_amounts(
                r, date(_year, mo, 1), date(_year, mo, mdays), _today).values())
            matrix[acct][mo - 1] += month_sum
            placed += month_sum
        annual_cost = stats.expense_annual_amount(r)        # set or variable
        amt = float(r["amount"] or 0.0)
        freq_label = safe_str(r.get("frequency")) or recurrence.frequency_label(sched.get("type"))
        if stats.is_variable(r):
            freq_label = f"{freq_label} · variable"
        if placed == 0 and annual_cost > 0:
            # Has an annual run-rate but no calendar placement (e.g. an annual bill
            # with no date set) — count it in the yearly outflow without a month.
            unscheduled[acct] += annual_cost
            bills[acct].append({"Bill": label, "Frequency": f"{freq_label} (no date set)",
                                "Amount": amt, "Annual": annual_cost})
        else:
            bills[acct].append({"Bill": label, "Frequency": freq_label,
                                "Amount": amt, "Annual": annual_cost})

    # Grand per-month totals; the "base" outflow is the floor that goes out every
    # month (the smallest month), and lumpy bills push individual months above it.
    grand = [sum(matrix[a][mo] for a in accounts) for mo in range(12)]
    monthly_base = min(grand) if grand else 0.0
    annual_total = sum(grand) + sum(unscheduled.values())
    m = st.columns(3)
    m[0].metric("Accounts drafting", len(accounts))
    m[1].metric("Monthly base outflow", money(monthly_base))
    m[2].metric("Annual outflow", money(annual_total))
    st.caption("Each month is the drafts that actually land that month on their "
               "schedules, so the monthly total varies across the year; the base is "
               "the floor that goes out every month.")

    # Month-by-month outflow table (months × accounts, with Total and Year rows).
    table = pd.DataFrame({a: matrix[a] for a in accounts}, index=_MONTH_ABBR)
    table["Total"] = table.sum(axis=1)
    table.loc["Year"] = table.sum(axis=0)
    table.index.name = "Month"
    colcfg = {c: st.column_config.NumberColumn(c, format="$%.0f") for c in table.columns}
    st.dataframe(table.reset_index(), column_config=colcfg,
                 hide_index=True, width="stretch")

    if any(unscheduled.values()):
        st.caption(esc(
            f"Note: {money(sum(unscheduled.values()))}/yr of annual auto-drafts have "
            "no due month set, so they're excluded from the monthly table — add a "
            "due month on the Expenses page to place them."))

    # Per-account bill lists.
    for acct in accounts:
        acct_annual = sum(matrix[acct]) + unscheduled[acct]
        with st.expander(esc(f"{acct} · {kind(acct)} — {money(acct_annual)}/yr")):
            st.dataframe(
                pd.DataFrame(bills[acct]),
                column_config={
                    "Amount": st.column_config.NumberColumn("Amount", format="$%.2f"),
                    "Annual": st.column_config.NumberColumn("Annual", format="$%.2f"),
                },
                hide_index=True, width="stretch")


def autodeposit_section(income):
    """Overview view of every account that income auto-deposits into, with a
    month-by-month inflow table (paychecks land per each stream's schedule, so the
    monthly totals differ). The income-side mirror of autodraft_section."""
    st.divider()
    st.subheader("Auto-deposit inflows by Account")

    if income.empty or "auto_deposit" not in income.columns:
        st.caption("No income yet.")
        return

    ad = income[income["auto_deposit"] == 1].copy()
    ad["deposit_target"] = ad["deposit_target"].astype("string").fillna("").str.strip()
    ad = ad[ad["deposit_target"] != ""]
    if ad.empty:
        st.caption("No income is set to auto-deposit. On the Income page, mark a stream "
                   "as auto-deposited and choose the account it lands in.")
        return

    year = date.today().year
    accounts = sorted(ad["deposit_target"].unique())
    matrix = {a: [0.0] * 12 for a in accounts}      # 12 monthly inflows per account
    streams = {a: [] for a in accounts}

    for _, r in ad.iterrows():
        acct = r["deposit_target"]
        pay = float(r["pay_amount"]) if pd.notna(r.get("pay_amount")) and r.get("pay_amount") else 0.0
        annual = float(r["amount"] or 0.0)
        label = safe_str(r.get("source")) or "Income"
        sched = recurrence.from_row(r)
        if pay > 0 and sched.get("type") not in (None, "", recurrence.NONE):
            vals = [len(recurrence.occurrences_in_month(sched, year, mo)) * pay
                    for mo in range(1, 13)]
            sched_label = safe_str(r.get("pay_day")) or "Scheduled"
        else:
            # No per-occurrence schedule/amount: spread the full-year total evenly.
            vals = [annual / 12.0] * 12
            sched_label = "Spread evenly"
        for mo in range(12):
            matrix[acct][mo] += vals[mo]
        streams[acct].append({"Stream": label, "Schedule": sched_label, "Annual": sum(vals)})

    annual_total = sum(sum(v) for v in matrix.values())
    mcol = st.columns(3)
    mcol[0].metric("Accounts receiving", len(accounts))
    mcol[1].metric("Avg monthly inflow", money(annual_total / 12))
    mcol[2].metric("Annual inflow", money(annual_total))
    st.caption("Each month reflects how many times each stream pays that month per its "
               "schedule, so a month with an extra paycheck shows more.")

    table = pd.DataFrame({a: matrix[a] for a in accounts}, index=_MONTH_ABBR)
    table["Total"] = table.sum(axis=1)
    table.loc["Year"] = table.sum(axis=0)
    table.index.name = "Month"
    colcfg = {c: st.column_config.NumberColumn(c, format="$%.0f") for c in table.columns}
    st.dataframe(table.reset_index(), column_config=colcfg, hide_index=True, width="stretch")

    for acct in accounts:
        acct_annual = sum(matrix[acct])
        with st.expander(esc(f"{acct} — {money(acct_annual)}/yr")):
            st.dataframe(
                pd.DataFrame(streams[acct]),
                column_config={"Annual": st.column_config.NumberColumn("Annual", format="$%.2f")},
                hide_index=True, width="stretch")


def overview_page():
    st.header("Overview")

    assets = db.load_df("assets")
    debts = db.load_df("debts")
    income = db.load_df("income")
    expenses = db.load_df("expenses")
    fed = db.get_constant("fed_funds_rate")

    # Stale-record flag: any record past its update window (Data Management page).
    # Passing the frames just loaded avoids re-reading all four tables for the check.
    datamgmt.render_stale_flag(frames={"assets": assets, "debts": debts,
                                       "income": income, "expenses": expenses})

    # Low-balance alert: flag any cash account projected to fall below $0 over the next
    # 30 days. Forced to the top of the Overview so it can't be missed.
    at_risk = cash_page.low_balance_alerts(assets, income, expenses)
    if at_risk:
        lines = " · ".join(
            f"**{a['name']}** → {money(a['min_balance'])} on {fmt_date(a['min_date'])}"
            for a in at_risk)
        st.error(esc(
            f"⚠️ Low-balance alert — projected to fall below $0: {lines}. "
            "Open the **Cash Accounts** page for the day-by-day projection."))

    # Over-limit alert: the credit-card mirror — flag any card projected to exceed
    # its limit over the next 30 days, surfaced up top the same way.
    over_limit = credit_page.over_limit_alerts(debts, expenses)
    if over_limit:
        lines = " · ".join(
            f"**{a['name']}** → {money(a['peak_balance'])} on {fmt_date(a['peak_date'])} "
            f"(limit {money(a['credit_limit'])})"
            for a in over_limit)
        st.error(esc(
            f"⚠️ Over-limit alert — projected to exceed the credit limit: {lines}. "
            "Open the **Credit Accounts** page for the day-by-day projection."))

    nw = stats.net_worth(assets, debts)
    ta = stats.total_assets(assets)
    td = stats.total_debts(debts)
    # Liquid nets out margin loans (borrowed against the portfolio → negative liquidity).
    liquid = stats.net_liquid_assets(assets, debts)
    runway = stats.runway_months(assets, expenses, debts)
    wapr = stats.weighted_avg_apr(debts)
    ytd, expected, eoy = stats.income_totals(income)
    proj = stats.projected_eoy_net_worth(assets, debts, income, expenses, months_remaining_in_year())
    ann_exp_v = stats.annual_expenses(expenses)
    burn_v = stats.monthly_recurring_expenses(expenses)
    gl_abs, _ = stats.unrealized_gain_loss(assets)
    if pd.isna(gl_abs):
        gl_label = "—"
    else:
        gl_label = ("+" + money(gl_abs)) if gl_abs >= 0 else money(gl_abs)

    # ── New band metrics ─────────────────────────────────────────────────────
    invested_total = sum(a["value"] for a in stats.investment_accounts(assets))
    net_flow = stats.monthly_net_cash_flow(income, expenses)
    cash_int_yr = sum(
        accts.interest_income_amounts(a["balance"], a["apy"], a["sched"])[0]
        for a in accts.cash_accounts(assets) if a["apy"] > 0)
    debt_int_yr = stats.yearly_debt_interest(debts)
    # A debt linked to an expense is the same payment — count it once (via the
    # expense), so the "due in 7 days" total isn't inflated by the pair.
    _due_debts = (debts[~debts["id"].isin(db.linked_id_set("debts", "expenses"))]
                  if not debts.empty and "id" in debts.columns else debts)
    due7 = stats.due_within_days(expenses, _due_debts, date.today(), 7)
    nxt_inc = stats.next_income_event(income, date.today())
    # Lowest projected cash balance over the rolling 30 days (cached projection,
    # shared with the low-balance alert above).
    _pstart, _pend = accts.default_window()
    _projs = cash_page.cached_projections(assets, income, expenses, _pstart, _pend)
    cash_low = min(_projs, key=lambda p: p["min_balance"]) if _projs else None

    df_months, df_note = stats.debt_free_months(debts)
    if td <= 0:
        df_label, df_help = "✓ Debt-free", "No debts carry a balance."
    elif df_months is None:
        df_label = "Never (min pmts)"
        df_help = (f"{df_note} (≤ its monthly interest) — raise the payment "
                   "to get a date.")
    elif df_months == 0:
        df_label, df_help = "—", (f"No debt has a minimum payment set "
                                  f"({df_note}).")
    else:
        _t = date.today()
        _y2 = _t.year + (_t.month - 1 + df_months) // 12
        _m2 = (_t.month - 1 + df_months) % 12 + 1
        df_label = date(_y2, _m2, 1).strftime("%b %Y")
        df_help = (f"The last debt pays off in ~{df_months} months at minimum "
                   "payments." + (f" Note: {df_note}." if df_note else ""))

    # Shared computation (taxes.ytd_tax_debt_net) so the Overview band, the Taxes
    # page, and snapshot capture always agree on this figure.
    tax_net = taxes.ytd_tax_debt_net(income, db.get_constant)

    # Snapshot history backs the change-over-range deltas under the metrics.
    ov_hist = db.snapshot_history()
    if not ov_hist.empty:
        ov_hist = ov_hist.copy()
        ov_hist["taken_at"] = pd.to_datetime(ov_hist["taken_at"]).dt.tz_localize(None)
        # Derived history columns so two of the new metrics get range deltas:
        # net cash flow from the captured income/burn metrics, and the invested
        # total from the account-tagged item history (NaN where untagged/missing,
        # so no fake zero baselines).
        ov_hist["net_cash_flow"] = ((ov_hist["income_ytd"]
                                     + ov_hist["income_expected"]) / 12.0
                                    - ov_hist["monthly_burn"])
        _items = db.snapshot_asset_items_history()
        if not _items.empty:
            _inv = (_items[_items["asset_type"].apply(is_investment_holding)]
                    .groupby("snapshot_id")["value"].sum())
            ov_hist["invested"] = ov_hist["id"].map(_inv)
        else:
            ov_hist["invested"] = float("nan")

    # The metric rows render INTO this slot so they stay first on the page, but
    # the range picker below is consulted before they're drawn — its buttons sit
    # under the metrics yet drive the deltas shown on them.
    metrics_slot = st.container()
    st.caption("Change window — the changes shown under the metrics above are "
               "over this range:")
    dom_start, dom_end, ov_tf = charting.range_picker("ov", ov_hist, default="1M")

    _now_ts = pd.Timestamp.now(tz="UTC").tz_localize(None)
    _jan1 = pd.Timestamp(_now_ts.year, 1, 1)

    def _range_delta(col, live_value, year_gated=False, inverse=False):
        """(delta_text, delta_color, delta_arrow) for metric `col` over the picked
        range. delta_text is None when it can't be computed (no history, or the
        metric wasn't captured at the baseline snapshot on an older DB). A
        year-gated metric whose window reaches into a previous year reads
        'omitted by range' in gray — YTD-style figures reset on Jan 1, so a
        cross-year delta would compare apples to last year's oranges. A
        genuinely flat range reads '▬ no change' in the same gray, arrow
        suppressed, so both states stay distinguishable from 'no data'."""
        color = "inverse" if inverse else "normal"
        if ov_hist.empty:
            return None, color, "auto"
        prior = ov_hist[ov_hist["taken_at"] <= dom_start]
        base_row = prior.iloc[-1] if not prior.empty else ov_hist.iloc[0]
        if year_gated:
            if dom_start < _jan1:
                # The window itself reaches into a previous year — no comparable
                # baseline exists for a figure that resets on Jan 1.
                return "omitted by range", "off", "off"
            if base_row["taken_at"] < _jan1:
                # Window is inside this year, but the carry-forward baseline
                # landed in December (YTD starts at exactly Jan 1 00:00, before
                # the year's first snapshot). Use the first snapshot INSIDE the
                # window instead of declaring it omitted.
                inside = ov_hist[(ov_hist["taken_at"] >= dom_start)
                                 & (ov_hist["taken_at"] <= dom_end)]
                if inside.empty:
                    return None, color, "auto"
                base_row = inside.iloc[0]
        base_v = base_row[col]
        if pd.isna(base_v):
            return None, color, "auto"
        if dom_end >= _now_ts - pd.Timedelta(minutes=1):
            end_v = float(live_value)            # range ends now → live value
        else:                                    # custom range ending in the past
            upto = ov_hist[ov_hist["taken_at"] <= dom_end]
            if upto.empty or pd.isna(upto.iloc[-1][col]):
                return None, color, "auto"
            end_v = float(upto.iloc[-1][col])
        d = end_v - float(base_v)
        if abs(d) < 0.005:
            # Flat ≠ missing: show it in gray with a flat-line glyph, no arrow.
            return "▬ no change", "off", "off"
        return (f"+{money(d)}" if d > 0 else money(d)), color, "auto"

    with metrics_slot:
        # ── 💰 Worth ─────────────────────────────────────────────────────────
        with st.container(border=True):
            st.markdown("**💰 Worth**")
            d_nw, c_nw, a_nw = _range_delta("net_worth", nw)
            d_ta, c_ta, a_ta = _range_delta("assets", ta)
            d_td, c_td, a_td = _range_delta("debts", td, inverse=True)
            d_lq, c_lq, a_lq = _range_delta("liquid_assets", liquid)
            d_iv, c_iv, a_iv = _range_delta("invested", invested_total)
            b = st.columns(5)
            b[0].metric("Net worth", money(nw), delta=d_nw, delta_color=c_nw,
                        delta_arrow=a_nw)
            b[1].metric("Total assets", money(ta), delta=d_ta, delta_color=c_ta,
                        delta_arrow=a_ta)
            b[2].metric("Total debts", money(td), delta=d_td, delta_color=c_td,
                        delta_arrow=a_td)
            b[3].metric("Liquid assets", money(liquid), delta=d_lq,
                        delta_color=c_lq, delta_arrow=a_lq)
            b[4].metric("Total Invested Assets", money(invested_total), delta=d_iv,
                        delta_color=c_iv, delta_arrow=a_iv,
                        help="Gross market value of everything in investment "
                             "accounts — brokerage, retirement, crypto, inherited "
                             "(the Investment Accounts page's Total Invested Assets).")

        # ── 🔄 Cash flow ─────────────────────────────────────────────────────
        with st.container(border=True):
            st.markdown("**🔄 Cash flow**")
            d_cf, c_cf, a_cf = _range_delta("net_cash_flow", net_flow)
            d_mb, c_mb, a_mb = _range_delta("monthly_burn", burn_v, inverse=True)
            d_ae, c_ae, a_ae = _range_delta("annual_expenses", ann_exp_v,
                                            inverse=True)
            b = st.columns(4)
            b[0].metric("Net cash flow / mo", money(net_flow), delta=d_cf,
                        delta_color=c_cf, delta_arrow=a_cf,
                        help="Expected yearly income ÷ 12, minus the monthly "
                             "burn — gaining or losing money in a typical month?")
            b[1].metric("Monthly burn", money(burn_v), delta=d_mb,
                        delta_color=c_mb, delta_arrow=a_mb)
            b[2].metric("Annual expenses", money(ann_exp_v), delta=d_ae,
                        delta_color=c_ae, delta_arrow=a_ae)
            d_ci, c_ci, a_ci = _range_delta("cash_interest_yr", cash_int_yr)
            b[3].metric("Cash interest / yr", money(cash_int_yr),
                        delta=d_ci, delta_color=c_ci, delta_arrow=a_ci,
                        help="What your cash accounts pay per year at their "
                             "APYs and payout schedules.")

        # ── ⏱ Near term ──────────────────────────────────────────────────────
        with st.container(border=True):
            st.markdown("**⏱ Near term**")
            b = st.columns(4)
            if cash_low is not None:
                b[0].metric("30-day cash low", money(cash_low["min_balance"]),
                            help=f"Lowest projected balance in the next 30 days: "
                                 f"{cash_low['name']} on "
                                 f"{fmt_date(cash_low['min_date'])} — see the "
                                 "Cash Accounts page.")
            else:
                b[0].metric("30-day cash low", "—",
                            help="No cash accounts to project yet.")
            b[1].metric("Due next 7 days", money(due7),
                        help="Bills and debt payments scheduled in the coming "
                             "week (calendar due dates).")
            if nxt_inc is not None:
                _nd, _namt, _nsrc = nxt_inc
                b[2].metric("Next income", f"{_nd.strftime('%m/%d')} · {money(_namt)}",
                            help=f"{_nsrc} on {fmt_date(_nd)}.")
            else:
                b[2].metric("Next income", "—",
                            help="No income stream has both a schedule and a "
                                 "per-payment amount yet.")
            b[3].metric("Runway (months)", num(runway),
                        help="How many months your liquid assets could cover "
                             "the monthly burn.")

        # ── 🏦 Debt ──────────────────────────────────────────────────────────
        with st.container(border=True):
            st.markdown("**🏦 Debt**")
            b = st.columns(3)
            b[0].metric("Interest cost / yr", money(debt_int_yr),
                        help="Balance × APR summed across debts — what they "
                             "cost per year just to exist, at current balances.")
            b[1].metric("Wtd. avg APR", pct(wapr, 2),
                        help="Average interest rate across debts, weighted by "
                             "balance.")
            b[2].metric("Debt-free (est.)", df_label, help=df_help)

        # ── 📅 This year ─────────────────────────────────────────────────────
        with st.container(border=True):
            st.markdown("**📅 This year**")
            d_yt, c_yt, a_yt = _range_delta("income_ytd", ytd, year_gated=True)
            d_ex, c_ex, a_ex = _range_delta("income_expected", expected,
                                            year_gated=True)
            d_pj, c_pj, a_pj = _range_delta("projected_eoy_net_worth", proj,
                                            year_gated=True)
            b = st.columns(5)
            b[0].metric("Income Year-to-Date", money(ytd), delta=d_yt,
                        delta_color=c_yt, delta_arrow=a_yt)
            b[1].metric("Expected (rest of yr)", money(expected), delta=d_ex,
                        delta_color=c_ex, delta_arrow=a_ex)
            b[2].metric("Projected EOY net worth", money(proj), delta=d_pj,
                        delta_color=c_pj, delta_arrow=a_pj)
            if pd.isna(gl_abs):                  # no basis-tracked positions
                d_gl, c_gl, a_gl = None, "normal", "auto"
            else:
                d_gl, c_gl, a_gl = _range_delta("unrealized_gl", gl_abs)
            b[3].metric("Unrealized G/L", gl_label, delta=d_gl,
                        delta_color=c_gl, delta_arrow=a_gl,
                        help="Value minus cost basis, summed over positions "
                             "that track a basis.")
            d_tx, c_tx, a_tx = _range_delta("ytd_tax_debt_net", tax_net,
                                            year_gated=True, inverse=True)
            b[4].metric("YTD tax debt", money(tax_net), delta=d_tx,
                        delta_color=c_tx, delta_arrow=a_tx,
                        help="Estimated income tax on what you've received "
                             "this year, minus tax already withheld — matches "
                             "the Taxes page. Negative = projected refund.")

    st.divider()

    # Build both "by class" breakdowns up front so the two side-by-side charts can
    # share one height — whichever list is longer sets it — keeping the panels
    # aligned regardless of how many classes each has.
    def _grouped(rows):
        if not rows:
            return None
        c = pd.DataFrame(rows).groupby(["Class", "Kind"], as_index=False)["Amount"].sum()
        c["Magnitude"] = c["Amount"].abs()
        return c.sort_values("Amount", ascending=True)

    # ── Assets (positive) & Debts (negative) ──
    rows = []
    if not assets.empty and "value" in assets.columns:
        _eff = assets.assign(_ev=stats.effective_asset_values(assets),
                             _fam=assets["asset_type"].apply(asset_family))
        for fam, amt in _eff.groupby("_fam")["_ev"].sum().items():
            if amt:
                rows.append({"Class": cards.family_label(fam), "Kind": "Asset",
                             "Amount": float(amt)})
    if not debts.empty and "balance" in debts.columns:
        for typ, amt in debts.groupby("type", dropna=False)["balance"].sum().items():
            if amt:
                label = cards.DEBT_TYPE_LABEL.get(
                    typ, str(typ).replace("_", " ").title() if typ else "Other Debts")
                rows.append({"Class": label, "Kind": "Debt", "Amount": -float(amt)})
    comp = _grouped(rows)

    # ── Income (positive) & Expenses (negative, annual equivalent) ──
    rows2 = []
    if not income.empty and "amount" in income.columns:
        for typ, amt in income.groupby("type", dropna=False)["amount"].sum().items():
            if amt:
                label = cards.INCOME_TYPE_LABEL.get(
                    typ, str(typ).replace("_", " ").title() if typ else "Other")
                rows2.append({"Class": label, "Kind": "Income", "Amount": float(amt)})
    ann_exp = stats.annual_expenses(expenses)
    if not expenses.empty and "amount" in expenses.columns:
        _ex = expenses.copy()
        _ex["_annual"] = _ex.apply(stats.expense_annual_amount, axis=1)   # set or variable
        for cat, amt in _ex.groupby("category", dropna=False)["_annual"].sum().items():
            if amt:
                rows2.append({"Class": str(cat) if cat else "Other",
                              "Kind": "Expense", "Amount": -float(amt)})

    # Investment income vs realized investment losses are two sides of one number:
    # net them so only ONE bar ever shows, sized by the sum — $15k income against
    # $10k of losses reads as $5k of "Investment income", not two opposing bars.
    _inv_label = cards.INCOME_TYPE_LABEL.get("capital", "Investment income")
    _inc_row = next((r for r in rows2
                     if r["Kind"] == "Income" and r["Class"] == _inv_label), None)
    _loss_row = next((r for r in rows2 if r["Kind"] == "Expense"
                      and r["Class"] == cards.INVESTMENT_LOSS_CATEGORY), None)
    if _inc_row and _loss_row:
        _net = _inc_row["Amount"] + _loss_row["Amount"]   # loss amount is negative
        rows2.remove(_inc_row)
        rows2.remove(_loss_row)
        if _net > 0:
            rows2.append({"Class": _inv_label, "Kind": "Income", "Amount": _net})
        elif _net < 0:
            rows2.append({"Class": cards.INVESTMENT_LOSS_CATEGORY,
                          "Kind": "Expense", "Amount": _net})
    comp2 = _grouped(rows2)

    # Shared height, driven by whichever breakdown has more classes.
    n_left = len(comp) if comp is not None else 0
    n_right = len(comp2) if comp2 is not None else 0
    class_chart_h = max(160, max(n_left, n_right) * 26)

    left, right = st.columns(2)

    with left:
        st.subheader("Assets & Debts by Class")
        if comp is not None:
            bars = (
                alt.Chart(comp)
                .mark_bar()
                .encode(
                    x=alt.X("Amount:Q", axis=alt.Axis(format="$,.0f"), title=""),
                    # Force a label for every class. Streamlit's browser-side Vega
                    # theme thins / truncates discrete-axis labels, which on a short
                    # list silently drops names; pinning the tick values (and turning
                    # off overlap-removal / the label-width limit) shows them all.
                    y=alt.Y("Class:N", sort=None, title="",
                            axis=alt.Axis(labelOverlap=False, labelLimit=1000,
                                          values=comp["Class"].drop_duplicates().tolist())),
                    color=alt.Color(
                        "Kind:N",
                        scale=alt.Scale(domain=["Asset", "Debt"],
                                        range=["#2ca02c", "#d62728"]),
                        legend=alt.Legend(title=None, orient="top"),
                    ),
                    tooltip=[
                        alt.Tooltip("Class:N"),
                        alt.Tooltip("Kind:N"),
                        alt.Tooltip("Magnitude:Q", format="$,.0f", title="Amount"),
                    ],
                )
            )
            # Vertical reference line at net worth (assets − debts).
            nw_df = pd.DataFrame({"Net worth": [nw]})
            nw_rule = (
                alt.Chart(nw_df)
                .mark_rule(color="#1f77b4", strokeDash=[5, 4], size=2)
                .encode(x="Net worth:Q",
                        tooltip=[alt.Tooltip("Net worth:Q", format="$,.0f")])
            )
            nw_label = (
                alt.Chart(nw_df)
                .mark_text(color="#1f77b4", fontWeight="bold",
                           align="right", baseline="top", dx=-4, dy=2)
                .encode(x="Net worth:Q", y=alt.value(0),
                        text=alt.value(f"Net worth {money(nw)}"))
            )
            chart = alt.layer(bars, nw_rule, nw_label).properties(height=class_chart_h)
            st.altair_chart(chart, width="stretch")
        else:
            st.caption("Add assets or debts to see the breakdown.")
        # esc() so the multiple $ amounts aren't parsed as $…$ LaTeX math.
        st.caption(esc(
            f"(Total Assets) {money(ta)} − {money(td)} (Total Debts) = "
            f"Net Worth {money(nw)}."
        ))

    with right:
        st.subheader("Income & Expenses by Class")
        if comp2 is not None:
            bars2 = (
                alt.Chart(comp2)
                .mark_bar()
                .encode(
                    x=alt.X("Amount:Q", axis=alt.Axis(format="$,.0f"), title=""),
                    # See the note on the left chart: pin tick values so every class
                    # name shows (Streamlit's theme otherwise drops some on short lists).
                    y=alt.Y("Class:N", sort=None, title="",
                            axis=alt.Axis(labelOverlap=False, labelLimit=1000,
                                          values=comp2["Class"].drop_duplicates().tolist())),
                    color=alt.Color(
                        "Kind:N",
                        scale=alt.Scale(domain=["Income", "Expense"],
                                        range=["#2ca02c", "#d62728"]),
                        legend=alt.Legend(title=None, orient="top"),
                    ),
                    tooltip=[
                        alt.Tooltip("Class:N"),
                        alt.Tooltip("Kind:N"),
                        alt.Tooltip("Magnitude:Q", format="$,.0f", title="Amount / yr"),
                    ],
                )
            )
            # Vertical reference line at annual net cash flow (income − expenses).
            net_cf = eoy - ann_exp
            cf_df = pd.DataFrame({"Net / yr": [net_cf]})
            cf_rule = (
                alt.Chart(cf_df)
                .mark_rule(color="#1f77b4", strokeDash=[5, 4], size=2)
                .encode(x="Net / yr:Q",
                        tooltip=[alt.Tooltip("Net / yr:Q", format="$,.0f")])
            )
            cf_label = (
                alt.Chart(cf_df)
                .mark_text(color="#1f77b4", fontWeight="bold",
                           align="right", baseline="top", dx=-4, dy=2)
                .encode(x="Net / yr:Q", y=alt.value(0),
                        text=alt.value(f"Net / yr {money(net_cf)}"))
            )
            chart2 = alt.layer(bars2, cf_rule, cf_label).properties(height=class_chart_h)
            st.altair_chart(chart2, width="stretch")
        else:
            st.caption("Add income or expenses to see the breakdown.")
        # esc() so the multiple $ amounts aren't parsed as $…$ LaTeX math.
        st.caption(esc(
            f"(Annual Income) {money(eoy)} − {money(ann_exp)} (Annual Expenses) = "
            f"Net {money(eoy - ann_exp)}/Year."
        ))

    st.divider()
    st.subheader("Net worth over time")

    hist = db.snapshot_history()

    if hist.empty:
        st.caption("No snapshots yet. Take one below to start the time series.")
    else:
        hist = hist.copy()
        hist["taken_at"] = pd.to_datetime(hist["taken_at"]).dt.tz_localize(None)

        # ── Timeframe (shared picker; keys are unchanged from the old inline
        # version, so previously-saved selections carry over) ─────────────────
        dom_start, dom_end, tf = charting.range_picker("nw", hist, default="1Y")
        now = pd.Timestamp.now(tz="UTC").tz_localize(None)

        view = hist[(hist["taken_at"] >= dom_start) & (hist["taken_at"] <= dom_end)]

        if tf != "Custom":
            # Anchor the window's LEFT edge: when the first in-window snapshot sits
            # after the window start (or none falls inside at all — common for 1D/1W
            # between snapshots), carry the most recent EARLIER snapshot's value
            # forward to the start, so short windows draw a level line instead of
            # "no snapshots".
            prior = hist[hist["taken_at"] < dom_start]
            if not prior.empty and (view.empty or view["taken_at"].min() > dom_start):
                baseline = prior.loc[prior["taken_at"].idxmax()]
                view = pd.concat([pd.DataFrame([{
                    "id": pd.NA, "taken_at": dom_start,
                    "label": fmt_date(dom_start),
                    "net_worth": float(baseline["net_worth"]),
                    # assets/debts are NULL for net-worth-only (imported) snapshots
                    # — keep them NaN so the ghost lines gap there, rather than
                    # float(None) crashing or a misleading 0.
                    "assets": _num_or_nan(baseline["assets"]),
                    "debts": _num_or_nan(baseline["debts"]),
                }]), view], ignore_index=True)

        if view.empty:
            st.caption("No snapshots in this range.")
        else:
            # For preset ranges, carry the line forward to the present using the
            # live totals, so the graph ends at today rather than at the last
            # snapshot. Custom ranges honor the user's chosen end date instead.
            if tf != "Custom" and now > view["taken_at"].max():
                today_point = pd.DataFrame([{
                    "id": pd.NA, "taken_at": now,
                    "label": fmt_date(now), "net_worth": nw,
                    "assets": ta, "debts": td,
                }])
                view = pd.concat([view, today_point], ignore_index=True)
            view = view.sort_values("taken_at").reset_index(drop=True)

            # Hour-level AXIS labels on the short windows; dates elsewhere. The
            # hover tooltip always shows the exact snapshot timestamp, whatever
            # the window.
            ax_fmt = {"1D": "%I:%M %p", "1W": "%m/%d"}.get(tf, "%m/%d/%Y")
            tt_fmt = "%m/%d/%Y %I:%M:%S %p"

            # ── Window delta header ────────────────────────────────────────────
            first_nw = float(view.iloc[0]["net_worth"])
            last_nw = float(view.iloc[-1]["net_worth"])
            delta = last_nw - first_nw
            pct_part = f" ({delta / abs(first_nw) * 100:+.1f}%)" if first_nw else ""
            if delta > 0:
                st.markdown(f":green[▲ **+{money(delta)}**{pct_part} over this range]")
            elif delta < 0:
                st.markdown(f":red[▼ **{money(delta)}**{pct_part} over this range]")
            else:
                st.markdown(":gray[▬ flat over this range]")

            # Raw dollars vs %-change (each series rebased to its own first
            # visible point). Persisted via a shadow key, like the investment
            # chart — widget state alone is dropped when the page isn't drawn.
            if "nw_chart_mode" not in st.session_state:
                st.session_state["nw_chart_mode"] = st.session_state.get(
                    "_nw_mode_saved", "Raw value ($)")
            nw_mode = st.radio("Chart mode",
                               ["Raw value ($)", "Percentage change (%)"],
                               horizontal=True, key="nw_chart_mode")
            st.session_state["_nw_mode_saved"] = nw_mode

            # Hover crosshair: pointermove snaps to the NEAREST snapshot's x and
            # draws a dashed rule + tooltip there, so hovering anywhere on the
            # chart reads a value — no need to hit a point dead-on. Pan/zoom stays
            # enabled via .interactive(); there is deliberately no interval brush
            # (it drew stray highlight bars and fought with dragging).
            hover = alt.selection_point(fields=["taken_at"], nearest=True,
                                        on="pointermove", empty=False)
            x_enc = alt.X("taken_at:T", title="", axis=alt.Axis(format=ax_fmt))

            # All three series on one chart: the net-worth line front and center,
            # with the asset and debt totals behind it as faint "ghost" context
            # lines (per-series opacity/width scales; no fill, fixed colors).
            SERIES = ["Net worth", "Assets", "Debts"]
            long = view.melt(id_vars=["taken_at"],
                             value_vars=["net_worth", "assets", "debts"],
                             var_name="Series", value_name="Amount")
            long["Series"] = long["Series"].map(
                {"net_worth": "Net worth", "assets": "Assets", "debts": "Debts"})

            if nw_mode.startswith("Percentage"):
                parts, dropped = [], []
                for name, g in long.groupby("Series"):
                    g = g.sort_values("taken_at")
                    # Rebase to the first KNOWN (non-NaN) point, not the first
                    # row. A partly-unknown series — e.g. assets/debts across a
                    # stretch of net-worth-only snapshots — would otherwise blank
                    # entirely because its first in-window point was unknown;
                    # this way it draws from where its data actually begins (0%
                    # there), still gapping over the unknown stretch.
                    known = g["Amount"].dropna()
                    base_v = float(known.iloc[0]) if not known.empty else float("nan")
                    if not (base_v > 0):         # no known data, or non-positive base
                        dropped.append(name)     # → no meaningful % rebase
                        continue
                    parts.append(g.assign(Amount=(g["Amount"] / base_v - 1.0)
                                          * 100.0))
                long = (pd.concat(parts, ignore_index=True)
                        if parts else long.iloc[0:0])
                if dropped:
                    st.caption(":gray[Omitted (no positive value to rebase from): "
                               + ", ".join(dropped) + "]")
                y_enc = alt.Y("Amount:Q", title="% change from each line's first point",
                              axis=alt.Axis(format="+.1f"),
                              scale=alt.Scale(zero=False, padding=36))
                tt_amount = alt.Tooltip("Amount:Q", title="% change",
                                        format="+.2f")

                def _fmt_peak(v):
                    return f"{v:+.1f}%"
            else:
                # padding leaves pixel headroom above/below the data so the
                # High/Low text labels aren't clipped at the chart borders
                # (.interactive()'s zoom binding clips marks to the plot area,
                # so the label needs real clearance: 12px offset + bold ascent).
                y_enc = alt.Y("Amount:Q", title="",
                              axis=alt.Axis(format="$,.0f"),
                              scale=alt.Scale(zero=False, padding=36))
                tt_amount = alt.Tooltip("Amount:Q", title="Total",
                                        format="$,.0f")
                _fmt_peak = money

            # One layer per series with MARK-level opacity/width: opacity driven
            # by an encoding scale on a nominal field proved unreliable (the
            # ghost levels didn't track the configured range), and mark
            # properties are unambiguous. The shared color scale still merges
            # the three layers into a single legend.
            color_scale = alt.Scale(domain=SERIES,
                                    range=["#1f77b4", "#16a34a", "#dc2626"])

            def _series_line(name, opacity, width):
                return alt.Chart(long).transform_filter(
                    alt.datum.Series == name
                ).mark_line(opacity=opacity, strokeWidth=width).encode(
                    x=x_enc, y=y_enc,
                    color=alt.Color("Series:N", scale=color_scale,
                                    legend=alt.Legend(title=None, orient="top")),
                )

            present = set(long["Series"])
            if long.empty:
                st.caption("Nothing to draw in this mode for the current range.")
            else:
                # Ghost lines tuned by eye: clearly present, the net line on top.
                layer_specs = [("Assets", 0.35, 1.2), ("Debts", 0.45, 1.2),
                               ("Net worth", 1.0, 2.5)]
                layers = [_series_line(n, o, w) for n, o, w in layer_specs
                          if n in present]
                nw_chart = layers[0]
                for ly in layers[1:]:
                    nw_chart = nw_chart + ly

                # Points + High/Low ride the net-worth series in whichever units
                # the mode plots (dollars or rebased %).
                net_plot = (long[long["Series"] == "Net worth"]
                            .sort_values("taken_at").reset_index(drop=True))
                if not net_plot.empty:
                    nw_chart = nw_chart + alt.Chart(net_plot).mark_point(
                        filled=True, size=40, color="#1f77b4",
                    ).encode(x=x_enc, y=alt.Y("Amount:Q",
                                              scale=alt.Scale(zero=False,
                                                              padding=36)))
                selectors = alt.Chart(long).mark_point(opacity=0).encode(
                    x=x_enc, y="Amount:Q",
                    tooltip=[alt.Tooltip("taken_at:T", title="Date",
                                         format=tt_fmt),
                             alt.Tooltip("Series:N", title="Series"),
                             tt_amount],
                ).add_params(hover)
                rule = (alt.Chart(long).mark_rule(color="#9ca3af",
                                                  strokeDash=[4, 3])
                        .encode(x=x_enc).transform_filter(hover))
                nw_chart = nw_chart + selectors + rule

                # High / low annotations on the net line — labeled only when
                # they're distinct points (a flat window has nothing to mark).
                if not net_plot.empty:
                    hi_i = net_plot["Amount"].idxmax()
                    lo_i = net_plot["Amount"].idxmin()
                    if hi_i != lo_i:
                        def _peak_label(row, label, dy):
                            # Edge-safe alignment: a marker anywhere NEAR the
                            # window's edges (outer 15% — not just the exact
                            # first/last point) anchors its text inward instead
                            # of centering it half off the chart.
                            t = row["taken_at"]
                            tmin = net_plot["taken_at"].min()
                            tmax = net_plot["taken_at"].max()
                            span = (tmax - tmin).total_seconds() or 1.0
                            frac = (t - tmin).total_seconds() / span
                            align = ("right" if frac > 0.85
                                     else "left" if frac < 0.15 else "center")
                            df = pd.DataFrame([{
                                "taken_at": t,
                                "Amount": float(row["Amount"]),
                                "txt": f"{label} {_fmt_peak(float(row['Amount']))}",
                            }])
                            return alt.Chart(df).mark_text(
                                dy=dy, align=align, fontSize=11,
                                fontWeight="bold", color="#6b7280",
                            ).encode(x="taken_at:T",
                                     y=alt.Y("Amount:Q",
                                             scale=alt.Scale(zero=False,
                                                             padding=36)),
                                     text="txt:N")
                        nw_chart = (nw_chart
                                    + _peak_label(net_plot.loc[hi_i], "High", -12)
                                    + _peak_label(net_plot.loc[lo_i], "Low", 16))

                st.altair_chart(nw_chart.properties(height=600).interactive(),
                                width="stretch")

    if st.button("Take snapshot now"):
        with st.spinner("Refreshing prices and taking snapshot…"):
            _, summary = prices.snapshot_with_refresh(label=fmt_date(date.today()))
        # Never claim "prices refreshed" when they weren't: an offline session
        # still snapshots (at cached prices), but says so.
        if summary is None:
            flash("⚠️ Snapshot saved, but the price refresh failed — values are "
                  "the last cached prices.")
        elif summary["failed"] or summary.get("yfinance_missing"):
            flash(f"⚠️ Snapshot saved. {prices.refresh_summary_msg(summary)}")
        else:
            flash("✅ Prices refreshed and snapshot saved.")
        st.rerun()

    # 5: Auto-draft outflows by card (renders its own divider + subheader)
    autodraft_section(assets, debts, expenses)

    # 5b: Auto-deposit inflows by account — the income mirror of the section above
    autodeposit_section(income)

    # 6: Debt payoff priority
    st.divider()
    st.subheader("Debt Payoff Priority")
    ranking = stats.debt_payoff_ranking(debts, fed)
    if ranking is not None and not ranking.empty:
        show = ranking.copy()
        # Yearly interest = balance × APR, computed before APR is scaled to %.
        show["yearly_interest"] = show["balance"] * show["apr"]
        show["apr"] = (show["apr"] * 100).round(2)
        show["spread_over_fed"] = (show["spread_over_fed"] * 100).round(2)
        show = show[["name", "balance", "yearly_interest", "apr", "spread_over_fed"]].rename(
            columns={"name": "Debt", "balance": "Balance", "yearly_interest": "Yearly Interest",
                     "apr": "APR %", "spread_over_fed": "Spread Over Fed %"})

        # Tint each row by carrying cost vs the risk-free rate: spread ≤ 0 means the
        # debt is at/below the fed funds rate ("cheap" money) → light green; spread
        # > 0 costs more than risk-free → light red (worth prioritising for payoff).
        def _tint(row):
            bg = "#d1f0d8" if row["Spread Over Fed %"] <= 0 else "#fcd8dc"
            return [f"background-color: {bg}"] * len(row)

        st.dataframe(
            show.style.apply(_tint, axis=1),
            width="stretch", hide_index=True,
            column_config={
                "Balance": st.column_config.NumberColumn("Balance", format="$%.0f"),
                "Yearly Interest": st.column_config.NumberColumn("Yearly Interest", format="$%.0f"),
            },
        )
        st.caption("Debts in order of highest APR first. Yearly interest is balance × APR. "
                   "Spread is APR minus the fed funds rate.")
    else:
        st.caption("Add debts to see payoff priority.")
