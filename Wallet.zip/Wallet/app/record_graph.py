"""
record_graph.py — the Group Map on the Groups page (under Calendar).

Every record is a vertex (colored by its coarse type); every link group is a
clique of edges (one color per group). The link_group_members table is already
a record↔group affiliation graph, so this is its one-mode projection onto the
records, drawn with a deliberate layout:

  • Unlinked records live ONLY in invisible margin bands around the edges of the
    canvas, scattered randomly with a spacing buffer so they don't overlap.
  • Linked records are placed group-by-group: a random ungraphed linked record
    is chosen, then the group it's in with the fewest already-graphed members
    (ties broken randomly); that group's remaining members are laid on a
    fixed-radius ring around a random, buffered centre in the interior.
  • The canvas height grows with the record count so neither the rings nor the
    band scatter run out of room on large datasets.

The layout is pure + seeded from the data, so it's stable across Streamlit
reruns (cached on the structural signature — node ids + group memberships — so
it only reshuffles when the graph itself changes, not on every interaction).
Rendered with Altair; vertices and edges are hoverable for details.
"""

import hashlib
import math
import random
from collections import defaultdict
from itertools import combinations

import altair as alt
import pandas as pd
import streamlit as st

import cards
import db

# Canvas + spacing in logical px (1 unit == 1 px, so rings stay circular). The
# canvas is rendered at this fixed width to fill a wide-layout page; a wider
# canvas fits more rings per row, which also keeps it from getting tall.
_W = 1440.0
_BAND = 66.0              # thickness of the margin bands that hold unlinked records
_R = 46.0                # fixed radius of every group ring
_NODE_R = 7.0            # visual node radius, for spacing math
_SEP = 10.0             # gap kept between a band node and an interior ring
_GROUP_BOUND = _R + _NODE_R + 6           # disk a ring occupies around its centre
_GROUP_PITCH = 2 * _GROUP_BOUND + 30      # min spacing between ring centres
_EDGE_MAX = 2.5 * _GROUP_PITCH            # an edge longer than this fails the check
_EDGE_OFFSET = 28.0      # lateral spacing between parallel edges (arc separation)
_ARC_POINTS = 14         # polyline points per curved edge
_SPARSE_BUF = 30.0       # min spacing between unlinked (band) nodes
_SPARSE_PITCH = 38.0     # grid pitch for band slots (≥ buffer → never overlap)
_HOVER_STEP = 4.0        # data-px spacing of the invisible hover dots strung along each edge
_HOVER_DOT = 460         # area (px²) of each hover dot — big + dense so the dots stay
                         # overlapped into a continuous hit ribbon even when zoomed in
_H_MIN = 440.0
_H_MAX = 4200.0          # hard ceiling so an absurd dataset can't make a mile-tall chart

_COARSE = {"assets": "Asset", "debts": "Debt", "income": "Income", "expenses": "Expense"}
_TYPE_COLORS = {"Asset": "#2e7d32", "Debt": "#c62828",
                "Income": "#1565c0", "Expense": "#ef6c00"}


def _load_graph_data():
    """Read all records and link groups into ({key: node_dict}, [group_dict]).
    A node key is 'table:id'; groups keep only members that still resolve to a
    node and that have at least two such members (singletons aren't drawn)."""
    nodes = {}
    for t in ("assets", "debts", "income", "expenses"):
        df = db.load_df(t)
        if df.empty:
            continue
        for _, r in df.iterrows():
            key = f"{t}:{int(r['id'])}"
            nodes[key] = {
                "key": key, "Record": cards._row_label(t, r), "Type": _COARSE[t],
                "Kind": cards.record_type_label(t, r),
            }
    groups = []
    for g in db.all_groups():
        members = tuple(sorted(
            f'{m["table"]}:{m["id"]}' for m in db.group_members(g["id"])
            if f'{m["table"]}:{m["id"]}' in nodes))
        if len(members) >= 2:
            groups.append({"id": int(g["id"]),
                           "name": g["name"] or f"Group {g['id']}",
                           "members": members})
    return nodes, groups


@st.cache_data(show_spinner=False)
def _compute_positions(node_keys, groups, w, salt=0):
    """The custom layout. `node_keys` is the deterministic full vertex order;
    `groups` is a tuple of (gid, name, members_tuple). Returns ({key: (x, y)},
    H). Seeded from the structure (and `salt`) so the same graph + salt always
    lays out the same — the Shuffle button just bumps the salt for a fresh one."""
    seed = int.from_bytes(
        hashlib.md5(repr((node_keys, groups, salt)).encode()).digest()[:8], "big")
    rng = random.Random(seed)

    membership, gid_members, connected = {}, {}, set()
    for gid, _name, members in groups:
        gid_members[gid] = members
        for k in members:
            connected.add(k)
            membership.setdefault(k, set()).add(gid)
    sparse = [k for k in node_keys if k not in connected]
    G, S = len(groups), len(sparse)

    # Interior region that may hold ring centres (inside the margin bands).
    cx_min = _BAND + _GROUP_BOUND + _SEP
    cx_max = w - _BAND - _GROUP_BOUND - _SEP
    per_row = max(1, int((cx_max - cx_min) // _GROUP_PITCH))

    # Height scales with whichever side needs more room. Rings: rows × pitch.
    rows = math.ceil(G / per_row) if G else 0
    h_groups = 2 * (_BAND + _GROUP_BOUND + _SEP) + rows * _GROUP_PITCH + _GROUP_PITCH
    # Band capacity is linear in H: band_area = 2·BAND·(H + W − 2·BAND). Unlinked
    # nodes sit on a buffered grid of pitch _SPARSE_PITCH (≥ buffer, so no two
    # overlap); size H so the band holds a grid cell per node, with slack.
    need = S * (_SPARSE_PITCH ** 2) * 1.25
    h_sparse = need / (2 * _BAND) - w + 2 * _BAND
    H = max(_H_MIN, h_groups, h_sparse)
    H = min(H, _H_MAX)

    cy_min = _BAND + _GROUP_BOUND + _SEP
    cy_max = H - _BAND - _GROUP_BOUND - _SEP

    # Random-but-buffered ring centres: shuffled grid cells, each jittered. The
    # grid pitch guarantees rings never overlap; the jitter keeps it organic.
    xs, x = [], cx_min
    while x <= cx_max + 1e-6:
        xs.append(x); x += _GROUP_PITCH
    ys, y = [], cy_min
    while y <= cy_max + 1e-6:
        ys.append(y); y += _GROUP_PITCH
    xs = xs or [(cx_min + cx_max) / 2]
    ys = ys or [(cy_min + cy_max) / 2]
    cells = [(cx, cy) for cy in ys for cx in xs]
    rng.shuffle(cells)
    jit = max(0.0, (_GROUP_PITCH - 2 * _GROUP_BOUND) / 2 - 2)

    positions = {}

    def _clamp(v, lo, hi):
        return lo if v < lo else hi if v > hi else v

    def _ring(centre, members, a0):
        cx, cy = centre
        k = len(members)
        if k == 1:
            return {members[0]: (cx, cy)}
        return {m: (cx + _R * math.cos(a0 + 2 * math.pi * i / k),
                    cy + _R * math.sin(a0 + 2 * math.pi * i / k))
                for i, m in enumerate(members)}

    def _over_long(gid, cand):
        """How many of this group's clique edges that touch a just-placed member
        would exceed _EDGE_MAX. Edges between two already-placed members are
        fixed (no centre helps), so they don't count toward the choice."""
        n = 0
        for a, b in combinations(gid_members[gid], 2):
            if a not in cand and b not in cand:
                continue
            pa, pb = cand.get(a) or positions.get(a), cand.get(b) or positions.get(b)
            if pa and pb and math.hypot(pa[0] - pb[0], pa[1] - pb[1]) > _EDGE_MAX:
                n += 1
        return n

    # Place linked records group-by-group per the chosen-vertex / least-graphed
    # -group rule. `remaining` keeps a deterministic order for the RNG.
    remaining = [k for k in node_keys if k in connected]
    while True:
        rem = [k for k in remaining if k not in positions]
        if not rem:
            break
        v = rem[rng.randrange(len(rem))]
        gids = membership[v]
        counts = {g: sum(1 for m in gid_members[g] if m in positions) for g in gids}
        least = min(counts.values())
        gid = rng.choice(sorted(g for g in gids if counts[g] == least))
        to_place = [m for m in gid_members[gid] if m not in positions]
        a0 = rng.uniform(0, 2 * math.pi)

        # Pick the candidate centres (from the buffered cell pool, so rings still
        # never overlap). When the group has already-placed BRIDGE members, bias
        # the candidates to the cells NEAREST the centroid of those bridges, so
        # the ring lands in their neighbourhood and the bridge edges stay short.
        # A group with no placed members has no bridge to aim at, so it just takes
        # the next random (shuffled) cells. Either way, up to 5 candidates.
        tries = min(5, len(cells)) or 1
        bridges = [positions[m] for m in gid_members[gid] if m in positions]
        if not cells:
            cand_idx = [None] * tries          # pool exhausted (more groups than cells)
        elif bridges:
            ax = sum(p[0] for p in bridges) / len(bridges)
            ay = sum(p[1] for p in bridges) / len(bridges)
            cand_idx = sorted(range(len(cells)),
                              key=lambda i: (cells[i][0] - ax) ** 2 + (cells[i][1] - ay) ** 2
                              )[:tries]
        else:
            cand_idx = list(range(tries))

        # Take the first candidate with no over-long edge; else the one with the
        # fewest (ties → the nearer one, since cand_idx is ordered by distance).
        best = None                            # (n_over, cell_idx | None, ring_positions)
        for idx in cand_idx:
            if idx is not None:
                bx, by = cells[idx]
                centre = (_clamp(bx + rng.uniform(-jit, jit), cx_min, cx_max),
                          _clamp(by + rng.uniform(-jit, jit), cy_min, cy_max))
            else:
                centre = (rng.uniform(cx_min, cx_max), rng.uniform(cy_min, cy_max))
            cand = _ring(centre, to_place, a0)
            n_over = _over_long(gid, cand)
            if best is None or n_over < best[0]:
                best = (n_over, idx, cand)
            if n_over == 0:
                break
        positions.update(best[2])
        if best[1] is not None:
            cells.pop(best[1])

    # Scatter unlinked records in the bands: enumerate buffered grid slots that
    # fall inside the margin frame, shuffle, and take one per node with a small
    # random jitter — random placement that still can't overlap (pitch ≥ buffer).
    pad = _NODE_R + 4
    sjit = max(0.0, (_SPARSE_PITCH - _SPARSE_BUF) / 2 - 0.5)

    def band_slot(px, py):
        # "Deep enough" in a band strip that ±sjit jitter can't leave the band.
        return (px <= _BAND - sjit or px >= w - _BAND + sjit
                or py <= _BAND - sjit or py >= H - _BAND + sjit)

    slots = []
    gy = pad
    while gy <= H - pad + 1e-6:
        gx = pad
        while gx <= w - pad + 1e-6:
            if band_slot(gx, gy):
                slots.append((gx, gy))
            gx += _SPARSE_PITCH
        gy += _SPARSE_PITCH
    rng.shuffle(slots)

    def clamp(v, lo, hi):
        return lo if v < lo else hi if v > hi else v

    for i, k in enumerate(sparse):
        if i < len(slots):
            sx, sy = slots[i]
            positions[k] = (clamp(sx + rng.uniform(-sjit, sjit), pad, w - pad),
                            clamp(sy + rng.uniform(-sjit, sjit), pad, H - pad))
        else:                                  # more nodes than slots (H capped)
            positions[k] = (rng.uniform(pad, _BAND - sjit), rng.uniform(pad, H - pad))

    return positions, H


def _bezier_pt(p, c, q, t):
    """Point at parameter t∈[0,1] on the quadratic Bézier p→q with control c."""
    u = 1 - t
    return (u * u * p[0] + 2 * u * t * c[0] + t * t * q[0],
            u * u * p[1] + 2 * u * t * c[1] + t * t * q[1])


def _hover_samples(pts, step):
    """Points spaced ~`step` px along the polyline `pts` (both ends included).
    A line/trail mark's tooltip only fires near its vertices (so a 2-point straight
    edge is hoverable only at its ends) — stringing transparent CIRCLES, each a real
    filled hit area, every few px along the edge gives a continuous, whole-edge hit
    target. The dots are placed in data space, so at high zoom their pixel gaps grow;
    `step` is kept small and the dot area large (see _HOVER_DOT) so they stay
    overlapped across the practical zoom range."""
    cum = [0.0]
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        cum.append(cum[-1] + math.hypot(x1 - x0, y1 - y0))
    total = cum[-1]
    if total <= 0:
        return [pts[0]]
    k = max(1, math.ceil(total / step))     # ceil → spacing ≤ step (dots stay overlapped)
    out, j = [], 0
    for s in range(k + 1):
        d = total * s / k
        while j < len(cum) - 2 and cum[j + 1] < d:
            j += 1
        seg = cum[j + 1] - cum[j]
        t = 0.0 if seg <= 0 else (d - cum[j]) / seg
        out.append((pts[j][0] + (pts[j + 1][0] - pts[j][0]) * t,
                    pts[j][1] + (pts[j + 1][1] - pts[j][1]) * t))
    return out


def _build_chart(nodes, positions, groups, H, zoom_name="grpzoom", pick_name="pick"):
    # Every clickable mark carries a single "Sel" id so the click selection resolves
    # WHAT was clicked no matter which layer is hit: "r:<table>:<id>" for a record
    # node, "g:<group id>" for an edge — on BOTH the visible line and its hit-dots, so
    # clicking the line itself (the obvious target) works, not only the dots.
    node_rows = [{**{c: nodes[k][c] for c in ("Record", "Type", "Kind")},
                  "Sel": f"r:{k}", "x": xy[0], "y": xy[1]}
                 for k, xy in positions.items() if k in nodes]
    ndf = pd.DataFrame(node_rows)

    # Edges are polylines (mark_line, ordered points). When the SAME pair of
    # records shares several groups, those parallel edges would overlap as one
    # straight line — so each is bowed into its own quadratic-Bézier arc, fanned
    # symmetrically about the straight line; a lone edge stays straight (control
    # point on the line). Each edge is its own `detail` group, so it's an
    # independently hoverable curve.
    by_pair = defaultdict(list)
    for gid, name, members in groups:
        present = [m for m in members if m in positions]
        for a, b in combinations(present, 2):
            by_pair[tuple(sorted((a, b)))].append((gid, name))

    edge_rows, hover_rows, eid = [], [], 0
    for (a, b), glist in by_pair.items():
        glist.sort()                            # by gid → stable arc assignment
        n = len(glist)
        (ax, ay), (bx, by) = positions[a], positions[b]
        length = math.hypot(bx - ax, by - ay) or 1.0
        perp = (-(by - ay) / length, (bx - ax) / length)
        mid = ((ax + bx) / 2, (ay + by) / 2)
        for rank, (gid, name) in enumerate(glist):
            lat = (rank - (n - 1) / 2) * _EDGE_OFFSET     # 0 for a lone/middle edge
            if lat == 0:
                pts = [(ax, ay), (bx, by)]                # straight
            else:
                ctrl = (mid[0] + perp[0] * lat, mid[1] + perp[1] * lat)
                pts = [_bezier_pt((ax, ay), ctrl, (bx, by), i / (_ARC_POINTS - 1))
                       for i in range(_ARC_POINTS)]
            for order, (xx, yy) in enumerate(pts):
                edge_rows.append({"edge": eid, "order": order, "x": xx, "y": yy,
                                  "GroupKey": str(gid), "Group": name,
                                  "Sel": f"g:{gid}"})
            for hx, hy in _hover_samples(pts, _HOVER_STEP):
                hover_rows.append({"x": hx, "y": hy, "Group": name, "Sel": f"g:{gid}"})
            eid += 1
    edf = pd.DataFrame(edge_rows)
    hdf = pd.DataFrame(hover_rows)

    xs = alt.Scale(domain=[0, _W], nice=False)
    ys = alt.Scale(domain=[0, H], nice=False)
    # The click selection (top-level → binds to every layer's marks, so a click on a
    # node or an edge dot/line reports back). No visual highlight: the selection
    # persists after a click, so a highlight would linger after the card is closed
    # (closing a dialog doesn't rerun the map) — the card opening is the feedback.
    # `clear` on pointer-leave re-arms it: Vega fires NO event when you re-click the
    # already-selected item, so without this you couldn't reopen the same card twice
    # in a row. Moving the mouse off the chart to close the card clears the selection,
    # so clicking the same node/edge again registers as a fresh click. This clears
    # without renaming the param, so the chart never re-embeds (no page jump).
    pick = alt.selection_point(name=pick_name, on="click", clear="pointerleave",
                               fields=["Sel"], empty=False)
    layers = []
    if not edf.empty:
        edge_base = alt.Chart(edf).encode(
            x=alt.X("x:Q", scale=xs, axis=None),
            y=alt.Y("y:Q", scale=ys, axis=None),
            detail="edge:N",
            order="order:Q",
        )
        # Visible colored edge (thin).
        layers.append(
            edge_base.mark_line(strokeWidth=2, opacity=0.45).encode(
                color=alt.Color("GroupKey:N", scale=alt.Scale(scheme="category20"),
                                legend=None),
            ))
        # Invisible hit target: transparent circles strung densely along every edge,
        # each carrying the group tooltip (and, via the shared selection, clickable).
        # A line/trail mark's tooltip/click only fires near its vertices, but each
        # CIRCLE is a real filled hit area, so the whole edge is hoverable/clickable.
        # Dot positions are in data space while their size is in pixels, so zooming in
        # grows the gaps between them — hence small _HOVER_STEP spacing and a large
        # _HOVER_DOT area, which keep the dots overlapped (a continuous ribbon) across
        # the practical zoom range. Below the nodes (added last), so a node wins where
        # they overlap.
        layers.append(
            alt.Chart(hdf).mark_circle(size=_HOVER_DOT, opacity=0).encode(
                x=alt.X("x:Q", scale=xs, axis=None),
                y=alt.Y("y:Q", scale=ys, axis=None),
                tooltip=[alt.Tooltip("Group:N", title="Group")],
            ))
    layers.append(
        alt.Chart(ndf).mark_circle(size=150, stroke="white", strokeWidth=1.2,
                                   opacity=0.95).encode(
            x=alt.X("x:Q", scale=xs, axis=None),
            y=alt.Y("y:Q", scale=ys, axis=None),
            color=alt.Color("Type:N",
                            scale=alt.Scale(domain=list(_TYPE_COLORS),
                                            range=list(_TYPE_COLORS.values())),
                            legend=alt.Legend(title="Record type", orient="bottom")),
            tooltip=[alt.Tooltip("Record:N", title="Record"),
                     alt.Tooltip("Type:N", title="Type"),
                     alt.Tooltip("Kind:N", title="Kind")],
        ))
    # Edges colour by group, nodes colour by type — two different colour scales.
    # Layered charts SHARE scales by default, which would merge them and leave the
    # edges' group keys uncolored (invisible); resolve colour independently.
    #
    # TWO top-level params (Streamlit only wires up selections defined at the top
    # level of the spec):
    #  • `zoom` — an interval bound to the shared x/y scales: scroll to zoom, drag to
    #    pan. Its `translate` is restricted to start on EMPTY space ([!event.item]),
    #    so pressing on a mark is NOT grabbed by the pan — the click reaches `pick`
    #    instead (the bound-scales pan was swallowing clicks on the line/nodes). Its
    #    NAME is `zoom_name`; Recenter changes the name → fresh zoom signal → reset.
    #  • `pick` — a point selection on click, keyed on the "Sel" field so the click
    #    returns that id directly (a no-field selection returns Vega's internal id,
    #    not our data). One selection spans every layer, so a click resolves whether
    #    it's a node ("r:…") or an edge ("g:…"). Its NAME is `pick_name`; the handler
    #    changes the name after each click so the selection clears (single-click
    #    reopen, and dismissing can't reopen it).
    zoom = alt.selection_interval(
        bind="scales", name=zoom_name,
        translate="[pointerdown[!event.item], pointerup] > pointermove")
    return (alt.layer(*layers).resolve_scale(color="independent")
            .properties(width=int(_W), height=int(H))
            .add_params(zoom, pick)
            .configure_view(strokeOpacity=0).configure_axis(grid=False))


def record_graph_section():
    """Render the Group Map: a 'Group Map' label and the interactive map. Shows a
    prompt when there are no records yet."""
    st.subheader("Group Map")
    nodes, groups = _load_graph_data()
    if not nodes:
        st.info("No records yet. Add records on their pages and link them into groups "
                "(the 🔗 link picker on any Add/Edit form) to see them mapped here.")
        return
    _map_fragment(nodes, groups)


@st.fragment
def _map_fragment(nodes, groups):
    """The interactive map (buttons + chart + click handling) in a FRAGMENT, so a
    chart click / shuffle / recenter reruns ONLY this block — the rest of the page
    doesn't re-render, which keeps the page's scroll position (a chart on_select
    rerun of the whole page jumps it to the top). Opening a record/group card dialog
    from inside a fragment is allowed (a dialog is itself a fragment; only nesting a
    dialog inside a dialog is disallowed)."""
    # Shuffle bumps the salt that seeds the layout (and keys its cache), so the whole
    # graph re-lays-out; Recenter bumps `view`, which renames the zoom selection → a
    # fresh (default) zoom signal, resetting the view. Done before the layout so a new
    # arrangement shows on the same click.
    salt = st.session_state.get("_groupmap_salt", 0)
    view = st.session_state.get("_groupmap_view", 0)
    bc1, bc2, _bspace = st.columns([1.0, 1.0, 4.0])
    if bc1.button("🔀 Shuffle vertices", width="stretch",
                  help="Lay the graph out again, differently."):
        salt += 1
        view += 1
        st.session_state["_groupmap_salt"] = salt
        st.session_state["_groupmap_view"] = view
    if bc2.button("🎯 Recenter", width="stretch",
                  help="Reset the map's pan & zoom to the default view "
                       "(you can also double-click the map)."):
        view += 1
        st.session_state["_groupmap_view"] = view

    node_keys = tuple(sorted(nodes))
    groups_t = tuple((g["id"], g["name"], g["members"]) for g in groups)
    positions, H = _compute_positions(node_keys, groups_t, _W, salt)

    st.caption(
        f"{len(nodes)} records · {len(groups)} link group(s). Each dot is a record "
        "(colored by type); each line joins records that share a link group — one "
        "color per group. Linked records cluster in rings; unlinked ones scatter in "
        "the margins. **Click** a dot for its record, a line for its group; **hover** "
        "for details; **scroll to zoom**, **drag to pan**.")
    # width="content" keeps the chart at its own fixed pixel width (so the rings stay
    # circular) — the non-deprecated form of use_container_width=False. The click
    # selection has a STABLE name ("pick"): renaming it (to clear the selection) makes
    # Vega re-embed the whole chart, which jumps the page on the next render (the card
    # close / next map click). A stable name never re-embeds → no jump, and the zoom
    # is preserved too. The handler dedups on the selection instead. on_select returns
    # clicks; selection_mode lists ONLY "pick", so panning doesn't rerun.
    event = st.altair_chart(
        _build_chart(nodes, positions, groups_t, H,
                     zoom_name=f"grpzoom{view}", pick_name="pick"),
        width="content", key="groupmap", on_select="rerun", selection_mode=["pick"])
    _handle_map_click(event)


def _sel_id(blob):
    """The clicked "Sel" id out of a Streamlit point-selection result, tolerating the
    shapes a fields-based selection can take: a list of row dicts ([{"Sel": …}]) or a
    field→values dict ({"Sel": […]}). Returns None when nothing is selected."""
    if isinstance(blob, list) and blob and isinstance(blob[0], dict):
        return blob[0].get("Sel")
    if isinstance(blob, dict):
        v = blob.get("Sel")
        return (v[0] if v else None) if isinstance(v, list) else v
    return None


def _handle_map_click(event):
    """Open the record / group card for a freshly clicked vertex / edge. The clicked
    row carries a "Sel" id: "r:<table>:<id>" for a record, "g:<group id>" for a group.

    The card dialog is opened DIRECTLY (not via request_view + st.rerun); a
    programmatic st.rerun jumps the page to the top, whereas opening inline keeps the
    scroll (this is how the calendar opens a record). The selection has a stable name
    and PERSISTS, so we dedup on it: act only when it differs from the last one we
    acted on — otherwise the card would reopen on every rerun (e.g. when it closes).
    Clearing it (None) re-arms, so clicking empty space then a record reopens it; a
    different record always reopens on a single click."""
    sel = getattr(event, "selection", None) or {}
    val = _sel_id(sel.get("pick"))
    if val == st.session_state.get("_map_last_sig"):
        return
    st.session_state["_map_last_sig"] = val
    if not val:
        return
    kind, _, ident = str(val).partition(":")
    import group_manager
    if kind == "r" and ":" in ident:
        table, _, rid = ident.partition(":")
        cards.view_record(table, int(rid))
    elif kind == "g" and ident.isdigit():
        group_manager.view_group(int(ident))


def consume_pending_group_view():
    """Open a queued group pop-up (from a Group Map edge click). Called at the top of
    the app — alongside cards.consume_pending_view — before the page renders."""
    import group_manager
    group_manager.consume_pending_group_view()


def groups_page():
    """The Groups page (under Calendar): customizable per-group statistics and a
    manager, above the Group Map of every record and the links that connect them."""
    import group_manager
    st.header("Groups")
    group_manager.group_manager_section()
    st.divider()
    record_graph_section()
