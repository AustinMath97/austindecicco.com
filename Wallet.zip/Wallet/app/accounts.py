"""
accounts.py — forward balance projections for cash accounts.

Pure compute: DataFrames + dates in, projections out. No database, no Streamlit, no
global state — so the math can be checked against a hand calculation (see
test_accounts.py). For each cash account it walks the balance forward one day at a
time over a window, applying three things:

  • auto-deposit income — money that lands in the account on its schedule
    (recurrence + the per-occurrence amount),
  • auto-draft expenses — bills that pull from the account on their due dates
    (monthly bills every month; annual bills in their one month),
  • APY interest — credited on the account's payout schedule, derived from the
    account's annual yield so the payouts compound back to the APY.

The Accounts page renders the per-day projection; the Overview page's
low-balance alert reads the same project_all() output (via its cached wrapper in
dashboard.py) to flag any account projected to dip below zero anywhere in the
window (a rolling 30 days starting today — see default_window).
"""

from __future__ import annotations

import calendar as _cal
from collections import defaultdict
from datetime import date, timedelta
from typing import TYPE_CHECKING

if TYPE_CHECKING:                     # pandas is only needed for type hints --
    import pandas as pd               # this module stays pandas-free at runtime

import recurrence
import stats
# NaN-safe coercers + the asset-type classifier — the shared utils implementations
# (utils is also pure).
from utils import is_cash, is_distribution, safe_float as _f, safe_str as _s

# A cash account's interest payout uses the SAME schedule model as income (see
# recurrence.py) — weekly, biweekly, semi-monthly, monthly, the nth weekday, quarterly
# in chosen months, or annual. APY already bakes in compounding, so the amount credited
# each payout is balance × ((1+apy)^(1/N) − 1), where N is how many times a year the
# schedule fires; N payouts compound back to the APY over the year.

# Default interest payout for a new interest-bearing account: the 1st of each month.
DEFAULT_INTEREST_SCHED = {"type": "monthly", "month_days": [1]}


# --- window -----------------------------------------------------------------

WINDOW_DAYS = 30


def default_window(today: date | None = None) -> tuple[date, date]:
    """Projection window: a rolling 30 days starting today (today through today + 30)."""
    today = today or date.today()
    return today, today + timedelta(days=WINDOW_DAYS)


def _months_in_range(start: date, end: date) -> list[tuple[int, int]]:
    """The (year, month) pairs the window touches, in order."""
    y, m = start.year, start.month
    out = []
    while (y, m) <= (end.year, end.month):
        out.append((y, m))
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


# --- account discovery + per-day cash-flow events ---------------------------

def asset_interest_sched(row: dict | pd.Series) -> dict:
    """The interest payout schedule of a cash asset (its interest_* columns) as a
    recurrence schedule dict — usable directly as forms.schedule_widget defaults."""
    return recurrence.from_row({
        "schedule_type": row.get("interest_schedule_type"),
        "weekday":       row.get("interest_weekday"),
        "week_ordinal":  row.get("interest_week_ordinal"),
        "anchor_date":   row.get("interest_anchor_date"),
        "pay_days":      row.get("interest_pay_days"),
        "months":        row.get("interest_months"),
    })


def cash_accounts(assets: pd.DataFrame | None) -> list[dict]:
    """Every cash account as {name, balance, apy, sched} (assets whose asset_type
    is Cash). `sched` is the recurrence schedule on which interest posts."""
    if assets is None or getattr(assets, "empty", True):
        return []
    out = []
    for _, r in assets.iterrows():
        # A pending estate/trust distribution is "Cash" but isn't an interest-
        # bearing account you deposit to — it groups with receivables instead.
        if not is_cash(r.get("asset_type")) or is_distribution(r.get("account_type")):
            continue
        out.append({"name": _s(r.get("name")) or "Account",
                    "balance": _f(r.get("value")),
                    "apy": _f(r.get("apy")),
                    "sched": asset_interest_sched(r)})
    return out


def occurrences_per_year(sched: dict, ref_year: int | None = None) -> int:
    """How many times the schedule fires across a representative year — i.e. the number
    of interest payouts a year, used to size each payout against the APY."""
    ref_year = ref_year or date.today().year
    return sum(len(recurrence.occurrences_in_month(sched, ref_year, m)) for m in range(1, 13))


def _interest_dates(apy: float, sched: dict, start: date,
                    end: date) -> dict[date, float]:
    """{date: payout_rate} — the dates interest posts within [start, end] (from the
    payout schedule) and the rate applied to that day's running balance. Each payout is
    balance × ((1+apy)^(1/N) − 1), where N is the schedule's yearly payout count, so N
    payouts compound back to the APY."""
    if apy <= 0:
        return {}
    n = occurrences_per_year(sched, start.year)
    if n <= 0:
        return {}
    rate = (1.0 + apy) ** (1.0 / n) - 1.0
    out = {}
    for (y, m) in _months_in_range(start, end):
        for d in recurrence.occurrences_in_month(sched, y, m):
            dt = date(y, m, d)
            if start <= dt <= end:
                out[dt] = rate
    return out


def next_interest_payout(balance: float, apy: float, sched: dict,
                         today: date | None = None) -> dict | None:
    """The next interest credit on or after `today`: {date, amount}, or None if the
    account has no APY / balance / scheduled payout in the next ~year."""
    if apy <= 0 or balance <= 0:
        return None
    today = today or date.today()
    dates = _interest_dates(apy, sched, today, today + timedelta(days=400))
    if not dates:
        return None
    dt = min(dates)
    return {"date": dt, "amount": balance * dates[dt]}


# --- interest-as-income helpers (shared by the seed and the income import button) ---

def interest_income_amounts(value: float, apy: float,
                            sched: dict) -> tuple[float, float]:
    """(annual, per_payment) interest an account pays out on schedule `sched`, sized so
    the per-payment amounts over a year sum to the account's APY yield on `value`."""
    n = occurrences_per_year(sched)
    if value <= 0 or apy <= 0 or n <= 0:
        return 0.0, 0.0
    per = value * ((1.0 + apy) ** (1.0 / n) - 1.0)
    return per * n, per


def _income_detail(row: pd.Series) -> str:
    """Readable context for an income deposit: its type and schedule summary."""
    parts = []
    itype = _s(row.get("type"))
    if itype:
        parts.append(itype.replace("_", " ").title())
    payday = _s(row.get("pay_day"))          # human schedule summary stored on the row
    if payday:
        parts.append(payday)
    return " · ".join(parts) or "Auto-deposit"


def _expense_detail(row: pd.Series) -> str:
    """Readable context for an auto-drafted expense: its broad category and the
    schedule summary (e.g. "Housing · 1st of the month", "Every other Friday")."""
    parts = []
    cat, sub = _s(row.get("category")), _s(row.get("subcategory"))
    if cat and sub:                          # the label is the sub-category; add the broad one
        parts.append(cat)
    desc = recurrence.describe(recurrence.from_row(row)) or _s(row.get("frequency"))
    if desc:
        parts.append(desc)
    return " · ".join(parts) or "Auto-draft"


def _deposit_events(name: str, income: pd.DataFrame | None, start: date,
                    end: date) -> dict[date, list[dict]]:
    """{date: [item, …]} for income auto-deposited into `name` within [start, end]. Each
    item is {label, detail, amount}. A stream needs a per-occurrence amount to be placed
    on a day; one without is skipped (we can't split a whole-period total across days)."""
    ev = defaultdict(list)
    if income is None or getattr(income, "empty", True):
        return ev
    months = _months_in_range(start, end)
    for _, row in income.iterrows():
        if int(_f(row.get("auto_deposit"))) != 1 or _s(row.get("deposit_target")) != name:
            continue
        pay = _f(row.get("pay_amount"))
        if pay <= 0:
            continue
        label, detail = _s(row.get("source")) or "Income", _income_detail(row)
        sched = recurrence.from_row(row)
        for (y, m) in months:
            for d in recurrence.occurrences_in_month(sched, y, m):
                dt = date(y, m, d)
                if start <= dt <= end:
                    ev[dt].append({"label": label, "detail": detail, "amount": pay})
    return ev


def _draft_events(name: str, expenses: pd.DataFrame | None, start: date,
                  end: date) -> dict[date, list[dict]]:
    """{date: [item, …]} for expenses auto-drafted from `name`; each item is
    {label, detail, amount} with a negative amount. The mirror of _deposit_events:
    each bill's recurrence schedule is expanded against every month in range, so a
    weekly / biweekly / quarterly / semi-annual bill lands on its real days — not
    forced into a monthly-or-annual approximation."""
    ev = defaultdict(list)
    if expenses is None or getattr(expenses, "empty", True):
        return ev
    today = date.today()
    for _, row in expenses.iterrows():
        if int(_f(row.get("auto_draft"))) != 1 or _s(row.get("draft_source")) != name:
            continue
        label = _s(row.get("subcategory")) or _s(row.get("category")) or "Expense"
        detail = _expense_detail(row)
        # Per-occurrence amounts: a fixed amount for a set bill, the recorded /
        # projected amount for a variable one (today anchors the projection).
        for dt, amt in stats.occurrence_amounts(row, start, end, today).items():
            if amt > 0:
                ev[dt].append({"label": label, "detail": detail, "amount": -amt})
    return ev


# --- projection -------------------------------------------------------------

def project_account(name: str, balance: float, apy: float, sched: dict,
                    income: pd.DataFrame | None, expenses: pd.DataFrame | None,
                    start: date, end: date) -> dict:
    """Day-by-day projection of one account over [start, end] inclusive. Returns a dict
    with the per-day rows plus the projected low point and whether it dips below zero.
    Interest posts on the account's payout schedule `sched`; that posting and the day's
    cash flows apply each day in order. The low point (min_balance / dips_below_zero)
    is the pessimistic intra-day low — drafts assumed to clear before deposits land —
    while the rows/ledger show end-of-day balances."""
    deposits = _deposit_events(name, income, start, end)
    drafts = _draft_events(name, expenses, start, end)
    interest_on = _interest_dates(apy, sched, start, end)
    _idesc = recurrence.describe(sched)
    int_detail = f"{apy * 100:.2f}% APY" + (f" · {_idesc}" if _idesc else "")

    running = balance
    rows = []        # one summary row per day (drives the balance chart)
    ledger = []      # one entry per transaction, with its running balance (the detail table)
    min_balance, min_date, dips = balance, start, balance < 0
    d = start
    while d <= end:
        day_start = running
        day_dep = day_drf = day_int = 0.0
        # Interest posts first, then deposits, then drafts — each a ledger line.
        rate = interest_on.get(d, 0.0)
        if rate:
            intr = running * rate
            running += intr
            day_int = intr
            ledger.append({"date": d, "kind": "interest", "label": "Interest",
                           "detail": int_detail, "amount": intr, "balance": running})
        for it in deposits.get(d, []):
            running += it["amount"]
            day_dep += it["amount"]
            ledger.append({"date": d, "kind": "deposit", "label": it["label"],
                           "detail": it["detail"], "amount": it["amount"], "balance": running})
        for it in drafts.get(d, []):
            running += it["amount"]         # already negative
            day_drf += -it["amount"]
            ledger.append({"date": d, "kind": "draft", "label": it["label"],
                           "detail": it["detail"], "amount": it["amount"], "balance": running})
        # Dip detection uses the pessimistic intra-day low: banks may clear a day's
        # drafts before its deposits land, so a same-day $800 out / $800 in on a $0
        # account is still an overdraft risk even though the end-of-day balance is
        # fine. Interest still posts first (it's credited overnight).
        worst = min(running, day_start + day_int - day_drf)
        if worst < min_balance:
            min_balance, min_date = worst, d
        if worst < 0:
            dips = True
        rows.append({"date": d, "deposit": day_dep, "draft": day_drf,
                     "interest": day_int, "balance": running})
        d += timedelta(days=1)
    return {"name": name, "start_balance": balance, "apy": apy, "rows": rows,
            "ledger": ledger, "min_balance": min_balance, "min_date": min_date,
            "end_balance": running, "dips_below_zero": dips}


def project_all(assets: pd.DataFrame, income: pd.DataFrame | None,
                expenses: pd.DataFrame | None, start: date | None = None,
                end: date | None = None) -> list[dict]:
    """Project every cash account over the window (defaults to default_window())."""
    if start is None or end is None:
        start, end = default_window()
    return [project_account(a["name"], a["balance"], a["apy"], a["sched"],
                            income, expenses, start, end)
            for a in cash_accounts(assets)]


# --- credit cards -----------------------------------------------------------
# A credit card is the mirror of a cash account: an auto-drafted expense charged
# to the card RAISES what you owe (instead of lowering cash), monthly interest
# raises it, and the minimum payment on the due day lowers it. The risk flag is
# going over the credit limit (vs. a cash account dipping below $0).

def statement_sched(row) -> dict:
    """A credit card's statement-close schedule as a recurrence dict: an ordinal
    weekday (statement_week_ordinal + statement_weekday — e.g. the last Friday, which
    drifts month to month) when both are set, else a fixed day of the month
    (statement_day), else 'none'. Reuses the recurrence engine so each month's close
    date is found the same way every other schedule is."""
    g = row.get if hasattr(row, "get") else (lambda k, d=None: None)
    wd, ordn = g("statement_weekday"), g("statement_week_ordinal")
    if _s(wd) and _s(ordn):
        return {"type": recurrence.MONTHLY_WEEKDAY,
                "weekday": int(_f(wd)), "ordinal": int(_f(ordn))}
    day = g("statement_day")
    if _s(day) and _f(day) >= 1:
        return {"type": recurrence.MONTHLY, "month_days": [int(_f(day))]}
    return {"type": recurrence.NONE}


def credit_accounts(debts: pd.DataFrame | None) -> list[dict]:
    """Every revolving credit card as its projection inputs (name, balance, apr,
    credit_limit, due_day, the statement-close schedule, and the minimum model)."""
    if debts is None or getattr(debts, "empty", True):
        return []
    out = []
    for _, r in debts.iterrows():
        if _s(r.get("type")) != "revolving":
            continue
        out.append({
            "name": _s(r.get("name")) or "Card",
            "balance": _f(r.get("balance")),
            "apr": _f(r.get("apr")),
            "credit_limit": _f(r.get("credit_limit")),
            "due_day": int(_f(r.get("due_day"))) if _s(r.get("due_day")) else None,
            "statement_sched": statement_sched(r),
            "mp_type": _s(r.get("min_payment_type")) or "fixed",
            "mp_pct": _f(r.get("min_payment_pct")),
            "mp_fixed": _f(r.get("min_payment")),
        })
    return out


def _payment_detail(card: dict) -> str:
    """Readable description of a card's minimum-payment rule for the ledger."""
    t = card.get("mp_type") or "fixed"
    p = card.get("mp_pct", 0.0) * 100
    if t == "percent":
        return f"min {p:.1f}% of balance"
    if t == "percent_floor":
        return f"min {p:.1f}% (≥ ${card['mp_fixed']:,.0f})"
    if t == "percent_interest":
        return f"min {p:.1f}% + interest"
    if t == "percent_interest_floor":
        return f"min {p:.1f}% + interest (≥ ${card['mp_fixed']:,.0f})"
    return f"min ${card['mp_fixed']:,.0f}"


def _charge_events(name: str, expenses, start: date, end: date) -> dict:
    """{date: [item,…]} for expenses auto-drafted (charged) to card `name`. Mirrors
    _draft_events, but amounts are POSITIVE — a charge raises the card balance."""
    ev = defaultdict(list)
    for dt, items in _draft_events(name, expenses, start, end).items():
        for it in items:
            ev[dt].append({"label": it["label"], "detail": it["detail"],
                           "amount": -it["amount"]})    # outflow → balance increase
    return ev


def project_credit_account(card: dict, expenses, start: date, end: date) -> dict:
    """Day-by-day projection of one credit card's balance (what you owe) over
    [start, end]. Charges and monthly interest raise it; the minimum payment on the
    due day lowers it (and once the balance is cleared there's nothing left to pay).

    The minimum is set by the balance when the statement closes (statement_day):
    charges made AFTER the statement don't raise that cycle's minimum. With no
    statement day, the minimum is taken from the balance on the due day instead.
    Flags any day the balance exceeds the credit limit."""
    name, apr, limit = card["name"], card["apr"], card["credit_limit"]
    due_day = card.get("due_day")
    stmt_sched = card.get("statement_sched") or {"type": recurrence.NONE}
    has_stmt = str(stmt_sched.get("type") or recurrence.NONE) != recurrence.NONE
    mp = (card["mp_type"], card["mp_pct"], card["mp_fixed"])
    charges = _charge_events(name, expenses, start, end)
    monthly = apr / 12.0

    # The statement close day(s) per month, computed via recurrence (so an ordinal
    # weekday lands on the real, drifting calendar day each month).
    _stmt_days: dict[tuple, set] = {}

    def _is_statement(dt: date) -> bool:
        if not has_stmt:
            return False
        key = (dt.year, dt.month)
        if key not in _stmt_days:
            _stmt_days[key] = set(recurrence.occurrences_in_month(stmt_sched, *key))
        return dt.day in _stmt_days[key]

    running = card["balance"]
    # The minimum currently owed, set at each statement close — start by assuming
    # the current balance is the latest statement balance. apr feeds the
    # "+ interest" minimum models (one month's interest on the statement balance).
    min_due = stats.min_payment_due(running, *mp, apr=apr)
    rows, ledger = [], []
    peak, peak_date = running, start
    over = limit > 0 and running > limit
    d = start
    while d <= end:
        day_charge = day_pay = day_int = 0.0
        for it in charges.get(d, []):
            running += it["amount"]
            day_charge += it["amount"]
            ledger.append({"date": d, "kind": "charge", "label": it["label"],
                           "detail": it["detail"], "amount": it["amount"], "balance": running})
        dim = _cal.monthrange(d.year, d.month)[1]
        is_stmt = _is_statement(d)
        is_due = bool(due_day) and d.day == min(int(due_day), dim)
        # Interest posts at statement close (or, with no statement schedule, on the
        # due day) and the balance then sets the minimum owed.
        if is_stmt or (is_due and not has_stmt):
            if monthly > 0 and running > 0:
                intr = running * monthly
                running += intr
                day_int = intr
                ledger.append({"date": d, "kind": "interest", "label": "Interest",
                               "detail": f"{apr * 100:.2f}% APR"
                               + (" · statement" if is_stmt else ""),
                               "amount": intr, "balance": running})
            min_due = stats.min_payment_due(running, *mp, apr=apr)
        # The day's high (after charges + interest, before the payment) drives the
        # over-limit / peak flags.
        if limit > 0 and running > limit:
            over = True
        if running > peak:
            peak, peak_date = running, d
        # Pay the statement minimum on the due day (capped at the balance).
        if is_due:
            pay = min(min_due, running)
            if pay > 0:
                running -= pay
                day_pay = pay
                ledger.append({"date": d, "kind": "payment", "label": "Payment",
                               "detail": _payment_detail(card), "amount": -pay,
                               "balance": running})
        rows.append({"date": d, "charge": day_charge, "payment": day_pay,
                     "interest": day_int, "balance": running})
        d += timedelta(days=1)
    return {"name": name, "start_balance": card["balance"], "apr": apr,
            "credit_limit": limit, "rows": rows, "ledger": ledger,
            "peak_balance": peak, "peak_date": peak_date, "over_limit": over,
            "end_balance": running, "due_day": due_day,
            "statement_desc": recurrence.describe(stmt_sched) if has_stmt else None,
            "utilization": (running / limit) if limit > 0 else None}


def project_all_credit(debts: pd.DataFrame | None, expenses: pd.DataFrame | None,
                       start: date | None = None, end: date | None = None) -> list[dict]:
    """Project every revolving credit card over the window (default default_window())."""
    if start is None or end is None:
        start, end = default_window()
    return [project_credit_account(c, expenses, start, end)
            for c in credit_accounts(debts)]
