"""
taxes_page.py — the Taxes page: brackets, the YTD/full-year income worksheet,
deductions/withholding, the tax-debt record actions, and the future-distribution
calculator. Split out of dashboard.py (the math lives in taxes.py).
"""


import pandas as pd
import streamlit as st

import db
import stats
import taxes
import widgets
from ui import flash, pct
from utils import esc, money

def _pull_income(updates):
    """on_click callback for the 'Pull from income' buttons: set each editable income
    box and persist it. `updates` is a list of (session_key, constant_key, value).
    Runs before the widgets re-instantiate, so writing their session_state is allowed.
    The "__seed" shadow (where the box uses one) is synced too, so the pulled value
    counts as system-set, not as a hand edit."""
    for ss_key, const_key, value in updates:
        st.session_state[ss_key] = float(value)
        st.session_state[ss_key + "__seed"] = float(value)
        db.set_constant(const_key, float(value))


def _pull_income_live(updates):
    """on_click for 'Pull Year-to-Date from income': show each bucket's live
    classified total and DELETE its stored override. A stored value wins over
    live income in taxes.ytd_tax_debt_net, so persisting the pulled number (as
    _pull_income would) would freeze the headline at pull-time figures — clearing
    it instead puts the box back into live-tracking mode until the next hand edit."""
    for ss_key, const_key, value in updates:
        st.session_state[ss_key] = float(value)
        st.session_state[ss_key + "__seed"] = float(value)
        db.delete_constant(const_key)

# Editable taxable income by treatment on the Taxes page: (bucket key, box label).
# Module-level so the mirror toggle's on_change callback can reach the widget keys.
_INC_BUCKETS = [
    ("ordinary",            "Ordinary (wages, rent…)"),
    ("ordinary_investment", "Investment — ordinary (interest, ST)"),
    ("preferential",        "Long-term gains / qual. dividends"),
    ("collectible",         "Collectible long-term (28% max)"),
]


def _mirror_toggled():
    """on_change for 'Full-year = YTD': drop the full-year widget keys so they re-seed
    on this rerun — entering mirror mode they seed to the (locked) YTD values; LEAVING
    it they re-seed from the stored full-year constants, restoring the user's
    hand-entered projections (which mirror mode no longer overwrites)."""
    for bk, _ in _INC_BUCKETS:
        st.session_state.pop(f"tinc_fy_{bk}", None)


def _set_session_value(key, val):
    """on_click: write a number into a seed-once widget key — the 'import from
    data' buttons on the distribution calculator use this to fill inputs (the
    callback runs before the widgets re-instantiate, so the write is allowed)."""
    st.session_state[key] = float(val)


# --- taxes page ------------------------------------------------------------

def taxes_page():
    st.header("Taxes")

    # --- income tax brackets -----------------------------------------------
    st.subheader(f"Income tax brackets ({taxes.TAX_YEAR})")
    st.caption("Federal and New Jersey statutory brackets. Pick a filing status "
               "to see the full schedules and an estimate on your income.")
    st.caption(
        "🔎 Verify the current figures: "
        "[IRS brackets ↗](https://www.irs.gov/filing/federal-income-tax-rates-and-brackets) · "
        "[IRS standard deduction ↗](https://www.irs.gov/credits-deductions/individuals/standard-deduction) · "
        "[NJ rate schedules ↗](https://www.nj.gov/treasury/taxation/taxtables.shtml)"
    )

    statuses = taxes.FILING_STATUSES
    cur_idx = int(db.get_constant("filing_status", 0))
    cur_idx = cur_idx if 0 <= cur_idx < len(statuses) else 0
    status = st.selectbox(
        "Filing status", statuses, index=cur_idx,
        format_func=lambda s: taxes.FILING_LABELS[s],
    )
    if statuses.index(status) != cur_idx:
        db.set_constant("filing_status", statuses.index(status))

    fed_brackets = taxes.FEDERAL_BRACKETS[status]
    nj_brackets = taxes.NJ_BRACKETS[status]

    # ── Tax estimate & tax debt ───────────────────────────────────────────
    income_df = db.load_df("income")
    auto_ytd = taxes.categorize_income(income_df, basis="ytd")   # received so far
    auto_fy = taxes.categorize_income(income_df, basis="fy")     # full-year amounts

    st.caption("Income is taxed by its **Tax treatment** (set on the Income page): "
               "long-term gains / qualified dividends at preferential 0/15/20% rates, "
               "interest / short-term gains at ordinary rates (both subject to NIIT), "
               "and wages/rent/etc. at ordinary rates. The Year-to-date boxes track "
               "the classified totals from the Income page until you type your own — "
               "a hand edit sticks, and **Pull** clears it to resume tracking. The "
               "full-year boxes hold your projections: **Pull** imports the expected "
               "totals, or type your own. No self-employment or payroll tax is modeled.")

    # "Full-year = YTD" mode: full-year tracks YTD live (for ignoring projections or
    # filing a completed/past year). Read first so the full-year column can react.
    if "tax_mirror" not in st.session_state:
        st.session_state["tax_mirror"] = bool(db.get_constant("tax_income_mirror_ytd", 0.0))
    mirror = st.checkbox(
        "Full-year = Year-to-Date (ignore projections — e.g. a completed or past tax year)",
        key="tax_mirror", on_change=_mirror_toggled,
        help="When on, the full-year boxes track the Year-to-Date boxes automatically and "
             "lock; your stored full-year projections are kept and restored when you turn "
             "it back off.")
    _mv = 1.0 if mirror else 0.0
    if _mv != db.get_constant("tax_income_mirror_ytd", 0.0):
        db.set_constant("tax_income_mirror_ytd", _mv)

    ic1, ic2 = st.columns(2)
    with ic1:
        st.markdown("**Year-to-date income**")
        inc_ytd = {}
        for bk, label in _INC_BUCKETS:
            sk, ck = f"tinc_ytd_{bk}", f"tax_income_ytd_{bk}"
            stored = db.get_constant(ck, None)
            # What the box shows when the user hasn't typed in it: the stored
            # hand edit if one exists, else the LIVE classified total (see
            # widgets.seed_tracked for how the two are told apart).
            base = float(stored) if stored is not None else float(auto_ytd[bk])
            widgets.seed_tracked(sk, base)
            inc_ytd[bk] = st.number_input(label, min_value=0.0, step=100.0, key=sk)
            # Persist only a real hand edit — never the auto-classified value:
            # a stored value is an override that wins over live income in
            # taxes.ytd_tax_debt_net, so persisting the auto total (as a first
            # visit once did) silently froze the Overview/snapshot headline.
            if inc_ytd[bk] != base:
                db.set_constant(ck, inc_ytd[bk])
                st.session_state[f"{sk}__seed"] = inc_ytd[bk]
        st.button("↪ Pull Year-to-Date from income", width="stretch", on_click=_pull_income_live,
                  args=([(f"tinc_ytd_{bk}", f"tax_income_ytd_{bk}", auto_ytd[bk])
                         for bk, _ in _INC_BUCKETS],),
                  help="Show the year-to-date (received-so-far) totals classified on the "
                       "Income page and clear any hand-typed overrides, so the boxes track "
                       "the Income page again.")
    with ic2:
        st.markdown("**Full-year income**" + ("  _= Year-to-Date_" if mirror else ""))
        inc_fy = {}
        for bk, label in _INC_BUCKETS:
            sk, ck = f"tinc_fy_{bk}", f"tax_income_fy_{bk}"
            ytd_val = float(inc_ytd[bk])
            if mirror:
                # Lock full-year to YTD for DISPLAY only (set before instantiation,
                # then disable). The stored full-year constants are deliberately NOT
                # written in mirror mode — overwriting them with YTD every rerun
                # destroyed the user's hand-entered projections; the toggle's
                # on_change re-seeds these keys from storage when mirror turns off.
                st.session_state[sk] = ytd_val
                inc_fy[bk] = st.number_input(label, min_value=0.0, step=100.0,
                                             key=sk, disabled=True)
            else:
                stored = db.get_constant(ck, None)
                # Baseline when untouched: the stored projection, else the live
                # full-year classification (see widgets.seed_tracked).
                base = float(stored) if stored is not None else float(auto_fy[bk])
                widgets.seed_tracked(sk, base)
                # Full-year can never be below YTD: clamp for DISPLAY only. The
                # clamped value is marked system-set and never persisted — a YTD
                # typo used to overwrite the stored projection through this
                # clamp, and correcting the typo didn't bring it back.
                if st.session_state[sk] < ytd_val:
                    st.session_state[sk] = ytd_val
                    st.session_state[f"{sk}__seed"] = ytd_val
                inc_fy[bk] = st.number_input(label, min_value=ytd_val, step=100.0, key=sk)
                # Persist only a hand edit: a value differing from both the
                # baseline and whatever the system itself put in the box.
                if inc_fy[bk] != base and inc_fy[bk] != st.session_state[f"{sk}__seed"]:
                    db.set_constant(ck, inc_fy[bk])
                    st.session_state[f"{sk}__seed"] = inc_fy[bk]
        st.button("↪ Pull full-year from income", width="stretch", disabled=mirror,
                  on_click=_pull_income,
                  args=([(f"tinc_fy_{bk}", f"tax_income_fy_{bk}", max(auto_fy[bk], auto_ytd[bk]))
                         for bk, _ in _INC_BUCKETS],),
                  help="Import the full-year expected totals classified on the Income page.")

    ytd_buckets = {**inc_ytd, "excluded": 0.0}
    fy_buckets = {**inc_fy, "excluded": 0.0}
    ytd_income = sum(inc_ytd.values())
    fy_income = sum(inc_fy.values())

    # Federal deduction (larger of standard / itemized) and a SEPARATE NJ
    # deduction — NJ does not allow the federal standard/itemized deduction.
    std_ded = taxes.STANDARD_DEDUCTION[status]

    # Sum tax-deductible expenses by jurisdiction, split YTD vs full-year (YTD +
    # expected): the Year-to-Date tax debt should only count deductions already
    # incurred, while the full-year projection counts what's still expected.
    _exp_df = db.load_df("expenses")

    def _ded_sum(juris_col, cols=("deductible_ytd", "deductible_expected")):
        if _exp_df.empty or "deductible" not in _exp_df.columns:
            return 0.0
        d = _exp_df[_exp_df["deductible"] == 1]
        if juris_col in d.columns:
            d = d[d[juris_col] == 1]
        total = 0.0
        for col in cols:
            if col in d.columns:
                total += float(pd.to_numeric(d[col], errors="coerce").fillna(0.0).sum())
        return total

    fed_ded_sum = _ded_sum("deduct_federal")                          # full-year
    fed_ded_ytd_sum = _ded_sum("deduct_federal", ("deductible_ytd",))
    nj_ded_sum = _ded_sum("deduct_state")
    nj_ded_ytd_sum = _ded_sum("deduct_state", ("deductible_ytd",))

    fc1, fc2 = st.columns(2)
    with fc1:
        # Keyed + seeded once from the stored constants so the Pull button can set
        # the fields via session_state without a value=/Session-State clash.
        if "c_itemized_ytd" not in st.session_state:
            st.session_state["c_itemized_ytd"] = float(
                db.get_constant("itemized_deductions_ytd", 0.0))
        itemized_ytd = st.number_input(
            "Federal itemized — Year-to-Date ($)", min_value=0.0, step=100.0,
            key="c_itemized_ytd",
            help="Deductible amounts already incurred this year — used for the "
                 "Year-to-Date tax debt. The larger of this and the standard "
                 f"deduction (${std_ded:,}) applies.")
        if itemized_ytd != db.get_constant("itemized_deductions_ytd", 0.0):
            db.set_constant("itemized_deductions_ytd", itemized_ytd)
        if "c_itemized" not in st.session_state:
            st.session_state["c_itemized"] = float(db.get_constant("itemized_deductions", 0.0))
        itemized = st.number_input(
            "Federal itemized — full-year ($)", min_value=0.0, step=100.0, key="c_itemized",
            help=f"Expected full-year itemized deductions — used for the full-year "
                 f"projection. The larger of this and the {taxes.TAX_YEAR} standard "
                 f"deduction (${std_ded:,}) reduces federal taxable income.")
        if itemized != db.get_constant("itemized_deductions", 0.0):
            db.set_constant("itemized_deductions", itemized)
        # The pull runs in an on_click callback — setting widget session_state is
        # only allowed before the widgets re-instantiate on the next run. One
        # button fills BOTH boxes: YTD ← incurred-so-far, full-year ← YTD + expected.
        st.button(esc(f"↪ Pull deductible expenses · Federal "
                      f"({money(fed_ded_ytd_sum)} YTD / {money(fed_ded_sum)} yr)"),
                  width="stretch", disabled=fed_ded_sum <= 0,
                  on_click=_pull_income,
                  args=([("c_itemized_ytd", "itemized_deductions_ytd", fed_ded_ytd_sum),
                         ("c_itemized", "itemized_deductions", fed_ded_sum)],),
                  help="Sum of expenses flagged tax-deductible for Federal: the "
                       "Year-to-Date portion and the full year (YTD + expected).")
    deduction_ytd = max(std_ded, itemized_ytd)
    deduction = max(std_ded, itemized)

    with fc2:
        # Default NJ deduction is the per-person exemption: $1,000, or $2,000 on
        # a joint return — taxes.ytd_tax_debt_net uses the same default.
        _nj_def = taxes.nj_default_deduction(status)
        if "c_nj_ded_ytd" not in st.session_state:
            st.session_state["c_nj_ded_ytd"] = float(
                db.get_constant("nj_deductions_ytd", _nj_def))
        nj_deduction_ytd = st.number_input(
            "NJ deductions — Year-to-Date ($)", min_value=0.0, step=100.0,
            key="c_nj_ded_ytd",
            help="NJ deductions/exemptions already incurred — used for the "
                 f"Year-to-Date tax debt. The ${taxes.NJ_PERSONAL_EXEMPTION:,}-per-person "
                 "exemption applies in full, so it's the default floor.")
        if nj_deduction_ytd != db.get_constant("nj_deductions_ytd", _nj_def):
            db.set_constant("nj_deductions_ytd", nj_deduction_ytd)
        if "c_nj_ded" not in st.session_state:
            st.session_state["c_nj_ded"] = float(
                db.get_constant("nj_deductions", _nj_def))
        nj_deduction = st.number_input(
            "NJ deductions — full-year ($)", min_value=0.0, step=100.0, key="c_nj_ded",
            help=f"NJ-specific deductions/exemptions — the ${taxes.NJ_PERSONAL_EXEMPTION:,}"
                 "-per-person exemption, property-tax deduction, etc. NJ does NOT allow "
                 "the federal standard or itemized deduction.")
        if nj_deduction != db.get_constant("nj_deductions", _nj_def):
            db.set_constant("nj_deductions", nj_deduction)
        st.button(esc(f"↪ Pull deductible expenses · NJ "
                      f"({money(nj_ded_ytd_sum)} YTD / {money(nj_ded_sum)} yr)"),
                  width="stretch", disabled=nj_ded_sum <= 0,
                  on_click=_pull_income,
                  args=([("c_nj_ded_ytd", "nj_deductions_ytd", nj_ded_ytd_sum),
                         ("c_nj_ded", "nj_deductions", nj_ded_sum)],),
                  help="Sum of expenses flagged tax-deductible for State (YTD and "
                       "full-year). Add the NJ personal exemption separately if "
                       "you want it.")

    st.caption(esc(
        f"Year-to-Date: federal **{'itemized' if itemized_ytd > std_ded else 'standard'}** "
        f"{money(deduction_ytd)} · NJ {money(nj_deduction_ytd)}.  Full-year: federal "
        f"**{'itemized' if itemized > std_ded else 'standard'}** {money(deduction)} · "
        f"NJ {money(nj_deduction)} (separate, plus a "
        f"{money(taxes.NJ_FILING_THRESHOLD[status])} filing-threshold floor). "
        "🔎 [IRS Schedule A ↗](https://www.irs.gov/forms-pubs/about-schedule-a-form-1040) · "
        "[NJ deductions ↗](https://www.nj.gov/treasury/taxation/njit13.shtml)"))

    # Tax already withheld / paid this year, by jurisdiction.
    wc1, wc2 = st.columns(2)
    stored_fed_wh = db.get_constant("fed_withheld_ytd", 0.0)
    fed_withheld = wc1.number_input(
        "Federal tax withheld Year-to-Date ($)", min_value=0.0,
        value=float(stored_fed_wh), step=100.0,
        help="Federal income tax already withheld from pay or paid as estimates.")
    if fed_withheld != stored_fed_wh:
        db.set_constant("fed_withheld_ytd", fed_withheld)
    stored_nj_wh = db.get_constant("nj_withheld_ytd", 0.0)
    nj_withheld = wc2.number_input(
        "NJ tax withheld Year-to-Date ($)", min_value=0.0,
        value=float(stored_nj_wh), step=100.0,
        help="NJ income tax already withheld from pay or paid as estimates.")
    if nj_withheld != stored_nj_wh:
        db.set_constant("nj_withheld_ytd", nj_withheld)
    st.caption(
        "🔎 Find withholding on your latest paystub (Year-to-Date) or W-2 — federal = box 2, "
        "NJ = box 17. [IRS Withholding Estimator ↗](https://www.irs.gov/individuals/tax-withholding-estimator)."
    )

    # The YTD tax debt counts only deductions already incurred; the full-year
    # projection uses the full expected deduction.
    ytd_est = taxes.estimate(ytd_buckets, status, deduction_ytd, nj_deduction_ytd)
    fy_est = taxes.estimate(fy_buckets, status, deduction, nj_deduction)
    ytd_net = (ytd_est["federal"] - fed_withheld) + (ytd_est["nj"] - nj_withheld)

    col_ytd, col_fy = st.columns(2)
    with col_ytd:
        if ytd_net >= 0:
            st.metric("Tax debt (Year-to-Date, net of withholding)", money(ytd_net))
        else:
            st.metric("Projected refund (Year-to-Date)", money(-ytd_net))
        st.caption(esc(
            f"Year-to-Date tax {money(ytd_est['total'])} (fed {money(ytd_est['federal'])} + "
            f"NJ {money(ytd_est['nj'])}) − withheld {money(fed_withheld + nj_withheld)}."))
    with col_fy:
        st.metric("Projected full-year tax", money(fy_est["total"]))
        st.caption(esc(f"Fed {money(fy_est['federal'])} + NJ {money(fy_est['nj'])} "
                       f"on {money(fy_income)} income, before withholding."))

    st.caption(
        "How to read these: the Year-to-Date estimate counts only deductions already "
        "incurred (the YTD boxes), while the full-year projection uses the full "
        "expected deduction — but the federal **standard deduction** applies in full "
        "to both (it isn't prorated), so the YTD figure can still understate tax "
        "early in the year for standard-deduction filers. Turn on **Full-year = "
        "Year-to-Date** above when filing a completed or past year. New Jersey "
        "figures treat all non-excluded income as NJ-ordinary and don't model NJ's "
        "Social-Security / pension exclusions, so they can run high on benefits or "
        "pension income.")

    with st.expander("Federal + NJ breakdown (Year-to-Date)"):
        breakdown = pd.DataFrame([
            {"Component": "Federal — ordinary income", "Amount": ytd_est["fed_ordinary"]},
            {"Component": "Federal — long-term gains / qual. dividends", "Amount": ytd_est["fed_ltcg"]},
            {"Component": "Federal — collectible gains (28% max)", "Amount": ytd_est["fed_collectible"]},
            {"Component": "Net Investment Income Tax (3.8%)", "Amount": ytd_est["niit"]},
            {"Component": "New Jersey income tax", "Amount": ytd_est["nj"]},
            {"Component": "Total", "Amount": ytd_est["total"]},
        ])
        st.dataframe(
            breakdown,
            column_config={"Amount": st.column_config.NumberColumn("Amount", format="$%.2f")},
            hide_index=True, width="stretch")
        st.caption(esc(
            f"Year-to-Date income by tax treatment: ordinary {money(ytd_buckets['ordinary'])} · "
            f"ordinary investment {money(ytd_buckets['ordinary_investment'])} · "
            f"preferential (LT gains / qual. div.) {money(ytd_buckets['preferential'])}"
            + (f" · collectible {money(ytd_buckets['collectible'])}" if ytd_buckets.get("collectible") else "")
            + (f" · excluded {money(ytd_buckets['excluded'])}" if ytd_buckets["excluded"] else "")
            + f". Excludes tax credits; LTCG breakpoints are {taxes.TAX_YEAR} estimates."))

    TAX_DEBT_NAME = "Estimated income tax (YTD)"
    if ytd_net > 0:
        if st.button("Record Year-to-Date tax as a tax debt", type="primary"):
            debts_df = db.load_df("debts")
            payload = {
                "name": TAX_DEBT_NAME, "balance": round(ytd_net, 2), "apr": 0.0,
                "min_payment": None, "type": "tax", "lender": "IRS / NJ (estimated)",
                "original_balance": None, "months_remaining": None, "due_day": None,
            }
            existing = debts_df[debts_df["name"] == TAX_DEBT_NAME] if not debts_df.empty else debts_df
            if not existing.empty:
                db.update_row("debts", int(existing.iloc[0]["id"]), payload)
                flash(f"✅ Updated tax debt to {money(round(ytd_net, 2))}.")
            else:
                db.insert_row("debts", payload)
                flash(f"✅ Added tax debt of {money(round(ytd_net, 2))}.")
            st.rerun()
    else:
        st.info("Withholding covers your Year-to-Date liability — no tax debt to record.")

    bc1, bc2 = st.columns(2)
    with bc1:
        st.markdown(f"**Federal — {taxes.FILING_LABELS[status]}**")
        st.dataframe(pd.DataFrame(taxes.bracket_rows(fed_brackets)),
                     hide_index=True, width="stretch")
    with bc2:
        st.markdown(f"**New Jersey — {taxes.NJ_SCHEDULE_LABEL[status]}**")
        st.dataframe(pd.DataFrame(taxes.bracket_rows(nj_brackets)),
                     hide_index=True, width="stretch")
    st.caption(
        f"Reference values for tax year {taxes.TAX_YEAR} — update `taxes.py` when "
        "new figures are published: "
        "[IRS ↗](https://www.irs.gov/filing/federal-income-tax-rates-and-brackets) · "
        "[NJ Division of Taxation ↗](https://www.nj.gov/treasury/taxation/taxtables.shtml)"
    )
    # ── Future Distribution Tax Obligations ─────────────────────────────────
    st.divider()
    st.subheader("Future Distribution Tax Obligations")
    st.caption("Tax-deferred accounts — traditional / inherited IRAs, 401(k)s and "
               "similar — are taxed as **ordinary income** when distributed, so "
               "their raw value overstates net worth by the tax their future "
               "distributions will incur. Estimate that hidden liability here.")

    inv_accts = stats.investment_accounts(db.load_df("assets"))
    src = st.selectbox(
        "Account", ["Manual amount"] + [a["label"] for a in inv_accts],
        key="fdt_src",
        help="Pick an investment account to use its current total value, or "
             "enter an amount manually.")
    if src == "Manual amount":
        fdt_value = st.number_input("Account value ($)", min_value=0.0,
                                    value=100_000.0, step=1_000.0, key="fdt_value")
    else:
        fdt_value = float(next(a["value"] for a in inv_accts if a["label"] == src))
        st.caption(f"Current account value: **{money(fdt_value)}**")

    fc1, fc2, fc3 = st.columns(3)
    fdt_mode = fc1.radio(
        "Distribution schedule",
        ["Spread evenly over N years", "1/m of balance (m = years left)",
         "Fixed annual amount"],
        key="fdt_mode",
        help="**Spread evenly** pays the level annuity amount — with growth that "
             "is deliberately MORE than 1/N of the starting balance in year one, "
             "so the final payment lands exactly at $0. **1/m** re-divides each "
             "year's grown balance by the years remaining (rising payouts; the "
             "final year, m = 1, distributes everything).")
    fdt_years = fdt_amount = None
    fdt_sched = "level"
    if fdt_mode == "Fixed annual amount":
        fdt_sched = "fixed"
        fdt_amount = fc2.number_input("Annual distribution ($)", min_value=0.0,
                                      value=10_000.0, step=1_000.0, key="fdt_amt")
    else:
        if fdt_mode.startswith("1/m"):
            fdt_sched = "fraction"
        fdt_years = int(fc2.number_input("Years", min_value=1, max_value=100,
                                         value=20, step=1, key="fdt_years"))
    fdt_growth = fc3.number_input(
        "Assumed YoY growth (%)", value=0.0, step=0.5, key="fdt_growth",
        help="Treated as a REAL (after-inflation) rate: with flat inflation and "
             "inflation-indexed brackets, today's brackets apply every year in "
             "today's dollars.")

    # The distribution rarely arrives in a vacuum: other income fills brackets
    # (and the deduction) first, each on its own growth path.
    st.markdown("**Other income & deductions** — the bracket context each year's "
                "distribution stacks on")
    ic1, ic2 = st.columns([2.2, 1])
    if "fdt_other" not in st.session_state:        # seed-once: the import button
        st.session_state["fdt_other"] = 0.0        # writes this key directly
    fdt_other = ic1.number_input(
        "Expected yearly income — other streams ($)", min_value=0.0,
        step=1_000.0, key="fdt_other",
        help="Your other ordinary taxable income each year; the distribution is "
             "taxed marginally on top of it.")
    _fdt_inc = float(auto_fy["ordinary"] + auto_fy["ordinary_investment"])
    ic1.button(f"↪ Import from data ({money(_fdt_inc)})", key="fdt_other_pull",
               disabled=_fdt_inc <= 0,
               on_click=_set_session_value, args=("fdt_other", _fdt_inc),
               help="Full-year ordinary + ordinary-investment income classified "
                    "on the Income page.")
    fdt_inc_growth = ic2.number_input(
        "Income growth (%/yr)", value=0.0, step=0.5, key="fdt_igrow",
        help="Real growth of that income stream — raises (or, negative, lowers) "
             "the brackets later distributions land in.")

    dc1, dc2 = st.columns([2.2, 1])
    if "fdt_ded" not in st.session_state:
        st.session_state["fdt_ded"] = 0.0
    fdt_ded = dc1.number_input(
        "Expected yearly deductible ($)", min_value=0.0, step=500.0, key="fdt_ded",
        help=f"Itemized deductions each year — the LARGER of this and the "
             f"standard deduction (${taxes.STANDARD_DEDUCTION[status]:,}) "
             "applies federally.")
    dc1.button(f"↪ Import from data ({money(fed_ded_sum)})", key="fdt_ded_pull",
               disabled=fed_ded_sum <= 0,
               on_click=_set_session_value, args=("fdt_ded", fed_ded_sum),
               help="Sum of expenses flagged tax-deductible for Federal "
                    "(full-year: deductible Year-to-Date + expected).")
    fdt_ded_growth = dc2.number_input(
        "Deductible growth (%/yr)", value=0.0, step=0.5, key="fdt_dgrow",
        help="Real growth of the yearly deductible.")

    if fdt_value > 0 and (fdt_years or (fdt_amount or 0) > 0):
        fdt = taxes.future_distribution_tax(
            fdt_value, status, growth=fdt_growth / 100.0,
            years=fdt_years, annual_amount=fdt_amount, schedule=fdt_sched,
            other_income=fdt_other, income_growth=fdt_inc_growth / 100.0,
            deduction=fdt_ded, deduction_growth=fdt_ded_growth / 100.0)
        fm1, fm2, fm3 = st.columns(3)
        fm1.metric("Total future tax obligation", money(fdt["total_tax"]))
        fm2.metric("Effective rate on distributions", pct(fdt["effective_rate"]))
        fm3.metric("After-tax value received",
                   money(fdt["total_distributed"] - fdt["total_tax"]))
        _first_d = fdt["rows"][0]["distribution"] if fdt["rows"] else 0.0
        st.caption(esc(
            f"Federal {money(fdt['fed_tax'])} + NJ {money(fdt['nj_tax'])} across "
            f"{len(fdt['rows'])} year(s) of distributions totalling "
            f"{money(fdt['total_distributed'])} (first year: {money(_first_d)}) — "
            f"counting this account at face value overstates net worth by "
            f"≈ {money(fdt['total_tax'])}."))
        if fdt_sched == "fixed" and fdt["rows"] and fdt["rows"][-1]["end_balance"] > 0.01:
            st.caption(":orange[At that distribution rate the balance outlives "
                       "100 years — totals cover the first 100.]")

        FDT_DEBT_NAME = "Future distribution tax (est.)"
        if fdt["total_tax"] > 0:
            if st.button("Record as a tax debt", type="primary", key="fdt_debt"):
                debts_df = db.load_df("debts")
                payload = {
                    "name": FDT_DEBT_NAME, "balance": round(fdt["total_tax"], 2),
                    "apr": 0.0, "min_payment": None, "type": "tax",
                    "lender": "IRS / NJ (future distributions, estimated)",
                    "original_balance": None, "months_remaining": None,
                    "due_day": None,
                }
                existing = (debts_df[debts_df["name"] == FDT_DEBT_NAME]
                            if not debts_df.empty else debts_df)
                if not existing.empty:
                    db.update_row("debts", int(existing.iloc[0]["id"]), payload)
                    flash(f"✅ Updated future-distribution tax debt to "
                          f"{money(round(fdt['total_tax'], 2))}.")
                else:
                    db.insert_row("debts", payload)
                    flash(f"✅ Added future-distribution tax debt of "
                          f"{money(round(fdt['total_tax'], 2))}.")
                st.rerun()
            st.caption("Recording it as a debt subtracts the obligation from net "
                       "worth — correcting the overstatement this calculator "
                       "measures.")

        with st.expander("Year-by-year breakdown"):
            fdt_df = pd.DataFrame(fdt["rows"]).rename(columns={
                "year": "Year", "distribution": "Distribution",
                "other_income": "Other income",
                "fed_tax": "Federal tax", "nj_tax": "NJ tax",
                "end_balance": "End balance"})
            st.dataframe(
                fdt_df, hide_index=True, width="stretch",
                column_config={c: st.column_config.NumberColumn(c, format="$%.2f")
                               for c in ("Distribution", "Other income",
                                         "Federal tax", "NJ tax", "End balance")})
        st.caption(f"Assumes the **{taxes.FILING_LABELS[status]}** brackets and "
                   f"standard deduction for {taxes.TAX_YEAR}, constant in real "
                   "terms (flat inflation, inflation-indexed brackets) — so all "
                   "growth rates here are REAL rates. Distributions are ordinary "
                   "income — no NIIT (retirement distributions are exempt), no "
                   "early-withdrawal penalties, RMD rules, Social Security "
                   "interactions, or NJ retirement-income exclusions (NJ can "
                   "run high). NJ applies its personal exemption, not the "
                   "deductible above.")

    st.caption("Load sample data or clear the database on the **Data Management** page.")

