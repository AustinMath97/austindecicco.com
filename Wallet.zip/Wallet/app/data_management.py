"""
data_management.py — the Data Management page plus the data-hygiene features that
reach onto other pages:

  • A per-record staleness window (default 90 days). Records not updated within their
    window are flagged at the top of the Data Management and Overview pages.
  • An update "watch list": records the user wants prompted for review on launch. The
    prompt fires once per session, on the same condition as the auto-snapshot (a
    snapshot is due) and BEFORE it, so the snapshot can capture freshly-updated values.
  • Load-sample-data and clear-database controls (the danger zone), with confirmations.

Stale/watch state lives in the record_settings table (see db.py).
"""

import os
import re
from datetime import date, datetime, time as dtime

import pandas as pd
import streamlit as st

import cards
import db
import prices
import seed
import ui
from utils import (days_since, fmt_date, fmt_datetime, money as _money,
                   safe_str, seconds_since)

SECONDS_PER_DAY = 86_400
DEFAULT_STALE_DAYS = 90
# Live-priced (tickered) records re-price automatically, so a much tighter default
# window turns the stale flag into a watchdog: if such a value hasn't refreshed within
# a day, something in the auto-update path failed (a bad price fetch, or the app not
# opened) and it gets surfaced instead of waiting 90 days.
AUTO_STALE_DAYS = 1

TABLES = ["assets", "debts", "income", "expenses"]
TYPE_LABEL = {"assets": "Asset", "debts": "Debt", "income": "Income", "expenses": "Expense"}


# ---------------------------------------------------------------------------
# Record metadata + staleness
# ---------------------------------------------------------------------------

def _value_text(t, r):
    """A record's headline number, so the review prompt can show it at a glance:
    asset value, debt balance, annual income, or expense amount with its cadence."""
    if t == "assets":
        return _money(r.get("value"))
    if t == "debts":
        return _money(r.get("balance"))
    if t == "income":
        return f"{_money(r.get('amount'))}/yr"
    # Expense: a per-occurrence amount plus its coarse cadence label (Monthly,
    # Quarterly, …) — the schedule replaced the old monthly/annual-only model.
    freq = safe_str(r.get("frequency"))
    return f"{_money(r.get('amount'))}" + (f" · {freq}" if freq else "")


def _records_meta(frames=None):
    """One dict per record across the four editable tables, with its last-updated
    timestamp, days since, staleness window, watch flag, and whether it's overdue.
    `frames` optionally supplies already-loaded {table: DataFrame}s (the Overview
    has just loaded all four) so the check doesn't re-read the database."""
    settings = db.all_record_settings()
    out = []
    for t in TABLES:
        df = frames[t] if frames is not None and t in frames else db.load_df(t)
        if df.empty:
            continue
        for _, r in df.iterrows():
            rid = int(r["id"])
            updated = r.get("updated_at")
            days = days_since(updated)        # whole days, for display
            secs = seconds_since(updated)     # exact, for the staleness test
            cfg = settings.get((t, rid), {})
            # A tickered asset re-prices automatically (Refresh market prices / on open).
            # Default its window to 1 day so a value that hasn't refreshed flags a failed
            # auto-update fast; manual records default to 90. A custom window wins either way.
            auto = t == "assets" and bool(safe_str(r.get("ticker")))
            watch = bool(cfg.get("watch", 0))
            # Auto-priced positions AND watch-list records default to a tight 1-day window
            # (a custom value still wins): the watch list exists to nag for review, so its
            # records flag stale fast. Removing a record from the list reverts it to 90.
            sd = (int(cfg["stale_days"]) if cfg.get("stale_days")
                  else (AUTO_STALE_DAYS if (auto or watch) else DEFAULT_STALE_DAYS))
            out.append({
                "table": t, "id": rid, "type": TYPE_LABEL[t],
                "label": db.row_label(t, rid) or f"{TYPE_LABEL[t]} #{rid}",
                "record_type": cards.record_type_label(t, r),
                "value_text": _value_text(t, r),
                "updated": updated, "days": days, "stale_days": sd,
                "watch": watch, "auto_update": auto,
                # Exact: a window of sd days lapses precisely sd×86 400 s after the
                # last update, not after a floored whole-day count.
                "stale": secs is not None and secs >= sd * SECONDS_PER_DAY,
            })
    return out


def stale_records(meta=None):
    """Records past their staleness window (overdue for an update)."""
    return [m for m in (meta if meta is not None else _records_meta()) if m["stale"]]


def render_stale_flag(meta=None, frames=None):
    """If any record is overdue for an update, render a warning banner. Shared by the
    top of the Data Management and Overview pages. Pass `meta` (already-built records
    meta) or `frames` (already-loaded {table: DataFrame}s) to avoid duplicate reads."""
    if meta is None and frames is not None:
        meta = _records_meta(frames)
    stale = stale_records(meta)
    if not stale:
        return
    shown = ", ".join(f"{m['label']} ({m['days']}d)" for m in stale[:6])
    more = f" +{len(stale) - 6} more" if len(stale) > 6 else ""
    st.warning(
        f"⏰ **{len(stale)} record(s) past their update window:** {shown}{more}. "
        "Review them on the **Data Management** page.")


# ---------------------------------------------------------------------------
# Launch update prompt (watch list) — runs before the auto-snapshot
# ---------------------------------------------------------------------------

def _watched_meta():
    """Metadata for the records on the update watch list."""
    watch = {(t, i) for (t, i) in db.watched_records()}
    return [m for m in _records_meta() if (m["table"], m["id"]) in watch]


def _finish_launch():
    """End the once-per-session launch sequence without taking a snapshot."""
    st.session_state["_launch_done"] = True
    # Done-button loading flag: normally popped by the loading pass, but a dismissal
    # landing mid-Done would otherwise leave it set and render Done permanently dead
    # if a re-prompt path is ever added.
    st.session_state.pop("_lp_done_loading", None)


def _take_snapshot_and_finish():
    """Take the gated auto-snapshot (best-effort) and end the launch sequence.
    A failed price refresh never blocks the snapshot, but it is surfaced as a
    flash message instead of silently freezing stale prices into history."""
    try:
        _, summary = prices.snapshot_with_refresh(label=fmt_date(date.today()))
        if summary is None:
            st.session_state["_flash_msg"] = (
                "⚠️ Launch snapshot saved, but the price refresh failed — it "
                "recorded the last cached prices.")
        elif summary["failed"]:
            st.session_state["_flash_msg"] = (
                f"⚠️ Launch snapshot saved; {summary['failed']} price(s) could "
                "not be fetched (cached prices kept).")
    except Exception:
        pass
    _finish_launch()


def _dismiss_prompt():
    """on_dismiss for the launch prompt: closing it with the X (or Esc / clicking away)
    takes the auto-snapshot too — but ONLY when one is actually due (no snapshot in the
    last hour), so dismissing a review that opened purely because a watched record was
    stale doesn't record a redundant point right after a recent snapshot. Guarded so the
    programmatic close that happens when an 'Edit ↗' opens a record's editor — which isn't
    a real dismissal — doesn't trip it, and so a dismiss landing after Done already
    snapshotted doesn't snapshot twice."""
    if st.session_state.get("_pending_edit") or st.session_state.get("_launch_done"):
        return
    if db.snapshot_due():
        _take_snapshot_and_finish()
    else:
        _finish_launch()


def _start_done():
    """on_click for the prompt's Done button: flip the loading flag BEFORE the rerun, so
    the re-render draws the button disabled as 'Loading…' while the slow snapshot work
    (yfinance price refresh + snapshot insert) runs — the button can't be spammed."""
    st.session_state["_lp_done_loading"] = True


def _confirm_launch_record(table, row_id):
    """on_change for a row's checkbox in the launch prompt: ticking it confirms the
    record is still correct. Its updated_at is re-stamped to now, so it stops counting
    as stale and fades off the list when the dialog re-renders."""
    db.touch_row(table, row_id)


def _due_watched(watched):
    """Watched records still due for review: past their staleness window."""
    return [m for m in watched if m["stale"]]


@st.dialog("Records due for review", on_dismiss=_dismiss_prompt)
def _update_prompt():
    # The due list is recomputed HERE, inside the dialog body: a dialog is a fragment,
    # so interacting with a widget in it re-runs only this function — with the original
    # arguments it was opened with. A list passed in as an argument would be frozen for
    # the dialog's lifetime, and confirmed/edited rows would never fade out.
    due = _due_watched(_watched_meta())
    if not due:
        st.success("All caught up — every watched record has been reviewed.")
    else:
        st.caption("These watch-list records are past their update window. Check the "
                   "value shown — if it's still right, tick the box to confirm it "
                   "(its timestamp refreshes and it drops off the list); if not, "
                   "**Edit ↗** it. **Done** confirms everything left and takes a fresh "
                   "snapshot; closing this dialog takes one too, unless a snapshot was "
                   "already taken in the last hour.")
    for m in due:
        c0, c1, c2 = st.columns([0.5, 3.1, 1])
        c0.checkbox("Confirm", key=f"lp_ok_{m['table']}_{m['id']}",
                    label_visibility="collapsed",
                    on_change=_confirm_launch_record, args=(m["table"], m["id"]),
                    help="This value is still correct — refresh its timestamp and "
                         "clear it from the list without editing.")
        if m["days"] is None:
            status = ":gray[never updated]"
        else:
            status = f":red[last updated {m['days']}d ago]"
        c1.markdown(f"**{m['type']}: {m['label']}** · {m['value_text']} — {status}")
        if c2.button("Edit ↗", key=f"lp_{m['table']}_{m['id']}", width="stretch"):
            cards.request_edit(m["table"], m["id"])
            st.rerun()                       # closes this prompt, opens that record's editor
    st.divider()
    # Two-pass submit: the click only flips a flag (in the on_click callback, before the
    # rerun); this pass then renders the button disabled as "Loading…" FIRST and runs the
    # slow work after, so the user sees a dead button instead of spamming a live one
    # while yfinance responds.
    loading = st.session_state.get("_lp_done_loading", False)
    st.button("Loading…" if loading else "Done — take snapshot & continue",
              key="lp_done", type="primary", width="stretch",
              disabled=loading, on_click=_start_done)
    if loading:
        with st.spinner("Refreshing prices and taking the snapshot…"):
            for m in due:                    # everything left is confirmed correct
                db.touch_row(m["table"], m["id"])
            _take_snapshot_and_finish()
        st.session_state.pop("_lp_done_loading", None)
        st.rerun()


def run_launch_sequence():
    """Once per session: open the watch-list review prompt when a snapshot is due OR a
    watched record is stale, then take the auto-snapshot. Call at the top of the app,
    before the router."""
    if st.session_state.get("_launch_done"):
        return
    # If an edit was queued from the prompt, let it open this rerun; re-prompt afterward
    # (the edited record will have refreshed and dropped off the due list).
    if st.session_state.get("_pending_edit"):
        return
    due = _due_watched(_watched_meta())
    snap_due = db.snapshot_due()
    if not due and not snap_due:
        st.session_state["_launch_done"] = True     # neither condition → nothing to do
        return
    if not due:
        # Snapshot due, but nothing on the watch list is stale → just snapshot, no prompt.
        _take_snapshot_and_finish()
        return
    # Stale watched records exist → review them first (whether or not a snapshot is due);
    # a snapshot is taken when the prompt is finished or dismissed.
    _update_prompt()


# ---------------------------------------------------------------------------
# Page
# ---------------------------------------------------------------------------

def _drop_record_keyed_state():
    """Forget widget state that references the replaced data after a seed or
    clear: ids are renumbered (a retained watch-list selection would silently
    point at different records), and the Taxes worksheet's widget keys would
    write the OLD dataset's bucket/deduction figures straight back into the
    freshly-reset constants on the next Taxes visit. The Economic Variables
    rate boxes use the same seed-once pattern — left behind, they'd display
    the pre-reset rates and one 'Save variables' click would persist them
    over the fresh constants. Likewise the distribution calculator's imported
    income/deduction figures describe the replaced dataset."""
    st.session_state.pop("dm_watch_add", None)
    st.session_state.pop("dm_search", None)
    for k in list(st.session_state):
        # dm_records editor state is versioned per search query (dm_records_*).
        if k.startswith(("tinc_", "dm_records")):
            st.session_state.pop(k, None)
    for k in ("c_itemized", "c_itemized_ytd", "c_nj_ded", "c_nj_ded_ytd",
              "tax_mirror",
              "c_fed_target_lo", "c_fed_target_hi", "c_fed_funds_rate",
              "c_inflation_rate",
              "fdt_other", "fdt_ded"):
        st.session_state.pop(k, None)


def _parse_hms(s):
    """'HH:MM:SS' → datetime.time, or None if it doesn't parse. Typed text is used
    for the Snapshot Manager's to-the-second filter bounds because st.time_input
    can't step finer than a minute."""
    try:
        h, m, sec = (int(p) for p in str(s).strip().split(":"))
        return dtime(h, m, sec)
    except (ValueError, TypeError):
        return None


def _snapmgr_select(sid):
    """on_click: open a snapshot's value editor inside the Snapshot Manager."""
    st.session_state["_snapmgr_edit_id"] = int(sid)


def _snapmgr_duplicate(sid):
    """on_click: clone a snapshot and open the new copy in the editor, so its
    timestamp and values can be adjusted right away."""
    new_id = db.duplicate_snapshot(int(sid))
    st.session_state["_snapmgr_edit_id"] = int(new_id)
    st.session_state.pop("_snapmgr_confirm_del", None)


def _snapmgr_request_delete(sid):
    """on_click: arm the inline delete confirmation on one snapshot row — every
    other destructive flow in the app is two-step, and a misclick in the tightly
    packed scroll list used to erase history with no undo."""
    st.session_state["_snapmgr_confirm_del"] = int(sid)


def _snapmgr_cancel_delete():
    st.session_state.pop("_snapmgr_confirm_del", None)


def _snapmgr_delete(sid):
    """on_click: delete a snapshot (after its row's inline confirm). Running in
    the callback (before the fragment rerun) means the list redraws without the
    row on the same click."""
    db.delete_snapshot(int(sid))
    st.session_state.pop("_snapmgr_confirm_del", None)
    if st.session_state.get("_snapmgr_edit_id") == int(sid):
        st.session_state.pop("_snapmgr_edit_id", None)


def _opt_money(s):
    """Parse an optional money string → float, or None when blank. Strips $,
    thousands commas and spaces; raises ValueError on non-empty garbage so the
    caller can flag it (blank stays None — recorded as 'unknown', not zero)."""
    s = (s or "").strip()
    if not s:
        return None
    return float(re.sub(r"[$,\s]", "", s))


def _parse_snapshot_rows(text):
    """Parse pasted/uploaded 'date, net worth' lines into ([(date, net_worth)],
    errors). Separators may be comma, tab, or whitespace; $ and thousands commas
    in the value are tolerated, blank lines skipped, and a leading header line
    (whose value isn't a number) is dropped silently. errors is a list of
    (line_no, raw, reason) for lines that couldn't be read, so the importer can
    show exactly what it ignored instead of failing the whole paste."""
    rows, errors = [], []
    for i, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        # Split into date + remainder on the FIRST separator only, so a thousands
        # comma inside the value (e.g. "2018-03-15, $31,250") isn't mistaken for a
        # field separator — the remainder keeps its commas, stripped off below.
        parts = (re.split(r"[,\t]", line, maxsplit=1) if ("," in line or "\t" in line)
                 else line.split(None, 1))
        if len(parts) < 2:
            errors.append((i, raw, "need a date and a net-worth value"))
            continue
        d_raw, v_raw = parts[0].strip(), parts[1].strip()
        try:
            d = pd.to_datetime(d_raw).date()
        except (ValueError, TypeError):
            if i == 1:
                continue                       # a header row like "Date, Net Worth"
            errors.append((i, raw, f"unreadable date {d_raw!r}"))
            continue
        try:
            v = float(re.sub(r"[$,\s]", "", v_raw))
        except ValueError:
            if i == 1:
                continue                       # a header row like "Date, Net Worth"
            errors.append((i, raw, f"unreadable number {v_raw!r}"))
            continue
        rows.append((d, v))
    return rows, errors


def _bulk_import_snapshots(rows, skip_existing_days, label):
    """Import parsed (date, net_worth) rows in one transaction. When
    skip_existing_days, days that already hold a snapshot (and repeats within the
    paste itself) are skipped. Returns (added, skipped)."""
    existing = db.snapshot_days() if skip_existing_days else set()
    records, skipped = [], 0
    for d, v in rows:
        if skip_existing_days and d in existing:
            skipped += 1
            continue
        records.append({"taken_at": d, "net_worth": v, "label": label})
        existing.add(d)
    if records:
        db.add_snapshots_bulk(records)
    return len(records), skipped


def _add_snapshots_section():
    """The 'Add or import snapshots' panel of the Snapshot Manager: a single
    hand-entered point, or a bulk paste/CSV of historical net-worth rows. Built
    for back-filling years of (day, net worth) points from an earlier tracker —
    anything left blank is stored as unknown, never zero (see db.add_manual_snapshot)."""
    with st.expander("➕ Add or import snapshots"):
        # A fragment rerun (below) wipes any success drawn before it, so the
        # confirmation is stashed and shown on the run after the insert.
        done = st.session_state.pop("_snap_add_msg", None)
        if done:
            st.success(done)
        st.caption("Back-fill historical net-worth points (e.g. from an older "
                   "tracker). A total you leave blank is recorded as *unknown* — "
                   "it shows as a gap in the asset/debt lines, never as zero.")
        add_tab, bulk_tab = st.tabs(["Add one", "Bulk paste / CSV"])

        # ── One hand-entered snapshot ─────────────────────────────────────────
        with add_tab:
            with st.form("snap_add_one", clear_on_submit=True):
                d = st.date_input("Date", value=date.today(),
                                  min_value=date(1990, 1, 1), max_value=date.today(),
                                  format="MM/DD/YYYY", key="snap_add_date")
                nw_in = st.text_input("Net worth ($)", key="snap_add_nw",
                                      placeholder="e.g. 42000")
                with st.expander("Asset / debt breakdown (optional)"):
                    st.caption("Leave a side blank to record it as unknown. Fill "
                               "both and leave net worth blank to set net worth = "
                               "assets − debts.")
                    ca, cd = st.columns(2)
                    a_in = ca.text_input("Assets ($)", key="snap_add_assets")
                    de_in = cd.text_input("Debts ($)", key="snap_add_debts")
                lbl = st.text_input("Label (optional)", key="snap_add_lbl")
                submitted = st.form_submit_button("Add snapshot", type="primary",
                                                  width="stretch")
            if submitted:
                try:
                    nw_val, a_val, d_val = (_opt_money(nw_in), _opt_money(a_in),
                                            _opt_money(de_in))
                except ValueError:
                    st.error("Net worth / assets / debts must be numbers (or blank).")
                else:
                    if nw_val is None and a_val is None and d_val is None:
                        st.warning("Enter a net worth, or an asset/debt breakdown.")
                    else:
                        if nw_val is None and (a_val is not None or d_val is not None):
                            nw_val = (a_val or 0.0) - (d_val or 0.0)
                        db.add_manual_snapshot(d, net_worth=nw_val, assets=a_val,
                                               debts=d_val,
                                               label=(lbl or "").strip() or None)
                        st.session_state["_snap_add_msg"] = (
                            f"Added a snapshot for {d:%m/%d/%Y}.")
                        st.rerun(scope="fragment")

        # ── Bulk paste / CSV ──────────────────────────────────────────────────
        with bulk_tab:
            st.caption("One snapshot per line as `date, net worth` — e.g. "
                       "`2021-03-15, 42000`. Most date formats work; `$` and "
                       "commas in the value are fine; a header line is skipped.")
            txt = st.text_area(
                "Rows", height=160, key="snap_bulk_txt",
                placeholder="2021-03-15, 42000\n2021-04-15, 43250.75")
            up = st.file_uploader("…or upload a CSV / text file",
                                  type=["csv", "txt"], key="snap_bulk_file")
            if up is not None:
                txt = up.getvalue().decode("utf-8", "replace")
            lbl = st.text_input("Label for imported rows", value="Imported",
                                key="snap_bulk_lbl",
                                help="Tags every row from this import so you can "
                                     "spot (and, if needed, re-find) them later.")
            skip = st.checkbox("Skip days that already have a snapshot",
                               value=True, key="snap_bulk_skip")
            rows, errs = _parse_snapshot_rows(txt or "")
            if (txt or "").strip():
                st.caption(f"Read **{len(rows)}** row(s)"
                           + (f"; **{len(errs)}** line(s) couldn't be read."
                              if errs else "."))
                if errs:
                    with st.expander(f"⚠️ {len(errs)} line(s) skipped"):
                        for ln, raw, why in errs[:50]:
                            st.caption(f"Line {ln}: {why} — `{raw[:80]}`")
                        if len(errs) > 50:
                            st.caption(f"…and {len(errs) - 50} more.")
                if rows and st.button(f"Import {len(rows)} snapshot(s)",
                                      type="primary", width="stretch",
                                      key="snap_bulk_go"):
                    added, skipped = _bulk_import_snapshots(
                        rows, skip, (lbl or "").strip() or None)
                    msg = f"Imported {added} snapshot(s)."
                    if skipped:
                        msg += f" Skipped {skipped} on days already covered."
                    st.session_state["_snap_add_msg"] = msg
                    st.rerun(scope="fragment")


@st.dialog("Snapshot Manager", width="large")
def _snapshot_manager():
    # Recomputed INSIDE the body: a dialog is a fragment, so every interaction
    # re-runs this function and the list must reflect adds/deletes/edits immediately.
    hist = db.snapshot_history()
    _add_snapshots_section()        # always offered, even with no history yet
    if hist.empty:
        st.info("No snapshots yet — add or import some above, or take one from "
                "the Overview page.")
        return
    st.caption(f"{len(hist)} snapshot(s). Edit a row to change its values, label, "
               "or timestamp (re-timing where it sits on the trend); ⧉ duplicates "
               "one as the basis for a new point; 🗑 deletes it. Changes apply "
               "immediately and cannot be undone.")

    # Filter on LOCAL timestamps so the bounds match the times shown in the list
    # (snapshots are stored UTC; fmt_datetime displays them local).
    hist = hist.copy()
    local_tz = datetime.now().astimezone().tzinfo
    hist["_ts"] = (pd.to_datetime(hist["taken_at"], utc=True)
                   .dt.tz_convert(local_tz).dt.tz_localize(None))

    with st.expander("🔎 Filter by date range"):
        prec = st.radio(
            "Precision", ["Day", "Second"], horizontal=True, key="snapmgr_prec",
            help="Day keeps a range of whole calendar days; Second picks ONE day "
                 "and a typed HH:MM:SS window inside it. Both match the (local) "
                 "times shown below.")
        d_min, d_max = hist["_ts"].min().date(), hist["_ts"].max().date()
        if prec == "Second":
            # A single day + an exact time window within it.
            f_day = st.date_input("Day", value=d_max, min_value=d_min,
                                  max_value=d_max, format="MM/DD/YYYY",
                                  key="snapmgr_day")
            t1, t2 = st.columns(2)
            from_t = _parse_hms(t1.text_input("From time (HH:MM:SS)",
                                              value="00:00:00", key="snapmgr_t1"))
            to_t = _parse_hms(t2.text_input("To time (HH:MM:SS)",
                                            value="23:59:59", key="snapmgr_t2"))
            if from_t is None or to_t is None:
                st.caption(":red[Times must be HH:MM:SS — falling back to the "
                           "whole day.]")
            from_t = from_t or dtime(0, 0, 0)
            to_t = to_t or dtime(23, 59, 59)
            if from_t > to_t:
                from_t, to_t = to_t, from_t
            lo = pd.Timestamp(datetime.combine(f_day, from_t))
            hi = pd.Timestamp(datetime.combine(f_day, to_t))
        else:
            c1, c2 = st.columns(2)
            f_from = c1.date_input("From", value=d_min, min_value=d_min,
                                   max_value=d_max, format="MM/DD/YYYY",
                                   key="snapmgr_from")
            f_to = c2.date_input("To", value=d_max, min_value=d_min,
                                 max_value=d_max, format="MM/DD/YYYY",
                                 key="snapmgr_to")
            if f_from > f_to:
                f_from, f_to = f_to, f_from
            lo = pd.Timestamp(f_from)
            hi = (pd.Timestamp(f_to) + pd.Timedelta(days=1)
                  - pd.Timedelta(microseconds=1))

    shown = hist[(hist["_ts"] >= lo) & (hist["_ts"] <= hi)]
    if len(shown) != len(hist):
        st.caption(f"Showing **{len(shown)}** of {len(hist)} snapshots.")

    # Fixed-height scroll area: however long the history gets, the editor below
    # stays in reach without scrolling the whole dialog. ~8 rows visible.
    with st.container(height=480):
        if shown.empty:
            st.caption("No snapshots in this range.")
        for _, s in shown.sort_values("_ts", ascending=False).iterrows():
            sid = int(s["id"])
            c1, c2, c3, c4 = st.columns([3.0, 0.8, 0.8, 0.6])
            label = safe_str(s.get("label"))
            c1.markdown(f"**{fmt_datetime(s['taken_at'])}** · net worth "
                        f"**{_money(s['net_worth'])}**"
                        + (f" · :gray[{label}]" if label else ""))
            # Duplicate is always available (cloning is non-destructive) and opens
            # the copy in the editor; Edit/Delete share c2/c4, swapping to the
            # two-step delete confirmation when armed.
            c3.button("⧉", key=f"snap_dup_{sid}", width="stretch",
                      on_click=_snapmgr_duplicate, args=(sid,),
                      help="Duplicate this snapshot, then edit the copy.")
            if st.session_state.get("_snapmgr_confirm_del") == sid:
                c2.button("✓ Delete", key=f"snap_dy_{sid}", width="stretch",
                          type="primary", on_click=_snapmgr_delete, args=(sid,),
                          help="Permanently delete this snapshot (no undo).")
                c4.button("✕", key=f"snap_dn_{sid}", width="stretch",
                          on_click=_snapmgr_cancel_delete, help="Keep it.")
            else:
                c2.button("✏ Edit", key=f"snap_e_{sid}", width="stretch",
                          on_click=_snapmgr_select, args=(sid,))
                c4.button("🗑", key=f"snap_d_{sid}", width="stretch",
                          on_click=_snapmgr_request_delete, args=(sid,),
                          help="Delete this snapshot (asks to confirm).")

    sel = st.session_state.get("_snapmgr_edit_id")
    if sel is not None and sel in set(hist["id"].astype(int)):
        row = hist[hist["id"] == sel].iloc[0]
        st.divider()
        st.markdown(f"**Editing snapshot {fmt_datetime(row['taken_at'])}**")

        # The timestamp is editable — re-times this point on the trend. Shown and
        # entered in LOCAL time (snapshots store UTC); the time reuses the same
        # HH:MM:SS parse as the range filter above.
        cur_local = row["_ts"]
        tc1, tc2 = st.columns(2)
        ed_date = tc1.date_input("Date", value=cur_local.date(),
                                 min_value=min(date(1990, 1, 1), cur_local.date()),
                                 format="MM/DD/YYYY", key=f"snap_date_{sel}")
        ed_time = tc2.text_input("Time (HH:MM:SS)",
                                 value=cur_local.strftime("%H:%M:%S"),
                                 key=f"snap_time_{sel}")

        new_label = st.text_input("Label", value=safe_str(row.get("label")),
                                  key=f"snap_lbl_{sel}")

        # Imported / hand-added snapshots carry their net worth directly (no item
        # rows), so offer it as an editable field. Captured snapshots derive net
        # worth from their items and have None here — they edit values below.
        rec_nw = db.snapshot_recorded_net_worth(sel)
        new_nw = None
        if rec_nw is not None:
            new_nw = st.text_input(
                "Recorded net worth ($)", value=f"{float(rec_nw):.2f}",
                key=f"snap_nw_{sel}",
                help="A directly-recorded value (this snapshot has no asset/debt "
                     "breakdown). Clear it to fall back to assets − debts.")

        items = db.snapshot_items(sel)
        if items.empty:
            st.caption("No asset/debt breakdown recorded for this snapshot.")
            edited = items
        else:
            edited = st.data_editor(
                items, key=f"snap_items_{sel}", hide_index=True, width="stretch",
                column_config={
                    "rid": None,                       # internal row handle — hidden
                    "institution": None,               # account-attribution columns —
                    "account_type": None,              # captured for the Investment
                    "asset_type": None,                # Accounts page, not for editing
                    "category": st.column_config.TextColumn("Category"),
                    "name": st.column_config.TextColumn("Name"),
                    "value": st.column_config.NumberColumn("Value ($)", format="%.2f"),
                },
                disabled=["category", "name"])
        b1, b2 = st.columns(2)
        if b1.button("Save changes", type="primary", width="stretch",
                     key=f"snap_save_{sel}"):
            # Validate every field BEFORE writing anything, so a bad time or net
            # worth can't half-apply (leaving the values saved but the timestamp not).
            new_t = _parse_hms(ed_time)
            if new_t is None:
                st.error("Time must be HH:MM:SS (e.g. 14:30:00).")
                st.stop()
            new_nw_val = None
            if rec_nw is not None:
                try:
                    new_nw_val = _opt_money(new_nw)
                except ValueError:
                    st.error("Net worth must be a number (or blank).")
                    st.stop()
            for (_, orig), (_, new) in zip(items.iterrows(), edited.iterrows()):
                if float(orig["value"]) != float(new["value"]):
                    db.update_snapshot_item(int(orig["rid"]), float(new["value"]))
            if rec_nw is not None:
                db.set_snapshot_net_worth(sel, new_nw_val)
            db.set_snapshot_taken_at(sel, datetime.combine(ed_date, new_t))
            db.set_snapshot_label(sel, new_label.strip() or None)
            st.session_state.pop("_snapmgr_edit_id", None)
            st.rerun(scope="fragment")             # stay in the dialog, list refreshed
        if b2.button("Close editor", width="stretch", key=f"snap_cancel_{sel}"):
            st.session_state.pop("_snapmgr_edit_id", None)
            st.rerun(scope="fragment")


def data_management_page():
    st.header("Data Management")
    meta = _records_meta()
    render_stale_flag(meta)

    # ── 1. Records by last updated, with a per-record staleness window ─────────
    st.subheader("Records by last updated")
    st.caption("Each record's update window defaults to 90 days — but just **1 day** for "
               "🔄 live-priced positions and 👁 watch-list records, so a failed price refresh "
               "or an overdue review is flagged fast. A record not updated within its window "
               "is flagged here and on the Overview page. Edit the **Stale after (days)** "
               "column to set a custom window per record.")
    if not meta:
        st.info("No records yet. Load the sample data below, or add records on their pages.")
    else:
        q = ui.search_box("Search records", key="dm_search",
                          placeholder="Search by name or type — e.g. brokerage, checking")
        ordered = sorted(meta, key=lambda m: (m["days"] if m["days"] is not None else -1),
                         reverse=True)
        if q:
            # Match the record name, its coarse kind (Asset/Debt/Income/Expense),
            # and its granular type (Brokerage, Mortgage, Rental income, …).
            ordered = [m for m in ordered if q in
                       f'{m["label"]} {m["type"]} {m["record_type"]}'.lower()]
        if not ordered:
            st.caption(f"No records match “{q}”.")
        else:
            df = pd.DataFrame([{
                "Type": m["type"], "Kind": m["record_type"], "Record": m["label"],
                "Updates": "🔄 Auto (live price)" if m["auto_update"] else "✋ Manual",
                "Last updated": fmt_date(m["updated"]),
                "Days since": m["days"],
                "Stale after (days)": m["stale_days"],
                "Status": "⏰ Stale" if m["stale"] else "✓ OK",
                "On watch list": "👁 Yes" if m["watch"] else "",
            } for m in ordered])
            # The editor key is versioned by the search text: its pending-edit
            # state is ROW-INDEX based, so a diff left over from one filter
            # would silently re-apply to whatever row holds that index under
            # the next filter — a fresh key per query keeps diffs with the
            # row set they were made against.
            edited = st.data_editor(
                df, key=f"dm_records_{q}", hide_index=True, width="stretch",
                column_config={
                    "Days since": st.column_config.NumberColumn("Days since", format="%d"),
                    "Stale after (days)": st.column_config.NumberColumn(
                        "Stale after (days)", min_value=1, max_value=3650, step=1),
                },
                disabled=["Type", "Kind", "Record", "Updates", "Last updated",
                          "Days since", "Status", "On watch list"])
            # Persist any changed windows, then rerun: the banner and the Status /
            # ⏰ columns above were computed from the PRE-edit windows, so without a
            # rerun they lag one interaction behind the edit. The row order is by
            # days-since-update (unaffected by the window), so the editor's pending
            # edit state re-applies to the same rows — now as a no-op.
            changed = False
            for m, new_sd in zip(ordered, edited["Stale after (days)"]):
                try:
                    nv = int(new_sd)
                except (TypeError, ValueError):
                    continue
                if nv >= 1 and nv != m["stale_days"]:
                    db.set_stale_days(m["table"], m["id"], nv)
                    changed = True
            if changed:
                st.rerun()

    # ── 2. Update watch list ──────────────────────────────────────────────────
    st.divider()
    st.subheader("Update watch list")
    st.caption("Records on this list get a **1-day** staleness window and are prompted for "
               "review on launch — once per session, when a snapshot is due **or at least "
               "one of them is stale** — via a pop-up on the Overview page that appears "
               "before the snapshot is taken (so you can refresh values first). Live-priced "
               "positions (🔄) update on their own, so they're excluded from the list.")

    # Exclude auto-updating (tickered) records — they refresh on their own, so there's
    # nothing to review manually.
    unwatched = [m for m in meta if not m["watch"] and not m["auto_update"]]
    if unwatched:
        label_map = {(m["table"], m["id"]): f"{m['type']}: {m['label']}" for m in unwatched}
        picked = st.multiselect(
            "Add records to the watch list", list(label_map.keys()),
            format_func=lambda k: label_map[k], key="dm_watch_add")
        if st.button("Add to watch list", type="primary", disabled=not picked):
            for (t, i) in picked:
                db.set_watch(t, i, True)
            st.rerun()

    watched = [m for m in meta if m["watch"]]
    if watched:
        st.markdown(f"**On the watch list ({len(watched)}):**")
        for m in watched:
            c1, c2 = st.columns([4, 1])
            if m["days"] is None:
                status = "never updated"
            elif m["stale"]:
                status = f"⏰ stale — updated {m['days']}d ago"
            else:
                status = f"updated {m['days']}d ago"
            c1.markdown(f"**{m['type']}: {m['label']}** — {status}")
            if c2.button("Remove", key=f"dm_unwatch_{m['table']}_{m['id']}", width="stretch"):
                db.set_watch(m["table"], m["id"], False)
                st.rerun()
    else:
        st.caption("No records on the watch list yet. Add some above to be reminded to "
                   "review them each launch.")

    # ── 3. Export / import ──────────────────────────────────────────────────────
    st.divider()
    st.subheader("Export / Import")
    st.caption("Download a consistent copy of the whole database — every record, "
               "snapshot, link group, and saved constant. Take one before anything "
               "in the danger zone below. Restore by uploading a backup here.")
    st.download_button(
        "⬇ Download database backup",
        data=db.export_database_bytes(),
        file_name=f"finance-backup-{datetime.now():%Y%m%d-%H%M%S}.db",
        mime="application/octet-stream",
    )

    st.write("")
    # The uploader's key is versioned because a file_uploader can't be reset by
    # writing its session state — bumping the version after a restore/cancel
    # gives the next run a fresh, empty widget.
    _rv = st.session_state.get("_dm_restore_ver", 0)
    uploaded = st.file_uploader(
        "⬆ Restore from a backup", key=f"dm_restore_{_rv}",
        help="A database download from above (or a finance.db.bak-… safety copy). "
             "Replaces ALL current data; an older backup is migrated forward "
             "automatically.")
    if uploaded is not None:
        st.warning(f"Restoring **{uploaded.name}** replaces **all** current data. "
                   "A timestamped safety copy of the current database is saved "
                   "next to `finance.db` first.")
        r1, r2 = st.columns(2)
        if r1.button("Yes, restore this backup", type="primary", width="stretch"):
            try:
                bak = db.restore_database_bytes(uploaded.getvalue())
            except ValueError as e:
                st.error(f"Restore failed — {e}. Nothing was changed.")
            else:
                # Same cleanup as seed/clear: ids and figures now belong to the
                # restored dataset, so record-keyed widget state must not leak.
                _drop_record_keyed_state()
                # The restored debts' margin APRs may be stale even if the
                # economic variables match — force the next run's refresh. Same
                # for the credit-card-minimum expense sync: restored expenses
                # must re-mirror the restored cards immediately.
                st.session_state.pop("_margin_econ_seen", None)
                st.session_state.pop("_cc_min_seen", None)
                st.session_state["_dm_restore_ver"] = _rv + 1
                st.session_state["_flash_msg"] = (
                    "✅ Database restored from backup."
                    + (f" Previous data saved to {os.path.basename(bak)}." if bak else ""))
                st.rerun()
        if r2.button("Cancel", key="dm_restore_cancel", width="stretch"):
            st.session_state["_dm_restore_ver"] = _rv + 1
            st.rerun()

    # ── 5. Danger zone: load sample data / clear database ─────────────────────
    st.divider()
    st.subheader("⚠️ Danger zone")

    st.markdown("**Load sample data**")
    st.caption("Replace **all** current data with a comprehensive sample dataset — assets, "
               "debts, income, expenses, link groups, an update watch list, and 13 months of "
               "net-worth snapshots. This overwrites everything currently in the database.")
    if st.session_state.get("_confirm_seed"):
        st.warning("This **replaces all current data** with sample data. Continue?")
        s1, s2 = st.columns(2)
        if s1.button("Yes, load sample data", type="primary", width="stretch"):
            msg = seed.seed_database()
            st.session_state["_confirm_seed"] = False
            _drop_record_keyed_state()
            # Shown as a toast after the rerun (an inline st.success drawn right
            # before st.rerun() is wiped by it and never displays).
            st.session_state["_flash_msg"] = f"✅ {msg}"
            st.rerun()
        if s2.button("Cancel", key="seed_cancel", width="stretch"):
            st.session_state["_confirm_seed"] = False
            st.rerun()
    else:
        if st.button("Load sample data"):
            st.session_state["_confirm_seed"] = True
            st.rerun()

    st.write("")
    st.markdown("**Snapshot Manager**")
    st.caption("Inspect the net-worth history directly: delete a bad snapshot or edit "
               "the values one recorded. Opens immediately — changes inside apply "
               "at once, with no undo.")
    if st.button("🗂 Snapshot Manager"):
        _snapshot_manager()

    st.write("")
    st.markdown("**Clear the database**")
    st.caption("Permanently delete **all** data — assets, debts, income, expenses, link "
               "groups, snapshots, the watch list, and saved constants (rates reset to 0). "
               "This cannot be undone.")
    if st.session_state.get("_confirm_clear_db"):
        st.error("This erases the **entire database**. Are you absolutely sure?")
        d1, d2 = st.columns(2)
        if d1.button("Yes, clear everything", type="primary", width="stretch"):
            db.clear_database()
            st.session_state["_confirm_clear_db"] = False
            _drop_record_keyed_state()
            st.session_state["_flash_msg"] = ("✅ Database cleared. Every record has "
                                              "been removed.")
            st.rerun()
        if d2.button("Cancel", key="clear_cancel", width="stretch"):
            st.session_state["_confirm_clear_db"] = False
            st.rerun()
    else:
        if st.button("🗑 Clear entire database"):
            st.session_state["_confirm_clear_db"] = True
            st.rerun()
