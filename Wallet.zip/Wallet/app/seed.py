"""
seed.py — comprehensive sample data.

Covers every asset-type family, debt type, income type, and expense category so
every section of the dashboard renders with realistic data. Specifically it
exercises the full breadth of the app:

  - Assets across every family (brokerage / retirement / inherited / crypto /
    cash w/ APY+payout schedules / real estate / vehicles / business / receivables
    / collectibles), with cost bases that drive unrealized gains and losses.
  - Every debt type, and income on every recurrence cadence (weekly … annual).
  - Expenses on EVERY schedule cadence — weekly, biweekly, semi-monthly, monthly,
    nth-weekday, quarterly, semi-annual, annual, and one-time — so the calendar,
    the auto-draft cash-flow forecast, and the expense cards all get tested.
  - Link groups tying each asset to its financing + bills, including debt↔expense
    payment pairs (mortgage, auto loan) that share a due day so the same payment
    is never drawn twice on the calendar.
  - Deductible expenses (401k, HSA, SALT/property tax, charity, business) feeding
    the Taxes page, a watch list with staleness, and 13 monthly net-worth snapshots.

Run once:

    python seed.py

If the database already has data, the CLI asks before replacing it (pass
--force to skip the prompt) and writes a timestamped finance.db.bak-… copy
first. Delete finance.db to start over with a blank slate.
"""

from datetime import date, timedelta

import pandas as pd

import accounts
import db
import recurrence
import taxes
from utils import safe_float, safe_str

# One-time charges are anchored relative to the seed date so they stay in the
# near future whenever you reseed (a hardcoded 2026 date would fall into the past
# next year and silently drop off the calendar / cash-flow forecast).
_TODAY = date.today()
_ONE_TIME_SOON = (_TODAY + timedelta(days=24)).isoformat()    # e.g. tax-prep fee
_ONE_TIME_LATER = (_TODAY + timedelta(days=46)).isoformat()   # e.g. concert tickets

# ---------------------------------------------------------------------------
# Assets — one row per position/account, every asset-type family represented
# ---------------------------------------------------------------------------

# Each asset carries an account_type (the tax/custody wrapper — None when held
# directly) and an asset_type (what the holding actually is).
SAMPLE_ASSETS = pd.DataFrame([

    # ── Brokerage — Fidelity ────────────────────────────────────────────────
    {"name": "NVDA",  "account_type": "Brokerage", "asset_type": "Stock",
     "institution": "Fidelity", "ticker": "NVDA",  "shares": 50,
     "value": 6875,  "liquid": 1, "last_price": 137.50, "updated_at": None,
     "cost_basis": 3_000},   # bought at ~$60/share

    {"name": "VTI",   "account_type": "Brokerage", "asset_type": "ETF / Index Fund",
     "institution": "Fidelity", "ticker": "VTI",   "shares": 80,
     "value": 19200, "liquid": 1, "last_price": 240.00, "updated_at": None,
     "cost_basis": 16_000},

    {"name": "BND",   "account_type": "Brokerage", "asset_type": "ETF / Index Fund",
     "institution": "Fidelity", "ticker": "BND",   "shares": 100,
     "value": 7220,  "liquid": 1, "last_price": 72.20,  "updated_at": None,
     "cost_basis": 7_050},

    # ── Brokerage — Schwab ───────────────────────────────────────────────────
    {"name": "AAPL",  "account_type": "Brokerage", "asset_type": "Stock",
     "institution": "Charles Schwab", "ticker": "AAPL",  "shares": 30,
     "value": 5490,  "liquid": 1, "last_price": 183.00, "updated_at": None,
     "cost_basis": 4_200},   # ESPP shares

    {"name": "SCHD",  "account_type": "Brokerage", "asset_type": "ETF / Index Fund",
     "institution": "Charles Schwab", "ticker": "SCHD",  "shares": 60,
     "value": 4380,  "liquid": 1, "last_price": 73.00,  "updated_at": None,
     "cost_basis": 3_800},

    # ── Roth IRA — Vanguard (individual positions) ───────────────────────────
    {"name": "VTI",   "account_type": "Roth IRA", "asset_type": "ETF / Index Fund",
     "institution": "Vanguard", "ticker": "VTI",   "shares": 120,
     "value": 28800, "liquid": 0, "last_price": 240.00, "updated_at": None,
     "cost_basis": 22_000},  # contributions over several years

    {"name": "VXUS",  "account_type": "Roth IRA", "asset_type": "ETF / Index Fund",
     "institution": "Vanguard", "ticker": "VXUS",  "shares": 60,
     "value": 3480,  "liquid": 0, "last_price": 58.00,  "updated_at": None,
     "cost_basis": 3_000},

    # ── Traditional IRA — Fidelity ───────────────────────────────────────────
    {"name": "FXAIX", "account_type": "Traditional IRA", "asset_type": "Mutual Fund",
     "institution": "Fidelity", "ticker": "FXAIX", "shares": 85,
     "value": 16490, "liquid": 0, "last_price": 194.00, "updated_at": None,
     "cost_basis": 14_000},   # Fidelity 500 Index Fund

    # ── 401(k) — Vanguard ────────────────────────────────────────────────────
    {"name": "VTTSX", "account_type": "401(k)", "asset_type": "Mutual Fund",
     "institution": "Vanguard 401(k)", "ticker": "VTTSX", "shares": 500,
     "value": 18500, "liquid": 0, "last_price": 37.00,  "updated_at": None,
     "cost_basis": 15_000},   # Target Retirement 2060

    # ── SEP IRA — Schwab (an S&P 500 index-fund position) ────────────────────
    # A held position with a 20% unrealized gain, so it carries the ticker /
    # shares / price that back that gain (value = shares × price).
    {"name": "SWPPX", "account_type": "SEP IRA", "asset_type": "Mutual Fund",
     "institution": "Charles Schwab", "ticker": "SWPPX", "shares": 500,
     "value": 42000, "liquid": 0, "last_price": 84.00,  "updated_at": None,
     "cost_basis": 35_000},

    # ── Inherited / Estate ───────────────────────────────────────────────────
    # An ETF held INSIDE an inherited IRA: the account type drives tax treatment
    # (tax-deferred — no capital gains), the asset type is what it actually is.
    {"name": "VOO", "account_type": "Inherited IRA (Traditional)",
     "asset_type": "ETF / Index Fund", "institution": "Fidelity",
     "ticker": "VOO", "shares": 40,
     "value": 22000, "liquid": 0, "last_price": 550.00, "updated_at": None,
     "cost_basis": 20000},   # stepped-up basis at inheritance

    {"name": "Estate cash distribution",
     "account_type": "Estate / Trust Distribution (pending)", "asset_type": "Cash",
     "institution": "Smith Family Trust", "ticker": None, "shares": None,
     "value": 15000, "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": None},

    # ── Crypto — Coinbase ────────────────────────────────────────────────────
    {"name": "Bitcoin",  "account_type": "Centralized Exchange (CEX)",
     "asset_type": "Cryptocurrency", "institution": "Coinbase", "ticker": "BTC-USD",
     "shares": 0.35, "value": 24500, "liquid": 1, "last_price": 70000.00,
     "updated_at": None, "cost_basis": 15_000},

    {"name": "Ethereum", "account_type": "Centralized Exchange (CEX)",
     "asset_type": "Cryptocurrency", "institution": "Coinbase", "ticker": "ETH-USD",
     "shares": 2.0,  "value": 7000,  "liquid": 1, "last_price": 3500.00,
     "updated_at": None, "cost_basis": 5_000},

    # ── Crypto — self-custody ────────────────────────────────────────────────
    {"name": "Solana",   "account_type": "Self-custody wallet",
     "asset_type": "Cryptocurrency", "institution": "Phantom Wallet", "ticker": "SOL-USD",
     "shares": 15,   "value": 2625,  "liquid": 0, "last_price": 175.00,
     "updated_at": None, "cost_basis": 3_000},  # slight unrealized loss

    # ── Cash & Bank Accounts ─────────────────────────────────────────────────
    {"name": "Checking",           "account_type": "Checking", "asset_type": "Cash",
     "institution": "Chase", "ticker": None, "shares": None,
     "value": 5200,  "liquid": 1, "last_price": None, "updated_at": None, "cost_basis": None},

    {"name": "High-Yield Savings", "account_type": "High-Yield Savings (HYSA)",
     "asset_type": "Cash", "institution": "Ally", "ticker": None, "shares": None,
     "value": 25000, "liquid": 1, "last_price": None, "updated_at": None, "cost_basis": None,
     "apy": 0.043, "interest_schedule_type": "monthly", "interest_pay_days": "1"},

    {"name": "Money Market",       "account_type": "Money Market", "asset_type": "Cash",
     "institution": "Fidelity", "ticker": None, "shares": None,
     "value": 8000,  "liquid": 1, "last_price": None, "updated_at": None, "cost_basis": None,
     "apy": 0.046, "interest_schedule_type": "monthly", "interest_pay_days": "1"},

    # An HSA is two parts: a cash spending buffer that earns a small APY, and an
    # invested portion (funds/ETFs with a cost basis). Model both — one HSA at
    # Optum, split across two rows: the cash side carries the APY (account "HSA
    # (Health Savings)"), the invested side carries the gain (account "HSA").
    {"name": "HSA",                "account_type": "HSA (Health Savings)", "asset_type": "Cash",
     "institution": "Optum Bank", "ticker": None, "shares": None,
     "value": 1400,  "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": None,
     "apy": 0.015, "interest_schedule_type": "monthly", "interest_pay_days": "1"},

    {"name": "VITSX",              "account_type": "HSA", "asset_type": "Mutual Fund",
     "institution": "Optum Bank", "ticker": "VITSX", "shares": 40,
     "value": 5000,  "liquid": 0, "last_price": 125.00, "updated_at": None,
     "cost_basis": 3900},   # Vanguard Total Stock Market Index; ~28% unrealized gain

    {"name": "I-Bonds",            "account_type": "Treasury Bills / I-Bonds",
     "asset_type": "Cash", "institution": "TreasuryDirect", "ticker": None, "shares": None,
     "value": 10000, "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": None,
     "apy": 0.043, "interest_schedule_type": "quarterly", "interest_pay_days": "1",
     "interest_months": "3,6,9,12"},

    {"name": "6-Month CD",         "account_type": "CD (Certificate of Deposit)",
     "asset_type": "Cash", "institution": "Marcus", "ticker": None, "shares": None,
     "value": 5000,  "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": None,
     "apy": 0.045, "maturity_date": "2026-12-05",
     "interest_schedule_type": "monthly", "interest_pay_days": "5"},

    # ── Real Estate (held directly — no account type) ────────────────────────
    {"name": "123 Oak Lane",  "account_type": None, "asset_type": "Primary Residence",
     "institution": None, "ticker": None, "shares": None,
     "value": 450000, "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": 360000,
     "street": "123 Oak Lane", "city": "Montclair", "state": "NJ", "zip_code": "07042",
     "beds": 4, "baths": 2.5, "sqft": 2400, "year_built": 1998},   # bought at $360k

    {"name": "456 Maple Ave", "account_type": None, "asset_type": "Rental Property",
     "institution": None, "ticker": None, "shares": None,
     "value": 280000, "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": 200000,
     "street": "456 Maple Ave", "city": "Montclair", "state": "NJ", "zip_code": "07043",
     "beds": 3, "baths": 2, "sqft": 1600, "year_built": 1975},     # bought at $200k

    # ── Vehicles ─────────────────────────────────────────────────────────────
    {"name": "2022 Toyota Camry",  "account_type": None, "asset_type": "Car",
     "institution": None, "ticker": None, "shares": None,
     "value": 24000, "liquid": 0, "last_price": None, "updated_at": None,
     "cost_basis": None, "mileage": 38000, "vin": "4T1C11AK5NU123456",
     "trim": "SE", "condition": "Good",
     "make": "Toyota", "model": "Camry", "model_year": 2022},

    {"name": "2019 Honda CBR500R", "account_type": None, "asset_type": "Motorcycle",
     "institution": None, "ticker": None, "shares": None,
     "value": 5500,  "liquid": 0, "last_price": None, "updated_at": None,
     "cost_basis": None, "mileage": 9500, "vin": "MLHPC4407K5200123",
     "condition": "Good",
     "make": "Honda", "model": "CBR500R", "model_year": 2019},

    # ── Business Interests ───────────────────────────────────────────────────
    {"name": "Acme Consulting LLC", "account_type": None,
     "asset_type": "Partnership / LLC Interest", "institution": None,
     "ticker": None, "shares": None,
     "value": 35000, "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": None,
     "ownership_pct": 0.6},

    # ── Receivables ──────────────────────────────────────────────────────────
    {"name": "Loan to Alex",                 "account_type": None,
     "asset_type": "Personal Loan to Someone", "institution": "Alex Rivera",
     "ticker": None, "shares": None,
     "value": 1500,  "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": None,
     "collection_date": "2026-09-01", "collection_prob": 0.9, "apy": 0.04},

    {"name": "Security deposit — old apt",   "account_type": None,
     "asset_type": "Security Deposit", "institution": "Maple Property Mgmt",
     "ticker": None, "shares": None,
     "value": 2400,  "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": None,
     "collection_date": "2026-08-15", "collection_prob": 1.0},

    {"name": "Federal tax refund",           "account_type": None,
     "asset_type": "Tax Refund Expected", "institution": "IRS",
     "ticker": None, "shares": None,
     "value": 1200,  "liquid": 1, "last_price": None, "updated_at": None, "cost_basis": None,
     "collection_date": "2026-06-20", "collection_prob": 1.0},

    # ── Collectibles ─────────────────────────────────────────────────────────
    {"name": "Omega Seamaster",       "account_type": None, "asset_type": "Jewelry / Watches",
     "institution": None, "ticker": None, "shares": None,
     "value": 4500,  "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": 3800},

    {"name": "Original oil painting", "account_type": None, "asset_type": "Art",
     "institution": None, "ticker": None, "shares": None,
     "value": 3200,  "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": 2500},

    {"name": "1952 Mantle PSA 7",     "account_type": None, "asset_type": "Trading Cards / Comics",
     "institution": None, "ticker": None, "shares": None,
     "value": 8500,  "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": 4200},

    # ── Other ────────────────────────────────────────────────────────────────
    {"name": "Whole life — cash value", "account_type": None, "asset_type": "Life Insurance CV",
     "institution": None, "ticker": None, "shares": None,
     "value": 12500, "liquid": 0, "last_price": None, "updated_at": None, "cost_basis": None},
])

# ---------------------------------------------------------------------------
# Debts — every type represented
# ---------------------------------------------------------------------------

SAMPLE_DEBTS = pd.DataFrame([

    # Percent-with-floor minimum: max(2% of balance, $35) — the common card rule. The
    # statement closes on the LAST FRIDAY each month (an ordinal-weekday schedule that
    # drifts month to month); that balance sets the minimum, due on the 17th.
    {"name": "Chase Sapphire Reserve",   "balance": 2400,   "apr": 0.2499,
     "min_payment": 35,   "type": "revolving",        "lender": "Chase",
     "min_payment_type": "percent_floor", "min_payment_pct": 0.02, "credit_limit": 15000,
     "statement_week_ordinal": -1, "statement_weekday": 4,
     "original_balance": None, "months_remaining": None, "due_day": 17},

    # Flat-dollar minimum on a tight limit: its many auto-drafted subscriptions push
    # the balance over the limit within the 30-day window, so the Credit Accounts
    # page raises an over-limit flag (the headline feature of that page).
    {"name": "Amex Blue Cash",           "balance": 850,    "apr": 0.1999,
     "min_payment": 25,   "type": "revolving",        "lender": "American Express",
     "min_payment_type": "fixed", "credit_limit": 1200,
     "statement_day": 6, "original_balance": None, "months_remaining": None, "due_day": 29},

    {"name": "Federal Direct Subsidized","balance": 18000,  "apr": 0.045,
     "min_payment": 185,  "type": "education",        "lender": "MOHELA",
     "original_balance": 22000,  "months_remaining": 96,   "due_day": 1},

    {"name": "Private — Sallie Mae",     "balance": 8200,   "apr": 0.065,
     "min_payment": 120,  "type": "education",        "lender": "Sallie Mae",
     "original_balance": 10000,  "months_remaining": 72,   "due_day": 5},

    {"name": "Auto — 2022 Toyota Camry", "balance": 12400,  "apr": 0.049,
     "min_payment": 350,  "type": "auto",             "lender": "Toyota Financial",
     "original_balance": 24000,  "months_remaining": 36,   "due_day": 21},

    {"name": "Mortgage — 123 Oak Lane",  "balance": 285000, "apr": 0.0675,
     "min_payment": 1895, "type": "mortgage",         "lender": "Wells Fargo",
     "original_balance": 360000, "months_remaining": 312,  "due_day": 1},

    {"name": "HELOC — 456 Maple Ave",    "balance": 15000,  "apr": 0.0850,
     "min_payment": 200,  "type": "home_equity",      "lender": "Bank of America",
     "original_balance": None,   "months_remaining": None, "due_day": 30},

    {"name": "Personal Loan — SoFi",     "balance": 5000,   "apr": 0.0899,
     "min_payment": 165,  "type": "personal",         "lender": "SoFi",
     "original_balance": 7500,   "months_remaining": 32,   "due_day": 22},

    {"name": "BNPL — MacBook Pro (Affirm)","balance": 950,  "apr": 0.0,
     "min_payment": 95,   "type": "bnpl",             "lender": "Affirm",
     "original_balance": 1900,   "months_remaining": 10,   "due_day": 31},

    {"name": "Medical — City Hospital",  "balance": 1200,   "apr": 0.0,
     "min_payment": 100,  "type": "medical",          "lender": "City Hospital",
     "original_balance": None,   "months_remaining": None, "due_day": 15},

    {"name": "IRS Installment 2023",     "balance": 3500,   "apr": 0.08,
     "min_payment": 300,  "type": "tax",              "lender": "IRS",
     "original_balance": 4200,   "months_remaining": 12,   "due_day": 14},

    {"name": "SBA Microloan — Acme LLC", "balance": 18000,  "apr": 0.065,
     "min_payment": 400,  "type": "business",         "lender": "SBA",
     "original_balance": 25000,  "months_remaining": 48,   "due_day": 3},

    # Margin loan: APR is a live formula over the economic variables (broker base
    # ≈ fed funds + 3% spread), borrowed against the Charles Schwab brokerage
    # account (margin_account is a plain datapoint — the lender is inferred from it,
    # it is NOT a link group). Counts as NEGATIVE liquidity; no scheduled payment.
    {"name": "Margin — Schwab",          "balance": 9000,   "apr": 0.0833,
     "apr_formula": "fed_funds_rate + 0.03",
     "margin_account": "Charles Schwab — Brokerage",
     "min_payment": 0,    "type": "margin",           "lender": "Charles Schwab",
     "original_balance": None,   "months_remaining": None, "due_day": None},

    {"name": "Loan from Mom",            "balance": 3000,   "apr": 0.0,
     "min_payment": 250,  "type": "personal_informal","lender": "Family",
     "original_balance": 3000,   "months_remaining": 12,   "due_day": 1},
])

# ---------------------------------------------------------------------------
# Income — one row per stream (full-year amount + how much received so far)
# ---------------------------------------------------------------------------

def _inc(source, amount, received_ytd, itype, *, schedule_type="none", weekday=None,
         week_ordinal=None, anchor_date=None, pay_days=None, months=None,
         pay_amount=None, tax_class=None, auto_deposit=0, deposit_target=None):
    """Build an income row. One row per stream: `amount` is the full-year expected
    total and `received_ytd` the portion already in hand. `tax_class` is the tax
    treatment (defaults from `itype`). `auto_deposit`/`deposit_target` mark a stream
    that lands in an account automatically (mirror of an auto-drafted expense).
    `frequency` and `pay_day` (the human summary) are derived from the schedule so the
    card label and calendar always agree — and the schedule projects this one stream
    forward exactly once."""
    sched = {"type": schedule_type, "weekday": weekday, "ordinal": week_ordinal,
             "anchor": anchor_date, "month_days": pay_days, "months": months}
    return {"source": source, "amount": amount, "received_ytd": received_ytd, "type": itype,
            "tax_class": tax_class or taxes.default_tax_class(itype),
            "auto_deposit": auto_deposit, "deposit_target": deposit_target,
            "frequency": recurrence.frequency_label(schedule_type),
            "pay_day": recurrence.describe(sched) or None,
            "pay_days": pay_days, "pay_amount": pay_amount,
            "schedule_type": schedule_type, "weekday": weekday,
            "week_ordinal": week_ordinal, "anchor_date": anchor_date, "months": months}

# One row per stream: amount = full-year expected total. The received_ytd values
# written here are placeholders for the schedule-less streams only — scheduled
# streams get theirs recomputed from the schedule at seed time (see
# _recompute_received_ytd), so the figures are right whatever date you seed on.
SAMPLE_INCOME = pd.DataFrame([
    # Semi-monthly salary — the 1st & 15th every month, ~$5,417/paycheck → $130k/yr.
    # Direct-deposited into Checking (auto-deposit, the mirror of an auto-drafted bill).
    _inc("Google", 130000, 54170, "wages",
         schedule_type="semimonthly", pay_days="1,15", pay_amount=5417,
         auto_deposit=1, deposit_target="Checking"),

    # Year-end bonus — once a year on Dec 31 (not yet received), direct-deposited.
    _inc("Google — Year-End Bonus", 12000, 0, "wages",
         schedule_type="annual", anchor_date="2026-12-31", pay_amount=12000,
         auto_deposit=1, deposit_target="Checking"),

    # Part-time paycheck — every other Friday (biweekly), $600 × 26 ≈ $15,600/yr.
    # The anchor is a known Friday payday; the fortnight rhythm is derived from it.
    _inc("Part-time — Cafe", 15600, 7200, "wages",
         schedule_type="biweekly", anchor_date="2026-01-09", pay_amount=600,
         auto_deposit=1, deposit_target="Checking"),

    # Freelance — one ongoing stream (not on the calendar): $7,500 expected this
    # year, $4,500 already paid (the rest is a Q3 project still to come). This used
    # to be split into two cards (received vs expected); received_ytd captures it.
    _inc("Freelance — design work", 7500, 4500, "self_employment"),

    # Dividends — quarterly, 15th of Mar / Jun / Sep / Dec ($300 × 4); qualified,
    # so they get preferential rates.
    _inc("Dividends — Fidelity", 1200, 600, "capital", tax_class="preferential",
         schedule_type="quarterly", pay_days="15", months="3,6,9,12", pay_amount=300),

    # Capital gains — irregular, not yet realised; long-term → preferential rates.
    _inc("Long-term Gains — NVDA", 2400, 0, "capital", tax_class="preferential"),

    # Interest paid out on the cash accounts, taken as income — each matches its
    # account's APY + payout schedule (see the asset's "Interest paid"). Ordinary-rate
    # investment income (subject to NIIT). Not auto-deposited: the account's APY already
    # grows its balance in the Accounts projection, so depositing it would double-count.
    # $25k @ 4.30% HYSA, monthly on the 1st  -> $87.86/mo (12 × ≈ $1,054/yr)
    _inc("Interest — Ally HYSA", 1054, 527, "capital", tax_class="ordinary_investment",
         schedule_type="monthly", pay_days="1", pay_amount=87.86),
    # $8k @ 4.60% Money Market, monthly on the 1st -> $30.04/mo (≈ $360/yr)
    _inc("Interest — Fidelity Money Market", 360, 180, "capital", tax_class="ordinary_investment",
         schedule_type="monthly", pay_days="1", pay_amount=30.04),
    # $5k @ 4.50% CD, monthly on the 5th -> $18.37/mo (≈ $220/yr)
    _inc("Interest — Marcus CD", 220, 110, "capital", tax_class="ordinary_investment",
         schedule_type="monthly", pay_days="5", pay_amount=18.37),
    # $10k @ 4.30% I-Bonds, quarterly on the 1st of Mar/Jun/Sep/Dec -> $105.81/qtr (≈ $423/yr)
    _inc("Interest — I-Bonds", 423, 212, "capital", tax_class="ordinary_investment",
         schedule_type="quarterly", pay_days="1", months="3,6,9,12", pay_amount=105.81),

    # Rental — 1st of the month, $700 → $8,400/yr (one stream, not double-booked)
    _inc("Rental — 456 Maple Ave", 8400, 3500, "rental",
         schedule_type="monthly", pay_days="1", pay_amount=700,
         auto_deposit=1, deposit_target="Checking"),

    # Royalties — 28th of the month, ~$50 → ~$600/yr
    _inc("Kindle — Programming Guide", 600, 250, "royalties",
         schedule_type="monthly", pay_days="28", pay_amount=50),

    # DoorDash — every Wednesday (weekday 2), $150 × 52 ≈ $7,800/yr. Lands on the
    # real Wednesdays of whatever month the calendar shows, not fixed day numbers.
    _inc("DoorDash", 7800, 3000, "gig",
         schedule_type="weekly", weekday=2, pay_amount=150),

    # Gift — one-off, already received, not on the calendar
    _inc("Birthday gift — family", 500, 500, "gift"),
])


def _recompute_received_ytd(income_df, today):
    """Make each scheduled stream's received_ytd match the seed date: occurrences
    from Jan 1 through `today` × the per-payment amount (pro-rata of the annual
    amount when no per-payment figure exists), capped at the annual amount. The
    static values above would otherwise only be right ~5 months into the year.
    Schedule-less streams (freelance, unrealised gains, gifts) keep their
    hand-written values — there is no schedule to count."""
    df = income_df.copy()
    received = []
    for row in df.to_dict("records"):
        # NaN-safe reads: the DataFrame round-trip turns None into NaN, and NaN is
        # truthy in Python — a plain `if pay:` would multiply by NaN.
        if not safe_str(row.get("schedule_type")):
            received.append(row.get("received_ytd"))
            continue
        sched = recurrence.from_row(row)
        done = total = 0
        for m in range(1, 13):
            days = recurrence.occurrences_in_month(sched, today.year, m)
            total += len(days)
            if m < today.month:
                done += len(days)
            elif m == today.month:
                done += sum(1 for d in days if d <= today.day)
        amount = safe_float(row.get("amount"))
        pay = safe_float(row.get("pay_amount"))
        if pay > 0:
            got = pay * done
        elif total:
            got = amount * done / total
        else:
            got = safe_float(row.get("received_ytd"))
        received.append(round(min(got, amount), 2))
    df["received_ytd"] = received
    return df

# ---------------------------------------------------------------------------
# Expenses — every category represented
# ---------------------------------------------------------------------------

def _e(cat, sub, amt, freq="monthly", auto=0, draft=None, due=None, due_month=None,
       deductible=0, deduction_category=None, deductible_ytd=0, deductible_expected=0,
       deduct_federal=1, deduct_state=1, deduction_notes=None,
       *, schedule_type=None, pay_days=None, anchor_date=None, weekday=None,
       week_ordinal=None, months=None):
    """Build an expense row on the full recurrence schedule (the model income uses).
    `amount` is the per-occurrence draft; `frequency` (coarse label) and `pay_day`
    (human summary) are derived from the schedule so the card and calendar agree.

    The legacy shorthand still works: pass freq="monthly" with `due` (day of month),
    or freq="annual" with `due`+`due_month`. For richer cadences pass the schedule
    params directly (schedule_type / pay_days / months / anchor_date / …)."""
    if schedule_type is None:
        if str(freq).lower() == "annual":
            schedule_type = recurrence.ANNUAL
            if anchor_date is None and due:
                anchor_date = f"2000-{int(due_month or 1):02d}-{int(due):02d}"
        else:
            schedule_type = recurrence.MONTHLY
            if pay_days is None and due:
                pay_days = str(int(due))
    sched = {"type": schedule_type, "weekday": weekday, "ordinal": week_ordinal,
             "anchor": anchor_date, "month_days": pay_days, "months": months}
    return {"category": cat, "subcategory": sub, "amount": amt,
            "frequency": recurrence.frequency_label(schedule_type),
            "auto_draft": auto, "draft_source": draft,
            "schedule_type": schedule_type, "weekday": weekday,
            "week_ordinal": week_ordinal, "anchor_date": anchor_date,
            "pay_days": pay_days, "months": months,
            "pay_day": recurrence.describe(sched) or None,
            "deductible": deductible,
            "deduction_category": deduction_category, "deductible_ytd": deductible_ytd,
            "deductible_expected": deductible_expected, "deduct_federal": deduct_federal,
            "deduct_state": deduct_state, "deduction_notes": deduction_notes}

# Every recurrence cadence is represented at least once so the calendar, the
# auto-draft forecast, and the expense cards all exercise the full schedule
# model: weekly, biweekly, semi-monthly, monthly, nth-weekday, quarterly,
# semi-annual (quarterly type w/ 2 months), annual, and one-time.
SAMPLE_EXPENSES = pd.DataFrame([
    # ── Housing — bills auto-draft from Checking ─────────────────────────────
    # Mortgage payment shares the linked debt's due day (the 1st) — the calendar
    # suppresses the debt itself so the bill isn't drawn twice on different days.
    _e("Housing", "Mortgage (P&I)",               1895, "monthly", 1, "Checking", 1),
    _e("Housing", "Electricity",                   130,  "monthly", 1, "Checking", 18),
    _e("Housing", "Gas / Heat",                     70,  "monthly", 1, "Checking", 18),
    # Quarterly water/sewer — billed the 15th of Feb / May / Aug / Nov.
    _e("Housing", "Water / Sewer",                 180,  auto=1, draft="Checking",
       schedule_type="quarterly", pay_days="15", months="2,5,8,11"),
    _e("Housing", "Internet",                       70,  "monthly", 1, "Checking", 12),
    _e("Housing", "HOA Fees",                      200,  "monthly", 1, "Checking", 1),
    # NJ property tax — quarterly on the 1st of Feb / May / Aug / Nov; deductible.
    _e("Housing", "Property Tax (NJ)",            2400,  auto=1, draft="Checking",
       schedule_type="quarterly", pay_days="1", months="2,5,8,11",
       deductible=1, deduction_category="State & Local Taxes (SALT)",
       deductible_ytd=4800, deductible_expected=4800,
       deduction_notes="SALT — capped at $10k federal; NJ property-tax deduction applies"),
    _e("Housing", "Homeowner's Insurance",        1800,  "annual",  1, "Checking", 1,  due_month=9),
    # Weekly housekeeper — every Friday (a cadence the old model couldn't hold).
    _e("Housing", "Cleaning Service",              120,  auto=1, draft="Checking",
       schedule_type="weekly", weekday=4),
    # Monthly lawn service on the first Monday of the month (nth-weekday schedule).
    _e("Housing", "Lawn / Landscaping",             90,  auto=1, draft="Checking",
       schedule_type="monthly_weekday", week_ordinal=1, weekday=0),

    # ── Transportation ───────────────────────────────────────────────────────
    # Car payment shares the auto loan's due day (the 21st); the debt is shown via
    # this expense, not redrawn on its own day.
    _e("Transportation", "Car Payment",            350,  "monthly", 1, "Checking", 21),
    # Semi-annual premium: $720 drafts on the 20th of March & September ($1,440/yr).
    _e("Transportation", "Car Insurance",          720,  auto=1, draft="Chase Sapphire Reserve",
       schedule_type="quarterly", pay_days="20", months="3,9"),
    _e("Transportation", "Gas / Fuel",             120,  "monthly", 0, None, None),
    _e("Transportation", "Public Transit / Metro", 100,  "monthly", 1, "Checking", 1),

    # ── Food & Dining (variable — not auto-drafted) ──────────────────────────
    _e("Food & Dining", "Groceries",               550,  "monthly", 0, None, None),
    _e("Food & Dining", "Dining Out",              220,  "monthly", 0, None, None),

    # ── Healthcare ───────────────────────────────────────────────────────────
    _e("Healthcare", "Health Insurance Premium",   320,  "monthly", 1, "Checking", 1),
    # Therapy every other Thursday (biweekly) — anchor is a known Thursday.
    _e("Healthcare", "Therapy / Counseling",       140,  auto=1, draft="Amex Blue Cash",
       schedule_type="biweekly", anchor_date="2026-01-08"),
    _e("Healthcare", "Prescriptions",               35,  "monthly", 1, "Amex Blue Cash", 15),
    _e("Healthcare", "Gym / Fitness",               40,  "monthly", 1, "Amex Blue Cash", 1),
    _e("Healthcare", "Dental / Vision Premium",    600,  "annual",  1, "Checking", 5,  due_month=1),

    # ── Insurance ────────────────────────────────────────────────────────────
    _e("Insurance", "Life Insurance (term) — Northwestern", 720, "annual", 1, "Checking", 10, due_month=6),
    _e("Insurance", "Umbrella Policy",             300,  "annual",  1, "Checking", 10, due_month=6),
    _e("Insurance", "Disability Insurance (LTD)",  480,  "annual",  1, "Checking", 10, due_month=6),

    # ── Subscriptions — all auto-draft to Amex Blue Cash ─────────────────────
    _e("Subscriptions", "Netflix",                  18,  "monthly", 1, "Amex Blue Cash", 7),
    _e("Subscriptions", "Spotify",                  11,  "monthly", 1, "Amex Blue Cash", 7),
    _e("Subscriptions", "Adobe CC",                 55,  "monthly", 1, "Amex Blue Cash", 14),
    _e("Subscriptions", "ChatGPT Plus",              20,  "monthly", 1, "Amex Blue Cash", 14),
    _e("Subscriptions", "iCloud 2TB",               10,  "monthly", 1, "Amex Blue Cash", 14),

    # ── Education / Childcare ────────────────────────────────────────────────
    # Daycare billed every other Friday (biweekly) — anchor is a known Friday.
    _e("Education", "Childcare / Daycare",         600,  auto=1, draft="Checking",
       schedule_type="biweekly", anchor_date="2026-01-09"),
    _e("Education", "Online Courses / Certifications", 600, "annual", 1, "Amex Blue Cash", 1, due_month=2),

    # ── Entertainment ────────────────────────────────────────────────────────
    _e("Entertainment", "Hobbies",                 100,  "monthly", 0, None, None),
    _e("Entertainment", "Travel / Vacation",      3000,  "annual",  0, None, 1,  due_month=7),
    # One-time concert tickets a few weeks out — a known upcoming charge the cash-
    # flow forecast accounts for (and that drops off after it happens).
    _e("Entertainment", "Concert — Hamilton tickets", 450, schedule_type="one_time",
       anchor_date=_ONE_TIME_LATER),

    # ── Personal & Family ────────────────────────────────────────────────────
    _e("Personal & Family", "Clothing & Apparel",  100,  "monthly", 0, None, None),
    _e("Personal & Family", "Personal Care / Grooming", 60, "monthly", 0, None, None),
    _e("Personal & Family", "Pet Care & Vet",       80,  "monthly", 0, None, None),
    _e("Personal & Family", "Gifts",               800,  "annual",  0, None, 15, due_month=12),
    _e("Personal & Family", "Charitable Donations",1200,  "annual",  0, None, 31, due_month=12,
       deductible=1, deduction_category="Charitable Contributions",
       deductible_ytd=400, deductible_expected=800, deduct_state=0,
       deduction_notes="Federal itemized only (NJ has no charitable deduction)"),

    # ── Savings — auto-draft on payday ───────────────────────────────────────
    # 401(k) payroll deferral rides the semi-monthly paychecks (1st & 15th),
    # $958 each → $22,992/yr; pre-tax, so it's a deductible.
    _e("Savings", "401(k) Contribution",           958,  auto=1, draft="Checking",
       schedule_type="semimonthly", pay_days="1,15",
       deductible=1, deduction_category="Traditional IRA / 401(k) Contribution",
       deductible_ytd=9580, deductible_expected=13412,
       deduction_notes="Pre-tax payroll deferral"),
    _e("Savings", "Roth IRA Contribution",          583, "monthly", 1, "Checking", 15),
    _e("Savings", "HSA Contribution",               346, "monthly", 1, "Checking", 1,
       deductible=1, deduction_category="HSA Contribution",
       deductible_ytd=1730, deductible_expected=2422),

    # ── Business ─────────────────────────────────────────────────────────────
    _e("Business Expense", "Software / SaaS — Acme LLC", 120, "monthly", 1, "Amex Blue Cash", 5),
    # One-time CPA fee for the business return — a deductible one-off this spring.
    _e("Business Expense", "Tax Prep — CPA (Acme LLC)", 450, schedule_type="one_time",
       anchor_date=_ONE_TIME_SOON, deductible=1,
       deduction_category="Business Expense", deductible_ytd=0, deductible_expected=450,
       deduction_notes="Schedule C — business tax preparation"),
])

# ---------------------------------------------------------------------------
# Seed
# ---------------------------------------------------------------------------

def seed_database():
    """Replace all data with the comprehensive sample dataset plus 13 monthly
    net-worth snapshots. Callable from the app (Data Management page) and the CLI.
    Returns a short summary string."""
    import sqlite3
    from datetime import datetime, timezone, timedelta

    db.init_db()

    # ── Live tables ──────────────────────────────────────────────────────────
    _today = datetime.now(timezone.utc).date()
    income_df = _recompute_received_ytd(SAMPLE_INCOME, _today)
    db.save_df("assets",   SAMPLE_ASSETS)
    db.save_df("debts",    SAMPLE_DEBTS)
    db.save_df("income",   income_df)
    db.save_df("expenses", SAMPLE_EXPENSES)
    db.set_constant("fed_funds_target_lower", 0.0525)
    db.set_constant("fed_funds_target_upper", 0.0550)
    db.set_constant("fed_funds_rate",         0.0533)   # effective, inside the range
    db.set_constant("inflation_rate",         0.031)
    # Derive the margin loan's stored APR from its formula + the constants just set.
    db.refresh_margin_aprs()

    # ── Link groups between related records ──────────────────────────────────
    # A record can belong to several groups; everyone in a group is linked to
    # everyone else in it (a clique), but a record can bridge groups that aren't
    # linked to each other. Financing chains (asset + its loan + that loan's
    # payment) are kept in their own group, separate from a property's other
    # bills, so e.g. utilities never become co-members of the mortgage (which
    # would wrongly offer to prefill the utility bill from the mortgage payment).
    # Looked up by name because save_df renumbers ids each reseed; a missing
    # record is skipped, and a group with <2 resolved members is dropped.
    db.clear_groups()
    _DF = {"assets": db.load_df("assets"), "debts": db.load_df("debts"),
           "income": db.load_df("income"), "expenses": db.load_df("expenses")}

    def _gid(table, col, val):
        m = _DF[table][_DF[table][col] == val]
        if len(m) > 1:
            # Sample names aren't guaranteed unique ("VTI" exists in two accounts);
            # silently linking the first match would wire the group to the wrong
            # record. Fail loud at seed time so the reference gets disambiguated.
            raise ValueError(f"seed group lookup {table}.{col}={val!r} is ambiguous "
                             f"({len(m)} matches)")
        return int(m.iloc[0]["id"]) if not m.empty else None

    def _group(name, *members):
        """members: (table, col, value[, role]) tuples. Create the group, add each
        resolvable member, and drop the group if fewer than two resolve."""
        gid = db.create_group(name)
        for m in members:
            rid = _gid(m[0], m[1], m[2])
            if rid is not None:
                db.add_to_group(gid, m[0], rid, m[3] if len(m) > 3 else None)
        if len(db.group_members(gid)) < 2:
            db.delete_group(gid)

    # 123 Oak Lane (primary residence): mortgage financing chain, kept apart from
    # the household bills — the property is in both, the mortgage and utilities aren't.
    _group("123 Oak Lane — mortgage",
           ("assets", "name", "123 Oak Lane", "property"),
           ("debts", "name", "Mortgage — 123 Oak Lane", "mortgage"),
           ("expenses", "subcategory", "Mortgage (P&I)", "payment"))
    _group("123 Oak Lane — household bills",
           ("assets", "name", "123 Oak Lane", "property"),
           ("expenses", "subcategory", "Electricity", "utility"),
           ("expenses", "subcategory", "Gas / Heat", "utility"),
           ("expenses", "subcategory", "Water / Sewer", "utility"),
           ("expenses", "subcategory", "Internet", "utility"),
           ("expenses", "subcategory", "Property Tax (NJ)", "property tax"),
           ("expenses", "subcategory", "Homeowner's Insurance", "insurance"),
           ("expenses", "subcategory", "HOA Fees", "HOA"))

    # 2022 Toyota Camry: auto-loan chain separate from its insurance.
    _group("2022 Toyota Camry — auto loan",
           ("assets", "name", "2022 Toyota Camry", "vehicle"),
           ("debts", "name", "Auto — 2022 Toyota Camry", "auto loan"),
           ("expenses", "subcategory", "Car Payment", "payment"))
    _group("2022 Toyota Camry — insurance",
           ("assets", "name", "2022 Toyota Camry", "vehicle"),
           ("expenses", "subcategory", "Car Insurance", "insurance"))

    # 456 Maple Ave (rental): the property, the rent it earns, and the HELOC on it.
    _group("456 Maple Ave (rental)",
           ("assets", "name", "456 Maple Ave", "rental property"),
           ("income", "source", "Rental — 456 Maple Ave", "rental income"),
           ("debts", "name", "HELOC — 456 Maple Ave", "home equity line"))

    # Acme Consulting LLC: SBA loan kept apart from the operating software cost.
    _group("Acme Consulting LLC — SBA loan",
           ("assets", "name", "Acme Consulting LLC", "business"),
           ("debts", "name", "SBA Microloan — Acme LLC", "business loan"))
    _group("Acme Consulting LLC — operating costs",
           ("assets", "name", "Acme Consulting LLC", "business"),
           ("expenses", "subcategory", "Software / SaaS — Acme LLC", "operating cost"),
           ("expenses", "subcategory", "Tax Prep — CPA (Acme LLC)", "operating cost"))

    # Each interest-bearing cash account ↔ the interest income it pays out. These links
    # drive the "Import interest" button on the income card (dates + amount from the asset).
    _group("Ally HYSA",
           ("assets", "name", "High-Yield Savings", "account"),
           ("income", "source", "Interest — Ally HYSA", "interest"))
    _group("Fidelity Money Market",
           ("assets", "name", "Money Market", "account"),
           ("income", "source", "Interest — Fidelity Money Market", "interest"))
    _group("Marcus CD",
           ("assets", "name", "6-Month CD", "account"),
           ("income", "source", "Interest — Marcus CD", "interest"))
    _group("I-Bonds (interest)",
           ("assets", "name", "I-Bonds", "account"),
           ("income", "source", "Interest — I-Bonds", "interest"))

    # Retirement / HSA holdings ↔ their monthly contributions.
    _group("401(k)",
           ("assets", "name", "VTTSX", "holding"),
           ("expenses", "subcategory", "401(k) Contribution", "contribution"))
    _group("Roth IRA",
           ("assets", "name", "VXUS", "holding"),
           ("expenses", "subcategory", "Roth IRA Contribution", "contribution"))
    _group("HSA",
           ("assets", "name", "HSA", "account"),
           ("assets", "name", "VITSX", "holding"),
           ("expenses", "subcategory", "HSA Contribution", "contribution"),
           ("expenses", "subcategory", "Health Insurance Premium", "HDHP premium"))

    # Payment pairings: each payment expense IS the debt's payment (as if imported
    # from the debt), so the Groups stats de-dup the pair instead of double-counting.
    def _pays(exp_subcat, debt_name):
        eid, did = _gid("expenses", "subcategory", exp_subcat), _gid("debts", "name", debt_name)
        if eid and did:
            db.set_expense_pays_debt(eid, did)
    _pays("Mortgage (P&I)", "Mortgage — 123 Oak Lane")
    _pays("Car Payment", "Auto — 2022 Toyota Camry")

    # ── Group statistics: a global default + a few tailored overrides ─────────
    # A fresh database shows nothing until the user picks statistics; the seed
    # chooses a broadly-useful default (each group still filters to what its
    # records support) and tailors a few groups so the feature is visible at a
    # glance — a homeowner equity/payoff view, a rental yield view, an investment
    # growth view. Group keys are looked up by name (ids renumber each reseed).
    db.set_group_stats_default(
        ["equity", "monthly_outflow", "net_monthly", "monthly_interest"])

    def _set_stats(group_name, keys):
        for g in db.all_groups():
            if g["name"] == group_name:
                db.set_group_stat_keys(g["id"], keys)
                return
    _set_stats("123 Oak Lane — mortgage",
               ["equity", "equity_pct", "ltv", "payoff_months", "monthly_interest"])
    _set_stats("456 Maple Ave (rental)",
               ["net_annual", "cap_rate", "monthly_income", "ltv", "equity"])
    _set_stats("401(k)",
               ["invested_value", "unrealized_gain", "unrealized_gain_pct", "cost_basis"])

    # ── Update watch list + staleness demo ───────────────────────────────────
    # Mark the manually-reconciled cash accounts as "watched" so the launch review
    # prompt and the stale flag have something to track, and back-date a few of them
    # past their (automatic) 1-day window so both fire on a fresh seed. Looked up by
    # name because save_df renumbers ids each reseed; record_settings is cleared first
    # so keys from a previous seed don't linger as orphans.
    db.clear_record_settings()
    # The Taxes worksheet's stored overrides (income buckets, deductions,
    # withholding) describe the replaced dataset — reset them too.
    db.clear_tax_worksheet_constants()
    _assets_now = db.load_df("assets")

    def _asset_id(name):
        m = _assets_now[_assets_now["name"] == name]
        return int(m.iloc[0]["id"]) if not m.empty else None

    # name → days to back-date its last-updated stamp (0 = leave fresh from the load).
    WATCHED_AGES = {"Checking": 0, "Money Market": 2, "HSA": 5, "I-Bonds": 11, "6-Month CD": 0}
    for _name, _age_days in WATCHED_AGES.items():
        _rid = _asset_id(_name)
        if _rid is None:
            continue
        db.set_watch("assets", _rid, True)
        if _age_days:
            _ts = (datetime.now(timezone.utc) - timedelta(days=_age_days)).isoformat(timespec="seconds")
            db.update_row("assets", _rid, {"updated_at": _ts})

    # ── Historical snapshots — one per month for the past 12 months ──────────
    # We simulate gradual portfolio growth so the net-worth trend line looks
    # realistic. Values walk forward from a lower base toward today's totals.
    db.clear_snapshots()

    today = datetime.now(timezone.utc).date()

    # Asset values 12 months ago as a fraction of today's seed values.
    # Markets up ~18%, debt paid down ~5%, cash roughly flat.
    ASSET_GROWTH   = 0.82   # portfolio was 82% of today's value 12 months ago
    DEBT_GROWTH    = 1.05   # debt was 105% (slightly higher in the past)

    # One read outside the loop (the tables don't change between iterations), and
    # a try/finally so a failure mid-loop closes the connection without committing
    # — leaving zero snapshots rather than a partial, misleading trend line.
    assets_df = db.load_df("assets")
    debts_df = db.load_df("debts")

    # Effective (ownership-scaled) totals for the per-snapshot metric rows —
    # the same formulas as db.take_snapshot / stats.py.
    _own = assets_df["ownership_pct"].fillna(0.0)
    _eff = assets_df["value"].fillna(0.0) * _own.where(_own > 0, 1.0)
    assets_eff_total = float(_eff.sum())
    liquid_eff_total = float(_eff[assets_df["liquid"] == 1].sum())
    debts_total = float(debts_df["balance"].fillna(0.0).sum())
    # Annual spend via the shared helper (set: amount × yearly occurrences;
    # variable: recorded past-year total) — in lockstep with the Accounts
    # auto-draft projection. Burn is that ÷ 12.
    import stats as _stats
    ann_exp_total = float(_stats.annual_expenses(SAMPLE_EXPENSES))
    burn_total = ann_exp_total / 12.0
    _inc_amt = pd.to_numeric(income_df["amount"], errors="coerce").fillna(0.0)
    _inc_rcv = pd.to_numeric(income_df["received_ytd"], errors="coerce").fillna(0.0)
    inc_total = float(_inc_amt.sum())
    live_ytd = float(_inc_rcv.sum())
    live_expected = float((_inc_amt - _inc_rcv).clip(lower=0.0).sum())

    # Cash interest (schedule-aware), unrealized G/L basis sums, and the tax
    # inputs for the three Python-side metric rows captured per snapshot.
    cash_int_live = sum(
        accounts.interest_income_amounts(a["balance"], a["apy"], a["sched"])[0]
        for a in accounts.cash_accounts(assets_df) if a["apy"] > 0)
    _basis = assets_df[assets_df["cost_basis"].notna()
                       & (assets_df["cost_basis"] > 0)]
    basis_value_total = float(_basis["value"].sum())
    basis_cost_total = float(_basis["cost_basis"].sum())
    fy_buckets = taxes.categorize_income(income_df, basis="fy")
    ytd_buckets_live = taxes.categorize_income(income_df, basis="ytd")
    _std = taxes.STANDARD_DEDUCTION["single"]
    _njd = float(taxes.NJ_PERSONAL_EXEMPTION)

    conn = sqlite3.connect(db.DB_PATH)
    try:
        conn.execute("PRAGMA foreign_keys = ON")

        for months_back in range(12, -1, -1):
            snap_date = today.replace(day=1)
            # Walk backward month by month
            for _ in range(months_back):
                if snap_date.month == 1:
                    snap_date = snap_date.replace(year=snap_date.year - 1, month=12)
                else:
                    snap_date = snap_date.replace(month=snap_date.month - 1)

            # Linear interpolation: 12 months ago → ASSET_GROWTH, today → 1.0
            t = (12 - months_back) / 12          # 0.0 at 12 mo ago, 1.0 today
            asset_mult = ASSET_GROWTH + t * (1.0 - ASSET_GROWTH)
            debt_mult  = DEBT_GROWTH  + t * (1.0 - DEBT_GROWTH)

            # Add some market noise (±3%) to past months only. The most recent
            # snapshot (months_back == 0) must equal today's live totals exactly,
            # so the trend line terminates at the dashboard's current net worth.
            if months_back != 0:
                import random
                random.seed(months_back * 7)
                noise = 1.0 + random.uniform(-0.03, 0.03)
                asset_mult *= noise

            label = snap_date.strftime("%m/%d/%Y")
            ts    = datetime(snap_date.year, snap_date.month, snap_date.day,
                             12, 0, 0, tzinfo=timezone.utc).isoformat(timespec="seconds")

            cur = conn.execute(
                "INSERT INTO snapshots (taken_at, label) VALUES (?, ?)", (ts, label)
            )
            sid = cur.lastrowid

            # Snapshot items scaled by the multiplier
            for _, row in assets_df.iterrows():
                ov = row["ownership_pct"]
                own = float(ov) if pd.notna(ov) and float(ov) > 0 else 1.0
                conn.execute(
                    "INSERT INTO snapshot_items (snapshot_id, category, name, value, "
                    "institution, account_type, asset_type) "
                    "VALUES (?, 'asset', ?, ?, ?, ?, ?)",
                    (sid, row["name"], float(row["value"]) * own * asset_mult,
                     row["institution"], row["account_type"], row["asset_type"]),
                )

            for _, row in debts_df.iterrows():
                conn.execute(
                    "INSERT INTO snapshot_items (snapshot_id, category, name, value) "
                    "VALUES (?, 'debt', ?, ?)",
                    (sid, row["name"], float(row["balance"]) * debt_mult),
                )

            # Derived metric rows ('metric' category) so the Overview's
            # change-over-range deltas have history: liquid scales with the asset
            # multiplier, expense bases stay constant, income YTD grows linearly
            # through each past year, and the newest snapshot (months_back == 0)
            # carries today's exact live figures — matching what take_snapshot
            # would record right now.
            if months_back == 0:
                ytd_m, exp_m, liq_m = live_ytd, live_expected, liquid_eff_total
                tax_buckets = dict(ytd_buckets_live)
            else:
                frac = min(snap_date.timetuple().tm_yday / 365.0, 1.0)
                ytd_m = inc_total * frac
                exp_m = max(inc_total - ytd_m, 0.0)
                liq_m = liquid_eff_total * asset_mult
                # YTD tax buckets approximated the same way as the income: each
                # full-year bucket scaled by how far into that year the snapshot is.
                tax_buckets = {k: v * frac for k, v in fy_buckets.items()}
                tax_buckets["excluded"] = 0.0
            snap_nw = assets_eff_total * asset_mult - debts_total * debt_mult
            proj_m = snap_nw + exp_m - burn_total * (12 - snap_date.month)
            tax_m = taxes.estimate(tax_buckets, "single", _std, _njd)["total"]
            for mname, mval in [
                ("liquid_assets", liq_m),
                ("annual_expenses", ann_exp_total),
                ("monthly_burn", burn_total),
                ("income_ytd", ytd_m),
                ("income_expected", exp_m),
                ("projected_eoy_net_worth", proj_m),
                ("cash_interest_yr", cash_int_live
                 * (1.0 if months_back == 0 else asset_mult)),
                ("unrealized_gl", basis_value_total
                 * (1.0 if months_back == 0 else asset_mult) - basis_cost_total),
                ("ytd_tax_debt_net", tax_m),     # seed sets no withholding
            ]:
                conn.execute(
                    "INSERT INTO snapshot_items (snapshot_id, category, name, value) "
                    "VALUES (?, 'metric', ?, ?)", (sid, mname, float(mval)))

        conn.commit()
    finally:
        conn.close()
    return "Seeded sample data, an update watch list, and 13 monthly snapshots into finance.db"


def _has_user_data():
    """True when any live table or the snapshot history has rows — the guard the
    CLI uses before wholesale-replacing the database."""
    import sqlite3
    conn = sqlite3.connect(db.DB_PATH)
    try:
        return any(
            conn.execute(f"SELECT 1 FROM {t} LIMIT 1").fetchone()
            for t in ("assets", "debts", "income", "expenses", "snapshots"))
    finally:
        conn.close()


if __name__ == "__main__":
    import argparse
    import shutil
    import sys
    from datetime import datetime

    parser = argparse.ArgumentParser(
        description="Replace ALL data in finance.db with the comprehensive "
                    "sample dataset plus 13 monthly net-worth snapshots.")
    parser.add_argument("--force", action="store_true",
                        help="replace existing data without asking")
    args = parser.parse_args()

    db.init_db()
    if _has_user_data():
        if not args.force:
            print("finance.db already contains data. Seeding REPLACES every asset, "
                  "debt, income, expense, link group, and snapshot in it.")
            if not sys.stdin.isatty():
                sys.exit("Refusing to overwrite without confirmation — run "
                         "interactively or pass --force.")
            if input("Type 'yes' to continue: ").strip().lower() != "yes":
                sys.exit("Aborted; nothing was changed.")
        backup = f"{db.DB_PATH}.bak-{datetime.now():%Y%m%d-%H%M%S}"
        shutil.copy2(db.DB_PATH, backup)
        print(f"Backed up the current database to {backup}")
    print(seed_database())
