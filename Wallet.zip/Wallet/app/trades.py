"""
trades.py — the "Buy / Sell Shares or Units" tool on the Assets page.

A pop-up that applies share/unit transactions to the existing tickered positions:

  • BUY  — adds units and the total cost to the position's cost basis (records no
    income). The transaction is a whole-dollar amount, not a per-unit price, and
    it doesn't move the market, so the position keeps its own last price and is
    just revalued at the new unit count.
  • SELL — removes units (and their cost basis) and records the realized capital
    gain (proceeds − basis of the units sold) as investment income, or the loss
    as a deductible expense, with the same tax treatment the delete-asset flow
    uses (cards.gain_income_row / loss_expense_row). A sale inside a tax-advantaged
    account (retirement / IRA / HSA-invested) is NOT a taxable event, so it only
    adjusts the position. Selling every unit closes the position (the row is
    removed).

Amounts entered are TOTALS for the whole transaction (the cost of all units
bought / the proceeds of all units sold), never a per-unit price.

The same ticker held at two institutions is two positions, so a transaction
targets one (ticker, institution). Single-entry or a bulk paste.

The plan/apply split (buy_plan / sell_plan are pure; apply_* do the db writes)
keeps the money math unit-testable without a database.
"""

import re

import streamlit as st

import cards
import db
import taxes
import ui
from utils import (ACCOUNT_TYPE_GROUPS, ACCOUNT_TYPE_OPTIONS, SECURITY_ASSET_TYPES,
                   asset_family, esc, is_inherited_account, is_investment_holding,
                   is_tax_advantaged_account, money)


def _f(v):
    """A value coerced to float, with None / NaN → 0.0 (so a NULL share count or
    basis doesn't blow up the arithmetic)."""
    try:
        x = float(v)
    except (TypeError, ValueError):
        return 0.0
    return 0.0 if x != x else x      # NaN


def _unit_value(row):
    """The position's current per-unit MARKET value — its live price. A
    transaction doesn't change the market price (only how many units you hold), so
    this is what the remaining/added units are valued at. Falls back to the
    position's own average value-per-unit when no last price is stored, then 0."""
    lp = _f(row.get("last_price"))
    if lp > 0:
        return lp
    units, value = _f(row.get("shares")), _f(row.get("value"))
    return value / units if units > 0 and value > 0 else 0.0


# ---------------------------------------------------------------------------
# Positions
# ---------------------------------------------------------------------------

def positions(assets):
    """{TICKER: [row_dict, ...]} for every tickered investment position, grouped
    by ticker so the UI can disambiguate a ticker held at several institutions."""
    if assets is None or assets.empty:
        return {}
    inv = assets[assets["asset_type"].apply(is_investment_holding)]
    out = {}
    for _, r in inv.iterrows():
        tk = str(r.get("ticker") or "").upper().strip()
        if not tk or tk == "NAN":
            continue
        out.setdefault(tk, []).append(r.to_dict())
    return out


def position_label(row):
    """A short account label distinguishing same-ticker positions: institution
    then account type (e.g. 'Fidelity · Roth IRA')."""
    parts = [str(row.get("institution") or "").strip(),
             str(row.get("account_type") or "").strip()]
    return " · ".join(p for p in parts if p) or str(row.get("name") or "account")


# ---------------------------------------------------------------------------
# Pure plans — what a transaction does, computed without touching the database
# ---------------------------------------------------------------------------

def sell_tax_class(asset_type, account_type, long_term):
    """The income tax_class for a realized gain on this holding, or None when the
    sale isn't a taxable event. Tax-advantaged accounts — any retirement / IRA /
    HSA, AND inherited retirement accounts / annuities — don't realize capital
    gains (see cards.is_taxable_capital_account). Inherited taxable property is
    always long-term (stepped-up basis)."""
    if not cards.is_taxable_capital_account(asset_type, account_type):
        return None
    if is_inherited_account(account_type):
        long_term = True
    return "preferential" if long_term else "ordinary_investment"


def buy_plan(row, units, cost):
    """The asset-column updates a buy applies: more units and `cost` more basis
    (cost is the TOTAL paid for all the units bought, not a per-unit price). The
    new total is revalued at the position's existing market price — the purchase
    doesn't move the market, so last_price is left untouched. A buy records no
    income. Falls back to the average purchase price only when the position has no
    market price of its own to value the new units at."""
    new_units = _f(row.get("shares")) + units
    new_basis = _f(row.get("cost_basis")) + cost
    unit_val = _unit_value(row) or (cost / units if units else 0.0)
    return {"new_units": new_units,
            "updates": {"shares": new_units, "cost_basis": round(new_basis, 2),
                        "value": round(new_units * unit_val, 2)}}


def sell_plan(row, units, proceeds, cost_basis_sold, long_term):
    """What a sale does (pure — writes nothing):
      realized P/L = proceeds − cost basis of the units sold.
    `proceeds` is the TOTAL the sale brought in (not a per-unit price), and
    `cost_basis_sold` the basis of just those units. The position loses those
    units and that basis; the units that remain keep their market value (value =
    remaining × the position's existing last price — selling doesn't move the
    market, so last_price is untouched). A gain becomes capital income and a loss
    a deductible expense — unless the account is tax-advantaged (sell_tax_class
    None), where the sale only adjusts the position. Selling every unit closes the
    position (no `updates`)."""
    asset_type = str(row.get("asset_type") or "")
    account_type = str(row.get("account_type") or "")
    name = str(row.get("name") or row.get("ticker") or "position")
    realized = proceeds - cost_basis_sold
    tax_class = sell_tax_class(asset_type, account_type, long_term)
    new_units = _f(row.get("shares")) - units
    sold_all = new_units <= 1e-9

    income = expense = None
    if tax_class is not None and abs(realized) >= 0.005:
        if realized > 0:
            income = cards.gain_income_row(name, realized, tax_class)
        else:
            term = ("long-term" if (long_term or is_inherited_account(account_type))
                    else "short-term")
            expense = cards.loss_expense_row(name, -realized, term,
                                             account_type or asset_type,
                                             cost_basis_sold, proceeds)
    updates = None
    if not sold_all:
        new_basis = max(0.0, _f(row.get("cost_basis")) - cost_basis_sold)
        updates = {"shares": new_units, "cost_basis": round(new_basis, 2),
                   "value": round(new_units * _unit_value(row), 2)}
    return {"realized": realized, "tax_class": tax_class, "sold_all": sold_all,
            "new_units": max(0.0, new_units), "proceeds": proceeds,
            "income": income, "expense": expense, "updates": updates}


# ---------------------------------------------------------------------------
# Apply — execute a plan against the database
# ---------------------------------------------------------------------------

def apply_buy(row, units, cost):
    plan = buy_plan(row, units, cost)
    db.update_row("assets", int(row["id"]), plan["updates"])
    return plan


def apply_sell(row, units, proceeds, cost_basis_sold, long_term):
    """Apply a sale: shrink (or close) the position and record any gain/loss,
    each in ONE transaction so the share change and its income/expense can't
    half-apply."""
    plan = sell_plan(row, units, proceeds, cost_basis_sold, long_term)
    aid = int(row["id"])
    if plan["sold_all"]:
        if plan["income"]:
            db.delete_row_recording_income("assets", aid, plan["income"])
        elif plan["expense"]:
            db.delete_row_recording_expense("assets", aid, plan["expense"])
        else:
            db.delete_row("assets", aid)
    else:
        if plan["income"]:
            db.update_row_recording_income("assets", aid, plan["updates"], plan["income"])
        elif plan["expense"]:
            db.update_row_recording_expense("assets", aid, plan["updates"], plan["expense"])
        else:
            db.update_row("assets", aid, plan["updates"])
    return plan


# ---------------------------------------------------------------------------
# Bulk paste parsing + apply
# ---------------------------------------------------------------------------

_TERMS = {"long": True, "lt": True, "l": True, "long-term": True,
          "short": False, "st": False, "s": False, "short-term": False}

# Asset types the Buy/Sell tool can CREATE from a paste — tradable holdings only
# (the securities + crypto set that `positions` operates on).
_BUYABLE_ASSET_TYPES = SECURITY_ASSET_TYPES + ["Cryptocurrency"]

# The valid account / asset types to type on a "create" line, shown (collapsed)
# in the bulk menu. Built from the live taxonomy so it can't drift from what the
# parser actually accepts.
_TYPE_REFERENCE_MD = (
    "**Account types** — any of:\n"
    + "\n".join(f"- **{grp}:** " + ", ".join(opts)
                for grp, opts in ACCOUNT_TYPE_GROUPS.items())
    + "\n\n**Asset types** — tradable holdings only (what this tool can create):\n\n"
    + ", ".join(_BUYABLE_ASSET_TYPES)
    + "\n\n_Real estate, vehicles, collectibles, etc. are added with **+ Add Asset**._"
)


def _match_choice(value, options):
    """Case-insensitively resolve a typed value to one canonical option, or None."""
    v = value.strip().lower()
    return next((o for o in options if o.lower() == v), None)


def _new_holding_op(ticker, units, total, extra):
    """Turn a buy line for a not-yet-held ticker into a 'Create' op, or return
    (None, guide) when the four creation fields are missing or invalid. Creation
    form (the four fields beyond the basic buy):

        buy, ticker, units, total, account_type, asset_type, institution, name

    account_type / asset_type / institution are single fields and must match the
    app's taxonomy (case-insensitive); name is whatever follows, so it may itself
    contain commas."""
    fields = [e.strip() for e in extra]
    name = ", ".join(fields[3:]).strip() if len(fields) > 3 else ""
    if len(fields) < 4 or not (fields[0] and fields[1] and fields[2] and name):
        return None, (
            f"no {ticker} position yet — to create one, add account type, asset "
            f"type, institution and name, e.g. `buy, {ticker}, {units:g}, "
            f"{total:g}, Brokerage, ETF / Index Fund, Fidelity, {ticker}`")
    account_type = _match_choice(fields[0], ACCOUNT_TYPE_OPTIONS)
    if account_type is None:
        return None, (f"unknown account type {fields[0]!r} for new {ticker} — use "
                      "one like Brokerage, Roth IRA, Traditional IRA, 401(k)")
    asset_type = _match_choice(fields[1], _BUYABLE_ASSET_TYPES)
    if asset_type is None:
        return None, (f"unknown asset type {fields[1]!r} for new {ticker} — one of: "
                      + ", ".join(_BUYABLE_ASSET_TYPES))
    return {"action": "Create", "ticker": ticker, "units": units, "total": total,
            "account_type": account_type, "asset_type": asset_type,
            "institution": fields[2], "name": name}, None


def _opt_cost(cb_raw):
    """Parse an optional cost-basis cell -> (value_or_None, error_or_None)."""
    if not cb_raw:
        return None, None
    try:
        return float(re.sub(r"[$,\s]", "", cb_raw)), None
    except ValueError:
        return None, f"bad cost basis {cb_raw!r}"


def _created_tickers(text, pos):
    """The set of tickers a valid 'create' line in this paste introduces, so a
    later buy/sell of one (in the same paste) isn't rejected for 'no position
    yet' — creates apply before buys before sells (see _apply_bulk)."""
    out = set()
    for raw in text.splitlines():
        parts = [p.strip() for p in re.split(r"[,\t]", raw.strip())]
        if len(parts) < 4 or parts[0].lower() not in ("b", "buy"):
            continue
        tk = parts[1].upper()
        if tk in pos or tk in out:
            continue
        try:
            u = float(re.sub(r"[,\s]", "", parts[2]))
            t = float(re.sub(r"[$,\s]", "", parts[3]))
        except ValueError:
            continue
        if u > 0 and t > 0 and _new_holding_op(tk, u, t, parts[4:])[0] is not None:
            out.add(tk)
    return out


def _resolve_row(rows, ticker, inst_raw):
    """Pick the single position row a line targets, or (None, error message). With
    one account the institution is optional; with several it must match exactly one."""
    if len(rows) == 1 and not inst_raw:
        return rows[0], None
    if inst_raw:
        matches = [r for r in rows if inst_raw.lower() in position_label(r).lower()]
        if len(matches) != 1:
            return None, (f"institution {inst_raw!r} didn't match exactly one "
                          f"{ticker} account")
        return matches[0], None
    return None, f"{ticker} is held in {len(rows)} accounts — add an institution column"


def _parse_bulk(text, pos):
    """Parse pasted transaction lines into (ops, errors). Two line shapes:
      • BUY  — `buy, ticker, units, total[, institution]`. For a ticker held
        nowhere yet, the 8-field create form
        `buy, ticker, units, total, account_type, asset_type, institution, name`
        makes a 'Create' op (see _new_holding_op).
      • SELL — `sell, ticker, units, total, cost_basis, term[, institution]`,
        where `cost_basis` (basis of the units sold) and `term` (long/short) are
        BOTH required; `institution` only disambiguates a ticker held in >1 account.
    A buy/sell of a ticker that ANOTHER line in the same paste creates is allowed
    too — a deferred op (asset_id None) resolved by ticker at apply time, since
    ops apply creates → buys → sells (see _apply_bulk). errors is a list of
    (line_no, raw, reason)."""
    created = _created_tickers(text, pos)
    ops, errors = [], []
    for i, raw in enumerate(text.splitlines(), 1):
        line = raw.strip()
        if not line:
            continue
        parts = [p.strip() for p in re.split(r"[,\t]", line)]
        if len(parts) < 4:
            errors.append((i, raw, "need action, ticker, units, total"))
            continue
        act = parts[0].lower()
        if act in ("b", "buy"):
            action = "Buy"
        elif act in ("s", "sell"):
            action = "Sell"
        else:
            errors.append((i, raw, f"action must be buy or sell, not {parts[0]!r}"))
            continue
        ticker = parts[1].upper()
        try:
            units = float(re.sub(r"[,\s]", "", parts[2]))
            total = float(re.sub(r"[$,\s]", "", parts[3]))
        except ValueError:
            errors.append((i, raw, "units and total must be numbers"))
            continue
        if units <= 0 or total <= 0:
            errors.append((i, raw, "units and total must be greater than 0"))
            continue
        rows = pos.get(ticker)

        # ── BUY: buy, ticker, units, total[, institution] — or, for a ticker held
        #    nowhere yet, the 8-field create form. No cost_basis / term. ─────────
        if action == "Buy":
            if not rows:
                op, why = _new_holding_op(ticker, units, total, parts[4:])
                if op is not None:
                    ops.append(op)                        # a brand-new holding
                elif ticker in created:                   # add to one this paste makes
                    ops.append({"action": "Buy", "asset_id": None, "ticker": ticker,
                                "units": units, "total": total, "cost_basis": None,
                                "long_term": True})
                else:
                    errors.append((i, raw, why))           # the create guide
                continue
            inst_raw = next((x for x in (p.strip() for p in parts[4:]) if x), "")
            row, err = _resolve_row(rows, ticker, inst_raw)
            if err:
                errors.append((i, raw, err))
                continue
            ops.append({"action": "Buy", "asset_id": int(row["id"]), "ticker": ticker,
                        "units": units, "total": total, "cost_basis": None,
                        "long_term": True})
            continue

        # ── SELL: sell, ticker, units, total, cost_basis, term[, institution].
        #    cost_basis (parts[4]) and term are BOTH required; the term and an
        #    optional institution sit in parts[5:7] in either order. ────────────
        cb_raw = parts[4].strip() if len(parts) > 4 else ""
        long_term, inst_raw, term_given = True, "", False
        for x in (p.strip() for p in parts[5:7]):
            if not x:
                continue
            if x.lower() in _TERMS:
                long_term, term_given = _TERMS[x.lower()], True
            else:
                inst_raw = x

        if not rows and ticker not in created:
            errors.append((i, raw, f"no position with ticker {ticker} to sell"))
            continue
        cost_basis, err = _opt_cost(cb_raw)
        if err:
            errors.append((i, raw, err))
            continue
        if cost_basis is None:
            errors.append((i, raw, "a sell needs cost_basis — the basis of the units sold"))
            continue
        if not term_given:
            errors.append((i, raw, "a sell needs term — long or short"))
            continue

        if not rows:                                       # deferred (created here)
            ops.append({"action": "Sell", "asset_id": None, "ticker": ticker,
                        "units": units, "total": total, "cost_basis": cost_basis,
                        "long_term": long_term})
            continue
        row, err = _resolve_row(rows, ticker, inst_raw)
        if err:
            errors.append((i, raw, err))
            continue
        if units > _f(row.get("shares")) + 1e-9:
            errors.append((i, raw, f"selling {units:g} but only "
                                   f"{_f(row.get('shares')):g} held"))
            continue
        ops.append({"action": "Sell", "asset_id": int(row["id"]), "ticker": ticker,
                    "units": units, "total": total, "cost_basis": cost_basis,
                    "long_term": long_term})
    return ops, errors


def _create_holding(op):
    """Insert a brand-new tickered holding from a 'Create' op: the purchase total
    is both its cost basis and its starting value (the next price refresh prices
    it from the ticker), and liquidity follows the account type — a taxable
    brokerage or a centralized crypto exchange is liquid, a retirement wrapper or
    self-custody wallet is not (mirroring the Add-asset form)."""
    units, total = op["units"], op["total"]
    if asset_family(op["asset_type"]) == "crypto":
        liquid = 1 if op["account_type"].startswith("Centralized") else 0
    else:
        liquid = 0 if is_tax_advantaged_account(op["account_type"]) else 1
    db.insert_row("assets", {
        "name": op["name"], "account_type": op["account_type"],
        "asset_type": op["asset_type"], "ticker": op["ticker"],
        "institution": op["institution"], "shares": units,
        "cost_basis": round(total, 2), "value": round(total, 2),
        "last_price": round(total / units, 4) if units else None,
        "liquid": liquid})


def _apply_bulk(ops):
    """Apply parsed ops as CREATES first, then BUYS, then SELLS — so a position
    bought or created earlier in the same paste exists before it's sold —
    preserving each tier's original order. Every non-create op re-reads its asset
    fresh (by id, or by ticker for a deferred op targeting a holding another line
    creates), so trades on the same position compound. Returns (applied, failed)."""
    done = failed = 0
    tier = {"Create": 0, "Buy": 1, "Sell": 2}
    for op in sorted(ops, key=lambda o: tier.get(o["action"], 2)):
        if op["action"] == "Create":
            try:
                _create_holding(op)
                done += 1
            except Exception:
                failed += 1
            continue
        assets = db.load_df("assets")
        if op.get("asset_id") is not None:
            match = assets[assets["id"] == op["asset_id"]]
        else:                                 # deferred: resolve by ticker
            tk = assets["ticker"].astype("string").str.upper()
            match = assets[tk.eq(op["ticker"]).fillna(False)]
        if match.empty:
            failed += 1
            continue
        row = match.iloc[0].to_dict()
        if op["action"] == "Sell" and op["units"] > _f(row.get("shares")) + 1e-9:
            failed += 1                       # an earlier op left too few units
            continue
        try:
            if op["action"] == "Buy":
                apply_buy(row, op["units"], op["total"])
            else:
                cb = op["cost_basis"]
                if cb is None:
                    held = _f(row.get("shares"))
                    cb = (_f(row.get("cost_basis")) * op["units"] / held) if held > 0 else 0.0
                apply_sell(row, op["units"], op["total"], cb, op["long_term"])
            done += 1
        except Exception:
            failed += 1
    return done, failed


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

def _validate(action, row, units, total):
    if units <= 0:
        return "Enter a number of units greater than 0."
    if total <= 0:
        return ("Enter the total amount " + ("paid." if action == "Buy" else "received."))
    if action == "Sell" and units > _f(row.get("shares")) + 1e-9:
        return (f"You can't sell {units:g} — the position holds only "
                f"{_f(row.get('shares')):g}.")
    return None


def _sell_msg(ticker, unit_word, units, plan):
    base = f"Sold {units:g} {unit_word} of {ticker}"
    if plan["sold_all"]:
        base += " (position closed)"
    r = plan["realized"]
    if plan["tax_class"] is None or abs(r) < 0.005:
        return base + "."
    if r > 0:
        return base + f" — realized gain {money(r)} recorded as income."
    return base + f" — realized loss {money(-r)} recorded as a deductible expense."


def _single_form(pos, P):
    action = st.radio("Action", ["Buy", "Sell"], horizontal=True, key=P + "action")
    ticker = st.selectbox("Ticker symbol", sorted(pos), key=P + "ticker")
    rows = pos[ticker]
    if len(rows) > 1:
        idx = st.selectbox("Institution / account", list(range(len(rows))),
                           format_func=lambda i: position_label(rows[i]), key=P + "inst")
        row = rows[idx]
    else:
        row = rows[0]
        st.caption(f"Account: **{position_label(row)}**")

    held = _f(row.get("shares"))
    unit_word = "units" if asset_family(row.get("asset_type")) == "crypto" else "shares"
    st.caption(esc(f"Holding **{held:g} {unit_word}** · cost basis "
                   f"**{money(_f(row.get('cost_basis')))}** · value "
                   f"**{money(_f(row.get('value')))}**"))

    c1, c2 = st.columns(2)
    verb = "bought" if action == "Buy" else "sold"
    units = c1.number_input(f"{unit_word.capitalize()} {verb}", min_value=0.0,
                            step=1.0, format="%.4f", key=P + "units")
    total = c2.number_input(
        "Total cost ($)" if action == "Buy" else "Total proceeds ($)",
        min_value=0.0, step=100.0, key=P + "total",
        help=("The whole amount paid for all the units bought."
              if action == "Buy"
              else "The whole amount the sale brought in (all the units sold)."))

    cost_basis_sold, long_term = 0.0, True
    if action == "Sell":
        taxable = cards.is_taxable_capital_account(
            str(row.get("asset_type") or ""), str(row.get("account_type") or ""))
        cost_basis_sold = st.number_input(
            "Original cost basis of the units sold ($)", min_value=0.0, value=0.0,
            step=100.0, key=P + "cb",
            help="The total you originally paid for just the units you're selling "
                 "(specific-lot or average cost).")
        if held > 0 and units > 0:
            st.caption(esc(f":gray[Average cost for {units:g} {unit_word} ≈ "
                           f"{money(_f(row.get('cost_basis')) * units / held)}.]"))
        if not taxable:
            st.caption("ℹ️ Tax-advantaged account — the sale adjusts the position "
                       "but records no taxable gain or loss.")
        elif is_inherited_account(row.get("account_type")):
            st.caption("ℹ️ Inherited property is treated as long-term (stepped-up basis).")
        else:
            long_term = st.radio(
                "Holding period", [True, False], horizontal=True, key=P + "lt",
                format_func=lambda lt: "Long-term (> 1 yr)" if lt else "Short-term (≤ 1 yr)")
        if units > 0 and total > 0:
            plan = sell_plan(row, units, total, cost_basis_sold, long_term)
            r = plan["realized"]
            if plan["tax_class"] is None:
                st.caption(esc(f"Proceeds **{money(plan['proceeds'])}** · no taxable event."))
            elif r >= 0:
                st.caption(esc(f":green[Realized gain **{money(r)}** → recorded as "
                               f"{taxes.TAX_CLASS_LABEL[plan['tax_class']]} income.]"))
            else:
                st.caption(esc(f":red[Realized loss **{money(-r)}** → recorded as a "
                               "deductible expense.]"))
            if plan["sold_all"]:
                st.caption(":gray[Selling the entire position — it will be removed.]")

    if st.button(f"Apply {action.lower()}", type="primary", width="stretch", key=P + "go"):
        err = _validate(action, row, units, total)
        if err:
            st.error(err)
            return
        if action == "Buy":
            apply_buy(row, units, total)
            ui.flash(esc(f"Bought {units:g} {unit_word} of {ticker} for "
                         f"{money(total)} — position updated."))
        else:
            plan = apply_sell(row, units, total, cost_basis_sold, long_term)
            ui.flash(esc(_sell_msg(ticker, unit_word, units, plan)))
        st.rerun()


def _bulk_form(pos, P):
    st.caption("One transaction per line. Amounts are always the whole total for all "
               "units, never a per-unit price. Buys (and new-holding lines) apply "
               "before sells, so you can create or add to a position and sell it in "
               "the same paste. Three line shapes:")
    st.caption("**Buy** — `buy, ticker, units, total[, institution]`. Adds units and "
               "cost to a holding you already have. `institution` is only needed when "
               "the ticker is held in more than one account.")
    st.caption("**Sell** — `sell, ticker, units, total, cost_basis, term[, institution]`. "
               "`cost_basis` (the basis of just the units sold) and `term` (`long` or "
               "`short`) are both required — a tax-advantaged account ignores them and "
               "records no gain either way; `institution` only when the ticker is held in "
               "more than one account.")
    st.caption("**Create a new holding** — buying a ticker you don't hold yet needs four "
               "more fields: `buy, ticker, units, total, account_type, asset_type, "
               "institution, name` (e.g. `buy, SPY, 100, 10000, Brokerage, "
               "ETF / Index Fund, Fidelity, SPDR S&P 500`). Account and asset types must "
               "match the lists below.")
    with st.expander("Valid account types & asset types"):
        st.markdown(_TYPE_REFERENCE_MD)
    txt = st.text_area(
        "Transactions", height=180, key=P + "bulk_txt",
        placeholder=("buy, NVDA, 10, 1400\n"
                     "buy, SPY, 100, 10000, Brokerage, ETF / Index Fund, Fidelity, SPDR S&P 500\n"
                     "sell, VTI, 20, 4900, 3800, long, Fidelity"))
    ops, errs = _parse_bulk(txt or "", pos)
    if (txt or "").strip():
        st.caption(f"Parsed **{len(ops)}** transaction(s)"
                   + (f"; **{len(errs)}** line(s) couldn't be read." if errs else "."))
        if errs:
            with st.expander(f"⚠️ {len(errs)} line(s) skipped"):
                for ln, raw, why in errs[:50]:
                    st.caption(f"Line {ln}: {why} — `{raw[:80]}`")
        if ops and st.button(f"Apply {len(ops)} transaction(s)", type="primary",
                             width="stretch", key=P + "bulk_go"):
            done, failed = _apply_bulk(ops)
            msg = f"Applied {done} transaction(s)."
            if failed:
                msg += f" {failed} couldn't be applied."
            ui.flash(msg)
            st.rerun()


@st.dialog("Buy / Sell Shares or Units", width="large")
def buy_sell_dialog():
    pos = positions(db.load_df("assets"))
    if not pos:
        st.info("No ticker-based positions yet — add a brokerage, crypto, or "
                "retirement holding (with a ticker) first.")
        return
    st.caption("Record a purchase or sale against an existing position. Buying "
               "adds units and cost basis; selling removes them and records the "
               "realized gain as investment income or the loss as a deductible "
               "expense (tax-advantaged accounts adjust the position only).")
    # Per-open key prefix (the launcher bumps `_bs_open` on every open, see
    # dashboard.assets_page): every widget below gets a brand-new identity each
    # open, so a prior open's selection can't linger. Streamlit keeps a dialog's
    # widget state after it's dismissed; reusing fixed keys made the toggle show
    # the old Sell/Bulk pick while the body rendered the default panel.
    P = f"bs_{st.session_state.get('_bs_open', 0)}_"
    mode = st.radio("Entry mode", ["Single", "Bulk paste"], horizontal=True, key=P + "mode")
    if mode == "Single":
        _single_form(pos, P)
    else:
        _bulk_form(pos, P)
