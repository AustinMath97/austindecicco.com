"""
utils.py — shared helpers used across dashboard, cards, forms, and calendar.

Keep this module free of Streamlit imports so it can be used anywhere.
"""

import ast
import math
import operator
import re
from datetime import date, datetime, timezone
from urllib.parse import quote

# The single date display format for the whole app: mm/dd/yyyy.
DATE_FORMAT = "%m/%d/%Y"

# Vehicle condition choices, shared by Add and Edit.
VEHICLE_CONDITIONS = ["Good", "Excellent", "Very Good", "Fair", "Poor"]


# ── Account Type + Asset Type taxonomy ────────────────────────────────────────
# An asset is described by three fields: `institution` (where it's held), an
# ACCOUNT TYPE (the tax/custody wrapper — NULL for directly-held things), and an
# ASSET TYPE (what the holding actually is). The asset type's *family* is the
# coarse kind (security/cash/real_estate/…) used for sectioning, cash detection,
# and investment grouping — the role the old `subtype` column played.

# Account types, grouped for the Add/Edit dropdown. A blank/None account type
# means the asset is held directly (real estate, vehicles, collectibles,
# business stakes, receivables).
ACCOUNT_TYPE_GROUPS = {
    "Taxable":     ["Brokerage"],
    "Retirement":  ["Roth IRA", "Traditional IRA", "401(k)", "Roth 401(k)", "403(b)",
                    "457(b)", "SEP IRA", "SIMPLE IRA", "Solo 401(k)", "HSA",
                    "529 / Education Savings", "Pension / Defined Benefit", "Annuity"],
    "Inherited":   ["Inherited IRA (Traditional)", "Inherited Roth IRA", "Inherited 401(k)",
                    "Inherited Brokerage / Taxable", "Inherited Annuity", "Beneficiary HSA",
                    "Estate / Trust Distribution (pending)"],
    "Cash / Bank": ["Checking", "Savings", "High-Yield Savings (HYSA)", "Money Market",
                    "CD (Certificate of Deposit)", "HSA (Health Savings)",
                    "Cash Management Account", "Treasury Bills / I-Bonds"],
    "Crypto":      ["Centralized Exchange (CEX)", "Self-custody wallet", "DeFi / staking"],
}
ACCOUNT_TYPE_OPTIONS = [a for grp in ACCOUNT_TYPE_GROUPS.values() for a in grp]

# Asset types grouped by family — the dict KEY is the family (coarse kind), the
# value is the asset-type choices the Add/Edit dropdowns offer for it.
ASSET_TYPES_BY_FAMILY = {
    "security":    ["Stock", "ETF / Index Fund", "Mutual Fund", "Bond / Fixed Income",
                    "REIT", "Options"],
    "crypto":      ["Cryptocurrency"],
    "cash":        ["Cash"],
    "real_estate": ["Primary Residence", "Rental Property", "Vacation / Short-Term Rental",
                    "Commercial Property", "Raw Land", "REIT / Real Estate Fund"],
    "vehicle":     ["Car", "Truck / SUV", "Motorcycle", "Boat", "RV / Camper", "Aircraft"],
    "business":    ["Sole Proprietorship", "Partnership / LLC Interest", "S-Corp / C-Corp Equity",
                    "Franchise", "Minority Stake"],
    "receivable":  ["Personal Loan to Someone", "Security Deposit", "Tax Refund Expected",
                    "Insurance Claim", "Legal Settlement", "Invoice / Client Payment Due"],
    "collectible": ["Jewelry / Watches", "Art", "Trading Cards / Comics", "Antiques",
                    "Wine / Spirits", "Instruments", "Electronics", "Designer Goods"],
    "other":       ["Other"],
}
ASSET_TYPE_OPTIONS = [t for grp in ASSET_TYPES_BY_FAMILY.values() for t in grp]
ASSET_TYPE_FAMILY = {t: fam for fam, types in ASSET_TYPES_BY_FAMILY.items() for t in types}
SECURITY_ASSET_TYPES = ASSET_TYPES_BY_FAMILY["security"]   # the dropdown for an account-held holding

# Account types whose growth/disposal is NOT a taxable capital event: every
# tax-advantaged wrapper, plus inherited retirement accounts / annuities / HSA
# (their distributions are ordinary income, not capital gains). An inherited
# *taxable* brokerage account is deliberately NOT here — it gets stepped-up basis
# and ordinary long-term capital-gain treatment.
TAX_ADVANTAGED_ACCOUNTS = set(ACCOUNT_TYPE_GROUPS["Retirement"]) | {
    "Inherited IRA (Traditional)", "Inherited Roth IRA", "Inherited 401(k)",
    "Inherited Annuity", "Beneficiary HSA", "HSA (Health Savings)",
}

# Asset-type families whose disposal can realize a capital gain/loss.
_CAPITAL_FAMILIES = {"security", "crypto", "real_estate", "collectible", "business", "other"}


def _astr(x) -> str:
    """A value as a stripped string; None / NaN / numbers (DataFrame cells) → ''."""
    return x.strip() if isinstance(x, str) else ""


def asset_family(asset_type) -> str:
    """The coarse kind of an asset type (security / crypto / cash / real_estate /
    …), defaulting to 'other'. Replaces the old `subtype` as the classifier."""
    return ASSET_TYPE_FAMILY.get(_astr(asset_type), "other")


def is_investment_holding(asset_type) -> bool:
    """A tradable security or crypto position — groups into Investment Accounts and
    is what the Buy/Sell tool operates on."""
    return asset_family(asset_type) in ("security", "crypto")


def is_cash(asset_type) -> bool:
    """A cash balance — the Cash & Bank section, earns APY, an auto-deposit target."""
    return asset_family(asset_type) == "cash"


def is_capital_asset(asset_type) -> bool:
    """Whether disposing of this asset type can realize a capital gain or loss."""
    return asset_family(asset_type) in _CAPITAL_FAMILIES


def is_tax_advantaged_account(account_type) -> bool:
    """Whether the account wrapper shields gains from capital-gains tax (any
    retirement / IRA / HSA, and inherited retirement accounts / annuities)."""
    return _astr(account_type) in TAX_ADVANTAGED_ACCOUNTS


def is_inherited_account(account_type) -> bool:
    """An inherited account — stepped-up basis, so a taxable sale is long-term."""
    a = _astr(account_type)
    return a.startswith("Inherited") or a == "Beneficiary HSA"


def is_distribution(account_type) -> bool:
    """A pending estate/trust cash distribution: money owed, not a holding (no
    ticker/shares, grouped with receivables)."""
    return _astr(account_type) == "Estate / Trust Distribution (pending)"


# ── Economic-variable rate formulas (Margin Loan APR) ──────────────────────────
# A Margin Loan's APR is a formula over the economic variables (db.constants,
# stored as decimals — 0.0533 = 5.33%). The user writes an arithmetic expression
# referencing these names; safe_eval_formula evaluates it against their current
# values, and db.refresh_margin_aprs re-derives the stored APR whenever the
# variables change. The set is intentionally small and matches the Economic
# Variables page.
ECONOMIC_VARIABLE_KEYS = [
    "fed_funds_rate", "fed_funds_target_lower", "fed_funds_target_upper",
    "inflation_rate",
]

# A margin loan is borrowed against an investment account, so it's a claim on
# liquid holdings: it contributes *negative* liquidity. debts.type == this value.
# Lives here (not stats) so db can reference it without importing the stats layer;
# stats re-exports it for its callers.
MARGIN_DEBT_TYPE = "margin"

_FORMULA_BINOPS = {
    ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
    ast.Div: operator.truediv, ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod, ast.Pow: operator.pow,
}
_FORMULA_UNARY = {ast.UAdd: operator.pos, ast.USub: operator.neg}


def safe_eval_formula(expr: str, variables: dict) -> float:
    """Evaluate a small arithmetic expression that may reference the names in
    `variables` (a Margin Loan APR formula over the economic variables). Allows
    numbers, those names, parentheses, and + - * / // % ** only — no function
    calls, attributes, comprehensions, or other names. Raises ValueError with a
    user-readable message on anything unsupported, an unknown name, a too-large
    exponent, or division by zero. Returns a float."""
    expr = (expr or "").strip()
    if not expr:
        raise ValueError("Enter a formula.")
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as exc:
        raise ValueError(f"Couldn't parse the formula: {exc.msg}.") from exc

    def _ev(node):
        if isinstance(node, ast.Expression):
            return _ev(node.body)
        if isinstance(node, ast.Constant):
            if isinstance(node.value, bool) or not isinstance(node.value, (int, float)):
                raise ValueError("Only numbers and the listed variables are allowed.")
            try:
                return float(node.value)
            except OverflowError as exc:            # an int literal too big for a float
                raise ValueError("A number in the formula is too large.") from exc
        if isinstance(node, ast.Name):
            if node.id not in variables:
                raise ValueError(
                    f"Unknown variable '{node.id}'. "
                    f"Available: {', '.join(variables)}.")
            return float(variables[node.id])
        if isinstance(node, ast.BinOp) and type(node.op) in _FORMULA_BINOPS:
            left, right = _ev(node.left), _ev(node.right)
            if isinstance(node.op, ast.Pow) and abs(right) > 64:
                raise ValueError("Exponent is too large.")
            try:
                return float(_FORMULA_BINOPS[type(node.op)](left, right))
            except ZeroDivisionError as exc:
                raise ValueError("Division by zero in the formula.") from exc
            except OverflowError as exc:            # e.g. float ** float too large
                raise ValueError("The formula's result is too large.") from exc
        if isinstance(node, ast.UnaryOp) and type(node.op) in _FORMULA_UNARY:
            return float(_FORMULA_UNARY[type(node.op)](_ev(node.operand)))
        raise ValueError(
            "Only numbers, the listed variables, parentheses, and + - * / // % ** are allowed.")

    result = _ev(tree)
    # A formula must yield a usable rate. inf can survive float arithmetic (which
    # overflows to inf rather than raising) and NaN propagates from a corrupted
    # variable; both would otherwise poison the stored APR silently — the callers
    # (refresh_margin_aprs, the dialogs) only handle ValueError.
    if not math.isfinite(result):
        raise ValueError("The formula doesn't produce a finite number.")
    return result


# ── Legacy → new field mapping (one-time migration backfill) ───────────────────
# The old model stored `subtype` + a conflated `asset_category`. legacy_to_new
# splits that into (account_type, asset_type); db._migrate calls it to backfill
# pre-split databases before dropping the deprecated columns. Once every live DB
# has migrated this is dead, but it stays to migrate old backups on restore.
_SECURITY_TYPE_SET = set(ASSET_TYPES_BY_FAMILY["security"])
# Best-guess asset type for a legacy account-held holding whose security type was
# never recorded (the data the split recovers). Reviewed per-row in the seed.
_LEGACY_HOLDING_DEFAULT = "ETF / Index Fund"


def legacy_to_new(subtype, asset_category):
    """(subtype, asset_category) → (account_type, asset_type)."""
    s, c = _astr(subtype), _astr(asset_category)
    if s == "brokerage":
        return "Brokerage", (c if c in _SECURITY_TYPE_SET else "Stock")
    if s in ("retirement", "ira"):
        acct = "HSA" if c == "HSA (invested)" else (c or "Brokerage")
        return acct, _LEGACY_HOLDING_DEFAULT
    if s == "inherited":
        if "Distribution" in c:
            return "Estate / Trust Distribution (pending)", "Cash"
        return (c or "Inherited Brokerage / Taxable"), _LEGACY_HOLDING_DEFAULT
    if s == "cash":
        return (c or "Checking"), "Cash"
    if s == "crypto":
        return (c or "Centralized Exchange (CEX)"), "Cryptocurrency"
    if s in ("real_estate", "vehicle", "business", "receivable", "collectible"):
        return None, (c or "Other")
    return None, (c or "Other")


def fmt_date(value, default: str = "—") -> str:
    """Format a date for display as mm/dd/yyyy.

    Accepts a ``date``/``datetime`` or an ISO string (date or datetime, with or
    without a trailing 'Z'). Dates are stored ISO in the database for sorting;
    this is the one place that turns them into the user-facing format.
    """
    if value is None:
        return default
    if isinstance(value, (date, datetime)):
        return value.strftime(DATE_FORMAT)
    s = str(value).strip()
    if not s or s in ("nan", "None", "NaT"):
        return default
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00")).strftime(DATE_FORMAT)
    except ValueError:
        try:
            return datetime.strptime(s[:10], "%Y-%m-%d").strftime(DATE_FORMAT)
        except ValueError:
            return s


def format_address(street="", city="", state="", zip_code="") -> str:
    """Assemble address parts into 'Street, City, ST ZIP', skipping any blanks."""
    street = (street or "").strip()
    city = (city or "").strip()
    state = (state or "").strip()
    zip_code = (zip_code or "").strip()
    locality = " ".join(p for p in (state, zip_code) if p)
    parts = [p for p in (street, city, locality) if p]
    return ", ".join(parts)


def zillow_search_url(address: str) -> str:
    """Zillow search URL for a property address. A full 'Street, City, ST ZIP'
    string (see format_address) resolves to the exact home and its Zestimate.
    There is no free Zestimate API, so the user opens this, reads the value, and
    updates it by hand."""
    q = quote((address or "").strip())
    if not q:
        return "https://www.zillow.com/how-much-is-my-home-worth/"
    return f"https://www.zillow.com/homes/{q}_rb/"


def _slug(s: str) -> str:
    """Lower-case URL slug: 'Sea Ray' → 'sea-ray', 'CBR500R' → 'cbr500r',
    'F-150' → 'f-150'. Runs of non-alphanumerics collapse to a single hyphen."""
    return re.sub(r"[^a-z0-9]+", "-", (s or "").strip().lower()).strip("-")


def parse_vehicle_name(name: str):
    """Best-effort split of a '<year> <make> <model…>' display name into
    (year, make, model). Used as a fallback for legacy rows saved before make /
    model / year were stored as their own fields. Multi-word makes (e.g. 'Sea
    Ray') can't be recovered this way — that's what the structured fields fix."""
    parts = (name or "").split()
    year = next((p for p in parts if len(p) == 4 and p.isdigit()), "")
    rest = [p for p in parts if p != year]
    make = rest[0] if rest else ""
    model = " ".join(rest[1:]) if len(rest) > 1 else ""
    return year, make, model


def vehicle_value_url(make: str = "", model: str = "", year="",
                      vehicle_type: str = "") -> str:
    """The single best free valuation page for a vehicle, deep-linked from its
    make / model / year and routed by type:
      cars / trucks / SUVs → KBB        kbb.com/{make}/{model}/{year}/
      motorcycles          → KBB        kbb.com/motorcycles/{make}/{model}/{year}/
      boats                → J.D. Power jdpower.com/boats/{year}/{make}-boats
      RVs / campers        → J.D. Power jdpower.com/rvs/{year}/{make}
      aircraft             → VREF (no public deep link; lands on the tool)
    Falls back to each site's value tool when the fields needed for a deep link
    are missing. (KBB does not cover boats, RVs, or aircraft.)"""
    vt = (vehicle_type or "").lower()
    mk, md = _slug(make), _slug(model)
    yr = str(year).strip().split(".")[0]              # '2022', not '2022.0'

    if "boat" in vt:
        return f"https://www.jdpower.com/boats/{yr}/{mk}-boats" if (yr and mk) \
            else "https://www.jdpower.com/boats"
    if "rv" in vt or "camper" in vt:
        return f"https://www.jdpower.com/rvs/{yr}/{mk}" if (yr and mk) \
            else "https://www.jdpower.com/rvs"
    if "aircraft" in vt:
        return "https://www.vref.com/"
    if "motorcycle" in vt:
        return f"https://www.kbb.com/motorcycles/{mk}/{md}/{yr}/" if (mk and md and yr) \
            else "https://www.kbb.com/motorcycles/"
    # Car / Truck / SUV / Other → KBB.
    if mk and md and yr:
        return f"https://www.kbb.com/{mk}/{md}/{yr}/"
    return "https://www.kbb.com/car-values/"


def coingecko_url(query: str) -> str:
    """CoinGecko search — free price reference for a coin yfinance can't price."""
    q = quote((query or "").strip())
    return f"https://www.coingecko.com/en/search?query={q}" if q else "https://www.coingecko.com/"


def _parse_utc(value):
    """Parse an ISO timestamp (stored UTC) into a tz-aware datetime, or None if it
    can't be parsed."""
    if value is None:
        return None
    s = str(value).strip()
    if not s or s in ("nan", "None", "NaT"):
        return None
    try:
        dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def days_since(value) -> "int | None":
    """Whole days between an ISO timestamp (stored UTC) and now, or None if it can't be
    parsed. For display; use seconds_since for an exact staleness test."""
    dt = _parse_utc(value)
    return None if dt is None else (datetime.now(timezone.utc) - dt).days


def seconds_since(value) -> "float | None":
    """Exact seconds between an ISO timestamp (stored UTC) and now, or None if it can't
    be parsed. Lets a staleness window of N days mean exactly N×86 400 seconds rather
    than a floored whole-day count."""
    dt = _parse_utc(value)
    return None if dt is None else (datetime.now(timezone.utc) - dt).total_seconds()


def fmt_datetime(value, default: str = "—") -> str:
    """Format a stored UTC ISO timestamp as local 'mm/dd/yyyy h:mm:ss AM/PM'
    (to the second). Used for "last updated" stamps on cards."""
    if value is None:
        return default
    if isinstance(value, datetime):
        dt = value
    else:
        s = str(value).strip()
        if not s or s in ("nan", "None", "NaT"):
            return default
        try:
            dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
        except ValueError:
            return default
    # Timestamps are stored UTC; a naive one is UTC without the marker. Treating
    # it as local (the old behavior) displayed it hours off and disagreed with
    # days_since/seconds_since, which already assume naive == UTC.
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    dt = dt.astimezone()                          # UTC -> local
    return dt.strftime("%m/%d/%Y %I:%M:%S %p")


def ordinal(n: int) -> str:
    """Return the ordinal string for a positive integer.

    1 → '1st', 2 → '2nd', 3 → '3rd', 11 → '11th', 21 → '21st', 31 → '31st'.
    """
    if n < 1:
        return str(n)
    if 11 <= (n % 100) <= 13:
        return f"{n}th"
    return f"{n}{('th','st','nd','rd','th','th','th','th','th','th')[n % 10]}"


def safe_float(v, default: float = 0.0) -> float:
    """Return v as a float, substituting default for None/NaN/non-numeric."""
    if v is None:
        return default
    try:
        f = float(v)
        return default if math.isnan(f) else f
    except (TypeError, ValueError):
        return default


def safe_str(v, default: str = "") -> str:
    """Return v as a stripped string, substituting default for None/NaN/empty."""
    if v is None:
        return default
    if isinstance(v, float) and math.isnan(v):
        return default
    s = str(v).strip()
    return default if s.lower() in ("", "nan", "none") else s


def money(x, decimals: int = 0) -> str:
    """$-format a value — '-$1,234' / '$1,234', or '—' for None/NaN/non-numeric.
    The single shared implementation (this module is import-cycle-free); pass
    decimals=2 where cents matter (e.g. card line items)."""
    try:
        v = float(x)
    except (TypeError, ValueError):
        return "—"
    if v != v:                              # NaN
        return "—"
    return f"-${abs(v):,.{decimals}f}" if v < 0 else f"${v:,.{decimals}f}"


def esc(s: str) -> str:
    """Escape '$' so Streamlit markdown doesn't treat $...$ as LaTeX math —
    needed whenever a markdown/caption string carries more than one dollar
    amount (st.metric values are not markdown-parsed, so they're fine)."""
    return s.replace("$", "\\$")


def md_escape(s: str) -> str:
    """Escape every markdown special character so arbitrary text renders LITERALLY
    — never as emphasis, inline code, or LaTeX. Use this (not backticks or a
    :color[...] directive) for untrusted text in a markdown/caption string, e.g. a
    user-entered APR formula whose underscores would otherwise italicize / look
    like math (backslash before ASCII punctuation is dropped, so the char shows)."""
    s = str(s)
    for ch in "\\`*_{}[]()#+-.!$|~<>":     # backslash first, so it isn't doubled
        s = s.replace(ch, "\\" + ch)
    return s


def utilization_color(util_pct: float) -> str:
    """Streamlit color name for a credit-utilization percentage (0–100+):
    ≤10 green · ≤40 yellow · ≤70 orange · >70 (incl. over-limit) red."""
    if util_pct <= 10:
        return "green"
    if util_pct <= 40:
        return "yellow"
    if util_pct <= 70:
        return "orange"
    return "red"
