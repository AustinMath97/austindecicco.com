"""
stats.py — the compute layer.

Every function here is PURE: it takes pandas DataFrames (or plain numbers) in
and returns a number or a DataFrame out. No database, no network, no global
state. That means you can test any of these against a hand calculation in
isolation, exactly the way you'd check a closed-form result — which is what the
test at the bottom of the project does.

Conventions:
  - APR and all rates are stored as DECIMALS (0.069 means 6.9%).
  - "value" on an asset and "balance" on a debt are both positive numbers;
    net worth is assets minus debts.
  - Functions return float('nan') rather than raising when a ratio is
    undefined (e.g. a savings rate with zero income), so the UI can just
    display a dash.
"""

from __future__ import annotations

import calendar
import json
from datetime import date, timedelta
from typing import TYPE_CHECKING

if TYPE_CHECKING:                     # pandas is only needed for type hints --
    import pandas as pd               # this module stays pandas-free at runtime
from math import ceil, nan

import recurrence
from utils import (MARGIN_DEBT_TYPE, is_investment_holding, safe_float,
                   safe_str)


# --- totals ----------------------------------------------------------------

def effective_asset_values(assets: pd.DataFrame) -> pd.Series:
    """Each asset's value scaled by your ownership fraction — i.e. your *stake*.
    A business worth $100k that you own 60% of counts as $60k toward net worth.
    Assets with no ownership_pct (the usual case) count fully. Returns a pandas
    Series aligned to `assets`."""
    vals = assets["value"].fillna(0.0)
    if "ownership_pct" in assets.columns:
        own = assets["ownership_pct"].fillna(1.0)
        own = own.where(own > 0, 1.0)        # blank / 0 → treat as fully owned
        return vals * own
    return vals


def total_assets(assets: pd.DataFrame) -> float:
    return float(effective_asset_values(assets).sum()) if not assets.empty else 0.0


def total_debts(debts: pd.DataFrame) -> float:
    return float(debts["balance"].sum()) if not debts.empty else 0.0


def net_worth(assets: pd.DataFrame, debts: pd.DataFrame) -> float:
    return total_assets(assets) - total_debts(debts)


def liquid_assets(assets: pd.DataFrame) -> float:
    if assets.empty or "liquid" not in assets.columns or "value" not in assets.columns:
        return 0.0
    return float(effective_asset_values(assets)[assets["liquid"] == 1].sum())


# A margin loan is borrowed against an investment account, so it's a claim on
# liquid holdings: it contributes *negative* liquidity. type == MARGIN_DEBT_TYPE
# (defined in utils so db can share it; re-exported above for this module's callers).


def margin_debt_total(debts: pd.DataFrame) -> float:
    """Total balance of margin loans. Borrowed against an investment account, a
    margin loan is a lien on liquid holdings, so the liquid figure subtracts it."""
    if debts.empty or "type" not in debts.columns or "balance" not in debts.columns:
        return 0.0
    return float(debts.loc[debts["type"] == MARGIN_DEBT_TYPE, "balance"].fillna(0.0).sum())


def net_liquid_assets(assets: pd.DataFrame, debts: pd.DataFrame) -> float:
    """Liquid assets minus the margin loans borrowed against them — the liquid
    figure the Overview shows, which a margin loan reduces."""
    return liquid_assets(assets) - margin_debt_total(debts)


def margin_by_account(debts: pd.DataFrame) -> dict:
    """Total margin-loan balance borrowed against each investment account, keyed by
    the account label stored on the loan (debts.margin_account — the same label
    investment_accounts() produces). Lets the Investment Accounts page net margin
    out of an account's value to show its equity."""
    out: dict = {}
    if debts.empty or "type" not in debts.columns or "margin_account" not in debts.columns:
        return out
    m = debts[debts["type"] == MARGIN_DEBT_TYPE]
    for _, r in m.iterrows():
        label = safe_str(r.get("margin_account"))
        if label:
            out[label] = out.get(label, 0.0) + safe_float(r.get("balance"))
    return out


# --- expense normalization -------------------------------------------------
# Expenses recur on a full schedule (weekly … annual). A "set" expense has one
# fixed per-occurrence amount; a "variable" expense records the actual amount of
# each occurrence over its last variable_years years (1 by default) and projects
# forward — by the recorded average, by repeating the recorded payments in order
# (by_period), or by each period's own cross-year average (seasonal). The same
# per-occurrence amounts the Accounts forecast and calendar place day-by-day
# annualize here, so the headline totals and the forecast can't drift apart.

def expense_annual_factor(row) -> float:
    """How many times a year one expense row's schedule fires (its per-occurrence
    amount × this = its annual cost). 0 for one-time / unscheduled rows."""
    return recurrence.occurrences_per_year(recurrence.from_row(row))


def is_variable(row) -> bool:
    """True when the expense tracks a different amount each period (vs. a fixed 'set'
    amount). NaN/blank/'set' → False."""
    return safe_str(row.get("amount_mode") if hasattr(row, "get") else None).lower() == "variable"


def variable_years_of(row) -> int:
    """How many years of payment history a variable expense records — the
    variable_years column, with blank/legacy/garbage reading as 1."""
    try:
        v = int(float(row.get("variable_years") if hasattr(row, "get") else 1))
    except (TypeError, ValueError):
        v = 1
    return max(1, v)


def parse_variable_amounts(row) -> dict:
    """{date: amount} of recorded past-year payments, parsed from the stored
    variable_amounts JSON. Blank / malformed → {}."""
    raw = safe_str(row.get("variable_amounts") if hasattr(row, "get") else None)
    if not raw:
        return {}
    try:
        obj = json.loads(raw)
    except (ValueError, TypeError):
        return {}
    out = {}
    for k, v in (obj.items() if isinstance(obj, dict) else []):
        try:
            out[date.fromisoformat(str(k)[:10])] = float(v)
        except (ValueError, TypeError):
            continue
    return out


def _occurrences_between(sched: dict, start: date, end: date) -> list:
    """Every occurrence date of `sched` in [start, end] (inclusive), in order."""
    out = []
    if end < start:
        return out
    y, m = start.year, start.month
    while (y, m) <= (end.year, end.month):
        for d in recurrence.occurrences_in_month(sched, y, m):
            dt = date(y, m, d)
            if start <= dt <= end:
                out.append(dt)
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


def variable_occurrence_dates(sched: dict, today: date, years: int = 1) -> list:
    """The occurrence dates a variable-amount expense must record an amount for: the
    most recent `years` years' worth of occurrences up to and including `today` —
    i.e. the last ``years × occurrences_per_year`` of them (12/24/36… for monthly,
    52/104… for weekly). Taking whole seasonal cycles (rather than every date in a
    day-count span, which double-counts the endpoints) keeps the cyclic projections
    (by_period / seasonal) aligned to the same season in later years."""
    period = int(round(recurrence.occurrences_per_year(sched)))
    years = max(1, int(years or 1))
    if period <= 0:
        return []
    # A ~400-day-per-year look-back comfortably covers the cycles of any cadence;
    # keep the most recent `period × years` occurrences that have already happened.
    occ = _occurrences_between(sched, today - timedelta(days=400 * years), today)
    return occ[-period * years:]


def past_year_occurrence_dates(sched: dict, today: date) -> list:
    """One year of variable_occurrence_dates — the pre-multi-year name, kept for
    its callers."""
    return variable_occurrence_dates(sched, today, 1)


def occurrence_amounts(row, start: date, end: date, today: date) -> dict:
    """{date: amount} for each occurrence of expense `row` in [start, end].
    A set expense uses its fixed amount everywhere. A variable expense uses its
    recorded amount for dates it has one, and projects future dates by its
    variable_method: the recorded average ('average', the default), repeating the
    recorded payments in order ('by_period' — with multi-year history that's the
    whole recorded cycle, season-aligned), or each period's own average across
    the recorded years ('seasonal' — e.g. January projects as the mean of the
    recorded Januaries)."""
    sched = recurrence.from_row(row)
    win = _occurrences_between(sched, start, end)
    if not is_variable(row):
        amt = safe_float(row.get("amount") if hasattr(row, "get") else 0.0)
        return {d: amt for d in win}
    obs = parse_variable_amounts(row)
    vals = [obs[k] for k in sorted(obs)]
    n = len(vals)
    avg = sum(vals) / n if n else 0.0
    method = safe_str(row.get("variable_method")).lower()
    period = int(round(recurrence.occurrences_per_year(sched)))
    # Cyclic positions are anchored to the END OF THE RECORDED RUN, not to
    # `today`: callers pass a live date.today(), and anchoring there would remap
    # phases as real time passes (the day after the record ages, December would
    # start projecting from November's data). Counting occurrences from just
    # after the last recorded one keeps every future date's phase — its offset
    # from the recorded sequence — fixed no matter when the caller asks.
    last_rec = max(obs) if obs else today
    fidx = {d: i for i, d in enumerate(
        _occurrences_between(sched, last_rec + timedelta(days=1), end))}
    out = {}
    for d in win:
        if d in obs:
            out[d] = obs[d]                       # an actual recorded payment
        elif d > today and n and method == "by_period":
            # Repeat the recorded payments in order; (n + i) keeps the phase
            # contiguous with the recorded tail.
            out[d] = vals[(n + fidx.get(d, 0)) % n]
        elif d > today and n and method == "seasonal" and period > 0:
            # The values at this occurrence's cyclic position, one per recorded
            # year — (n + i) % period is the phase relative to the FIRST recorded
            # occurrence, correct even when the record isn't whole years.
            season = vals[(n + fidx.get(d, 0)) % period::period]
            out[d] = sum(season) / len(season) if season else avg
        else:
            out[d] = avg                          # average projection (or fallback)
    return out


def expense_annual_amount(row) -> float:
    """One expense's annual cost: amount × yearly occurrences for a set expense, or
    the recorded per-occurrence average × yearly occurrences for a variable one —
    NOT the raw sum of records, which would overstate the year once the history
    spans multiple years. (For a complete single-year record the two are equal.)
    This is the RUN-RATE across the whole recorded history: under by_period the
    individual projected years replay the recorded years and so oscillate around
    this figure, averaging back to it over the full cycle."""
    if is_variable(row):
        obs = parse_variable_amounts(row)
        if not obs:
            return 0.0
        period = recurrence.occurrences_per_year(recurrence.from_row(row))
        return float(sum(obs.values()) / len(obs) * period)
    amt = safe_float(row.get("amount") if hasattr(row, "get") else 0.0)
    return amt * recurrence.occurrences_per_year(recurrence.from_row(row))


def annual_expenses(expenses: pd.DataFrame) -> float:
    """Total recurring annual spend across every expense (set + variable)."""
    if expenses.empty or "amount" not in expenses.columns:
        return 0.0
    return float(expenses.apply(expense_annual_amount, axis=1).sum())


def monthly_recurring_expenses(expenses: pd.DataFrame) -> float:
    """Recurring monthly burn — the annual run-rate spread evenly over 12 months."""
    return annual_expenses(expenses) / 12.0


def investment_accounts(assets: pd.DataFrame) -> list[dict]:
    """Group investment holdings (securities + crypto — see utils.is_investment_
    holding) into accounts by (institution, account_type), e.g. "Fidelity —
    Brokerage" or "Vanguard — Roth IRA". Returns a list of dicts sorted by value
    (largest first):
        {institution, account_type, label, value, cost_basis, gain, names, holdings}
    `value` is ownership-effective; `gain`/`cost_basis` sum only the positions
    that track a cost basis (gain is None when none do); `holdings` is the
    asset-row sub-DataFrame for display."""
    out = []
    if assets.empty or "asset_type" not in assets.columns:
        return out
    inv = assets[assets["asset_type"].apply(is_investment_holding)].copy()
    if inv.empty:
        return out
    inv["_eff"] = effective_asset_values(assets).loc[inv.index]
    # DataFrame.get's default for a missing column is the scalar "" — .fillna on
    # a str raises. Guard each column instead so this degrades (the convention).
    inv["_inst"] = (inv["institution"].fillna("").astype(str).str.strip()
                    if "institution" in inv.columns else "")
    inv["_acct"] = (inv["account_type"].fillna("").astype(str).str.strip()
                    if "account_type" in inv.columns else "")
    for (inst, acct), grp in inv.groupby(["_inst", "_acct"], dropna=False):
        basis_rows = grp[grp["cost_basis"].notna() & (grp["cost_basis"] > 0)] \
            if "cost_basis" in grp.columns else grp.iloc[0:0]
        cost = float(basis_rows["cost_basis"].sum()) if not basis_rows.empty else 0.0
        gain = (float((basis_rows["value"] - basis_rows["cost_basis"]).sum())
                if not basis_rows.empty else None)
        label = " — ".join(p for p in (inst, acct) if p) or "Uncategorized"
        out.append({
            "institution": inst, "account_type": acct, "label": label,
            "value": float(grp["_eff"].sum()),
            "cost_basis": cost, "gain": gain,
            "names": list(grp["name"]),
            "holdings": grp.drop(columns=["_eff", "_inst", "_acct"]),
        })
    out.sort(key=lambda a: -a["value"])
    return out


def unrealized_gain_loss(assets: pd.DataFrame) -> tuple[float, float]:
    """Total unrealized gain/loss for positions that have a cost_basis set.
    Returns (absolute_gain, percentage) — both nan when no cost basis exists."""
    if assets.empty or "cost_basis" not in assets.columns:
        return nan, nan
    inv = assets[assets["cost_basis"].notna() & (assets["cost_basis"] > 0)].copy()
    if inv.empty:
        return nan, nan
    gl = float((inv["value"] - inv["cost_basis"]).sum())
    cost = float(inv["cost_basis"].sum())
    return gl, (gl / cost if cost > 0 else nan)


# --- income ----------------------------------------------------------------

def income_totals(income: pd.DataFrame) -> tuple[float, float, float]:
    """Return (ytd_realized, expected_remaining, projected_eoy).

    Each income row is one stream: `amount` is its full-year expected total and
    `received_ytd` is how much of that is already in hand. So YTD realised is the
    sum of received_ytd, and what's still expected this year is the per-stream
    remainder amount − received_ytd (floored at 0 so an over-received stream can't
    drag the remainder negative). Projected EOY is realised + still-expected."""
    if income.empty:
        return 0.0, 0.0, 0.0
    amount = income["amount"].fillna(0.0).astype(float)
    received = (income["received_ytd"].fillna(0.0).astype(float)
                if "received_ytd" in income.columns else amount * 0.0)
    ytd = float(received.sum())
    expected = float((amount - received).clip(lower=0.0).sum())
    return ytd, expected, ytd + expected


# --- ratios ----------------------------------------------------------------

def savings_rate(income: pd.DataFrame, expenses: pd.DataFrame) -> float:
    """(projected annual income - annual expenses) / projected annual income."""
    _, _, eoy = income_totals(income)
    if eoy <= 0:
        return nan
    return (eoy - annual_expenses(expenses)) / eoy


def runway_months(assets: pd.DataFrame, expenses: pd.DataFrame, debts=None) -> float:
    """How many months of recurring expenses your liquid assets cover. When `debts`
    is given, margin loans (negative liquidity) are netted out of the liquid total."""
    burn = monthly_recurring_expenses(expenses)
    if burn <= 0:
        return nan
    liq = liquid_assets(assets) if debts is None else net_liquid_assets(assets, debts)
    return liq / burn


def debt_to_income(debts: pd.DataFrame, income: pd.DataFrame) -> float:
    """Standard monthly DTI: total minimum debt payments / monthly gross
    income (using projected EOY income / 12)."""
    _, _, eoy = income_totals(income)
    if eoy <= 0:
        return nan
    monthly_income = eoy / 12.0
    if debts.empty or "min_payment" not in debts.columns:
        payments = 0.0
    else:
        payments = float(debts["min_payment"].fillna(0).sum())
    return payments / monthly_income


def weighted_avg_apr(debts: pd.DataFrame) -> float:
    """Balance-weighted average APR across all debts."""
    if debts.empty or "balance" not in debts.columns or "apr" not in debts.columns:
        return nan
    total = float(debts["balance"].sum())
    if total <= 0:
        return nan
    return float((debts["balance"] * debts["apr"]).sum()) / total


# NaN-safe float for row fields: `float(x or 0)` lets NaN straight through
# (NaN is truthy), which poisons every comparison and ceil() downstream.
# The shared utils implementation (utils is also pure).
_f = safe_float


def monthly_net_cash_flow(income: pd.DataFrame, expenses: pd.DataFrame) -> float:
    """Projected income per month (full-year expected ÷ 12) minus the recurring
    monthly burn — "am I gaining or losing money in a typical month?"."""
    _, _, eoy = income_totals(income)
    return eoy / 12.0 - monthly_recurring_expenses(expenses)


def yearly_debt_interest(debts: pd.DataFrame) -> float:
    """What the debts cost per year just to exist: Σ balance × APR (a flat-balance
    approximation — amortizing debts cost a bit less as they shrink)."""
    if debts.empty or "balance" not in debts.columns or "apr" not in debts.columns:
        return 0.0
    return float((debts["balance"].fillna(0.0) * debts["apr"].fillna(0.0)).sum())


def min_payment_due(balance, mp_type=None, pct=None, fixed=None, apr=None) -> float:
    """The minimum payment owed on a debt this period for its payment model:
      'percent'                → pct × balance
      'percent_floor'          → max(pct × balance, the dollar floor `fixed`)
      'percent_interest'       → pct × balance + one month's interest (balance × apr/12)
      'percent_interest_floor' → max(pct × balance + one month's interest, `fixed`)
      'fixed' / None           → the flat dollar amount `fixed`
    The interest models mirror how most issuers actually bill a card minimum (a
    slice of principal plus the period's interest), so they always outrun the
    interest and pay principal down. Capped at the balance: once the balance is at
    or below the minimum, the payment is simply the remaining balance."""
    balance = safe_float(balance)
    if balance <= 0:
        return 0.0
    fixed, pct = safe_float(fixed), safe_float(pct)
    interest = balance * safe_float(apr) / 12.0
    t = safe_str(mp_type).lower()
    if t == "percent":
        due = balance * pct
    elif t == "percent_floor":
        due = max(balance * pct, fixed)
    elif t == "percent_interest":
        due = balance * pct + interest
    elif t == "percent_interest_floor":
        due = max(balance * pct + interest, fixed)
    else:
        due = fixed
    return float(min(due, balance))


def debt_min_payment(row) -> float:
    """min_payment_due read straight off a debt row's columns."""
    g = row.get if hasattr(row, "get") else (lambda k, d=None: d)
    return min_payment_due(g("balance"), g("min_payment_type"),
                           g("min_payment_pct"), g("min_payment"), apr=g("apr"))


def cc_min_expense_fields(card) -> dict:
    """The expense-row columns a credit-card-minimum expense mirrors from its
    card's debt record: the CURRENT computed minimum (every payment model,
    including % + interest), a monthly-on-due-day schedule, the card's name as
    the sub-category, and the pays-debt pairing (so group stats de-dup the
    pair). The single source of truth shared by the Add/Edit expense dialogs
    and db.sync_cc_min_expenses — a card edit, the statement-day refresh, and
    what the dialogs preview can never disagree."""
    g = card.get if hasattr(card, "get") else (lambda k, d=None: d)
    dd = safe_float(g("due_day"))
    sched = {"type": recurrence.MONTHLY, "weekday": None, "ordinal": None,
             "anchor": None, "month_days": [int(dd)] if dd > 0 else [],
             "months": None}
    desc = recurrence.describe(sched)
    return {
        "category": "Debt Payments",
        "subcategory": safe_str(g("name")) or "Card",
        "amount": float(round(debt_min_payment(card), 2)),
        "amount_mode": "set", "variable_method": None,
        "variable_amounts": None, "variable_years": None,
        "pays_debt_id": int(g("id")),
        "cc_min_debt_id": int(g("id")),
        "schedule_type": recurrence.MONTHLY, "weekday": None,
        "week_ordinal": None, "anchor_date": None,
        "pay_days": str(int(dd)) if dd > 0 else None, "months": None,
        "frequency": recurrence.frequency_label(recurrence.MONTHLY),
        "pay_day": desc or None,
    }


def months_to_payoff(balance, apr, mp_type=None, pct=None, fixed=None, cap: int = 600):
    """(months, total_interest) to clear `balance` paying the minimum each month —
    simulated, so a percent-of-balance minimum (which shrinks with the balance) is
    handled, not just a flat amount. Each month interest accrues, the minimum is
    taken on the statement balance, and the rest reduces principal. Returns
    (None, None) when the minimum can't outrun the interest (a true 'never') or it
    wouldn't clear within `cap` months."""
    balance = safe_float(balance)
    if balance <= 0:
        return 0, 0.0
    r = safe_float(apr) / 12.0
    b, months, interest = balance, 0, 0.0
    while b > 1.0 and months < cap:
        i = b * r if r > 0 else 0.0
        pay = min_payment_due(b + i, mp_type, pct, fixed, apr=apr)
        if pay <= 0 or pay <= i:
            return None, None
        b = b + i - pay
        interest += i
        months += 1
    return (None, None) if b > 1.0 else (months, interest)


def debt_free_months(debts: pd.DataFrame) -> tuple[int | None, str | None]:
    """(months, note) — months until the LAST debt with a payment plan pays off at
    minimum payments; 0 when none qualify. Debts without a minimum payment (tax
    accruals, informal loans…) have no payoff schedule, so they're EXCLUDED rather
    than blocking the date — `note` names them. months is None only when some
    payment can't outrun its monthly interest (a true never; `note` names it)."""
    if debts.empty or "balance" not in debts.columns:
        return 0, None
    worst, skipped, margin_skipped = 0, [], []
    for _, row in debts.iterrows():
        balance = _f(row.get("balance"))
        if balance <= 0:
            continue
        name = str(row.get("name") or "a debt")
        # A margin loan has no scheduled payment BY DESIGN — call that out
        # separately so it doesn't read like a forgotten data entry.
        if safe_str(row.get("type")) == MARGIN_DEBT_TYPE:
            margin_skipped.append(name)
            continue
        if debt_min_payment(row) <= 0:
            skipped.append(name)
            continue
        n, _ = months_to_payoff(balance, row.get("apr"), row.get("min_payment_type"),
                                row.get("min_payment_pct"), row.get("min_payment"))
        if n is None:
            return None, f"{name} can never pay off at its minimum payment"
        worst = max(worst, int(n))
    parts = []
    if skipped:
        parts.append("excludes " + ", ".join(skipped) + " — no minimum payment set")
    if margin_skipped:
        parts.append("excludes " + ", ".join(margin_skipped)
                     + " — margin loans have no scheduled payment")
    return worst, ("; ".join(parts) if parts else None)


def due_within_days(expenses: pd.DataFrame, debts: pd.DataFrame,
                    start: date, days: int = 7) -> float:
    """Total bills + debt payments falling due in [start, start + days): each
    expense expanded on its recurrence schedule (any cadence), and minimum
    payments on debts still carrying a balance. Due days past a month's end clamp
    to its last day, matching the calendar."""
    window = {start + timedelta(days=i) for i in range(days)}
    end = start + timedelta(days=days - 1)
    total = 0.0

    if expenses is not None and not expenses.empty and "amount" in expenses.columns:
        # Per-occurrence amounts (a variable bill uses its projected amount), kept
        # to the ones that land inside the window.
        for _, row in expenses.iterrows():
            for dt, amt in occurrence_amounts(row, start, end, start).items():
                if dt in window:
                    total += amt

    if debts is not None and not debts.empty and "due_day" in debts.columns:
        for d in window:
            ndays = calendar.monthrange(d.year, d.month)[1]
            for _, row in debts.iterrows():
                balance = _f(row.get("balance"))
                mp = debt_min_payment(row)       # honors %/floor models, caps at balance
                try:
                    due = int(row.get("due_day"))
                except (TypeError, ValueError):
                    continue
                if balance > 0 and mp > 0 and due > 0 and min(due, ndays) == d.day:
                    total += mp
    return total


# --- group statistics -------------------------------------------------------

def _effective_value(row) -> float:
    """An asset row's value scaled by ownership_pct (blank/0 → fully owned)."""
    own = safe_float(row.get("ownership_pct"), 1.0)
    return safe_float(row.get("value")) * (own if own > 0 else 1.0)


def _group_row_label(table, row) -> str:
    """A short label for a record from its own columns (no db) — for superlative
    and 'most stale' stats."""
    if table == "income":
        return safe_str(row.get("source")) or "Income"
    if table == "expenses":
        return (safe_str(row.get("subcategory")) or safe_str(row.get("category"))
                or "Expense")
    return safe_str(row.get("name")) or "?"


def _group_next_income(income_rows, today: date):
    """(date, amount, source) of the soonest scheduled income arrival on/after
    `today` within a year, or None. Mirrors next_income_event for dict rows."""
    best = None
    y, m = today.year, today.month
    for _ in range(13):
        for row in income_rows:
            amt = safe_float(row.get("pay_amount"))
            if amt <= 0:
                continue
            sched = recurrence.from_row(row)
            for day in recurrence.occurrences_in_month(sched, y, m):
                d = date(y, m, day)
                if d >= today and (best is None or d < best[0]):
                    best = (d, amt, safe_str(row.get("source")) or "Income")
        if best is not None:
            return best
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return None


def _next_due_date(today: date, due: int) -> date:
    """The next date on/after `today` whose day is `due` (clamped to month length)."""
    y, m = today.year, today.month
    for _ in range(13):
        d = date(y, m, min(due, calendar.monthrange(y, m)[1]))
        if d >= today:
            return d
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return today


def _group_next_payment(expense_rows, debt_rows, today: date, paid_ids):
    """(date, amount, label) of the soonest bill or debt payment due on/after
    `today`, across expenses (any cadence) and debts with a due day, or None. A
    debt whose payment is an included expense (paid_ids) is skipped (de-dup)."""
    best = None
    end = today + timedelta(days=400)
    for row in expense_rows:
        for d, amt in occurrence_amounts(row, today, end, today).items():
            if d >= today and amt and (best is None or d < best[0]):
                best = (d, amt, _group_row_label("expenses", row))
    for row in debt_rows:
        if int(safe_float(row.get("id"))) in paid_ids:
            continue
        mp = debt_min_payment(row)
        try:
            due = int(row.get("due_day"))
        except (TypeError, ValueError):
            continue
        if mp <= 0 or due <= 0:
            continue
        d = _next_due_date(today, due)
        if best is None or d < best[0]:
            best = (d, mp, safe_str(row.get("name")) or "Debt")
    return best


def group_statistics(records: list, today: date | None = None) -> dict:
    """Aggregate statistics for a link group. `records` is a list of
    {"table": "assets"|"debts"|"income"|"expenses", "in_stats": bool, "row": dict}.

    Each record contributes only to the stats its type carries data for (an asset to
    value/equity, a debt to balance/equity/cost/interest, income to income, an
    expense to cost), and a record with in_stats False is skipped entirely.

    An expense that is a debt's payment (its row['pays_debt_id'] points at a debt in
    the group) de-dups that debt's cash payment, so the group's monthly outflow
    counts the pair once — via the expense, the actual payment. A debt with no such
    paying expense contributes its own minimum payment.

    Returns a flat dict of every figure the GROUP_STATS_CATALOG can display; ratios
    that are undefined (e.g. a savings rate with no income) are nan. `today`, when
    given, also computes the schedule-dependent figures (next income / next payment);
    passing it keeps the function pure (deterministic in its inputs)."""
    inc = [r for r in records if r.get("in_stats")]
    assets = [r["row"] for r in inc if r["table"] == "assets"]
    debts = [r["row"] for r in inc if r["table"] == "debts"]
    income = [r["row"] for r in inc if r["table"] == "income"]
    expenses = [r["row"] for r in inc if r["table"] == "expenses"]

    # --- balance sheet ---
    total_value = sum(_effective_value(a) for a in assets)
    total_debt = sum(safe_float(d.get("balance")) for d in debts)
    equity = total_value - total_debt
    # Margin loans in the group are a lien on liquid holdings → negative liquidity.
    margin_in_group = sum(safe_float(d.get("balance")) for d in debts
                          if safe_str(d.get("type")) == MARGIN_DEBT_TYPE)
    liquid_value = sum(_effective_value(a) for a in assets
                       if int(safe_float(a.get("liquid"))) == 1) - margin_in_group

    basis_assets = [a for a in assets if safe_float(a.get("cost_basis")) > 0]
    cost_basis = sum(safe_float(a.get("cost_basis")) for a in basis_assets)
    unrealized_gain = (sum(safe_float(a.get("value")) - safe_float(a.get("cost_basis"))
                           for a in basis_assets) if basis_assets else nan)
    unrealized_gain_pct = (unrealized_gain / cost_basis
                           if basis_assets and cost_basis > 0 else nan)

    inv_assets = [a for a in assets if is_investment_holding(a.get("asset_type"))]
    invested_value = sum(_effective_value(a) for a in inv_assets)

    # --- cash flow ---
    paid_ids = {int(safe_float(e.get("pays_debt_id"))) for e in expenses
                if safe_float(e.get("pays_debt_id")) > 0}
    debt_payments = sum(debt_min_payment(d) for d in debts
                        if int(safe_float(d.get("id"))) not in paid_ids)
    expense_monthly = sum(expense_annual_amount(e) for e in expenses) / 12.0
    monthly_outflow = debt_payments + expense_monthly
    monthly_income = sum(safe_float(i.get("amount")) for i in income) / 12.0
    net_monthly = monthly_income - monthly_outflow
    annual_income = monthly_income * 12.0
    savings_rate = (net_monthly * 12.0 / annual_income) if annual_income > 0 else nan
    income_coverage = (monthly_income / monthly_outflow) if monthly_outflow > 0 else nan

    # --- debt & interest ---
    monthly_interest = sum(
        safe_float(d.get("balance")) * safe_float(d.get("apr")) / 12.0 for d in debts)
    total_min_payments = sum(debt_min_payment(d) for d in debts)
    interest_share = (monthly_interest / total_min_payments
                      if total_min_payments > 0 else nan)
    wavg_apr = (sum(safe_float(d.get("balance")) * safe_float(d.get("apr")) for d in debts)
                / total_debt if total_debt > 0 else 0.0)

    # Group payoff: the longest among debts that actually have a payment plan.
    payoff_months, payoff_interest, payoff_never, has_payoff = 0, 0.0, False, False
    for d in debts:
        if safe_float(d.get("balance")) <= 0 or debt_min_payment(d) <= 0:
            continue
        has_payoff = True
        n, intr = months_to_payoff(d.get("balance"), d.get("apr"),
                                   d.get("min_payment_type"), d.get("min_payment_pct"),
                                   d.get("min_payment"))
        if n is None:
            payoff_never = True
            break
        payoff_months = max(payoff_months, int(n))
        payoff_interest += intr

    # --- credit cards (revolving = has a credit_limit) ---
    cards = [d for d in debts if safe_float(d.get("credit_limit")) > 0]
    total_limit = sum(safe_float(c.get("credit_limit")) for c in cards)
    card_balance = sum(safe_float(c.get("balance")) for c in cards)
    available_credit = total_limit - card_balance
    utilization = (card_balance / total_limit) if total_limit > 0 else nan
    card_min_payments = sum(debt_min_payment(c) for c in cards)

    # --- ratios ---
    equity_pct = (equity / total_value) if total_value > 0 else nan
    ltv = (total_debt / total_value) if total_value > 0 else nan
    runway_months = (liquid_value / monthly_outflow) if monthly_outflow > 0 else nan
    cap_rate = (net_monthly * 12.0 / total_value) if total_value > 0 else nan

    # --- superlatives / meta ---
    largest_holding = max(((_group_row_label("assets", a), _effective_value(a))
                           for a in assets), key=lambda t: t[1], default=None)
    largest_debt = max(((_group_row_label("debts", d), safe_float(d.get("balance")))
                        for d in debts), key=lambda t: t[1], default=None)
    stalest = None
    for r in inc:
        u = safe_str(r["row"].get("updated_at"))
        if u and (stalest is None or u < stalest[0]):
            stalest = (u[:10], _group_row_label(r["table"], r["row"]))

    next_income = _group_next_income(income, today) if today is not None else None
    next_payment = (_group_next_payment(expenses, debts, today, paid_ids)
                    if today is not None else None)

    return {
        "n_assets": len(assets), "n_debts": len(debts),
        "n_income": len(income), "n_expenses": len(expenses),
        "n_positions": len(inv_assets), "n_basis": len(basis_assets),
        "n_cards": len(cards),
        "total_value": total_value, "total_debt": total_debt,
        "equity": equity, "equity_pct": equity_pct, "liquid_value": liquid_value,
        "cost_basis": cost_basis, "unrealized_gain": unrealized_gain,
        "unrealized_gain_pct": unrealized_gain_pct, "invested_value": invested_value,
        "monthly_outflow": monthly_outflow, "annual_outflow": monthly_outflow * 12.0,
        "expenses_monthly": expense_monthly, "debt_payments_monthly": debt_payments,
        "monthly_interest": monthly_interest, "annual_interest": monthly_interest * 12.0,
        "monthly_income": monthly_income, "annual_income": annual_income,
        "net_monthly": net_monthly, "net_annual": net_monthly * 12.0,
        "savings_rate": savings_rate, "income_coverage": income_coverage,
        "total_min_payments": total_min_payments, "interest_share": interest_share,
        "wavg_apr": wavg_apr,
        "payoff_months": (None if (not has_payoff or payoff_never) else payoff_months),
        "payoff_interest": payoff_interest, "payoff_never": payoff_never,
        "has_payoff_plan": has_payoff,
        "available_credit": available_credit, "utilization": utilization,
        "card_min_payments": card_min_payments,
        "ltv": ltv, "runway_months": runway_months, "cap_rate": cap_rate,
        "largest_holding": largest_holding, "largest_debt": largest_debt,
        "stalest": stalest, "next_income": next_income, "next_payment": next_payment,
    }


# The catalog of selectable group statistics. Each entry is a stat the user can
# choose to show for a group (filtered to the ones its composition supports via
# `needs`). `key` indexes the group_statistics() dict; `kind` tells the UI how to
# format the value (see group_manager._stat_value). Order here is display order.
GROUP_STATS_CATALOG = [
    ("total_value", "Total value", "Balance sheet", "money",
     lambda s: s["n_assets"] > 0),
    ("total_debt", "Total debt", "Balance sheet", "money",
     lambda s: s["n_debts"] > 0),
    ("equity", "Equity", "Balance sheet", "money",
     lambda s: s["n_assets"] or s["n_debts"]),
    ("equity_pct", "Equity %", "Balance sheet", "pct",
     lambda s: s["total_value"] > 0),
    ("liquid_value", "Liquid value", "Balance sheet", "money",
     lambda s: s["n_assets"] > 0),
    ("cost_basis", "Cost basis", "Investments", "money",
     lambda s: s["n_basis"] > 0),
    ("unrealized_gain", "Unrealized gain/loss", "Investments", "money",
     lambda s: s["n_basis"] > 0),
    ("unrealized_gain_pct", "Unrealized gain %", "Investments", "pct",
     lambda s: s["n_basis"] > 0),
    ("invested_value", "Invested value", "Investments", "money",
     lambda s: s["n_positions"] > 0),
    ("n_positions", "# Positions", "Investments", "int",
     lambda s: s["n_positions"] > 0),
    ("monthly_outflow", "Monthly outflow", "Cash flow", "money",
     lambda s: s["n_expenses"] or s["n_debts"]),
    ("annual_outflow", "Annual outflow", "Cash flow", "money",
     lambda s: s["n_expenses"] or s["n_debts"]),
    ("expenses_monthly", "Monthly expenses", "Cash flow", "money",
     lambda s: s["n_expenses"] > 0),
    ("debt_payments_monthly", "Monthly debt payments", "Cash flow", "money",
     lambda s: s["n_debts"] > 0),
    ("monthly_income", "Monthly income", "Cash flow", "money",
     lambda s: s["n_income"] > 0),
    ("annual_income", "Annual income", "Cash flow", "money",
     lambda s: s["n_income"] > 0),
    ("net_monthly", "Net monthly cash flow", "Cash flow", "money",
     lambda s: s["n_income"] and (s["n_expenses"] or s["n_debts"])),
    ("net_annual", "Net annual cash flow", "Cash flow", "money",
     lambda s: s["n_income"] and (s["n_expenses"] or s["n_debts"])),
    ("savings_rate", "Savings rate", "Cash flow", "pct",
     lambda s: s["annual_income"] > 0),
    ("income_coverage", "Income coverage", "Cash flow", "ratio",
     lambda s: s["n_income"] and s["monthly_outflow"] > 0),
    ("monthly_interest", "Monthly interest", "Debt", "money",
     lambda s: s["n_debts"] > 0),
    ("annual_interest", "Annual interest", "Debt", "money",
     lambda s: s["n_debts"] > 0),
    ("wavg_apr", "Weighted-avg APR", "Debt", "pct",
     lambda s: s["total_debt"] > 0),
    ("total_min_payments", "Minimum payments", "Debt", "money",
     lambda s: s["n_debts"] > 0),
    ("interest_share", "Interest share of payment", "Debt", "pct",
     lambda s: s["total_min_payments"] > 0),
    ("payoff_months", "Payoff time", "Debt", "months",
     lambda s: s["has_payoff_plan"]),
    ("payoff_interest", "Interest until payoff", "Debt", "money",
     lambda s: s["has_payoff_plan"] and not s["payoff_never"]),
    ("available_credit", "Available credit", "Credit cards", "money",
     lambda s: s["n_cards"] > 0),
    ("utilization", "Utilization", "Credit cards", "pct",
     lambda s: s["n_cards"] > 0),
    ("card_min_payments", "Card minimum payments", "Credit cards", "money",
     lambda s: s["n_cards"] > 0),
    ("ltv", "Loan-to-value (LTV)", "Ratios", "pct",
     lambda s: s["total_value"] > 0 and s["n_debts"] > 0),
    ("runway_months", "Runway (liquid ÷ burn)", "Ratios", "months_plain",
     lambda s: s["monthly_outflow"] > 0 and s["liquid_value"] > 0),
    ("cap_rate", "Yield on value", "Ratios", "pct",
     lambda s: s["total_value"] > 0 and s["n_income"] > 0),
    ("largest_holding", "Largest holding", "Composition", "labelmoney",
     lambda s: s["n_assets"] > 0),
    ("largest_debt", "Largest debt", "Composition", "labelmoney",
     lambda s: s["n_debts"] > 0),
    ("stalest", "Most stale record", "Composition", "datename",
     lambda s: s["stalest"] is not None),
    ("next_income", "Next income", "Schedule", "date_amt",
     lambda s: s["next_income"] is not None),
    ("next_payment", "Next payment due", "Schedule", "date_amt",
     lambda s: s["next_payment"] is not None),
]


def next_income_event(income: pd.DataFrame,
                      today: date) -> tuple[date, float, str] | None:
    """(date, amount, source) of the soonest scheduled income arrival on or after
    `today` (searching a year ahead), or None when no stream has both a schedule
    and a per-payment amount."""
    if income.empty:
        return None
    best = None
    y, m = today.year, today.month
    for _ in range(13):
        for _, row in income.iterrows():
            amt = _f(row.get("pay_amount"))
            if amt <= 0:
                continue
            sched = recurrence.from_row(row)
            for day in recurrence.occurrences_in_month(sched, y, m):
                d = today.replace(year=y, month=m, day=day)
                if d < today:
                    continue
                if best is None or d < best[0]:
                    best = (d, amt, str(row.get("source") or "Income"))
        if best is not None:
            return best
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return None


# --- debt prioritization (avalanche) ---------------------------------------

def debt_payoff_ranking(debts: pd.DataFrame, fed_rate: float) -> pd.DataFrame:
    """Rank debts highest-APR-first (the avalanche order minimizes interest
    paid). `spread` is APR over the risk-free fed funds rate — a debt with a
    large positive spread is the most expensive money you hold and the most
    valuable to retire."""
    needed = {"name", "balance", "apr"}
    if debts.empty or not needed.issubset(debts.columns):
        return debts.iloc[0:0]
    out = debts[["name", "balance", "apr"]].copy()
    out["spread_over_fed"] = out["apr"] - fed_rate
    return out.sort_values("apr", ascending=False).reset_index(drop=True)


# --- forward-looking (uses constants) --------------------------------------

def projected_eoy_net_worth(assets: pd.DataFrame, debts: pd.DataFrame,
                            income: pd.DataFrame, expenses: pd.DataFrame,
                            months_remaining: int) -> float:
    """Current net worth, plus income still expected this year, minus the
    recurring burn projected over the months left. `months_remaining` is
    passed in (not computed from today's date) so this stays a pure function."""
    nw = net_worth(assets, debts)
    _, expected, _ = income_totals(income)
    remaining_burn = monthly_recurring_expenses(expenses) * months_remaining
    return nw + expected - remaining_burn
