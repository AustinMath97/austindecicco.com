"""
db.py — the data layer for the personal finance dashboard.

Everything that touches storage lives here. The rest of the app (stats.py,
dashboard.py) only ever calls these functions, never sqlite3 directly.

Schema philosophy: no artificial CHECK constraints on category columns — the
project is expanding and every new asset class or debt type should slot in
without a migration. Real constraints (NOT NULL, FK) are kept because they
protect data integrity, not because they limit future growth.

Row identity: ``id`` values are stable. Single-row edits and deletes go
straight to SQL (UPDATE/DELETE … WHERE id = ?) and adds use ``insert_row``,
so an autoincrement id, once assigned, refers to the same record for the life
of the database. Only ``save_df`` (used for bulk seeding) rewrites a table
wholesale and therefore renumbers — it is not used on the interactive paths.
"""

import json
import math
import os
import sqlite3
from contextlib import contextmanager
from datetime import date, datetime, time, timedelta, timezone
from pathlib import Path

import pandas as pd

import recurrence
import utils

# The database — and the .bak safety copies made beside it — live in a dedicated
# "databases" folder kept separate from the code. It resolves to one level above
# this module: the project root in the dev tree (Wallet/databases/) and the
# package root in the packaged download (Wallet/databases/, next to "Start
# Wallet.bat"). Derived from __file__, so it's independent of the working
# directory, and created automatically on first use. Set WALLET_DB_DIR to
# override the location (e.g. to point at a shared/synced folder).
DB_DIR = Path(os.environ.get("WALLET_DB_DIR")
              or Path(__file__).resolve().parent.parent / "databases")
DB_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = str(DB_DIR / "finance.db")

EDITABLE_TABLES = {"assets", "debts", "income", "expenses"}


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


@contextmanager
def _session():
    """A connection that commits on success, rolls back on error, and always
    closes. Use for every read or write so connections never leak."""
    conn = get_conn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """Create tables (if absent) then run forward migrations. Safe to call on
    every app start — all operations are idempotent."""
    with _session() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS assets (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                name           TEXT    NOT NULL,
                -- An asset is described by account_type (the tax/custody wrapper —
                -- NULL = held directly) and asset_type (what the holding is); the
                -- asset_type's family (see utils.asset_family) is the coarse kind.
                -- These replaced the old conflated subtype/asset_category columns,
                -- which _migrate drops after backfilling these from them.
                account_type   TEXT,
                asset_type     TEXT,
                ticker         TEXT,
                shares         REAL,
                value          REAL    NOT NULL DEFAULT 0,
                liquid         INTEGER NOT NULL DEFAULT 0,
                last_price     REAL,
                updated_at     TEXT,
                institution    TEXT,
                cost_basis     REAL,
                mileage        INTEGER,
                vin            TEXT,
                street         TEXT,
                city           TEXT,
                state          TEXT,
                zip_code       TEXT,
                beds           REAL,
                baths          REAL,
                sqft           INTEGER,
                year_built     INTEGER,
                apy            REAL,
                -- Interest payout schedule (same recurrence model as income; see
                -- recurrence.py): when APY interest is paid out / posts.
                interest_schedule_type TEXT,
                interest_weekday       INTEGER,
                interest_week_ordinal  INTEGER,
                interest_anchor_date   TEXT,
                interest_pay_days      TEXT,
                interest_months        TEXT,
                ownership_pct  REAL,
                maturity_date  TEXT,
                trim           TEXT,
                condition      TEXT,
                collection_date TEXT,
                collection_prob REAL,
                make           TEXT,
                model          TEXT,
                model_year     INTEGER
            );

            CREATE TABLE IF NOT EXISTS debts (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                name             TEXT    NOT NULL,
                balance          REAL    NOT NULL DEFAULT 0,
                apr              REAL    NOT NULL DEFAULT 0,
                -- min_payment is the fixed/floor dollar amount; for a credit card the
                -- minimum can instead be a percent of balance ('percent'), a percent
                -- with a dollar floor ('percent_floor'), a percent plus the period's
                -- interest ('percent_interest'), or that with a floor
                -- ('percent_interest_floor'). The floor variants use min_payment as the
                -- floor; min_payment_pct holds the percent. NULL/'fixed' = flat amount.
                min_payment      REAL,
                min_payment_type TEXT,
                min_payment_pct  REAL,
                credit_limit     REAL,    -- revolving cards: the card's limit
                -- The statement closes on a restricted monthly schedule — either a
                -- fixed day-of-month (statement_day) OR an ordinal weekday that drifts
                -- month to month (statement_week_ordinal + statement_weekday, e.g. the
                -- last Friday). The balance when it closes sets the minimum payment,
                -- paid on due_day. All NULL → the minimum uses the due-day balance.
                statement_day        INTEGER,
                statement_weekday    INTEGER,   -- 0=Mon..6=Sun (ordinal-weekday mode)
                statement_week_ordinal INTEGER, -- 1..4 or -1 (last)
                type             TEXT,
                lender           TEXT,
                original_balance REAL,
                months_remaining INTEGER,
                due_day          INTEGER,
                updated_at       TEXT
            );

            CREATE TABLE IF NOT EXISTS income (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                source        TEXT    NOT NULL,
                amount        REAL    NOT NULL DEFAULT 0,  -- full-year expected total
                received_ytd  REAL    NOT NULL DEFAULT 0,  -- of `amount`, received so far this year
                type          TEXT,
                tax_class     TEXT,    -- tax treatment for the estimate (see taxes.py)
                frequency     TEXT,
                pay_day       TEXT,    -- human-readable summary ("Every Wednesday")
                pay_days      TEXT,    -- day-of-month ints for month-day schedules ("1,15")
                pay_amount    REAL,    -- per-occurrence amount for calendar display
                schedule_type TEXT,    -- recurrence kind (see recurrence.py)
                weekday       INTEGER, -- 0=Mon..6=Sun, for weekly / monthly_weekday
                week_ordinal  INTEGER, -- 1..4 or -1 (last), for monthly_weekday
                anchor_date   TEXT,    -- ISO date: biweekly phase / annual / one_time
                months        TEXT,    -- comma month ints for quarterly ("3,6,9,12")
                auto_deposit   INTEGER NOT NULL DEFAULT 0,  -- mirror of expenses.auto_draft
                deposit_target TEXT,                         -- account the income lands in
                updated_at    TEXT
            );

            -- Expenses recur on a full recurrence schedule (see recurrence.py),
            -- the same model income uses — weekly / biweekly / semi-monthly /
            -- monthly / nth-weekday / quarterly / annual / one-time. `amount` is
            -- the per-occurrence draft; the schedule columns (schedule_type,
            -- weekday, week_ordinal, anchor_date, pay_days, months) place each
            -- draft on its real calendar days so the Accounts auto-draft forecast
            -- is accurate for any cadence. `frequency` (coarse label) and
            -- `pay_day` (human summary) are derived from the schedule for display.
            -- An expense can be flagged tax-deductible, which adds the columns
            -- below (deductible portion split YTD vs expected, the deduction
            -- category, which return(s) it counts on, and notes).
            CREATE TABLE IF NOT EXISTS expenses (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                category            TEXT    NOT NULL,
                amount              REAL    NOT NULL DEFAULT 0,
                frequency           TEXT,                  -- coarse cadence label (display)
                subcategory         TEXT,
                auto_draft          INTEGER NOT NULL DEFAULT 0,
                draft_source        TEXT,
                schedule_type       TEXT,                  -- recurrence kind (see recurrence.py)
                weekday             INTEGER,               -- 0=Mon..6=Sun
                week_ordinal        INTEGER,               -- 1..4 or -1 (last)
                anchor_date         TEXT,                  -- ISO: biweekly phase / annual / one_time
                pay_days            TEXT,                  -- comma day-of-month ints ("1,15")
                months              TEXT,                  -- comma month ints for quarterly
                pay_day             TEXT,                  -- human schedule summary
                -- The debt this expense IS the payment for (set when the expense
                -- imports a debt's payment, or matched in the group manager), so a
                -- group doesn't double-count the debt's cost and this expense.
                pays_debt_id        INTEGER,
                -- The credit card this expense is FORCED to mirror (a "credit
                -- card minimum payment" expense): amount, schedule, and name
                -- re-derive from the card's debt record on every card edit and
                -- once a day for statement closes (sync_cc_min_expenses).
                -- NULL for every other expense.
                cc_min_debt_id      INTEGER,
                -- Amount mode: 'set' (a fixed per-occurrence amount in `amount`,
                -- the default) or 'variable' (per-period amounts recorded over the
                -- last variable_years years in variable_amounts JSON, projected
                -- forward by variable_method = 'average' | 'by_period' | 'seasonal').
                amount_mode         TEXT,
                variable_method     TEXT,
                variable_amounts    TEXT,                  -- JSON {ISO date: amount}
                variable_years      INTEGER,               -- history length (NULL → 1)
                deductible          INTEGER NOT NULL DEFAULT 0,
                deduction_category  TEXT,
                deductible_ytd      REAL    NOT NULL DEFAULT 0,
                deductible_expected REAL    NOT NULL DEFAULT 0,
                deduct_federal      INTEGER NOT NULL DEFAULT 1,
                deduct_state        INTEGER NOT NULL DEFAULT 1,
                deduction_notes     TEXT,
                updated_at          TEXT
            );

            CREATE TABLE IF NOT EXISTS constants (
                key        TEXT PRIMARY KEY,
                value      REAL NOT NULL DEFAULT 0,
                updated_at TEXT
            );

            -- net_worth is NULL for a captured snapshot (take_snapshot): its net
            -- worth derives from the item rows below. It is SET for a hand-added
            -- / imported snapshot (add_manual_snapshot) that records a net-worth
            -- total directly without a full asset/debt breakdown — which also
            -- marks the snapshot as one where absent asset/debt items mean
            -- "unknown" (reported as NULL), not zero.
            CREATE TABLE IF NOT EXISTS snapshots (
                id        INTEGER PRIMARY KEY AUTOINCREMENT,
                taken_at  TEXT NOT NULL,
                label     TEXT,
                net_worth REAL
            );

            -- Asset items also carry the holding's account_type / asset_type /
            -- institution at capture time, so per-account history (the Investment
            -- Accounts page) can attribute values without guessing from names
            -- (which collide — e.g. "VTI" held in two accounts).
            CREATE TABLE IF NOT EXISTS snapshot_items (
                snapshot_id    INTEGER NOT NULL,
                category       TEXT    NOT NULL,
                name           TEXT    NOT NULL,
                value          REAL    NOT NULL,
                institution    TEXT,
                account_type   TEXT,
                asset_type     TEXT,
                FOREIGN KEY (snapshot_id) REFERENCES snapshots(id) ON DELETE CASCADE
            );

            -- LEGACY edge-links (superseded by link_groups below). Kept only so a
            -- one-time migration in init_db() can fold any existing edges into
            -- groups; new code never writes here.
            CREATE TABLE IF NOT EXISTS links (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                a_table    TEXT    NOT NULL,
                a_id       INTEGER NOT NULL,
                b_table    TEXT    NOT NULL,
                b_id       INTEGER NOT NULL,
                kind       TEXT,
                created_at TEXT
            );

            -- Named groups of related rows. A row may belong to several groups;
            -- every pair of rows within a group is implicitly linked (the group is
            -- a clique). Two rows are "linked" iff they share at least one group, so
            -- one row can bridge groups that are not themselves linked (e.g. a
            -- property in both a "mortgage" group and a "household bills" group,
            -- without the mortgage and the utilities becoming linked).
            CREATE TABLE IF NOT EXISTS link_groups (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                name       TEXT,
                created_at TEXT
            );
            CREATE TABLE IF NOT EXISTS link_group_members (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                group_id   INTEGER NOT NULL,
                rec_table  TEXT    NOT NULL,
                rec_id     INTEGER NOT NULL,
                role       TEXT,
                -- Whether this member feeds the group's statistics (NULL/1 = yes,
                -- 0 = the user omitted it from this group's stats).
                in_stats   INTEGER,
                created_at TEXT,
                UNIQUE (group_id, rec_table, rec_id)
            );

            -- "Are these the same payment?" prompts that the user answered NO: a
            -- (debt, expense) pair whose amounts matched but which they said aren't
            -- related. Suppresses the re-prompt until one of the two records is
            -- updated (its updated_at moves past dismissed_at).
            CREATE TABLE IF NOT EXISTS payment_match_dismissed (
                debt_id      INTEGER NOT NULL,
                expense_id   INTEGER NOT NULL,
                dismissed_at TEXT    NOT NULL,
                UNIQUE (debt_id, expense_id)
            );

            -- Per-record data-management settings (Data Management page): a custom
            -- staleness window (NULL = default) and whether the record is on the
            -- launch update-prompt watch list.
            CREATE TABLE IF NOT EXISTS record_settings (
                rec_table  TEXT    NOT NULL,
                rec_id     INTEGER NOT NULL,
                stale_days INTEGER,
                watch      INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (rec_table, rec_id)
            );

            -- Small app-wide key/value settings store (text values, often JSON).
            -- Used for things with no natural home of their own — e.g. the global
            -- default set of group statistics every group shows unless it overrides.
            CREATE TABLE IF NOT EXISTS app_settings (
                key        TEXT PRIMARY KEY,
                value      TEXT,
                updated_at TEXT
            );
        """)

        for key in ("fed_funds_rate", "fed_funds_target_lower",
                    "fed_funds_target_upper", "inflation_rate"):
            conn.execute(
                "INSERT OR IGNORE INTO constants (key, value, updated_at) VALUES (?, 0.0, ?)",
                (key, _now()),
            )

    _migrate()
    prune_empty_groups()   # sweep up any group created but never populated


def _columns(conn, table):
    return [r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()]


def _migrate():
    """Forward migrations — each step is guarded so it runs only once. The whole
    pass runs inside ONE explicit transaction: sqlite3's executescript would
    auto-commit each DDL statement, so a crash mid-table-rebuild could otherwise
    strand the data in the renamed backup table with the run-once guard no longer
    matching (the new table has no CHECK clause). BEGIN + individual statements
    keep rename/create/copy/drop atomic — interrupted means rolled back, retried
    whole next launch."""
    with _session() as conn:
        conn.execute("BEGIN")

        # Recovery for DBs touched by the old auto-committing version of the two
        # rebuilds below: a leftover backup table means the copy/drop never ran.
        # Finish the copy if the new table is still empty, then drop the backup.
        for table in ("assets", "expenses"):
            leftover = f"_{table}_v1"
            row = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                (leftover,)).fetchone()
            if not row:
                continue
            if conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0] == 0:
                old_cols = set(_columns(conn, leftover))
                shared = [c for c in _columns(conn, table) if c in old_cols]
                collist = ", ".join(shared)
                where = (" WHERE frequency IN ('monthly','annual')"
                         if table == "expenses" else "")
                conn.execute(
                    f"INSERT INTO {table} ({collist}) "
                    f"SELECT {collist} FROM {leftover}{where}")
            conn.execute(f"DROP TABLE {leftover}")

        # --- assets: drop old CHECK constraint on subtype -------------------
        row = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='assets'"
        ).fetchone()
        if row and "CHECK (subtype IN" in row[0]:
            old_cols = _columns(conn, "assets")
            conn.execute("ALTER TABLE assets RENAME TO _assets_v1")
            conn.execute("""
                CREATE TABLE assets (
                    id             INTEGER PRIMARY KEY AUTOINCREMENT,
                    name           TEXT    NOT NULL,
                    subtype        TEXT    NOT NULL,
                    ticker         TEXT,
                    shares         REAL,
                    value          REAL    NOT NULL DEFAULT 0,
                    liquid         INTEGER NOT NULL DEFAULT 0,
                    last_price     REAL,
                    updated_at     TEXT,
                    institution    TEXT,
                    asset_category TEXT,
                    cost_basis     REAL
                )
            """)
            # Copy every column the old table and new table share, so nothing
            # populated before this migration is lost.
            shared = [c for c in _columns(conn, "assets") if c in old_cols]
            collist = ", ".join(shared)
            conn.execute(
                f"INSERT INTO assets ({collist}) SELECT {collist} FROM _assets_v1"
            )
            conn.execute("DROP TABLE _assets_v1")

        # --- expenses: remove one_time, add payment columns -----------------
        row = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='expenses'"
        ).fetchone()
        if row and "'one_time'" in row[0]:
            old_cols = _columns(conn, "expenses")
            conn.execute("ALTER TABLE expenses RENAME TO _expenses_v1")
            conn.execute("""
                CREATE TABLE expenses (
                    id           INTEGER PRIMARY KEY AUTOINCREMENT,
                    category     TEXT    NOT NULL,
                    amount       REAL    NOT NULL DEFAULT 0,
                    frequency    TEXT    NOT NULL DEFAULT 'monthly'
                                 CHECK (frequency IN ('monthly','annual')),
                    subcategory  TEXT,
                    auto_draft   INTEGER NOT NULL DEFAULT 0,
                    draft_source TEXT,
                    due_day      INTEGER,
                    due_month    INTEGER
                )
            """)
            # Preserve every shared column (incl. auto_draft/draft_source/due_day
            # if the old table already had them) — not just the original five.
            shared = [c for c in _columns(conn, "expenses") if c in old_cols]
            collist = ", ".join(shared)
            conn.execute(
                f"INSERT INTO expenses ({collist}) "
                f"SELECT {collist} FROM _expenses_v1 "
                f"WHERE frequency IN ('monthly','annual')"
            )
            conn.execute("DROP TABLE _expenses_v1")

        # --- add new columns to existing tables (idempotent) ----------------
        # Each ALTER either succeeds (column was absent) or fails with a
        # "duplicate column name" error, which we treat as already-applied.
        # Any other OperationalError is a real problem and re-raised.
        additions = [
            ("assets",   "institution",     "TEXT"),
            ("assets",   "cost_basis",      "REAL"),
            ("assets",   "mileage",         "INTEGER"),
            ("assets",   "vin",             "TEXT"),
            ("assets",   "street",          "TEXT"),
            ("assets",   "city",            "TEXT"),
            ("assets",   "state",           "TEXT"),
            ("assets",   "zip_code",        "TEXT"),
            ("assets",   "beds",            "REAL"),
            ("assets",   "baths",           "REAL"),
            ("assets",   "sqft",            "INTEGER"),
            ("assets",   "year_built",      "INTEGER"),
            ("assets",   "apy",             "REAL"),
            ("assets",   "interest_schedule_type", "TEXT"),
            ("assets",   "interest_weekday",       "INTEGER"),
            ("assets",   "interest_week_ordinal",  "INTEGER"),
            ("assets",   "interest_anchor_date",   "TEXT"),
            ("assets",   "interest_pay_days",      "TEXT"),
            ("assets",   "interest_months",        "TEXT"),
            ("assets",   "ownership_pct",   "REAL"),
            ("assets",   "maturity_date",   "TEXT"),
            ("assets",   "trim",            "TEXT"),
            ("assets",   "condition",       "TEXT"),
            ("assets",   "collection_date", "TEXT"),
            ("assets",   "collection_prob", "REAL"),
            ("assets",   "make",            "TEXT"),
            ("assets",   "model",           "TEXT"),
            ("assets",   "model_year",      "INTEGER"),
            ("debts",    "updated_at",      "TEXT"),
            ("income",   "updated_at",      "TEXT"),
            ("expenses", "updated_at",      "TEXT"),
            ("debts",    "lender",          "TEXT"),
            ("debts",    "original_balance","REAL"),
            ("debts",    "months_remaining","INTEGER"),
            ("debts",    "due_day",         "INTEGER"),
            ("debts",    "min_payment_type","TEXT"),
            ("debts",    "min_payment_pct", "REAL"),
            ("debts",    "credit_limit",    "REAL"),
            ("debts",    "statement_day",   "INTEGER"),
            ("debts",    "statement_weekday",      "INTEGER"),
            ("debts",    "statement_week_ordinal", "INTEGER"),
            # Margin loans: a formula over the economic variables (see utils.
            # safe_eval_formula) re-derives `apr` live via refresh_margin_aprs;
            # margin_account is the investment-account label it's borrowed against
            # (a plain datapoint — investment accounts are a derived grouping, not
            # records, so this is a string, not a link).
            ("debts",    "apr_formula",     "TEXT"),
            ("debts",    "margin_account",  "TEXT"),
            # Debt snapshot items capture the loan's borrowed-against account so
            # the Investments chart can net each snapshot's margin AS OF that
            # time (NULL on rows captured before this column, or non-margin debts).
            ("snapshot_items", "margin_account", "TEXT"),
            ("income",   "frequency",       "TEXT"),
            ("income",   "pay_day",         "TEXT"),
            ("income",   "pay_days",        "TEXT"),
            ("income",   "pay_amount",      "REAL"),
            ("income",   "schedule_type",   "TEXT"),
            ("income",   "weekday",         "INTEGER"),
            ("income",   "week_ordinal",    "INTEGER"),
            ("income",   "anchor_date",     "TEXT"),
            ("income",   "months",          "TEXT"),
            ("income",   "received_ytd",    "REAL"),
            ("income",   "tax_class",       "TEXT"),
            ("income",   "auto_deposit",    "INTEGER"),
            ("income",   "deposit_target",  "TEXT"),
            ("expenses", "subcategory",     "TEXT"),
            ("expenses", "auto_draft",      "INTEGER"),
            ("expenses", "draft_source",    "TEXT"),
            # due_day/due_month are intentionally NOT here: they're legacy columns
            # the schedule-rebuild below reads-then-drops, and re-adding them each
            # launch would churn the table. Old DBs already have them; the backfill
            # falls back to `frequency` alone when they're absent.
            ("expenses", "schedule_type",   "TEXT"),
            ("expenses", "weekday",         "INTEGER"),
            ("expenses", "week_ordinal",    "INTEGER"),
            ("expenses", "anchor_date",     "TEXT"),
            ("expenses", "pay_days",        "TEXT"),
            ("expenses", "months",          "TEXT"),
            ("expenses", "pay_day",         "TEXT"),
            ("expenses", "amount_mode",     "TEXT"),
            ("expenses", "variable_method", "TEXT"),
            ("expenses", "variable_amounts","TEXT"),
            ("expenses", "variable_years",  "INTEGER"),
            ("expenses", "pays_debt_id",    "INTEGER"),
            ("expenses", "cc_min_debt_id",  "INTEGER"),
            ("link_group_members", "in_stats", "INTEGER"),
            # Per-group override of which statistics it shows: JSON list of stat
            # keys, or NULL to follow the global default (app_settings).
            ("link_groups", "stat_keys", "TEXT"),
            ("expenses", "deductible",          "INTEGER"),
            ("expenses", "deduction_category",  "TEXT"),
            ("expenses", "deductible_ytd",      "REAL"),
            ("expenses", "deductible_expected", "REAL"),
            ("expenses", "deduct_federal",      "INTEGER"),
            ("expenses", "deduct_state",        "INTEGER"),
            ("expenses", "deduction_notes",     "TEXT"),
            ("snapshot_items", "institution",    "TEXT"),
            ("snapshots",      "net_worth",      "REAL"),
            ("assets",         "account_type",   "TEXT"),
            ("assets",         "asset_type",     "TEXT"),
            ("snapshot_items", "account_type",   "TEXT"),
            ("snapshot_items", "asset_type",     "TEXT"),
        ]
        for table, col, coltype in additions:
            try:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} {coltype}")
            except sqlite3.OperationalError as exc:
                if "duplicate column name" not in str(exc).lower():
                    raise

        # Expenses moved from a 2-value frequency (monthly/annual) + due_day/
        # due_month to the full recurrence schedule income already uses. Backfill
        # the schedule columns from the old fields for any row that doesn't have
        # one yet (guard = idempotent), THEN rebuild the table to drop the old
        # CHECK constraint and the superseded due_day/due_month columns.
        expense_cols = {r[1] for r in conn.execute("PRAGMA table_info(expenses)")}
        if "schedule_type" in expense_cols:
            # Read due_day/due_month only if they still exist (a pre-rebuild DB);
            # a very old DB without them still gets monthly/annual from frequency.
            _has_due = "due_day" in expense_cols and "due_month" in expense_cols
            _sel = ("id, frequency, due_day, due_month" if _has_due
                    else "id, frequency, NULL, NULL")
            for r in conn.execute(
                    f"SELECT {_sel} FROM expenses "
                    "WHERE schedule_type IS NULL").fetchall():
                eid, freq, due_day, due_month = r
                if str(freq or "monthly").lower() == "annual":
                    stype = recurrence.ANNUAL
                    pay_days = None
                    # annual ignores the year but gates year >= anchor.year, so use
                    # a long-past year and the saved month/day. No day → no anchor
                    # (never placed on the calendar, exactly like the old behavior).
                    anchor = (f"2000-{int(due_month):02d}-{int(due_day):02d}"
                              if due_day and due_month else None)
                else:
                    stype = recurrence.MONTHLY
                    pay_days = str(int(due_day)) if due_day else None
                    anchor = None
                sched = {"type": stype, "weekday": None, "ordinal": None,
                         "anchor": anchor, "month_days": pay_days, "months": None}
                # Don't touch `frequency` yet: the OLD CHECK still rejects anything
                # but 'monthly'/'annual'. It's recapitalized after the rebuild.
                conn.execute(
                    "UPDATE expenses SET schedule_type = ?, pay_days = ?, "
                    "anchor_date = ?, pay_day = ? WHERE id = ?",
                    (stype, pay_days, anchor, recurrence.describe(sched) or None, eid))

        # Rebuild to the schedule-based schema: drop the frequency CHECK and the
        # now-unused due_day/due_month. Guarded on the old CHECK still being present
        # (a no-op on a fresh or already-migrated DB). Inside the migration's BEGIN,
        # so an interrupted rebuild rolls back rather than stranding data.
        erow = conn.execute(
            "SELECT sql FROM sqlite_master WHERE type='table' AND name='expenses'"
        ).fetchone()
        if erow and "CHECK (frequency IN" in erow[0]:
            old_cols = _columns(conn, "expenses")
            conn.execute("ALTER TABLE expenses RENAME TO _expenses_v2")
            conn.execute("""
                CREATE TABLE expenses (
                    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                    category            TEXT    NOT NULL,
                    amount              REAL    NOT NULL DEFAULT 0,
                    frequency           TEXT,
                    subcategory         TEXT,
                    auto_draft          INTEGER NOT NULL DEFAULT 0,
                    draft_source        TEXT,
                    schedule_type       TEXT,
                    weekday             INTEGER,
                    week_ordinal        INTEGER,
                    anchor_date         TEXT,
                    pay_days            TEXT,
                    months              TEXT,
                    pay_day             TEXT,
                    pays_debt_id        INTEGER,
                    cc_min_debt_id      INTEGER,
                    amount_mode         TEXT,
                    variable_method     TEXT,
                    variable_amounts    TEXT,
                    variable_years      INTEGER,
                    deductible          INTEGER NOT NULL DEFAULT 0,
                    deduction_category  TEXT,
                    deductible_ytd      REAL    NOT NULL DEFAULT 0,
                    deductible_expected REAL    NOT NULL DEFAULT 0,
                    deduct_federal      INTEGER NOT NULL DEFAULT 1,
                    deduct_state        INTEGER NOT NULL DEFAULT 1,
                    deduction_notes     TEXT,
                    updated_at          TEXT
                )
            """)
            shared = [c for c in _columns(conn, "expenses") if c in old_cols]
            collist = ", ".join(shared)
            conn.execute(
                f"INSERT INTO expenses ({collist}) SELECT {collist} FROM _expenses_v2")
            conn.execute("DROP TABLE _expenses_v2")
            # Now the CHECK is gone: recapitalize frequency to the coarse display
            # label that matches each row's schedule (e.g. 'monthly' -> 'Monthly',
            # and any richer cadence backfilled above gets its proper label).
            for stype, label in recurrence.FREQUENCY_LABEL.items():
                conn.execute("UPDATE expenses SET frequency = ? WHERE schedule_type = ?",
                             (label, stype))

        # Split the old conflated (subtype, asset_category) into the new
        # account_type / asset_type for any row that doesn't have them yet, THEN
        # drop the deprecated columns. Both steps are guarded on the legacy
        # columns still existing, so the whole block is a no-op once a DB has been
        # migrated (or was created fresh on the new schema). Old snapshot_items
        # predating account capture had NULL subtype/asset_category and stay
        # untagged. This is the one place the conflated category is split apart.
        for tbl in ("assets", "snapshot_items"):
            legacy = [c for c in ("subtype", "asset_category") if c in _columns(conn, tbl)]
            if not legacy:
                continue                      # already migrated / fresh schema
            where = "asset_type IS NULL"
            if tbl == "snapshot_items":
                where += " AND category = 'asset'"
            sel = ", ".join(legacy)
            for r in conn.execute(
                    f"SELECT rowid, {sel} FROM {tbl} WHERE {where}").fetchall():
                vals = dict(zip(legacy, r[1:]))
                sub, cat = vals.get("subtype"), vals.get("asset_category")
                if not sub and not cat:
                    continue
                acct, atype = utils.legacy_to_new(sub, cat)
                conn.execute(
                    f"UPDATE {tbl} SET account_type = ?, asset_type = ? WHERE rowid = ?",
                    (acct, atype, r[0]))
            # Drop the deprecated conflated columns now their meaning is carried by
            # account_type/asset_type. SQLite ≥3.35 DROP COLUMN keeps the
            # snapshot_items FK / cascade intact (a table rebuild would have to
            # recreate them).
            for col in legacy:
                conn.execute(f"ALTER TABLE {tbl} DROP COLUMN {col}")

        # Income used to split a stream into separate 'ytd' / 'expected' rows; the
        # model is now one row per stream with `amount` = full-year total and
        # `received_ytd` the portion already in hand. On a legacy DB (the `kind`
        # column still exists), seed received_ytd once from the old kind: a 'ytd'
        # row's amount was money already received; an 'expected' row's was not.
        income_cols = {r[1] for r in conn.execute("PRAGMA table_info(income)")}
        if "kind" in income_cols:
            conn.execute(
                "UPDATE income SET received_ytd = "
                "CASE WHEN kind = 'ytd' THEN amount ELSE 0 END "
                "WHERE received_ytd IS NULL"
            )
            # Merge each stream's old 'ytd' + 'expected' row pair into ONE row under
            # the new model: full-year amount = received + still-expected. The
            # 'expected' row is kept (it carries the forward-looking fields) and the
            # 'ytd' row folds into its received_ytd. Only unambiguous pairs — a
            # source with exactly one row of each kind — are merged; anything else
            # is left for the user. Idempotent: merged sources no longer pair up.
            pairs = conn.execute(
                "SELECT y.id, COALESCE(y.amount, 0), e.id FROM income y "
                "JOIN income e ON e.source = y.source "
                "AND y.kind = 'ytd' AND e.kind = 'expected' "
                "WHERE (SELECT COUNT(*) FROM income i2 "
                "       WHERE i2.source = y.source AND i2.kind = 'ytd') = 1 "
                "  AND (SELECT COUNT(*) FROM income i3 "
                "       WHERE i3.source = y.source AND i3.kind = 'expected') = 1"
            ).fetchall()
            for ytd_id, ytd_amt, exp_id in pairs:
                conn.execute(
                    "UPDATE income SET amount = COALESCE(amount, 0) + ?, "
                    "received_ytd = ? WHERE id = ?", (ytd_amt, ytd_amt, exp_id))
                # Re-point the dropped row's group memberships at the kept row
                # (skipping groups the kept row is already in), then clean up.
                conn.execute(
                    "UPDATE link_group_members SET rec_id = ? "
                    "WHERE rec_table = 'income' AND rec_id = ? AND group_id NOT IN "
                    "(SELECT group_id FROM link_group_members "
                    " WHERE rec_table = 'income' AND rec_id = ?)",
                    (exp_id, ytd_id, exp_id))
                conn.execute(
                    "DELETE FROM link_group_members "
                    "WHERE rec_table = 'income' AND rec_id = ?", (ytd_id,))
                conn.execute(
                    "DELETE FROM record_settings "
                    "WHERE rec_table = 'income' AND rec_id = ?", (ytd_id,))
                conn.execute("DELETE FROM income WHERE id = ?", (ytd_id,))

        # ALTER TABLE ADD COLUMN can't carry the NOT NULL DEFAULTs the fresh
        # schema declares, so a migrated DB would hold NULL where a fresh DB holds
        # the default — flipping behavior (e.g. a NULL deduct_federal is falsy
        # where the fresh default is 1). Backfill to match. received_ytd stays
        # after the kind backfill above so legacy values win over the plain 0.
        for table, col, default in [
            ("income",   "received_ytd",       0),
            ("income",   "auto_deposit",       0),
            ("expenses", "auto_draft",         0),
            ("expenses", "deductible",         0),
            ("expenses", "deductible_ytd",     0),
            ("expenses", "deductible_expected", 0),
            ("expenses", "deduct_federal",     1),
            ("expenses", "deduct_state",       1),
        ]:
            conn.execute(
                f"UPDATE {table} SET {col} = ? WHERE {col} IS NULL", (default,))

        # Backfill the per-row tax classification from each row's `type` for any
        # rows that predate the dropdown (capital → ordinary investment income;
        # gifts excluded; everything else ordinary). Users refine it on the form.
        conn.execute(
            "UPDATE income SET tax_class = CASE "
            "WHEN type = 'gift' THEN 'excluded' "
            "WHEN type = 'capital' THEN 'ordinary_investment' "
            "ELSE 'ordinary' END "
            "WHERE tax_class IS NULL"
        )

        # The standalone tax_events feature was removed (deductibility now lives on
        # expenses). Drop the table and any group memberships pointing at it, then
        # prune groups left with fewer than two members.
        te_groups = [r[0] for r in conn.execute(
            "SELECT DISTINCT group_id FROM link_group_members WHERE rec_table='tax_events'")]
        conn.execute("DELETE FROM link_group_members WHERE rec_table='tax_events'")
        for gid in te_groups:
            n = conn.execute("SELECT COUNT(*) FROM link_group_members WHERE group_id=?",
                             (gid,)).fetchone()[0]
            if n < 2:
                conn.execute("DELETE FROM link_group_members WHERE group_id=?", (gid,))
                conn.execute("DELETE FROM link_groups WHERE id=?", (gid,))
        conn.execute("DROP TABLE IF EXISTS tax_events")

        # `tax_year` on a deductible expense was dropped (always the current year).
        expense_cols = {r[1] for r in conn.execute("PRAGMA table_info(expenses)")}
        if "tax_year" in expense_cols:
            try:
                conn.execute("ALTER TABLE expenses DROP COLUMN tax_year")
            except sqlite3.OperationalError:
                pass   # very old SQLite without DROP COLUMN — leave it orphaned

        # The cash-account interest payout was a simple frequency+day; it's now a full
        # recurrence schedule (interest_schedule_type etc.). Drop the superseded columns.
        asset_cols = {r[1] for r in conn.execute("PRAGMA table_info(assets)")}
        for _old in ("interest_frequency", "interest_day"):
            if _old in asset_cols:
                try:
                    conn.execute(f"ALTER TABLE assets DROP COLUMN {_old}")
                except sqlite3.OperationalError:
                    pass   # very old SQLite without DROP COLUMN — leave it orphaned

        # One-time migration: fold legacy edge-links into groups — each connected
        # component of the old graph becomes one group — then retire the edge rows.
        # (Old links already formed cliques per component, so this is faithful.)
        have_groups = conn.execute("SELECT COUNT(*) FROM link_groups").fetchone()[0]
        old_links = conn.execute(
            "SELECT a_table, a_id, b_table, b_id FROM links").fetchall()
        if old_links and have_groups == 0:
            from collections import defaultdict
            adj = defaultdict(set)
            for at, ai, bt, bi in old_links:
                adj[(at, ai)].add((bt, bi))
                adj[(bt, bi)].add((at, ai))
            seen = set()
            for start in list(adj):
                if start in seen:
                    continue
                comp, stack = [], [start]
                seen.add(start)
                while stack:
                    n = stack.pop()
                    comp.append(n)
                    for nb in adj[n]:
                        if nb not in seen:
                            seen.add(nb)
                            stack.append(nb)
                if len(comp) >= 2:
                    gid = conn.execute(
                        "INSERT INTO link_groups (name, created_at) VALUES (?, ?)",
                        (None, _now())).lastrowid
                    for t, i in comp:
                        conn.execute(
                            "INSERT INTO link_group_members "
                            "(group_id, rec_table, rec_id, role, created_at) "
                            "VALUES (?, ?, ?, ?, ?)", (gid, t, int(i), None, _now()))
            conn.execute("DELETE FROM links")


def _now():
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _clean(v):
    """Coerce a Python/pandas/NumPy scalar into something sqlite3 accepts,
    turning NaN/NA/NaT into NULL and unwrapping NumPy scalar types."""
    if v is None:
        return None
    # pandas' missing-value singletons (from nullable Int64/boolean/datetime
    # columns, e.g. a data_editor) are rejected by sqlite3 with InterfaceError.
    if v is pd.NaT or v is pd.NA:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    item = getattr(v, "item", None)        # NumPy scalar -> native Python
    if callable(item) and v.__class__.__module__ == "numpy":
        v = v.item()
    if isinstance(v, float) and math.isnan(v):
        return None
    return v


# ---------------------------------------------------------------------------
# Whole-table read
# ---------------------------------------------------------------------------

def load_df(table):
    if table not in EDITABLE_TABLES:
        raise ValueError(f"{table!r} is not an editable table")
    with _session() as conn:
        return pd.read_sql_query(f"SELECT * FROM {table}", conn)


def save_df(table, df):
    """Replace an entire table from a DataFrame. This renumbers autoincrement
    ids, so it is reserved for bulk seeding / imports — interactive edits use
    insert_row / update_row / delete_row, which keep ids stable."""
    if table not in EDITABLE_TABLES:
        raise ValueError(f"{table!r} is not an editable table")
    df = df.drop(columns=[c for c in ("id",) if c in df.columns])
    with _session() as conn:
        valid = set(_columns(conn, table))
        unknown = [c for c in df.columns if c not in valid]
        if unknown:
            # Silently discarding columns on a destructive whole-table rewrite
            # would lose data without a trace — fail loud so the schema (or the
            # seed) gets fixed instead.
            raise ValueError(
                f"save_df({table!r}): column(s) {unknown} aren't in the schema")
        if "updated_at" in valid:
            df = df.copy()
            df["updated_at"] = _now()       # stamp the whole bulk load
        conn.execute(f"DELETE FROM {table}")
        df.to_sql(table, conn, if_exists="append", index=False)


# ---------------------------------------------------------------------------
# Single-row write (id-stable)
# ---------------------------------------------------------------------------

def _insert_row_in(conn, table, values):
    """insert_row's body, on an existing connection — lets multi-step operations
    (see delete_row_recording_income) share one transaction."""
    cols = [c for c in _columns(conn, table) if c != "id"]
    data = {k: _clean(v) for k, v in values.items() if k in cols}
    if not data:
        raise ValueError("no recognized columns to insert")
    if "updated_at" in cols and not data.get("updated_at"):
        data["updated_at"] = _now()
    keys = list(data)
    placeholders = ", ".join("?" for _ in keys)
    cur = conn.execute(
        f"INSERT INTO {table} ({', '.join(keys)}) VALUES ({placeholders})",
        [data[k] for k in keys],
    )
    return cur.lastrowid


def insert_row(table, values):
    """Insert one new row from a dict; returns the new id. Unknown keys are
    ignored and missing columns fall back to their schema defaults."""
    if table not in EDITABLE_TABLES:
        raise ValueError(f"{table!r} is not an editable table")
    with _session() as conn:
        return _insert_row_in(conn, table, values)


def _update_row_in(conn, table, row_id, updates):
    """update_row's body, on an existing connection — lets multi-step operations
    (a partial sale that updates the position AND records income) share one
    transaction. numpy.int64 ids are coerced; unknown keys are ignored."""
    cols = [c for c in _columns(conn, table) if c != "id"]
    data = {k: _clean(v) for k, v in updates.items() if k in cols}
    if not data:
        return
    if "updated_at" in cols and not data.get("updated_at"):
        data["updated_at"] = _now()
    assignments = ", ".join(f"{k} = ?" for k in data)
    conn.execute(
        f"UPDATE {table} SET {assignments} WHERE id = ?",
        [*data.values(), int(row_id)],
    )


def update_row(table, row_id, updates):
    """Update specific fields on one row by id. Other rows are untouched and
    no ids are renumbered."""
    if table not in EDITABLE_TABLES:
        raise ValueError(f"{table!r} is not an editable table")
    with _session() as conn:
        _update_row_in(conn, table, row_id, updates)
    # A debt edit re-derives every credit-card-minimum expense forced to mirror
    # it. AFTER the session above commits — the sync opens its own; nesting two
    # write transactions on separate connections would deadlock on SQLite's
    # single write lock.
    if table == "debts":
        sync_cc_min_expenses(int(row_id))


def update_row_recording_income(table, row_id, updates, income_values):
    """Atomically update a row AND insert an income row in one transaction — used
    when a PARTIAL sale both shrinks a position and records its realized gain.
    Either both happen or neither (a failure can't leave a phantom gain or apply
    the share change without it). Returns the new income id."""
    if table not in EDITABLE_TABLES:
        raise ValueError(f"{table!r} is not an editable table")
    with _session() as conn:
        new_id = _insert_row_in(conn, "income", income_values)
        _update_row_in(conn, table, row_id, updates)
        return new_id


def update_row_recording_expense(table, row_id, updates, expense_values):
    """The loss-side mirror of update_row_recording_income: atomically shrink a
    position and record its realized loss as a deductible expense. Returns the
    new expense id."""
    if table not in EDITABLE_TABLES:
        raise ValueError(f"{table!r} is not an editable table")
    with _session() as conn:
        new_id = _insert_row_in(conn, "expenses", expense_values)
        _update_row_in(conn, table, row_id, updates)
        return new_id


def touch_row(table, row_id):
    """Re-stamp a row's updated_at to now without changing any data — used when the
    user confirms a record is still correct (e.g. in the launch review prompt), so
    it stops counting as stale."""
    if table not in EDITABLE_TABLES:
        raise ValueError(f"{table!r} is not an editable table")
    with _session() as conn:
        if "updated_at" in _columns(conn, table):
            conn.execute(
                f"UPDATE {table} SET updated_at = ? WHERE id = ?", (_now(), int(row_id)))


def _delete_row_in(conn, table, row_id):
    """delete_row's body, on an existing connection — shared with
    delete_row_recording_income so both steps commit (or roll back) together."""
    conn.execute(f"DELETE FROM {table} WHERE id = ?", (row_id,))
    if table == "debts":
        # Expenses that mirrored (or paid) this debt lose their pointers in the
        # same transaction: a forced credit-card-minimum expense becomes a plain
        # editable expense keeping its last-synced values, and the pays-debt
        # pairing can't dangle at a dead id.
        conn.execute("UPDATE expenses SET cc_min_debt_id = NULL "
                     "WHERE cc_min_debt_id = ?", (row_id,))
        conn.execute("UPDATE expenses SET pays_debt_id = NULL "
                     "WHERE pays_debt_id = ?", (row_id,))
    gids = [r[0] for r in conn.execute(
        "SELECT group_id FROM link_group_members WHERE rec_table=? AND rec_id=?",
        (table, row_id)).fetchall()]
    conn.execute(
        "DELETE FROM link_group_members WHERE rec_table=? AND rec_id=?",
        (table, row_id))
    for gid in gids:
        _prune_group(conn, gid)
    # Drop any per-record data-management settings (staleness window / watch flag).
    conn.execute("DELETE FROM record_settings WHERE rec_table=? AND rec_id=?",
                 (table, row_id))


def delete_row(table, row_id):
    """Delete a single row by id, and drop it from any link group it belonged to
    (pruning groups that fall below two members)."""
    if table not in EDITABLE_TABLES:
        raise ValueError(f"{table!r} is not an editable table")
    with _session() as conn:
        _delete_row_in(conn, table, int(row_id))


def delete_row_recording_income(table, row_id, income_values):
    """Atomically insert an income row AND delete a record in one transaction —
    used when deleting an appreciated asset records its realized gain. Either both
    happen or neither, so a failure can't leave a phantom gain-income row behind
    (or charge the gain twice on a retry). Returns the new income id."""
    if table not in EDITABLE_TABLES:
        raise ValueError(f"{table!r} is not an editable table")
    with _session() as conn:
        new_id = _insert_row_in(conn, "income", income_values)
        _delete_row_in(conn, table, int(row_id))
        return new_id


def delete_row_recording_expense(table, row_id, expense_values):
    """The loss-side mirror of delete_row_recording_income: atomically insert an
    expense row (a realized capital loss recorded as a deductible expense) and
    delete the record in one transaction. Returns the new expense id."""
    if table not in EDITABLE_TABLES:
        raise ValueError(f"{table!r} is not an editable table")
    with _session() as conn:
        new_id = _insert_row_in(conn, "expenses", expense_values)
        _delete_row_in(conn, table, int(row_id))
        return new_id


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

def get_constant(key, default=0.0):
    with _session() as conn:
        row = conn.execute(
            "SELECT value FROM constants WHERE key = ?", (key,)
        ).fetchone()
    return row[0] if row else default


def get_constant_updated_at(key):
    """ISO timestamp (stored UTC) a constant was last written, or None if the key
    has never been stored. Lets the UI show a 'last updated' tag next to a rate."""
    with _session() as conn:
        row = conn.execute(
            "SELECT updated_at FROM constants WHERE key = ?", (key,)
        ).fetchone()
    return row[0] if row and row[0] else None


def set_constant(key, value):
    with _session() as conn:
        conn.execute(
            "INSERT INTO constants (key, value, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value = excluded.value, "
            "updated_at = excluded.updated_at",
            (key, float(value), _now()),
        )


def delete_constant(key):
    """Remove a stored constant so readers fall back to their defaults — used to
    clear a hand-edited override (e.g. a Taxes-page income bucket) so the value
    resumes tracking live data."""
    with _session() as conn:
        conn.execute("DELETE FROM constants WHERE key = ?", (key,))


def economic_variables() -> dict:
    """Current values of the economic variables a Margin Loan's APR formula may
    reference (decimals, e.g. 0.0533 = 5.33%). See utils.ECONOMIC_VARIABLE_KEYS.
    One query for all keys — the dialogs call this on every rerun. A key never
    stored reads 0.0, same as get_constant's default."""
    keys = utils.ECONOMIC_VARIABLE_KEYS
    with _session() as conn:
        rows = conn.execute(
            "SELECT key, value FROM constants WHERE key IN "
            f"({','.join('?' * len(keys))})", keys).fetchall()
    found = {k: v for k, v in rows if v is not None}
    return {k: float(found.get(k, 0.0)) for k in keys}


def refresh_margin_aprs(variables=None) -> int:
    """Re-derive the stored `apr` of every debt that carries an `apr_formula`
    (margin loans) from the current economic variables, persisting any that moved.
    Returns the count updated. A formula that no longer evaluates (bad expression
    or a removed variable) keeps its last good apr — the debt card flags it.
    The dashboard calls this when the variables change (passing the dict it
    already read) so the rate is current before anything reads it — every other
    consumer keeps reading the plain `apr` column unchanged."""
    if variables is None:
        variables = economic_variables()
    updated = 0
    with _session() as conn:
        rows = conn.execute(
            "SELECT id, apr, apr_formula FROM debts "
            "WHERE apr_formula IS NOT NULL AND TRIM(apr_formula) <> ''"
        ).fetchall()
        for rid, apr, formula in rows:
            try:
                new_apr = utils.safe_eval_formula(formula, variables)
            except ValueError:
                continue
            if abs(float(apr or 0.0) - new_apr) > 1e-12:
                conn.execute("UPDATE debts SET apr = ? WHERE id = ?", (new_apr, rid))
                updated += 1
    return updated


def repoint_margin_account(old_label, new_label) -> int:
    """Follow an investment-account rename: margin loans borrowed against
    `old_label` re-point to `new_label`. The label is DERIVED from the holdings'
    institution + account type, so editing an asset can move it out from under
    the loans that reference it — edit_asset calls this when a rename makes the
    old label vanish entirely. Returns the count re-pointed."""
    if not old_label or not new_label or old_label == new_label:
        return 0
    with _session() as conn:
        cur = conn.execute(
            "UPDATE debts SET margin_account = ? "
            "WHERE type = ? AND margin_account = ?",
            (new_label, utils.MARGIN_DEBT_TYPE, old_label))
        return cur.rowcount


# ---------------------------------------------------------------------------
# Link groups — named groups of related rows across the editable tables.
# A row may belong to several groups; everyone in a group is linked to everyone
# else in it (a clique). Two rows are "linked" iff they share at least one group,
# so a row can bridge groups that aren't themselves linked.
# ---------------------------------------------------------------------------

def create_group(name=None):
    """Create an (optionally named) empty group; returns its id."""
    with _session() as conn:
        return conn.execute(
            "INSERT INTO link_groups (name, created_at) VALUES (?, ?)",
            ((name or None), _now()),
        ).lastrowid


def all_groups():
    """Every link group as [{id, name}], ordered by id — lets an Add dialog offer a
    new record the choice of joining an existing group."""
    with _session() as conn:
        rows = conn.execute("SELECT id, name FROM link_groups ORDER BY id").fetchall()
    return [{"id": r[0], "name": r[1]} for r in rows]


def add_to_group(group_id, table, row_id, role=None):
    """Add a row to a group (idempotent). If already a member and `role` is
    given, the role is updated. Returns the membership id."""
    if table not in EDITABLE_TABLES:
        raise ValueError("only editable-table rows can be grouped")
    group_id, row_id = int(group_id), int(row_id)
    with _session() as conn:
        existing = conn.execute(
            "SELECT id FROM link_group_members "
            "WHERE group_id=? AND rec_table=? AND rec_id=?",
            (group_id, table, row_id),
        ).fetchone()
        if existing:
            if role is not None:
                conn.execute("UPDATE link_group_members SET role=? WHERE id=?",
                             (role, existing[0]))
            return existing[0]
        return conn.execute(
            "INSERT INTO link_group_members "
            "(group_id, rec_table, rec_id, role, created_at) VALUES (?, ?, ?, ?, ?)",
            (group_id, table, row_id, role, _now()),
        ).lastrowid


def groups_for(table, row_id):
    """Groups a row belongs to: list of {member_id, group_id, name, role},
    ordered by group id."""
    row_id = int(row_id)
    with _session() as conn:
        rows = conn.execute(
            "SELECT m.id, m.group_id, g.name, m.role FROM link_group_members m "
            "JOIN link_groups g ON g.id = m.group_id "
            "WHERE m.rec_table=? AND m.rec_id=? ORDER BY m.group_id",
            (table, row_id),
        ).fetchall()
    return [{"member_id": r[0], "group_id": r[1], "name": r[2], "role": r[3]}
            for r in rows]


def group_members(group_id, exclude=None):
    """Members of a group: list of {member_id, table, id, role, in_stats}. `exclude`
    is an optional (table, id) pair to drop (e.g. the record being viewed/edited).
    in_stats defaults to 1 (NULL = included in the group's statistics)."""
    with _session() as conn:
        rows = conn.execute(
            "SELECT id, rec_table, rec_id, role, in_stats FROM link_group_members "
            "WHERE group_id=? ORDER BY id", (int(group_id),),
        ).fetchall()
    out = [{"member_id": r[0], "table": r[1], "id": r[2], "role": r[3],
            "in_stats": 1 if r[4] is None else int(r[4])} for r in rows]
    if exclude is not None:
        ex = (exclude[0], int(exclude[1]))
        out = [m for m in out if (m["table"], m["id"]) != ex]
    return out


def linked_records(table, row_id):
    """Every row sharing at least one group with (table, row_id), as a list of
    {table, id, group_id, group_name, role} — one entry per shared group (a row
    linked via two groups appears once per group)."""
    row_id = int(row_id)
    out = []
    for g in groups_for(table, row_id):
        for m in group_members(g["group_id"], exclude=(table, row_id)):
            out.append({"table": m["table"], "id": m["id"], "group_id": g["group_id"],
                        "group_name": g["name"], "role": m["role"]})
    return out


def linked_id_set(table_a, table_b):
    """The set of `table_a` row ids that share at least one link group with some
    `table_b` row. One query (vs. linked_records per row) for callers that just
    need to know "is this row linked to any row of that other table?" — e.g. the
    calendar suppressing a debt payment already represented by a linked expense."""
    with _session() as conn:
        rows = conn.execute(
            "SELECT DISTINCT a.rec_id FROM link_group_members a "
            "JOIN link_group_members b ON a.group_id = b.group_id "
            "WHERE a.rec_table = ? AND b.rec_table = ?",
            (table_a, table_b)).fetchall()
    return {int(r[0]) for r in rows}


def _prune_group(conn, group_id):
    """Delete a group (and its rows) once it has fewer than two members — a
    0/1-member group links nothing."""
    n = conn.execute("SELECT COUNT(*) FROM link_group_members WHERE group_id=?",
                     (group_id,)).fetchone()[0]
    if n < 2:
        conn.execute("DELETE FROM link_group_members WHERE group_id=?", (group_id,))
        conn.execute("DELETE FROM link_groups WHERE id=?", (group_id,))


def remove_member(member_id):
    """Remove one membership row by its id; prune the group if it gets too small."""
    member_id = int(member_id)
    with _session() as conn:
        row = conn.execute("SELECT group_id FROM link_group_members WHERE id=?",
                           (member_id,)).fetchone()
        conn.execute("DELETE FROM link_group_members WHERE id=?", (member_id,))
        if row:
            _prune_group(conn, row[0])


def remove_from_group(group_id, table, row_id):
    """Remove a row from one group; prune the group if it falls below two members."""
    with _session() as conn:
        conn.execute(
            "DELETE FROM link_group_members WHERE group_id=? AND rec_table=? AND rec_id=?",
            (int(group_id), table, int(row_id)),
        )
        _prune_group(conn, int(group_id))


def delete_group(group_id):
    """Delete a group and all its memberships."""
    with _session() as conn:
        gid = int(group_id)
        conn.execute("DELETE FROM link_group_members WHERE group_id=?", (gid,))
        conn.execute("DELETE FROM link_groups WHERE id=?", (gid,))


def clear_groups():
    """Wipe all groups and memberships. Used on reseed (ids are renumbered)."""
    with _session() as conn:
        conn.execute("DELETE FROM link_group_members")
        conn.execute("DELETE FROM link_groups")


def rename_group(group_id, name):
    """Rename a group (blank/None → unnamed)."""
    with _session() as conn:
        conn.execute("UPDATE link_groups SET name=? WHERE id=?",
                     ((name or None), int(group_id)))


def set_member_in_stats(member_id, included):
    """Set whether a membership feeds its group's statistics."""
    with _session() as conn:
        conn.execute("UPDATE link_group_members SET in_stats=? WHERE id=?",
                     (1 if included else 0, int(member_id)))


# --- app settings + per-group statistic selection ---------------------------

def get_setting(key, default=None):
    """Read a value from the app_settings key/value store (text; often JSON).
    Returns `default` when the key is absent."""
    with _session() as conn:
        row = conn.execute("SELECT value FROM app_settings WHERE key=?",
                           (str(key),)).fetchone()
    return row[0] if row and row[0] is not None else default


def set_setting(key, value):
    """Upsert a value into the app_settings store (value stored as text)."""
    with _session() as conn:
        conn.execute(
            "INSERT INTO app_settings (key, value, updated_at) VALUES (?, ?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value, "
            "updated_at=excluded.updated_at",
            (str(key), None if value is None else str(value), _now()))


def get_group_stats_default():
    """The global default list of statistic keys every group shows unless it
    overrides — a list of strings (empty when never set / malformed)."""
    raw = get_setting("group_stats_default")
    if not raw:
        return []
    try:
        v = json.loads(raw)
    except (ValueError, TypeError):
        return []
    return [str(x) for x in v] if isinstance(v, list) else []


def set_group_stats_default(keys):
    """Set the global default list of statistic keys (a list of strings)."""
    set_setting("group_stats_default", json.dumps([str(k) for k in (keys or [])]))


def group_stat_keys(group_id):
    """A group's own statistic-key override as a list of strings, or None when it
    follows the global default. (An explicit empty list means 'show none'.)"""
    with _session() as conn:
        row = conn.execute("SELECT stat_keys FROM link_groups WHERE id=?",
                           (int(group_id),)).fetchone()
    if not row or row[0] is None:
        return None
    try:
        v = json.loads(row[0])
    except (ValueError, TypeError):
        return None
    return [str(x) for x in v] if isinstance(v, list) else None


def set_group_stat_keys(group_id, keys):
    """Set (a list of strings) or clear (None → follow the global default) a
    group's statistic-key override."""
    val = None if keys is None else json.dumps([str(k) for k in keys])
    with _session() as conn:
        conn.execute("UPDATE link_groups SET stat_keys=? WHERE id=?",
                     (val, int(group_id)))


def set_member_role(member_id, role):
    """Set (or clear) a membership's role label."""
    with _session() as conn:
        conn.execute("UPDATE link_group_members SET role=? WHERE id=?",
                     ((role or None), int(member_id)))


def set_expense_pays_debt(expense_id, debt_id):
    """Record (debt_id) — or clear (None) — that an expense IS a debt's payment."""
    with _session() as conn:
        conn.execute("UPDATE expenses SET pays_debt_id=? WHERE id=?",
                     (int(debt_id) if debt_id else None, int(expense_id)))


def _sync_value_same(a, b):
    """Loose equality for sync_cc_min_expenses: a stored SQLite/pandas value vs a
    freshly derived one. NULL/NaN/'' all mean empty; numbers compare as floats
    (5 == 5.0 == '5'); everything else compares as trimmed strings."""
    a_empty = a is None or a == "" or (isinstance(a, float) and math.isnan(a))
    b_empty = b is None or b == ""
    if a_empty or b_empty:
        return a_empty and b_empty
    try:
        return float(a) == float(b)
    except (TypeError, ValueError):
        return utils.safe_str(a) == utils.safe_str(b)


def sync_cc_min_expenses(debt_id=None):
    """Re-derive every credit-card-minimum expense (rows carrying cc_min_debt_id)
    from its card's CURRENT debt record — amount (every payment model), the
    monthly-on-due-day schedule, the card's name, and the pays-debt pairing
    (stats.cc_min_expense_fields is the single source of truth). Runs after every
    debt edit (update_row) and once a day at launch (dashboard.py), which covers
    statement-day recomputes and bulk paths that bypass update_row (a restore or
    seed). A linked debt that no longer exists or is no longer a revolving card
    unlinks its expense — it keeps the last-synced values and becomes a plain
    editable expense again. Rows already in sync are not rewritten, so
    updated_at only moves on a real change (staleness tracking and payment-match
    dismissals stay honest). Returns the number of expense rows written."""
    import stats as _stats
    with _session() as conn:
        exp = pd.read_sql_query(
            "SELECT * FROM expenses WHERE cc_min_debt_id IS NOT NULL", conn)
        debts = pd.read_sql_query("SELECT * FROM debts", conn)
    changed = 0
    for _, e in exp.iterrows():
        did = int(e["cc_min_debt_id"])
        if debt_id is not None and did != int(debt_id):
            continue
        m = debts[debts["id"] == did] if not debts.empty else debts
        card = m.iloc[0].to_dict() if not m.empty else None
        if card is None or utils.safe_str(card.get("type")) != "revolving":
            update_row("expenses", int(e["id"]), {"cc_min_debt_id": None})
            changed += 1
            continue
        fields = _stats.cc_min_expense_fields(card)
        if any(not _sync_value_same(e.get(k), v) for k, v in fields.items()):
            update_row("expenses", int(e["id"]), fields)
            changed += 1
    return changed


def dismiss_payment_match(debt_id, expense_id):
    """Record that the user said a matching (debt, expense) pair is NOT related, so
    the "are these the same payment?" prompt stops — until a record is updated."""
    with _session() as conn:
        conn.execute(
            "INSERT OR REPLACE INTO payment_match_dismissed "
            "(debt_id, expense_id, dismissed_at) VALUES (?, ?, ?)",
            (int(debt_id), int(expense_id), _now()))


def active_payment_dismissals():
    """{(debt_id, expense_id)} the user dismissed and that are still in force. A
    dismissal lapses once either record is edited after it (its updated_at moves
    past dismissed_at), so the prompt can return — ISO timestamps compare correctly
    as strings."""
    with _session() as conn:
        rows = conn.execute(
            "SELECT pm.debt_id, pm.expense_id FROM payment_match_dismissed pm "
            "JOIN debts d ON d.id = pm.debt_id "
            "JOIN expenses e ON e.id = pm.expense_id "
            "WHERE COALESCE(d.updated_at, '') <= pm.dismissed_at "
            "  AND COALESCE(e.updated_at, '') <= pm.dismissed_at").fetchall()
    return {(int(r[0]), int(r[1])) for r in rows}


def prune_empty_groups():
    """Delete every link group that has no members. Group creation is two steps
    (create_group, then add_to_group), and every member-removal path already prunes a
    group once it falls below two members — so this only sweeps up a group that was
    created but never populated. Returns the number of groups removed."""
    with _session() as conn:
        gids = [r[0] for r in conn.execute(
            "SELECT g.id FROM link_groups g "
            "LEFT JOIN link_group_members m ON m.group_id = g.id "
            "WHERE m.group_id IS NULL"
        ).fetchall()]
        for gid in gids:
            conn.execute("DELETE FROM link_groups WHERE id = ?", (gid,))
    return len(gids)


def export_database_bytes():
    """The whole database as bytes — a consistent point-in-time copy made with
    SQLite's online backup API (safe while other connections are writing), so
    the download is a drop-in replacement for finance.db."""
    import os
    import tempfile
    fd, path = tempfile.mkstemp(suffix=".db")
    os.close(fd)
    try:
        src = get_conn()
        dst = sqlite3.connect(path)
        try:
            src.backup(dst)
        finally:
            dst.close()
            src.close()
        with open(path, "rb") as f:
            return f.read()
    finally:
        os.unlink(path)


def restore_database_bytes(data):
    """Replace the live database with `data` — the bytes of a finance.db backup
    (an export_database_bytes download, or a .bak copy). The upload is validated
    BEFORE anything is touched (SQLite header, integrity check, expected
    tables); the current file is saved to a timestamped .bak alongside it; then
    the swap is atomic (same-directory os.replace) and the forward migrations
    re-run, so an older backup is upgraded on the way in. Returns the safety
    backup's path (None if there was no current database). Raises ValueError
    when the upload isn't a usable database."""
    import os
    import shutil
    import tempfile

    if not data or data[:16] != b"SQLite format 3\x00":
        raise ValueError("that file isn't a SQLite database")
    # Stage in the same directory so os.replace stays on one volume (atomic).
    fd, tmp = tempfile.mkstemp(suffix=".db", dir=str(Path(DB_PATH).parent))
    os.close(fd)
    try:
        with open(tmp, "wb") as f:
            f.write(data)
        conn = sqlite3.connect(tmp)
        try:
            ok = conn.execute("PRAGMA integrity_check").fetchone()[0]
            tables = {r[0] for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'")}
        finally:
            conn.close()
        if ok != "ok":
            raise ValueError("the file failed SQLite's integrity check")
        missing = EDITABLE_TABLES - tables
        if missing:
            raise ValueError("not a finance.db backup — missing table(s): "
                             + ", ".join(sorted(missing)))
        backup = None
        if os.path.exists(DB_PATH):
            backup = f"{DB_PATH}.bak-{datetime.now():%Y%m%d-%H%M%S}"
            shutil.copy2(DB_PATH, backup)
        os.replace(tmp, DB_PATH)
    except Exception:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    init_db()        # forward-migrate an older backup to the current schema
    return backup


def clear_database():
    """Delete every row from every table — a full wipe back to an empty database
    (assets, debts, income, expenses, link groups, snapshots, and constants). The
    schema stays in place, so the app keeps working and reads defaults afterwards.
    Children are deleted before parents to respect foreign keys."""
    tables = [
        "assets", "debts", "income", "expenses",
        "link_group_members", "link_groups", "links", "record_settings",
        "snapshot_items", "snapshots", "constants",
    ]
    with _session() as conn:
        for t in tables:
            conn.execute(f"DELETE FROM {t}")


# ---------------------------------------------------------------------------
# Per-record data-management settings (staleness window + update watch list)
# ---------------------------------------------------------------------------

def get_record_setting(table, row_id):
    """A record's {stale_days, watch}; stale_days is None when using the default."""
    with _session() as conn:
        row = conn.execute(
            "SELECT stale_days, watch FROM record_settings WHERE rec_table=? AND rec_id=?",
            (table, int(row_id))).fetchone()
    return {"stale_days": row[0], "watch": row[1]} if row else {"stale_days": None, "watch": 0}


def all_record_settings():
    """{(table, id): {stale_days, watch}} for every record that has custom settings."""
    with _session() as conn:
        rows = conn.execute(
            "SELECT rec_table, rec_id, stale_days, watch FROM record_settings").fetchall()
    return {(r[0], int(r[1])): {"stale_days": r[2], "watch": r[3]} for r in rows}


def _upsert_record_setting(conn, table, row_id, stale_days, watch):
    conn.execute(
        "INSERT INTO record_settings (rec_table, rec_id, stale_days, watch) VALUES (?, ?, ?, ?) "
        "ON CONFLICT(rec_table, rec_id) DO UPDATE SET stale_days=excluded.stale_days, "
        "watch=excluded.watch",
        (table, int(row_id), stale_days, 1 if watch else 0))


def set_stale_days(table, row_id, days):
    """Set a record's custom staleness window (days), preserving its watch flag."""
    cur = get_record_setting(table, row_id)
    with _session() as conn:
        _upsert_record_setting(conn, table, row_id, int(days) if days else None, cur["watch"])


def set_watch(table, row_id, watch):
    """Add/remove a record from the launch update-prompt watch list, keeping its window."""
    cur = get_record_setting(table, row_id)
    with _session() as conn:
        _upsert_record_setting(conn, table, row_id, cur["stale_days"], 1 if watch else 0)


def watched_records():
    """(table, id) pairs on the update watch list, ordered by table then id."""
    with _session() as conn:
        rows = conn.execute(
            "SELECT rec_table, rec_id FROM record_settings WHERE watch=1 "
            "ORDER BY rec_table, rec_id").fetchall()
    return [(r[0], int(r[1])) for r in rows]


def clear_tax_worksheet_constants():
    """Reset the Taxes page's stored worksheet state — bucket overrides,
    deduction boxes, withholding, the mirror flag, and filing status. The seed
    calls this: those values describe the PREVIOUS dataset's income/expenses and
    would silently override the fresh sample's classified totals."""
    keys = ["tax_income_mirror_ytd", "itemized_deductions",
            "itemized_deductions_ytd", "nj_deductions", "nj_deductions_ytd",
            "fed_withheld_ytd", "nj_withheld_ytd", "filing_status"]
    with _session() as conn:
        conn.execute("DELETE FROM constants WHERE key LIKE 'tax_income_%'")
        conn.executemany("DELETE FROM constants WHERE key = ?",
                         [(k,) for k in keys])


def clear_record_settings():
    """Remove every per-record data-management setting (staleness windows + watch list).
    The seed renumbers record ids, so old (table, id) keys must be cleared on reseed to
    avoid orphaned settings pointing at records that no longer exist."""
    with _session() as conn:
        conn.execute("DELETE FROM record_settings")


_LABEL_SQL = {
    "assets":   ("SELECT name FROM assets WHERE id=?",),
    "debts":    ("SELECT name FROM debts WHERE id=?",),
    "income":   ("SELECT source FROM income WHERE id=?",),
    "expenses": ("SELECT category, subcategory FROM expenses WHERE id=?",),
}


def row_label(table, row_id):
    """Short human label for a row (for link display), or None if it's gone."""
    sql = _LABEL_SQL.get(table)
    if not sql:
        return None
    with _session() as conn:
        row = conn.execute(sql[0], (int(row_id),)).fetchone()
    if not row:
        return None
    if table == "expenses":
        cat, sub = row[0], row[1]
        return f"{cat} — {sub}" if sub else cat
    return row[0]


# ---------------------------------------------------------------------------
# Snapshots
# ---------------------------------------------------------------------------

def clear_snapshots():
    """Wipe all snapshot history. Used when re-seeding. snapshot_items are
    removed via ON DELETE CASCADE (foreign keys are enabled per connection)."""
    with _session() as conn:
        conn.execute("DELETE FROM snapshots")


# Derived metric rows captured with every snapshot (category 'metric'), so the
# Overview's change-over-range readouts can compare them across history. Asset /
# debt / net-worth totals derive from the item rows and aren't duplicated here.
SNAPSHOT_METRICS = ["liquid_assets", "annual_expenses", "monthly_burn",
                    "income_ytd", "income_expected", "projected_eoy_net_worth",
                    "cash_interest_yr", "unrealized_gl", "ytd_tax_debt_net"]


def take_snapshot(label=None):
    with _session() as conn:
        cur = conn.execute(
            "INSERT INTO snapshots (taken_at, label) VALUES (?, ?)",
            (_now(), label),
        )
        sid = cur.lastrowid
        # Record your stake (value × ownership), so a partly-owned business
        # contributes the same to the snapshot as it does to live net worth.
        # institution/account_type/asset_type ride along so per-account history
        # can attribute each item without name matching.
        conn.execute(
            "INSERT INTO snapshot_items (snapshot_id, category, name, value, "
            "institution, account_type, asset_type) "
            "SELECT ?, 'asset', name, "
            "value * CASE WHEN ownership_pct > 0 THEN ownership_pct ELSE 1.0 END, "
            "institution, account_type, asset_type FROM assets",
            (sid,),
        )
        # margin_account rides along on debt items (NULL for non-margin debts) so
        # per-account margin history is reconstructible, mirroring the asset tags.
        conn.execute(
            "INSERT INTO snapshot_items (snapshot_id, category, name, value, "
            "margin_account) "
            "SELECT ?, 'debt', name, balance, margin_account FROM debts",
            (sid,),
        )
        # Derived metrics, frozen alongside the items (same formulas as stats.py:
        # ownership-scaled liquid total; monthly×12+annual / monthly+annual÷12
        # expense bases; income received vs still-expected; and the EOY projection
        # nw + expected − burn × whole months left this year).
        # Mirrors stats.effective_asset_values: anything not strictly positive
        # (NULL, 0, or a bad negative) counts as fully owned. The old
        # COALESCE(NULLIF(...)) form let a negative ownership_pct through,
        # making the captured snapshot disagree with live net worth.
        eff = "CASE WHEN ownership_pct > 0 THEN ownership_pct ELSE 1.0 END"
        assets_total = conn.execute(
            f"SELECT COALESCE(SUM(value * {eff}), 0) FROM assets").fetchone()[0]
        debts_total = conn.execute(
            "SELECT COALESCE(SUM(balance), 0) FROM debts").fetchone()[0]
        # Liquid total nets out margin loans — they're borrowed against an
        # investment account, so they're negative liquidity. The rule lives in
        # stats.margin_debt_total (one place), same as the live Overview figure.
        import stats as _stats
        liquid = conn.execute(
            f"SELECT COALESCE(SUM(value * {eff}), 0) FROM assets WHERE liquid = 1"
        ).fetchone()[0]
        liquid -= _stats.margin_debt_total(
            pd.read_sql_query("SELECT type, balance FROM debts", conn))
        # Annual spend = each expense's annual cost (set: amount × yearly
        # occurrences; variable: its recorded past-year total) via the shared
        # stats helper; monthly burn is that ÷ 12. In Python now that the cadence
        # (and per-period amounts) live in the schedule, not a 2-value frequency.
        _exp_df = pd.read_sql_query("SELECT * FROM expenses", conn)
        ann_exp = float(_stats.annual_expenses(_exp_df)) if not _exp_df.empty else 0.0
        burn = ann_exp / 12.0
        inc_ytd = conn.execute(
            "SELECT COALESCE(SUM(COALESCE(received_ytd, 0)), 0) FROM income"
        ).fetchone()[0]
        inc_expected = conn.execute(
            "SELECT COALESCE(SUM(MAX(COALESCE(amount, 0) - "
            "COALESCE(received_ytd, 0), 0)), 0) FROM income").fetchone()[0]
        # Whole months left this year, in UTC — taken_at is UTC, so a snapshot
        # near a month boundary must not pair a UTC timestamp with the LOCAL
        # clock's month for its burn projection.
        months_rem = 12 - datetime.now(timezone.utc).month

        # Three more need Python-side math (payout schedules / tax brackets), so
        # read the frames off this same connection. Lazy imports keep db at the
        # bottom of the layering — accounts/taxes are pure and don't import db.
        import accounts as _accounts
        import taxes as _taxes
        assets_df = pd.read_sql_query("SELECT * FROM assets", conn)
        income_df = pd.read_sql_query("SELECT * FROM income", conn)
        cash_interest = sum(
            _accounts.interest_income_amounts(a["balance"], a["apy"], a["sched"])[0]
            for a in _accounts.cash_accounts(assets_df) if a["apy"] > 0)
        unrealized_gl = conn.execute(
            "SELECT COALESCE(SUM(value - cost_basis), 0) FROM assets "
            "WHERE cost_basis IS NOT NULL AND cost_basis > 0").fetchone()[0]

        def _const(key, default=0.0):
            row = conn.execute("SELECT value FROM constants WHERE key = ?",
                               (key,)).fetchone()
            return row[0] if row and row[0] is not None else default

        metrics = {
            "liquid_assets": liquid,
            "annual_expenses": ann_exp,
            "monthly_burn": burn,
            "income_ytd": inc_ytd,
            "income_expected": inc_expected,
            "projected_eoy_net_worth": ((assets_total - debts_total)
                                        + inc_expected - burn * months_rem),
            "cash_interest_yr": cash_interest,
            "unrealized_gl": unrealized_gl,
            "ytd_tax_debt_net": _taxes.ytd_tax_debt_net(income_df, _const),
        }
        conn.executemany(
            "INSERT INTO snapshot_items (snapshot_id, category, name, value) "
            "VALUES (?, 'metric', ?, ?)",
            [(sid, k, float(v)) for k, v in metrics.items()])
    return sid


def _snapshot_iso(taken_at):
    """Normalize a date / datetime / ISO string into the UTC ISO timestamp a
    snapshot stores. A bare date (no time) is anchored at LOCAL noon: snapshots
    are stored UTC but displayed/filtered in local time, and noon keeps the
    snapshot on the same calendar day everywhere — midnight could roll across the
    date boundary under the UTC↔local conversion the UI does."""
    if isinstance(taken_at, str):
        try:
            taken_at = datetime.fromisoformat(taken_at)
        except ValueError:
            taken_at = date.fromisoformat(taken_at)        # a bare 'YYYY-MM-DD'
    if isinstance(taken_at, datetime):
        dt = taken_at
    else:                                                  # datetime.date
        dt = datetime.combine(taken_at, time(12, 0))
    if dt.tzinfo is None:
        dt = dt.astimezone()                               # interpret as local
    return dt.astimezone(timezone.utc).isoformat(timespec="seconds")


def add_snapshots_bulk(records):
    """Insert many hand-entered / imported snapshots in ONE transaction; returns
    the new ids. Each record is a dict with keys: taken_at (date/datetime/ISO,
    required) and the optional net_worth, assets, debts, label.

    This is for back-filling historical net-worth points from before the
    dashboard existed — it records only the totals you supply, NOT a live
    portfolio capture (see take_snapshot for that). A total left out (None) is
    recorded as UNKNOWN: net_worth lands in the snapshots row (NULL when absent),
    while assets/debts each become one synthetic item row only when supplied — so
    a net-worth-only import has no asset/debt items and snapshot_history reports
    those as NULL (a gap), never a fake zero. When net_worth is given it is the
    snapshot's authoritative net worth even if an asset/debt breakdown is also
    supplied; when it is absent but a breakdown is given, net worth derives from
    the items as usual."""
    ids = []
    with _session() as conn:
        for r in records:
            nw = r.get("net_worth")
            sid = conn.execute(
                "INSERT INTO snapshots (taken_at, label, net_worth) VALUES (?, ?, ?)",
                (_snapshot_iso(r["taken_at"]), (r.get("label") or None),
                 None if nw is None else float(nw)),
            ).lastrowid
            if r.get("assets") is not None:
                conn.execute(
                    "INSERT INTO snapshot_items (snapshot_id, category, name, value) "
                    "VALUES (?, 'asset', 'Assets', ?)", (sid, float(r["assets"])))
            if r.get("debts") is not None:
                conn.execute(
                    "INSERT INTO snapshot_items (snapshot_id, category, name, value) "
                    "VALUES (?, 'debt', 'Debts', ?)", (sid, float(r["debts"])))
            ids.append(sid)
    return ids


def add_manual_snapshot(taken_at, net_worth=None, assets=None, debts=None, label=None):
    """Add one hand-entered snapshot at a chosen date; returns its id. Thin
    wrapper over add_snapshots_bulk — see it for the missing-data semantics."""
    return add_snapshots_bulk([{
        "taken_at": taken_at, "net_worth": net_worth,
        "assets": assets, "debts": debts, "label": label}])[0]


def snapshot_days():
    """The set of LOCAL calendar dates that already have at least one snapshot —
    lets a bulk import skip days it would otherwise duplicate."""
    with _session() as conn:
        rows = [r[0] for r in conn.execute("SELECT taken_at FROM snapshots")]
    out = set()
    for ts in rows:
        if not ts:
            continue
        try:
            dt = datetime.fromisoformat(ts)
        except ValueError:
            continue
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        out.add(dt.astimezone().date())
    return out


def snapshot_items(snapshot_id):
    """All item rows of one snapshot (assets, debts, and captured metrics), with
    the SQLite rowid included so the Snapshot Manager can edit individual values
    (snapshot_items has no PK of its own). Asset rows carry institution/
    account_type/asset_type when captured by current code (NULL on older
    snapshots)."""
    with _session() as conn:
        return pd.read_sql_query(
            "SELECT rowid AS rid, category, name, value, institution, "
            "account_type, asset_type, margin_account FROM snapshot_items "
            "WHERE snapshot_id = ? ORDER BY category, name",
            conn, params=(int(snapshot_id),))


def snapshot_asset_items_history():
    """Every account-tagged asset item across ALL snapshots, joined with its
    snapshot's timestamp — the per-account value history behind the Investment
    Accounts chart. Untagged rows (snapshots predating account capture) are
    excluded; they can't be attributed to an account."""
    with _session() as conn:
        return pd.read_sql_query(
            "SELECT s.id AS snapshot_id, s.taken_at, i.name, i.value, "
            "i.institution, i.account_type, i.asset_type "
            "FROM snapshot_items i JOIN snapshots s ON s.id = i.snapshot_id "
            "WHERE i.category = 'asset' AND i.asset_type IS NOT NULL "
            "ORDER BY s.taken_at", conn)


def snapshot_margin_history():
    """Margin-loan balances captured with each snapshot, tagged with the account
    they were borrowed against — the per-snapshot margin the Investment Accounts
    chart nets out of each point, AS OF that snapshot rather than today. Rows
    captured before margin tagging simply aren't here (their margin was 0 —
    margin loans didn't exist before the tagging did)."""
    with _session() as conn:
        return pd.read_sql_query(
            "SELECT s.id AS snapshot_id, s.taken_at, i.margin_account, i.value "
            "FROM snapshot_items i JOIN snapshots s ON s.id = i.snapshot_id "
            "WHERE i.category = 'debt' AND i.margin_account IS NOT NULL "
            "AND TRIM(i.margin_account) <> '' "
            "ORDER BY s.taken_at", conn)


def update_snapshot_item(rid, value):
    """Set one snapshot item's recorded value (by rowid — see snapshot_items)."""
    with _session() as conn:
        conn.execute("UPDATE snapshot_items SET value = ? WHERE rowid = ?",
                     (float(value), int(rid)))


def set_snapshot_label(snapshot_id, label):
    """Rename a snapshot's display label (None/empty clears it)."""
    with _session() as conn:
        conn.execute("UPDATE snapshots SET label = ? WHERE id = ?",
                     (label or None, int(snapshot_id)))


def snapshot_recorded_net_worth(snapshot_id):
    """The directly-recorded net worth on a snapshot (the snapshots.net_worth
    column), or None when it derives from the asset/debt items — i.e. None marks
    a captured snapshot, a number marks a hand-added / imported one. Lets the
    Snapshot Manager edit the recorded value for imports that have no items."""
    with _session() as conn:
        row = conn.execute("SELECT net_worth FROM snapshots WHERE id = ?",
                           (int(snapshot_id),)).fetchone()
    return row[0] if row else None


def set_snapshot_net_worth(snapshot_id, value):
    """Set a snapshot's directly-recorded net worth (None clears it, so the value
    falls back to deriving from the asset/debt items)."""
    with _session() as conn:
        conn.execute("UPDATE snapshots SET net_worth = ? WHERE id = ?",
                     (None if value is None else float(value), int(snapshot_id)))


def set_snapshot_taken_at(snapshot_id, taken_at):
    """Re-time a snapshot — move where its point sits on the net-worth trend.
    `taken_at` is a date / datetime / ISO string; a bare date is anchored at local
    noon and any value is stored UTC (see _snapshot_iso), matching how the
    Snapshot Manager reads and displays times."""
    with _session() as conn:
        conn.execute("UPDATE snapshots SET taken_at = ? WHERE id = ?",
                     (_snapshot_iso(taken_at), int(snapshot_id)))


def duplicate_snapshot(snapshot_id):
    """Clone a snapshot — its timestamp, label, recorded net worth, and every item
    row (assets, debts, captured metrics, with their account tags) — into a new
    snapshot; returns the new id. The copy keeps the original's timestamp (re-time
    it afterward in the manager) and gets a ' (copy)' label so it's easy to find.
    Lets one point seed a hand-edited one without re-entering every value."""
    sid = int(snapshot_id)
    with _session() as conn:
        src = conn.execute(
            "SELECT taken_at, label, net_worth FROM snapshots WHERE id = ?",
            (sid,)).fetchone()
        if not src:
            raise ValueError(f"no snapshot with id {sid}")
        taken_at, label, net_worth = src
        new_id = conn.execute(
            "INSERT INTO snapshots (taken_at, label, net_worth) VALUES (?, ?, ?)",
            (taken_at, (f"{label} (copy)" if label else "Copy"), net_worth),
        ).lastrowid
        conn.execute(
            "INSERT INTO snapshot_items (snapshot_id, category, name, value, "
            "institution, account_type, asset_type) "
            "SELECT ?, category, name, value, institution, "
            "account_type, asset_type FROM snapshot_items WHERE snapshot_id = ?",
            (new_id, sid))
    return new_id


def delete_snapshot(snapshot_id):
    """Delete one snapshot; its items go with it (FK ON DELETE CASCADE)."""
    with _session() as conn:
        conn.execute("DELETE FROM snapshots WHERE id = ?", (int(snapshot_id),))


def latest_snapshot_at():
    """Return the newest snapshot's timestamp as a tz-aware UTC datetime, or
    None if there are no snapshots."""
    with _session() as conn:
        row = conn.execute(
            "SELECT taken_at FROM snapshots ORDER BY taken_at DESC LIMIT 1"
        ).fetchone()
    if not row or not row[0]:
        return None
    try:
        dt = datetime.fromisoformat(row[0])
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def snapshot_due(max_age=timedelta(hours=1)):
    """True if a fresh snapshot should be taken now: the newest snapshot is
    older than `max_age` (or none exists yet) AND the portfolio isn't empty.
    Exposed so callers can do work (e.g. refresh prices) only when a snapshot
    will actually be taken."""
    latest = latest_snapshot_at()
    if latest is not None and datetime.now(timezone.utc) - latest < max_age:
        return False
    with _session() as conn:
        count = conn.execute(
            "SELECT (SELECT COUNT(*) FROM assets) + (SELECT COUNT(*) FROM debts)"
        ).fetchone()[0]
    return bool(count)


def snapshot_history():
    """One row per snapshot: net worth plus the asset/debt totals behind it (the
    Overview chart's three lines), and each captured 'metric' row pivoted into its
    own column. Metric columns are NULL (NaN) for snapshots that predate metric
    capture — deliberately not 0, so a range delta can't compare against a fake
    zero baseline.

    Imported / hand-added snapshots (snapshots.net_worth IS NOT NULL) follow the
    same rule for their breakdown: net worth is the recorded value, and assets /
    debts are NULL (unknown — a gap in the ghost lines) whenever that snapshot
    carries no asset / debt item, rather than collapsing to a misleading 0. A
    captured snapshot (net_worth NULL) keeps the old behavior: its totals derive
    from its items and a genuinely empty side reads 0."""
    metric_cols = ",\n".join(
        f"SUM(CASE WHEN i.category = 'metric' AND i.name = '{m}' "
        f"THEN i.value END) AS {m}" for m in SNAPSHOT_METRICS)
    with _session() as conn:
        return pd.read_sql_query(
            f"""
            SELECT s.id, s.taken_at, s.label,
                   CASE WHEN s.net_worth IS NOT NULL
                             AND SUM(CASE WHEN i.category='asset' THEN 1
                                          ELSE 0 END) = 0
                        THEN NULL
                        ELSE COALESCE(SUM(CASE WHEN i.category = 'asset'
                                              THEN i.value END), 0)
                   END AS assets,
                   CASE WHEN s.net_worth IS NOT NULL
                             AND SUM(CASE WHEN i.category='debt' THEN 1
                                          ELSE 0 END) = 0
                        THEN NULL
                        ELSE COALESCE(SUM(CASE WHEN i.category = 'debt'
                                              THEN i.value END), 0)
                   END AS debts,
                   COALESCE(s.net_worth,
                            SUM(CASE WHEN i.category = 'asset' THEN  i.value
                                     WHEN i.category = 'debt'  THEN -i.value
                                     ELSE 0 END), 0) AS net_worth,
                   {metric_cols}
            FROM snapshots s
            LEFT JOIN snapshot_items i ON i.snapshot_id = s.id
            GROUP BY s.id, s.taken_at, s.label, s.net_worth
            ORDER BY s.taken_at
            """,
            conn,
        )


if __name__ == "__main__":
    init_db()
    print(f"Initialized {DB_PATH}")
