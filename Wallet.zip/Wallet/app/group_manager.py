"""
group_manager.py — the group statistics + manager on the Groups page (above the
map). Pick one or more groups to see their aggregate statistics — and choose WHICH
statistics each group shows. There is a global default set (edited at the top) that
every group follows unless it overrides with its own selection. The catalog of
available statistics lives in stats.GROUP_STATS_CATALOG; a group only offers the
ones its composition supports (e.g. utilization only when it holds a credit card).

Each group can also be managed inline: rename it, add/remove records, label a
record's role, omit a record from the stats, and pair an expense to the debt it
pays. When an unpaired debt and expense in a group have matching payments, it
offers to link them as the same payment (dismissible until a record changes)."""

from datetime import date

import streamlit as st

import db
import stats
from ui import flash
from utils import money, safe_float, safe_str

_COARSE = {"assets": "Asset", "debts": "Debt", "income": "Income", "expenses": "Expense"}
_TABLES = ("assets", "debts", "income", "expenses")

# Catalog lookups (key → its (key, label, category, kind, needs) tuple).
_CATALOG = stats.GROUP_STATS_CATALOG
_ENTRY = {e[0]: e for e in _CATALOG}


def _label_of(key):
    e = _ENTRY.get(key)
    return e[1] if e else key


def _cat_label(key):
    """'Category · Label' — used in the (composition-blind) default picker."""
    e = _ENTRY.get(key)
    return f"{e[2]} · {e[1]}" if e else key


def _add_months(d: date, n: int) -> date:
    m = d.month - 1 + n
    return date(d.year + m // 12, m % 12 + 1, 1)


def _stat_value(kind, v, today):
    """Format a stat value for display. Returns a string (NaN/None → '—')."""
    def _nan(x):
        return x is None or (isinstance(x, float) and x != x)

    if kind == "money":
        return money(v)
    if kind == "pct":
        return "—" if _nan(v) else f"{v * 100:.1f}%"
    if kind == "ratio":
        return "—" if _nan(v) else f"{v:.2f}×"
    if kind == "int":
        return "—" if _nan(v) else f"{int(v):,}"
    if kind == "months_plain":
        return "—" if _nan(v) else f"{v:.1f} mo"
    if kind == "labelmoney":
        return "—" if not v else f"{v[0]} · {money(v[1])}"
    if kind == "datename":
        return "—" if not v else f"{v[1]} · {v[0]}"
    if kind == "date_amt":
        if not v:
            return "—"
        d = v[0]
        return f"{money(v[1])} · {d:%b} {d.day}"
    return "—"


def _payoff_value(s, today):
    """Special-cased 'Payoff time' value (uses the never flag + approx date)."""
    if s.get("payoff_never"):
        return "Never"
    n = s.get("payoff_months")
    if n is None:
        return "—"
    return f"{int(n)} mo · {_add_months(today, int(n)):%b %Y}"


def _row_lookup(frames, table, rec_id):
    df = frames.get(table)
    if df is None or getattr(df, "empty", True):
        return None
    m = df[df["id"] == int(rec_id)]
    return m.iloc[0].to_dict() if not m.empty else None


def _label(table, rec_id):
    return db.row_label(table, rec_id) or "?"


# ── on_change / on_click callbacks (run before the rerun, so the edit sticks) ──

# `kp` is a key prefix so the SAME manager can render both on the page panel (kp="")
# and inside the group pop-up (kp="pop_") for the same group without colliding keys.

def _save_role(member_id, kp=""):
    db.set_member_role(member_id, st.session_state.get(f"gm_role_{kp}{member_id}", "").strip())


def _toggle_stats(member_id, kp=""):
    db.set_member_in_stats(member_id, st.session_state.get(f"gm_stats_{kp}{member_id}", True))


def _remove_member(member_id):
    db.remove_member(member_id)


def _set_pays(gid, expense_id, kp=""):
    db.set_expense_pays_debt(
        expense_id, st.session_state.get(f"gm_pays_{kp}{gid}_{expense_id}"))


def _remember_view():
    """Mirror the 'Groups to view' selection into a plain key that survives page
    navigation (the widget key itself is dropped when the page isn't rendered)."""
    st.session_state["gm_view_saved"] = list(st.session_state.get("gm_view_groups", []))


def _save_global_default():
    db.set_group_stats_default(st.session_state.get("gm_global_default", []))


def _stats_mode_change(gid, keep_keys, kp=""):
    """Switch a group between following the global default and a custom selection.
    Switching to custom seeds the override with what it currently shows."""
    if st.session_state.get(f"gm_smode_{kp}{gid}") == "Custom":
        db.set_group_stat_keys(gid, list(keep_keys))
    else:
        db.set_group_stat_keys(gid, None)
    st.session_state.pop(f"gm_sset_{kp}{gid}", None)   # let the multiselect re-init


def _stats_set_change(gid, kp=""):
    db.set_group_stat_keys(gid, list(st.session_state.get(f"gm_sset_{kp}{gid}") or []))


# ── rendering ────────────────────────────────────────────────────────────────

@st.dialog("New Group", width="large")
def _new_group_dialog():
    """Create a group from scratch: name it and pick its founding records. A
    group with fewer than two members is automatically pruned (it links
    nothing), so creation requires at least two."""
    frames = {t: db.load_df(t) for t in _TABLES}
    name = st.text_input("Group name (optional)",
                         placeholder="e.g. Rental property — Elm St")
    options = []
    for t in _TABLES:
        df = frames.get(t)
        if df is None or getattr(df, "empty", True):
            continue
        options.extend((t, int(rid)) for rid in df["id"].astype(int))
    if not options:
        st.info("No records yet — add assets/debts/income/expenses first.")
        return
    picks = st.multiselect(
        "Records to link — pick at least two", options,
        format_func=lambda o: f"{_COARSE[o[0]]}: {_label(o[0], o[1])}",
        help="A group is a link between records; one with fewer than two members "
             "is deleted automatically, so it starts with at least two.")
    if len(picks) == 1:
        st.caption(":orange[Pick one more — a single-record group would be "
                   "auto-deleted.]")
    c1, c2 = st.columns(2)
    if c1.button("Create group", type="primary", width="stretch",
                 disabled=len(picks) < 2):
        gid = db.create_group((name or "").strip() or None)
        for t, rid in picks:
            db.add_to_group(gid, t, rid)
        # Select the new group so its panel is open after the rerun (the pills
        # widget re-seeds from the saved list when its key is absent).
        st.session_state["gm_view_saved"] = list(dict.fromkeys(
            st.session_state.get("gm_view_saved", []) + [gid]))
        st.session_state.pop("gm_view_groups", None)
        flash("Group created.")
        st.rerun()
    if c2.button("Cancel", width="stretch"):
        st.rerun()


def group_manager_section():
    """Group statistics + manager. Rendered above the map on the Groups page."""
    st.subheader("Group statistics")
    if st.button("➕ New group",
                 help="Link two or more records into a new group."):
        _new_group_dialog()
    groups = db.all_groups()
    if not groups:
        st.caption("No groups yet. Click **➕ New group**, or link records "
                   "together with the 🔗 link picker on any Add or Edit form — "
                   "then view and manage the group here.")
        return

    _default_statistics_editor()

    labels = {g["id"]: (g["name"] or f"Group {g['id']}") for g in groups}
    # Pills (multi-select toggle buttons), like "Accounts shown" on the Investment
    # Accounts page. Streamlit drops a widget's state when its page isn't rendered, so
    # the selection would reset on navigating away. Keep it in a plain (non-widget)
    # session key that survives navigation, and seed the widget from it each run —
    # also dropping any id whose group no longer exists.
    opt_ids = {g["id"] for g in groups}
    src = (st.session_state["gm_view_groups"] if "gm_view_groups" in st.session_state
           else st.session_state.get("gm_view_saved", []))
    st.session_state["gm_view_groups"] = [gid for gid in src if gid in opt_ids]
    sel = st.pills(
        "Groups to view", [g["id"] for g in groups], selection_mode="multi",
        format_func=lambda gid: labels[gid], key="gm_view_groups",
        on_change=_remember_view,
        help="Pick one or more groups to see their statistics and manage them.")
    st.session_state["gm_view_saved"] = list(sel or [])
    if not sel:
        st.caption("Select a group above to see its statistics and manage it.")
        return

    frames = {t: db.load_df(t) for t in _TABLES}
    dismissed = db.active_payment_dismissals()
    default_keys = db.get_group_stats_default()
    for gid in sel:
        _group_panel(gid, labels[gid], frames, dismissed, default_keys)


def _default_statistics_editor():
    """Pick the global default set of statistics — what every group shows unless it
    overrides. Composition-blind (it spans all groups), so the full catalog is on
    offer; each group still filters to what it can actually compute."""
    with st.expander("⚙️ Default statistics — shown on every group unless customized"):
        gkey = "gm_global_default"
        if gkey not in st.session_state:
            st.session_state[gkey] = db.get_group_stats_default()
        st.pills(
            "Default statistics", [e[0] for e in _CATALOG], selection_mode="multi",
            format_func=_cat_label, key=gkey, on_change=_save_global_default,
            help="Each group shows the ones its records support. Set a group to "
                 "'Custom' (in ⚙️ Manage group) to override this list.")
        if not st.session_state[gkey]:
            st.caption("Nothing selected yet — groups show no statistics until you "
                       "pick some here (or customize an individual group).")


def _group_panel(gid, name, frames, dismissed, default_keys):
    with st.container(border=True):
        members = db.group_members(gid)
        recs = []
        for m in members:
            row = _row_lookup(frames, m["table"], m["id"])
            if row is not None:
                recs.append({**m, "row": row})

        st.markdown(f"#### 🔗 {name}")
        if not recs:
            st.caption("This group has no resolvable records.")
            with st.expander("⚙️ Manage group"):
                _rename_delete(gid, name)
            return

        today = date.today()
        s = stats.group_statistics(
            [{"table": r["table"], "in_stats": bool(r["in_stats"]), "row": r["row"]}
             for r in recs], today=today)
        override = db.group_stat_keys(gid)
        chosen = override if override is not None else default_keys
        _render_stats(s, chosen, today)

        _match_prompts(gid, recs, dismissed)

        with st.expander("⚙️ Manage group"):
            _manage_group(gid, name, recs, frames, s, override, default_keys)


def _applicable(s):
    """Catalog entries this group's composition supports, in catalog order."""
    return [e for e in _CATALOG if e[4](s)]


def _render_stats(s, chosen, today):
    """Render the chosen statistics that this group's composition supports, as a
    grid of metrics. Chosen-but-inapplicable keys are silently skipped."""
    app_keys = {e[0] for e in _applicable(s)}
    entries = [_ENTRY[k] for k in chosen if k in _ENTRY and k in app_keys]
    if not entries:
        st.caption("No statistics selected — pick them in ⚙️ Manage group below "
                   "(or set defaults at the top of the page).")
    else:
        for i in range(0, len(entries), 4):
            cols = st.columns(4)
            for col, (key, label, _cat, kind, _needs) in zip(cols, entries[i:i + 4]):
                val = (_payoff_value(s, today) if key == "payoff_months"
                       else _stat_value(kind, s.get(key), today))
                col.metric(label, val)  # st.metric values aren't markdown-parsed, $ ok

    counts = [f"{s[k]} {lbl}" for k, lbl in
              (("n_assets", "assets"), ("n_debts", "debts"),
               ("n_income", "income"), ("n_expenses", "expenses")) if s[k]]
    st.caption("Counting " + " · ".join(counts) + "." if counts
               else "No records are counted (all omitted).")


# ── group pop-up (opened by clicking an edge on the Group Map) ────────────────

def request_group_view(group_id):
    """Queue a group to be shown in a pop-up. The caller issues st.rerun (closing any
    open dialog); consume_pending_group_view() then opens it — mirrors cards.request_
    view, so clicking a group on the map swaps in its card instead of stacking one."""
    st.session_state["_pending_group_view"] = int(group_id)


def consume_pending_group_view():
    """Open a queued group pop-up. Call once at the very top of the app (before the
    page renders), alongside cards.consume_pending_view."""
    gid = st.session_state.pop("_pending_group_view", None)
    if gid is None:
        return
    if any(g["id"] == int(gid) for g in db.all_groups()):
        view_group(int(gid))


def _member_link(group_id, r):
    """A link-styled button for one group member that opens that record's card
    pop-up (via the view queue + rerun, so this group pop-up is replaced, not
    stacked under the record's)."""
    import cards
    t, rid = r["table"], int(r["id"])
    role = safe_str(r.get("role"))
    face = f"{_COARSE[t]}: {db.row_label(t, rid)}" + (f"  ·  {role}" if role else "")
    if st.button(face, key=f"vg_{group_id}_{r['member_id']}", type="tertiary",
                 width="stretch", help="Open this record's card pop-up"):
        cards.request_view(t, rid)
        st.rerun()


@st.dialog("Group", width="large")
def view_group(group_id):
    """Pop-up showing a group's card: its name, the statistics it's set to show, and
    its members (each a link to that record's own card). Opened by clicking an edge
    on the Group Map (an edge joins records that share a group)."""
    g = next((x for x in db.all_groups() if x["id"] == int(group_id)), None)
    if not g:
        st.error("This group no longer exists.")
        return
    st.markdown(f"#### 🔗 {g['name'] or f'Group {group_id}'}")

    frames = {t: db.load_df(t) for t in _TABLES}
    recs = []
    for m in db.group_members(group_id):
        row = _row_lookup(frames, m["table"], m["id"])
        if row is not None:
            recs.append({**m, "row": row})
    if not recs:
        st.caption("This group has no resolvable records.")
        return

    today = date.today()
    s = stats.group_statistics(
        [{"table": r["table"], "in_stats": bool(r["in_stats"]), "row": r["row"]}
         for r in recs], today=today)
    override = db.group_stat_keys(group_id)
    default_keys = db.get_group_stats_default()
    _render_stats(s, override if override is not None else default_keys, today)

    st.divider()
    st.caption("**Members** — click to open a record's card.")
    for r in recs:
        _member_link(group_id, r)

    # The same manager as the page panel — kp="pop_" namespaces its widget keys so
    # they don't collide if this group is also open in a panel behind the pop-up.
    with st.expander("⚙️ Manage group"):
        _manage_group(group_id, g["name"], recs, frames, s, override, default_keys,
                      kp="pop_")


def _match_prompts(gid, recs, dismissed):
    """Offer to link an unpaired debt and expense whose monthly payments match."""
    debts = [r for r in recs if r["table"] == "debts" and r["in_stats"]]
    expenses = [r for r in recs if r["table"] == "expenses" and r["in_stats"]]
    paid = {int(safe_float(e["row"].get("pays_debt_id"))) for e in expenses
            if safe_float(e["row"].get("pays_debt_id")) > 0}
    unpaired_exp = [e for e in expenses if not safe_float(e["row"].get("pays_debt_id")) > 0]

    shown = 0
    for d in debts:
        if int(d["id"]) in paid:
            continue
        dmin = stats.debt_min_payment(d["row"])
        if dmin <= 0:
            continue
        for e in unpaired_exp:
            emon = stats.expense_annual_amount(e["row"]) / 12.0
            if abs(dmin - emon) >= 0.01 or (int(d["id"]), int(e["id"])) in dismissed:
                continue
            dl, el = _label("debts", d["id"]), _label("expenses", e["id"])
            st.info(f"💡 **{el}** ({money(emon)}/mo) matches the payment on **{dl}**. "
                    "Are they the same payment?")
            p1, p2, _sp = st.columns([1.2, 1, 4])
            key = f"{gid}_{d['id']}_{e['id']}"
            if p1.button("Yes — link them", key=f"gm_myes_{key}", width="stretch"):
                db.set_expense_pays_debt(int(e["id"]), int(d["id"]))
                flash("Linked as the same payment."); st.rerun()
            if p2.button("No", key=f"gm_mno_{key}", width="stretch"):
                db.dismiss_payment_match(int(d["id"]), int(e["id"])); st.rerun()
            shown += 1
            if shown >= 3:
                return


def _stats_picker(gid, s, override, default_keys, kp=""):
    """Choose which statistics this group shows: follow the global default, or a
    custom selection (filtered to what the group's composition supports)."""
    st.markdown("**📊 Statistics shown**")
    app_keys = [e[0] for e in _applicable(s)]
    custom = override is not None
    keep = [k for k in (override if custom else default_keys) if k in app_keys]
    st.radio("Statistics mode", ["Use default", "Custom"], index=1 if custom else 0,
             horizontal=True, key=f"gm_smode_{kp}{gid}", label_visibility="collapsed",
             on_change=_stats_mode_change, args=(gid, keep, kp))
    if not custom:
        shown = [_label_of(k) for k in default_keys if k in app_keys]
        st.caption(("Following the default — showing: " + ", ".join(shown) +
                    ". Choose **Custom** to tailor this group.") if shown else
                   ("Following the default, but none of the default statistics apply "
                    "to this group. Choose **Custom** to pick from what it supports."))
        return
    sset = f"gm_sset_{kp}{gid}"
    if sset not in st.session_state:
        st.session_state[sset] = [k for k in (override or []) if k in app_keys]
    st.pills("Statistics for this group", app_keys, selection_mode="multi",
             format_func=_label_of, key=sset, label_visibility="collapsed",
             on_change=_stats_set_change, args=(gid, kp),
             help="Only the statistics this group's records support are listed.")
    if not app_keys:
        st.caption("This group's records don't support any statistics yet.")


def _rename_delete(gid, name, kp=""):
    rc1, rc2 = st.columns([4, 1])
    new = rc1.text_input("Group name", value=name or "", key=f"gm_rn_{kp}{gid}")
    if rc2.button("Rename", key=f"gm_rnb_{kp}{gid}", width="stretch"):
        if new.strip() != (name or ""):
            db.rename_group(gid, new.strip()); flash("Group renamed."); st.rerun()
    if st.button("🗑 Delete this group", key=f"gm_delg_{kp}{gid}",
                 help="Removes the group; the records themselves are kept."):
        db.delete_group(gid); flash("Group deleted."); st.rerun()


def _manage_group(gid, name, recs, frames, s, override, default_keys, kp=""):
    _rename_delete(gid, name, kp)
    st.divider()
    _stats_picker(gid, s, override, default_keys, kp)
    st.divider()
    st.caption("**Role** labels a record's part in the group. Untick **In stats** to omit "
               "a record from this group's statistics. For an expense, set **Pays off** to "
               "the debt it's the payment for, so the two aren't double-counted.")

    debt_opts = {int(r["id"]): _label("debts", r["id"])
                 for r in recs if r["table"] == "debts"}
    for r in recs:
        _member_row(gid, r, debt_opts, kp)

    st.divider()
    _add_member(gid, recs, frames, kp)


def _member_row(gid, r, debt_opts, kp=""):
    mid, t, rid = r["member_id"], r["table"], int(r["id"])
    c1, c2, c3, c4 = st.columns([3, 2.4, 1.1, 0.6])
    c1.markdown(f"**{_COARSE[t]}:** {_label(t, rid)}")
    c2.text_input("Role", value=safe_str(r.get("role")), key=f"gm_role_{kp}{mid}",
                  label_visibility="collapsed", placeholder="role (optional)",
                  on_change=_save_role, args=(mid, kp))
    c3.checkbox("In stats", value=bool(r["in_stats"]), key=f"gm_stats_{kp}{mid}",
                on_change=_toggle_stats, args=(mid, kp))
    c4.button("✕", key=f"gm_rm_{kp}{mid}", help="Remove from group",
              on_click=_remove_member, args=(mid,))
    if t == "expenses" and debt_opts:
        cur = int(safe_float(r["row"].get("pays_debt_id"))) or None
        opts = [None] + list(debt_opts.keys())
        st.selectbox(
            "↳ Pays off (debt)", opts, index=opts.index(cur) if cur in opts else 0,
            key=f"gm_pays_{kp}{gid}_{rid}",
            format_func=lambda d: "— not a debt payment —" if d is None
            else debt_opts.get(d, f"Debt {d}"),
            on_change=_set_pays, args=(gid, rid, kp))


def _add_member(gid, recs, frames, kp=""):
    present = {(r["table"], int(r["id"])) for r in recs}
    options = []
    for t in _TABLES:
        df = frames.get(t)
        if df is None or getattr(df, "empty", True):
            continue
        for rid in df["id"].astype(int):
            if (t, int(rid)) not in present:
                options.append((t, int(rid)))
    if not options:
        st.caption("Every record is already in this group.")
        return
    ac1, ac2 = st.columns([4, 1])
    pick = ac1.selectbox(
        "Add a record", options, key=f"gm_add_{kp}{gid}", label_visibility="collapsed",
        format_func=lambda o: f"{_COARSE[o[0]]}: {_label(o[0], o[1])}")
    if ac2.button("Add", key=f"gm_addb_{kp}{gid}", width="stretch"):
        db.add_to_group(gid, pick[0], pick[1]); flash("Record added to group."); st.rerun()
