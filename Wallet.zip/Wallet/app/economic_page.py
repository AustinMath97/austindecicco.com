"""
economic_page.py — the Economic Variables page (fed funds target/effective
rates and inflation) and its save callback. Split out of dashboard.py.
"""

import streamlit as st

import db
from utils import fmt_datetime


def _rate_label(base, key):
    """Rate input label with its 'last updated' stamp inline: the rate text in bold,
    the full date+time stamp greyed (like the muted card 'Updated' captions), both on
    the same line via the widget label's markdown."""
    ts = db.get_constant_updated_at(key)
    stamp = f"🕑 Updated {fmt_datetime(ts)}" if ts else "🕑 Not set yet"
    return f"**{base}**  :gray[{stamp}]"


def _save_constants():
    """on_click for 'Save variables': persist only the rates that actually changed,
    so each one's updated_at (and its inline stamp) moves only when its value really
    changed. Running as a callback — before the inputs re-render — means the new
    stamp shows on the same click. The tolerance shrugs off float round-trip noise."""
    # Enforce the FOMC ordering: lower target ≤ effective rate ≤ upper target. The
    # boxes hold percentages; writing their session_state here is allowed because the
    # callback runs before the inputs re-instantiate, so each clamp shows in the box
    # too, not just in storage. Clamp the bounds first, then fit the effective rate
    # inside the corrected range.
    notes = []
    lo_pct = float(st.session_state.get("c_fed_target_lo", 0.0))
    hi_pct = float(st.session_state.get("c_fed_target_hi", 0.0))
    if lo_pct > hi_pct:
        lo_pct = hi_pct
        st.session_state["c_fed_target_lo"] = lo_pct
        notes.append("lower target capped at the upper target")
    eff_pct = float(st.session_state.get("c_fed_funds_rate", 0.0))
    eff_fit = min(max(eff_pct, lo_pct), hi_pct)
    if eff_fit != eff_pct:
        st.session_state["c_fed_funds_rate"] = eff_fit
        notes.append("effective rate pulled inside the target range")

    rates = {
        "fed_funds_target_lower": "c_fed_target_lo",
        "fed_funds_target_upper": "c_fed_target_hi",
        "fed_funds_rate":         "c_fed_funds_rate",
        "inflation_rate":         "c_inflation_rate",
    }
    changed = 0
    for const_key, ss_key in rates.items():
        val = float(st.session_state.get(ss_key, 0.0)) / 100.0
        if abs(db.get_constant(const_key) - val) > 1e-9:
            db.set_constant(const_key, val)
            changed += 1
    msg = f"Updated {changed} rate(s)." if changed else "No changes to save."
    if notes:
        msg += " Adjusted: " + ", ".join(notes) + "."
    st.session_state["_const_saved_msg"] = msg



# --- economic variables page -----------------------------------------------

def economic_variables_page():
    st.header("Economic Variables")
    st.caption("Rates are stored as decimals internally; enter them here as percentages.")

    # ── Federal funds: FOMC target range + the effective rate inside it ──────
    st.markdown("**Federal funds rate**")
    # Seed each rate input once from its stored constant and pass NO value= on the
    # widgets below, so the Save callback can also write their session_state (the
    # ordering clamps) without Streamlit's "default value + Session State API" warning.
    for _sk, _ck in (("c_fed_target_lo",  "fed_funds_target_lower"),
                     ("c_fed_target_hi",  "fed_funds_target_upper"),
                     ("c_fed_funds_rate", "fed_funds_rate"),
                     ("c_inflation_rate", "inflation_rate")):
        if _sk not in st.session_state:
            st.session_state[_sk] = float(db.get_constant(_ck) * 100)

    fr1, fr2, fr3 = st.columns(3)
    fr1.number_input(
        _rate_label("Target lower (%)", "fed_funds_target_lower"),
        step=0.25, key="c_fed_target_lo")
    fr2.number_input(
        _rate_label("Target upper (%)", "fed_funds_target_upper"),
        step=0.25, key="c_fed_target_hi")
    fr3.number_input(
        _rate_label("Effective rate (%)", "fed_funds_rate"),
        step=0.25, key="c_fed_funds_rate",
        help="The rate actually traded within the target range; used in the "
             "debt-payoff spread and present-value calculations.")
    # Show the SAVED target range (read from the stored constants), so it only moves
    # when you Save — not while a new value is merely typed into a box but unsaved.
    saved_lo = db.get_constant("fed_funds_target_lower") * 100
    saved_hi = db.get_constant("fed_funds_target_upper") * 100
    if saved_hi > 0:
        st.caption(f"Current target range: **{saved_lo:.2f}% – {saved_hi:.2f}%**")
    st.caption(
        "🔎 [FOMC target range — Federal Reserve ↗](https://www.federalreserve.gov/monetarypolicy/openmarket.htm) · "
        "[upper ↗](https://fred.stlouisfed.org/series/DFEDTARU) · "
        "[lower ↗](https://fred.stlouisfed.org/series/DFEDTARL) · "
        "[effective ↗](https://fred.stlouisfed.org/series/FEDFUNDS)"
    )

    # ── Inflation ────────────────────────────────────────────────────────────
    st.number_input(
        _rate_label("Inflation rate (%)", "inflation_rate"),
        step=0.1, key="c_inflation_rate")
    st.caption("🔎 [CPI 12-month inflation — U.S. BLS ↗](https://www.bls.gov/cpi/)")

    st.button("Save variables", on_click=_save_constants)
    _msg = st.session_state.pop("_const_saved_msg", None)
    if _msg:
        st.success(_msg)

