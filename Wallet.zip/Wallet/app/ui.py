"""
ui.py — tiny Streamlit helpers shared by the page modules.

Lives below the pages in the import graph (it imports nothing from them), so
overview/taxes/etc. can share these without a cycle through dashboard.py.
money/esc and the safe coercers live in utils (Streamlit-free); these need st.
"""

import pandas as pd
import streamlit as st

try:
    # Optional: a text input that reruns per keystroke (debounced), so a search
    # box filters live as you type instead of only on Enter.
    from st_keyup import st_keyup as _keyup
except ImportError:
    _keyup = None        # plain st.text_input fallback (filters on Enter/blur)


def search_box(label, key, placeholder=""):
    """A search input shared by the record pages and Data Management: a 🔎 icon
    inline on the left and no text above the box (the label still exists,
    collapsed, for accessibility — so the input sits level with buttons sharing
    its row). When streamlit-keyup is installed it filters live as you type
    (debounced); without it, a plain text input that commits on Enter/blur.
    Returns the query stripped and lower-cased (the component returns None
    before its frontend mounts)."""
    # A flex row (not columns) so the icon hugs the box with a fixed tiny gap
    # instead of a ratio-sized column that widens with the page.
    with st.container(horizontal=True, vertical_alignment="center", gap="xsmall"):
        st.markdown("🔎", width="content")
        with st.container():                      # stretch → the rest of the row
            if _keyup is not None:
                query = _keyup(label, key=key, debounce=250, placeholder=placeholder,
                               label_visibility="collapsed")
            else:
                query = st.text_input(label, key=key, placeholder=placeholder,
                                      label_visibility="collapsed")
    return (query or "").strip().lower()


def pct(x, digits=1):
    if x is None or pd.isna(x):
        return "—"
    return f"{x * 100:.{digits}f}%"


def num(x, digits=1):
    if x is None or pd.isna(x):
        return "—"
    return f"{x:.{digits}f}"


def flash(msg):
    """Queue a message to display (as a toast) on the run AFTER an st.rerun() — a
    success/info element drawn immediately before a rerun is wiped by it and never
    actually shows. main() pops and shows the queued message at the top of each run."""
    st.session_state["_flash_msg"] = msg
