"""
vin.py — VIN decoding via the free NHTSA vPIC API (no key, no signup).

`decode_vin(vin)` returns {year, make, model, trim, body} pulled from the VIN's
structure. vPIC decodes the year/make/model/trim from the VIN's WMI + VDS
digits, so it resolves a vehicle even when the VIN isn't a registered one (it's
reading how the VIN is built, not looking up a registration) — which means it
works for sample data too. Any network/parse failure degrades to {} so callers
fall back to whatever the user typed.

Stdlib only (urllib), matching prices.py — importing this module never reaches
the network; only calling decode_vin() does.
"""

import json
import re
import urllib.parse
import urllib.request

_API = "https://vpic.nhtsa.dot.gov/api/vehicles/DecodeVinValues/{}?format=json"

# VINs use only these characters (no I/O/Q) and vPIC needs a substantially
# complete one (11+ of the 17). Validating before building a URL out of user
# input keeps spaces/slashes/junk from producing a malformed request that
# would just fail silently.
_VIN_RE = re.compile(r"[A-HJ-NPR-Z0-9]{11,17}")


def decode_vin(vin):
    """Decode a VIN to {year, make, model, trim, body}, or {} if it can't be
    resolved. `trim` falls back to the model series when no trim is reported."""
    v = (vin or "").strip().upper()
    if not _VIN_RE.fullmatch(v):
        return {}
    try:
        req = urllib.request.Request(_API.format(urllib.parse.quote(v, safe="")),
                                     headers={"User-Agent": "wallet-dashboard"})
        with urllib.request.urlopen(req, timeout=8) as resp:
            row = json.load(resp)["Results"][0]
    except Exception:
        return {}

    year = (row.get("ModelYear") or "").strip()
    make = (row.get("Make") or "").strip()
    model = (row.get("Model") or "").strip()
    trim = (row.get("Trim") or row.get("Series") or "").strip()
    body = (row.get("BodyClass") or "").strip()
    if not (make and model):              # a decode with no make/model is useless
        return {}
    # vPIC returns the make in all caps ("TOYOTA"); title-case it for display.
    # The valuation links lower-case it anyway, so casing only affects the field.
    return {"year": year, "make": make.title(), "model": model,
            "trim": trim, "body": body}
