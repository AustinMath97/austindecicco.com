"""
investments.py — the Investment Accounts page: per-account holdings, values,
unrealized gains, and the per-account history chart over snapshots. Split out
of dashboard.py.
"""

import altair as alt
import pandas as pd
import streamlit as st

import charting
import db
import stats
from utils import esc, is_investment_holding, money

# --- investment accounts page ------------------------------------------------

def investment_accounts_page():
    st.header("Investment Accounts")
    assets = db.load_df("assets")
    accts = stats.investment_accounts(assets)
    if not accts:
        st.info("No investment holdings yet — add brokerage / retirement / crypto "
                "assets on the Assets page.")
        return
    st.caption("Holdings grouped into accounts by institution + account type, "
               "with each account's total value, unrealized G/L, and its change "
               "over the selected range.")

    hist = db.snapshot_history()
    if not hist.empty:
        hist = hist.copy()
        hist["taken_at"] = pd.to_datetime(hist["taken_at"]).dt.tz_localize(None)

    # The chart renders INTO this slot so it sits at the top of the page, while
    # the range picker and summary stats live BELOW it — they're consulted before
    # the slot is filled, so their state still drives the chart.
    st.subheader("Account values over time")
    chart_slot = st.container()

    st.caption("Range — drives the chart above and the per-account change below:")
    dom_start, dom_end, inv_tf = charting.range_picker("inv", hist, default="1M")

    # Baseline for deltas: the latest snapshot at/before the range start (carry-
    # forward, matching the Overview), else the earliest. Snapshot items captured
    # by current code carry institution/account_type, so each account's baseline
    # is attributed exactly — name matching would double-count holdings like a
    # "VTI" held in two accounts. Older untagged snapshots yield no delta.
    base_items = None
    base_margin = {}          # margin per account label AS OF the base snapshot
    if not hist.empty:
        prior = hist[hist["taken_at"] <= dom_start]
        base_row = prior.iloc[-1] if not prior.empty else hist.iloc[0]
        bi_all = db.snapshot_items(int(base_row["id"]))
        bi = bi_all[(bi_all["category"] == "asset") & bi_all["asset_type"].notna()]
        if not bi.empty:
            base_items = bi
        # Margin captured with that same snapshot, so equity deltas compare
        # equity to equity (older untagged snapshots had no margin loans → 0).
        if "margin_account" in bi_all.columns:
            bm = bi_all[(bi_all["category"] == "debt")
                        & bi_all["margin_account"].notna()]
            if not bm.empty:
                base_margin = bm.groupby("margin_account")["value"].sum().to_dict()

    def _acct_rows(df, acc):
        """Tagged asset-item rows belonging to this account — matched uniformly by
        institution + account_type (now that the account is stored explicitly),
        restricted to investment holdings (securities / crypto)."""
        inst_ok = df["institution"].fillna("").str.strip() == acc["institution"]
        return df[inst_ok
                  & (df["account_type"].fillna("").str.strip() == acc["account_type"])
                  & df["asset_type"].apply(is_investment_holding)]

    def _baseline_value(acc):
        if base_items is None:
            return None
        m = _acct_rows(base_items, acc)
        return float(m["value"].sum()) if not m.empty else None

    def _baseline_equity(acc):
        base = _baseline_value(acc)
        return None if base is None else base - base_margin.get(acc["label"], 0.0)

    def _delta_str(cur, base):
        if base is None:
            return None
        d = cur - base
        if abs(d) < 0.005:
            return None
        return f"+{money(d)}" if d > 0 else money(d)

    # Margin loans borrowed against these accounts (by the stored account label) —
    # they reduce an account's value to its equity.
    margin_map = stats.margin_by_account(db.load_df("debts"))
    total_margin = sum(margin_map.values())
    # A loan whose stored label matches no current account (renamed / emptied)
    # still counts against portfolio liquidity but can't be netted from any
    # account below — surface it rather than letting the mismatch stay silent.
    _cur_labels = {a["label"] for a in accts}
    _orphaned = {k: v for k, v in margin_map.items() if k not in _cur_labels}
    if _orphaned:
        st.warning(esc("Margin loan(s) point at accounts that no longer exist: "
                       + ", ".join(f"{k} ({money(v)})"
                                   for k, v in _orphaned.items())
                       + " — renamed or emptied? Re-link them in Edit Debt so "
                       "they net against the right account."))

    # Overall summary across every investment account: gross holdings (Assets) and
    # the same net of margin loans (Equity).
    total_v = sum(a["value"] for a in accts)
    total_equity = total_v - total_margin
    overall_base = None
    if base_items is not None:
        ob = base_items[base_items["asset_type"].apply(is_investment_holding)]
        overall_base = float(ob["value"].sum()) if not ob.empty else None
    gains = [a["gain"] for a in accts if a["gain"] is not None]
    s1, s2, s3, s4 = st.columns(4)
    s1.metric("Total Invested Assets", money(total_v),
              delta=_delta_str(total_v, overall_base),
              help="Gross market value of every investment holding.")
    s2.metric("Total Invested Equity", money(total_equity),
              delta=_delta_str(total_equity,
                               None if overall_base is None
                               else overall_base - sum(base_margin.values())),
              help="Invested assets minus the margin loans borrowed against them."
              if total_margin else "Same as assets — no margin loans.")
    s3.metric("Accounts", len(accts))
    s4.metric("Unrealized G/L (tracked)",
              ("+" + money(sum(gains))) if gains and sum(gains) >= 0
              else (money(sum(gains)) if gains else "—"))

    st.divider()

    # ── Account values over time (fills the slot created above) ──────────────
    with chart_slot:
        items_hist = db.snapshot_asset_items_history()
        if items_hist.empty:
            st.caption("No account-tagged snapshot history yet — the chart appears "
                       "once snapshots taken by the current version exist.")
        else:
            items_hist = items_hist.copy()
            items_hist["taken_at"] = (pd.to_datetime(items_hist["taken_at"])
                                      .dt.tz_localize(None))
            now_ts = pd.Timestamp.now(tz="UTC").tz_localize(None)

            # One series per account: per-snapshot sums inside the picked window,
            # left-anchored with the last pre-window value and carried to the live
            # value at `now` — the same anchoring as the net-worth chart. Each
            # point is EQUITY as of its own snapshot: the margin captured WITH
            # that snapshot nets out of it (0 when none existed yet), and the
            # live now-point nets today's margin — netting today's balance from
            # old points would rewrite history whenever the loan moves.
            mhist = db.snapshot_margin_history()
            if not mhist.empty:
                mhist = mhist.copy()
                mhist["taken_at"] = (pd.to_datetime(mhist["taken_at"])
                                     .dt.tz_localize(None))
            frames = []
            for acc in accts:
                rows = _acct_rows(items_hist, acc)
                ser = (rows.groupby("taken_at", as_index=False)["value"].sum()
                       .sort_values("taken_at")) if not rows.empty else rows
                if not ser.empty and not mhist.empty:
                    _am = (mhist[mhist["margin_account"] == acc["label"]]
                           .groupby("taken_at")["value"].sum())
                    ser["value"] = (ser["value"]
                                    - ser["taken_at"].map(_am).fillna(0.0))
                view_s = (ser[(ser["taken_at"] >= dom_start)
                              & (ser["taken_at"] <= dom_end)]
                          if not ser.empty else ser)
                if inv_tf != "Custom":
                    if not ser.empty:
                        prior = ser[ser["taken_at"] < dom_start]
                        if not prior.empty and (view_s.empty
                                                or view_s["taken_at"].min() > dom_start):
                            view_s = pd.concat([pd.DataFrame([{
                                "taken_at": dom_start,
                                "value": float(prior.iloc[-1]["value"])}]), view_s],
                                ignore_index=True)
                    last_t = (view_s["taken_at"].max() if not view_s.empty
                              else dom_start)
                    if now_ts > last_t:
                        view_s = pd.concat([view_s, pd.DataFrame([{
                            "taken_at": now_ts,
                            "value": float(acc["value"])
                                     - margin_map.get(acc["label"], 0.0)}])],
                            ignore_index=True)
                if view_s.empty:
                    continue
                view_s = view_s.sort_values("taken_at").copy()
                view_s["Account"] = acc["label"]
                frames.append(view_s[["taken_at", "value", "Account"]])

            if not frames:
                st.caption("No snapshots in this range.")
            else:
                long = pd.concat(frames, ignore_index=True)
                # STABLE options (every account, whatever the window) so changing
                # the timeframe can't change the widget's identity and silently
                # reset the selection. Seed-once from a shadow key: widget state
                # is dropped when a page doesn't render, so the underscore key is
                # what actually survives visiting other pages.
                all_labels = [a["label"] for a in accts]
                if "inv_lines" not in st.session_state:
                    saved = st.session_state.get("_inv_lines_saved")
                    st.session_state["inv_lines"] = (
                        [l for l in saved if l in all_labels]
                        if saved is not None else all_labels)
                shown = st.pills("Accounts shown", all_labels,
                                 selection_mode="multi", key="inv_lines")
                st.session_state["_inv_lines_saved"] = shown
                if "inv_chart_mode" not in st.session_state:
                    st.session_state["inv_chart_mode"] = st.session_state.get(
                        "_inv_mode_saved", "Raw value ($)")
                inv_mode = st.radio("Chart mode",
                                    ["Raw value ($)", "Percentage change (%)"],
                                    horizontal=True, key="inv_chart_mode")
                st.session_state["_inv_mode_saved"] = inv_mode

                plot = long[long["Account"].isin(shown or [])]
                if plot.empty:
                    st.caption("Toggle at least one account above to draw the chart.")
                else:
                    if inv_mode.startswith("Percentage"):
                        # Each line rebased to its own first visible point.
                        parts, dropped = [], []
                        for label, g in plot.groupby("Account"):
                            g = g.sort_values("taken_at")
                            base = float(g.iloc[0]["value"])
                            if base <= 0:
                                dropped.append(label)
                                continue
                            parts.append(g.assign(
                                Amount=(g["value"] / base - 1.0) * 100.0))
                        plot = (pd.concat(parts, ignore_index=True)
                                if parts else plot.iloc[0:0])
                        if dropped:
                            st.caption(":gray[Omitted (zero value at range start): "
                                       + ", ".join(dropped) + "]")
                        y_enc = alt.Y("Amount:Q", title="% change from range start",
                                      axis=alt.Axis(format="+.1f"),
                                      scale=alt.Scale(zero=False, padding=24))
                        tt_amount = alt.Tooltip("Amount:Q", title="% change",
                                                format="+.2f")
                    else:
                        plot = plot.assign(Amount=plot["value"].astype(float))
                        y_enc = alt.Y("Amount:Q", title="",
                                      axis=alt.Axis(format="$,.0f"),
                                      scale=alt.Scale(zero=False, padding=24))
                        tt_amount = alt.Tooltip("Amount:Q", title="Value",
                                                format="$,.2f")

                    if plot.empty:
                        st.caption("Nothing to draw for this selection.")
                    else:
                        # Assembled exactly like the (working) net-worth chart:
                        # one mark_line layer PER series via transform_filter,
                        # axis spec on the line layers, bare-y points/selectors,
                        # explicit color scale — the single color-encoded-layer
                        # variant rendered with a broken y axis in Streamlit.
                        ax_fmt = {"1D": "%I:%M %p",
                                  "1W": "%m/%d"}.get(inv_tf, "%m/%d/%Y")
                        hover = alt.selection_point(fields=["taken_at"],
                                                    nearest=True,
                                                    on="pointermove", empty=False)
                        x_enc = alt.X("taken_at:T", title="",
                                      axis=alt.Axis(format=ax_fmt))
                        labels_plot = [l for l in all_labels
                                       if l in set(plot["Account"])]
                        PALETTE = ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728",
                                   "#9467bd", "#8c564b", "#e377c2", "#7f7f7f",
                                   "#bcbd22", "#17becf"]
                        color_scale = alt.Scale(
                            domain=labels_plot,
                            range=[PALETTE[i % len(PALETTE)]
                                   for i in range(len(labels_plot))])

                        def _acct_line(lbl):
                            return alt.Chart(plot).transform_filter(
                                alt.datum.Account == lbl
                            ).mark_line(strokeWidth=2).encode(
                                x=x_enc, y=y_enc,
                                color=alt.Color(
                                    "Account:N", scale=color_scale,
                                    legend=alt.Legend(title=None, orient="top")))

                        inv_chart = _acct_line(labels_plot[0])
                        for lbl in labels_plot[1:]:
                            inv_chart = inv_chart + _acct_line(lbl)
                        pts = alt.Chart(plot).mark_point(
                            filled=True, size=30,
                        ).encode(x=x_enc,
                                 y=alt.Y("Amount:Q",
                                         scale=alt.Scale(zero=False, padding=24)),
                                 color=alt.Color("Account:N", scale=color_scale,
                                                 legend=None))
                        selectors = alt.Chart(plot).mark_point(opacity=0).encode(
                            x=x_enc, y="Amount:Q",
                            tooltip=[alt.Tooltip("taken_at:T", title="Date",
                                                 format="%m/%d/%Y %I:%M:%S %p"),
                                     alt.Tooltip("Account:N", title="Account"),
                                     tt_amount],
                        ).add_params(hover)
                        rule = (alt.Chart(plot)
                                .mark_rule(color="#9ca3af", strokeDash=[4, 3])
                                .encode(x=x_enc).transform_filter(hover))
                        inv_chart = inv_chart + pts + selectors + rule
                        st.altair_chart(
                            inv_chart.properties(height=450).interactive(),
                            width="stretch")

    for acc in accts:
        with st.container(border=True):
            hc, mc = st.columns([2.6, 1.4])
            hc.markdown(f"**{acc['label']}**")
            hc.caption(f"{len(acc['names'])} holding(s)")
            # The account's value is its EQUITY — gross holdings minus any margin
            # loan borrowed against it. The delta compares equity to the base
            # snapshot's equity (its own captured margin), so a loan that grew or
            # shrank over the range moves the badge too, not just the number.
            acct_margin = margin_map.get(acc["label"], 0.0)
            mc.metric("Value", money(acc["value"] - acct_margin),
                      delta=_delta_str(acc["value"] - acct_margin,
                                       _baseline_equity(acc)),
                      label_visibility="collapsed")
            if acct_margin > 0:
                hc.markdown(esc(f":orange[Margin loan: {money(acct_margin)}  →  "
                                f"Assets: {money(acc['value'])}]"))
            if acc["gain"] is not None and acc["cost_basis"] > 0:
                g = acc["gain"]
                gp = g / acc["cost_basis"] * 100
                color = "green" if g >= 0 else "red"
                sign = "+" if g >= 0 else ""
                hc.markdown(esc(f":{color}[Unrealized G/L: **{sign}{money(g)}** "
                                f"({gp:+.1f}%) on {money(acc['cost_basis'])} basis]"))

            h = acc["holdings"]
            tbl = pd.DataFrame({
                "Holding": h["name"],
                "Ticker": h.get("ticker"),
                "Shares": pd.to_numeric(h.get("shares"), errors="coerce"),
                "Value": pd.to_numeric(h["value"], errors="coerce"),
                "Cost basis": pd.to_numeric(h.get("cost_basis"), errors="coerce"),
            })
            tbl["G/L"] = tbl["Value"] - tbl["Cost basis"]
            st.dataframe(
                tbl, hide_index=True, width="stretch",
                height=(len(tbl) + 1) * 35 + 2,
                column_config={
                    "Shares": st.column_config.NumberColumn("Shares", format="%.4f"),
                    "Value": st.column_config.NumberColumn("Value", format="$%.2f"),
                    "Cost basis": st.column_config.NumberColumn("Cost basis",
                                                                format="$%.2f"),
                    "G/L": st.column_config.NumberColumn("G/L", format="$%.2f"),
                })

    if base_items is None and not hist.empty:
        st.caption("No per-account history at the start of this range yet — deltas "
                   "appear once snapshots taken by the current version cover it.")

