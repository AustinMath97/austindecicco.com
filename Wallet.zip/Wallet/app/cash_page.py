"""
cash_page.py — the Cash Accounts page plus the cached 30-day projections it
shares with the Overview's low-balance alert. Split out of dashboard.py.
"""

from itertools import groupby

import altair as alt
import pandas as pd
import streamlit as st

import accounts as accts
import cards
import db
from ui import pct
from utils import esc, fmt_date, money

# --- accounts page ---------------------------------------------------------

@st.cache_data(show_spinner=False)
def cached_projections(assets, income, expenses, start, end):
    """The 30-day projection of every cash account, cached per data-state:
    st.cache_data hashes the DataFrames, so an edit recomputes while a plain rerun
    (every widget interaction) reuses the result. Shared by the Overview low-balance
    banner and the Accounts page so one render computes it at most once."""
    return accts.project_all(assets, income, expenses, start, end)


def low_balance_alerts(assets, income, expenses):
    """Shared low-balance check used by the Overview banner and the Accounts page:
    accounts projected to dip below $0 in the rolling 30-day window."""
    start, end = accts.default_window()
    return [{"name": p["name"], "min_balance": p["min_balance"], "min_date": p["min_date"]}
            for p in cached_projections(assets, income, expenses, start, end)
            if p["dips_below_zero"]]


def accounts_page():
    st.header("Cash Accounts")
    assets = db.load_df("assets")
    income = db.load_df("income")
    expenses = db.load_df("expenses")

    start, end = accts.default_window()
    projections = cached_projections(assets, income, expenses, start, end)

    st.caption(esc(
        f"Projected daily balances for your cash accounts over the next 30 days "
        f"({fmt_date(start)} → {fmt_date(end)}). "
        "An account projected to fall below $0 is flagged here and on "
        "the Overview page."))

    if not projections:
        st.info("No cash accounts yet. Add a **Cash & Bank Account** on the Assets page "
                "to project its balance.")
        return

    at_risk = [p for p in projections if p["dips_below_zero"]]
    if at_risk:
        lines = " · ".join(
            f"**{p['name']}** dips to {money(p['min_balance'])} on {fmt_date(p['min_date'])}"
            for p in at_risk)
        st.error(esc(f"⚠️ Low-balance alert — {lines}."))
    else:
        st.success("All cash accounts stay above $0 through the projection window.")

    # Projections carry account NAMES (the identity auto-deposits/drafts match
    # by); map them back to their asset rows so each card can open its editor.
    _aid = {str(r["name"]): int(r["id"]) for _, r in assets.iterrows()}

    for p in projections:
        with st.container(border=True):
            hc, he = st.columns([6, 1], vertical_alignment="center")
            hc.subheader(p["name"])
            _rid = _aid.get(p["name"])
            if _rid is not None and he.button(
                    "Edit ↗", key=f"cashpg_edit_{_rid}", width="stretch",
                    help="Edit the underlying asset record"):
                cards.request_edit("assets", _rid)
                st.rerun()          # consume_pending_edit opens the editor
            c1, c2, c3, c4 = st.columns(4)
            c1.metric("Current balance", money(p["start_balance"]))
            c2.metric("Projected low", money(p["min_balance"]))
            c3.metric("End of window", money(p["end_balance"]))
            c4.metric("APY", pct(p["apy"], 2) if p["apy"] else "—")
            if p["dips_below_zero"]:
                st.error(esc(f"Projected to fall to {money(p['min_balance'])} on "
                             f"{fmt_date(p['min_date'])} — a shortfall of "
                             f"{money(-p['min_balance'])}."))

            # Daily balance line, with a red zero baseline so a dip is unmistakable.
            chart_df = pd.DataFrame([{"Date": r["date"], "Balance": r["balance"]}
                                     for r in p["rows"]])
            base = alt.Chart(chart_df).encode(
                x=alt.X("Date:T", title="", axis=alt.Axis(format="%m/%d")),
                y=alt.Y("Balance:Q", title="", axis=alt.Axis(format="$,.0f"),
                        scale=alt.Scale(zero=True)),
                tooltip=[alt.Tooltip("Date:T", format="%m/%d/%Y"),
                         alt.Tooltip("Balance:Q", format="$,.2f")])
            area = base.mark_area(opacity=0.12, color="#1f77b4")
            line = base.mark_line(color="#1f77b4", strokeWidth=2)
            zero = (alt.Chart(pd.DataFrame({"y": [0]}))
                    .mark_rule(color="#d62728", strokeDash=[4, 4], size=1.5)
                    .encode(y="y:Q"))
            st.altair_chart((area + line + zero), width="stretch")

            # Itemized ledger, grouped into a subtable per date. Each transaction (auto-
            # deposit, auto-draft, interest posting) shows what drove it and the balance
            # after; the date header carries the day's net change and end balance.
            ledger = p["ledger"]
            _FLOW = {"deposit": "⬆ Deposit", "draft": "⬇ Draft", "interest": "✦ Interest"}
            n_days = len({e["date"] for e in ledger})
            with st.expander(f"Cash-flow detail — {len(ledger)} transaction(s) over {n_days} day(s)"):
                if ledger:
                    for dt, _grp in groupby(ledger, key=lambda e: e["date"]):
                        grp = list(_grp)
                        day_net = sum(e["amount"] for e in grp)
                        end_bal = grp[-1]["balance"]
                        net_str = money(day_net) if day_net < 0 else f"+{money(day_net)}"
                        color = "red" if day_net < 0 else "green"
                        st.markdown(
                            f"**{fmt_date(dt)}**  ·  net :{color}[{esc(net_str)}]  ·  "
                            f"end balance {esc(money(end_bal))}")
                        tdf = pd.DataFrame([{
                            "Flow": _FLOW.get(e["kind"], e["kind"].title()),
                            "Item": e["label"],
                            "Description": e["detail"],
                            "In": e["amount"] if e["amount"] > 0 else None,
                            "Out": -e["amount"] if e["amount"] < 0 else None,
                            "Balance": e["balance"],
                        } for e in grp])
                        st.dataframe(
                            tdf,
                            column_config={
                                "In":  st.column_config.NumberColumn("In", format="$%.2f"),
                                "Out": st.column_config.NumberColumn("Out", format="$%.2f"),
                                "Balance": st.column_config.NumberColumn("Balance", format="$%.2f"),
                            },
                            hide_index=True, width="stretch",
                            # rows are 35px in Streamlit 1.58 (+1 row for the
                            # header, +2px border) — 36 left a dead sliver/scrollbar
                            height=(len(grp) + 1) * 35 + 2)
                    st.caption("Grouped by date. Interest posts first each day, then "
                               "deposits, then drafts; each row's balance is after that "
                               "transaction.")
                else:
                    st.caption("No auto-deposits, auto-drafts, or interest postings hit "
                               "this account in the window. Mark income auto-deposited / "
                               "expenses auto-drafted to this account, or set its interest "
                               "schedule, to project its cash flow.")

