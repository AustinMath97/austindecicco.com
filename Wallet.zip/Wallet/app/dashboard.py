"""
dashboard.py — the Streamlit presentation layer.

Run it with:   streamlit run dashboard.py

This script reads everything fresh from the database on each run (Streamlit
re-executes top to bottom on every interaction), computes metrics via stats.py,
and renders them. The DB is the only place state lives.
"""

from datetime import date

import streamlit as st

import calendar_page as cal_page
import cards
import cash_page
import credit_page
import data_management as datamgmt
import db
import economic_page
import edit_dialogs
import forms
import widgets
import investments
import overview
import prices
import record_graph
import taxes_page
import trades

st.set_page_config(page_title="Finance Dashboard", layout="wide")
db.init_db()
# Re-derive every margin loan's APR from its formula before anything reads the
# debts — but only when the economic variables actually changed (or once per
# session): the formulas depend on nothing else, so re-evaluating them on every
# click is pure waste. Restoring a backup clears the marker (data_management),
# since restored formulas need a pass even if the variables happen to match.
_econ = db.economic_variables()
if st.session_state.get("_margin_econ_seen") != _econ:
    db.refresh_margin_aprs(_econ)
    st.session_state["_margin_econ_seen"] = _econ

# Credit-card-minimum expenses mirror their card's debt record. Card edits sync
# them at save time (db.update_row); this once-a-day pass covers statement-day
# recomputes and anything that rewrote debts in bulk (a restore or seed).
# Restoring a backup clears the marker (data_management) so it re-runs at once.
if st.session_state.get("_cc_min_seen") != date.today().isoformat():
    db.sync_cc_min_expenses()
    st.session_state["_cc_min_seen"] = date.today().isoformat()

# Launch sequence (once per browser session): when a net-worth snapshot is due — the most
# recent is over an hour old and the portfolio isn't empty — OR a watch-list record has
# gone stale, first prompt to review the stale records, then capture the snapshot (which
# prices the portfolio first). The slow, network-bound price fetch only runs when the
# snapshot is actually taken, so a normal rerun never triggers it. See
# data_management.run_launch_sequence.
datamgmt.run_launch_sequence()


# --- card-based table pages ------------------------------------------------

def assets_page():
    st.header("Assets")
    # One flex row: content-width buttons snug on the left (no stretched
    # whitespace inside them) and the search box — rendered into `srch` by
    # cards.asset_cards — filling the rest, all vertically centered (the keyup
    # iframe is height-clamped to button height in cards._CARD_CSS). Click
    # handling happens after the row so spinners/messages don't render inside it.
    # "distribute" (space-between) on a two-child row: the button group hugs the
    # left edge, the search box the right — native flex, no CSS.
    with st.container(horizontal=True, horizontal_alignment="distribute",
                      vertical_alignment="center"):
        with st.container(horizontal=True, width="content",
                          vertical_alignment="center"):
            add_clicked = st.button("**+ Add Asset**", type="primary")
            buysell_clicked = st.button("**Buy/Sell Shares/Units**")
            refresh_clicked = st.button("**Refresh market prices**")
        srch = st.container(width=420)      # a sane search width, not the whole row
    if add_clicked:
        # reset the keyed vehicle / interest-schedule fields and link picker for a fresh open
        widgets.clear_widget_state("add_veh_", "add_aint_", "lnk_assets_")
        forms.add_asset()
    if buysell_clicked:
        widgets.clear_widget_state("bs_")        # drop the previous open's widgets
        # Bump the per-open counter so the dialog's widgets get a fresh key
        # prefix each open (see trades.buy_sell_dialog) — without it a dismissed
        # dialog's Sell/Bulk pick lingers in the toggle on reopen. Kept outside
        # the "bs_" namespace so clear_widget_state above doesn't reset it.
        st.session_state["_bs_open"] = st.session_state.get("_bs_open", 0) + 1
        trades.buy_sell_dialog()
    if refresh_clicked:
        with st.spinner("Fetching market prices…"):
            result = prices.refresh_asset_prices()
        # No rerun needed: the refresh ran before the cards render below, so they
        # already show the new values — and the message survives to be read.
        st.info(prices.refresh_summary_msg(result))
    st.write("")
    cards.asset_cards(search_slot=srch)


def debts_page():
    st.header("Debts")
    # Content-width button + the search box (filled by cards.debt_cards) in one
    # centered flex row — same layout as the Assets page.
    with st.container(horizontal=True, horizontal_alignment="distribute",
                      vertical_alignment="center"):
        add_clicked = st.button("**+ Add Debt**", type="primary")
        srch = st.container(width=420)
    if add_clicked:
        widgets.clear_widget_state("lnk_debts_")   # reset the link picker for a fresh open
        forms.add_debt()
    st.write("")
    cards.debt_cards(search_slot=srch)


def income_page():
    st.header("Income")
    with st.container(horizontal=True, horizontal_alignment="distribute",
                      vertical_alignment="center"):
        add_clicked = st.button("**+ Add Income**", type="primary")
        srch = st.container(width=420)
    if add_clicked:
        # reset the keyed schedule / amount fields and the link picker for a fresh open
        widgets.clear_widget_state("add_inc_", "lnk_income_", "axi_")
        forms.add_income()
    st.write("")
    cards.income_cards(search_slot=srch)


def expenses_page():
    st.header("Expenses")
    with st.container(horizontal=True, horizontal_alignment="distribute",
                      vertical_alignment="center"):
        add_clicked = st.button("**+ Add Expense**", type="primary")
        srch = st.container(width=420)
    if add_clicked:
        # reset the keyed amount/freq/due fields and the link picker for a fresh open
        widgets.clear_widget_state("lnk_expenses_", "axe_")
        forms.add_expense()
    st.write("")
    cards.expense_cards(search_slot=srch)


# --- router ----------------------------------------------------------------

def main():
    # If an "Edit ↗" on a linked card was clicked, open that record's editor —
    # done here so the jump works from any page or dialog.
    edit_dialogs.consume_pending_edit()
    # If a linked record (or calendar item) was clicked, open its card pop-up here —
    # before the page renders — so it replaces any pop-up the click closed and its
    # widget keys are namespaced ahead of the same card drawing on the page.
    cards.consume_pending_view()
    # Same, for a group clicked on the Group Map (opens that group's card pop-up).
    record_graph.consume_pending_group_view()

    # Tighten record-card spacing app-wide (scoped to the cards' own key class).
    cards.inject_card_css()

    # Trim the top-right toolbar: hide the Deploy button, and reduce the ⋮ menu to
    # just the light/dark theme switcher. In Streamlit 1.58 the theme options sit in
    # their own group (data-testid="stThemeSwitcher", role="menuitemradio"); every
    # other action (Rerun, Print, Record, About, Settings toggles…) is role="menuitem"
    # / "menuitemcheckbox" with stMainMenuDivider separators, and the "Made with
    # Streamlit" version line is a sibling of the menu list. We hide all of those and
    # keep the theme group.
    st.markdown(
        """
        <style>
        [data-testid="stAppDeployButton"], [data-testid="stDeployButton"] {
            display: none !important;
        }
        [data-testid="stMainMenuList"] [role="menuitem"],
        [data-testid="stMainMenuList"] [role="menuitemcheckbox"],
        [data-testid="stMainMenuList"] [data-testid="stMainMenuDivider"],
        [data-testid="stMainMenuList"] ~ * {
            display: none !important;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    # Show any message queued (via flash) before the st.rerun() that brought us here.
    _fm = st.session_state.pop("_flash_msg", None)
    if _fm:
        st.toast(_fm)

    # Native sectioned navigation (replaces the old sidebar radio): grouped
    # pages with Material icons, a real URL per page, and working browser
    # back/forward. st.navigation must run every script run — it both renders
    # the menu and returns the page to execute.
    pg = st.navigation({
        "": [
            st.Page(overview.overview_page, title="Overview",
                    icon=":material/dashboard:", url_path="overview", default=True),
            st.Page(cal_page.calendar_page, title="Calendar",
                    icon=":material/calendar_month:", url_path="calendar"),
            st.Page(record_graph.groups_page, title="Groups",
                    icon=":material/hub:", url_path="groups"),
        ],
        "Records": [
            st.Page(assets_page, title="Assets",
                    icon=":material/account_balance:", url_path="assets"),
            st.Page(debts_page, title="Debts",
                    icon=":material/credit_card:", url_path="debts"),
            st.Page(income_page, title="Income",
                    icon=":material/payments:", url_path="income"),
            st.Page(expenses_page, title="Expenses",
                    icon=":material/receipt_long:", url_path="expenses"),
        ],
        "Accounts": [
            st.Page(cash_page.accounts_page, title="Cash Accounts",
                    icon=":material/savings:", url_path="cash-accounts"),
            st.Page(credit_page.credit_accounts_page, title="Credit Accounts",
                    icon=":material/credit_card:", url_path="credit-accounts"),
            st.Page(investments.investment_accounts_page, title="Investment Accounts",
                    icon=":material/trending_up:", url_path="investments"),
        ],
        "Planning": [
            st.Page(taxes_page.taxes_page, title="Taxes",
                    icon=":material/request_quote:", url_path="taxes"),
            st.Page(economic_page.economic_variables_page, title="Economic Variables",
                    icon=":material/percent:", url_path="economic"),
        ],
        "Manage": [
            st.Page(datamgmt.data_management_page, title="Data Management",
                    icon=":material/database:", url_path="data-management"),
        ],
    }, expanded=True)

    # Navigating away abandons any inline delete confirmation that was left open —
    # without this, returning to the page would reopen that card on the confirm.
    if st.session_state.get("_cur_page") != pg.title:
        st.session_state["_cur_page"] = pg.title
        cards.clear_delete_confirms()

    pg.run()


main()
