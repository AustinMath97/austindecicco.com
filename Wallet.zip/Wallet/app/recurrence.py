"""
recurrence.py — the schedule model for dated, repeating cash flows (income).

A *schedule* says when money arrives. The core entry point,
``occurrences_in_month(sched, year, month)``, returns the day-of-month integers
the schedule actually fires on **in that specific month** — so an "every
Wednesday" schedule lands on the real Wednesdays of that month, not on fixed day
numbers that drift off the weekday from one month to the next. That drift was
the whole reason a day-of-month-only model couldn't represent weekly or biweekly
pay.

Everything here is pure (no Streamlit, no DB, no pandas import), so it can be
unit-tested against a calendar by hand — see test_schedule.py. Rows passed to
``from_row`` may be pandas Series, so NaN is handled without importing pandas.

Schedule types
--------------
  weekly          — every week on ``weekday`` (0=Mon .. 6=Sun)
  biweekly        — every other week, phase + weekday taken from ``anchor`` date
  monthly_weekday — the ``ordinal``-th ``weekday`` of the month (ordinal -1 = last)
  semimonthly     — the given ``month_days`` every month (e.g. 1 & 15)
  monthly         — a single day of the month (also stored in ``month_days``)
  quarterly       — ``month_days`` but only in ``months`` (e.g. 15th of 3/6/9/12)
  annual          — one month/day each year, taken from ``anchor``
  one_time        — a single calendar date, taken from ``anchor``
  none            — never shown on the calendar

A schedule dict has keys: ``type``, ``weekday`` (int|None), ``ordinal``
(int|None), ``anchor`` (date|ISO str|None), ``month_days`` (list[int]|csv str),
``months`` (list[int]|csv str).
"""

from __future__ import annotations

import calendar
from datetime import date
from typing import TYPE_CHECKING

if TYPE_CHECKING:                     # pandas is only needed for type hints --
    import pandas as pd               # this module stays pandas-free at runtime

from utils import ordinal as _ordinal    # shared implementation (utils is also pure)

# Schedule type constants.
WEEKLY = "weekly"
BIWEEKLY = "biweekly"
MONTHLY_WEEKDAY = "monthly_weekday"
SEMIMONTHLY = "semimonthly"
MONTHLY = "monthly"
QUARTERLY = "quarterly"
ANNUAL = "annual"
ONE_TIME = "one_time"
NONE = "none"

ALL_TYPES = [WEEKLY, BIWEEKLY, SEMIMONTHLY, MONTHLY, MONTHLY_WEEKDAY,
             QUARTERLY, ANNUAL, ONE_TIME, NONE]

WEEKDAY_NAMES = ["Monday", "Tuesday", "Wednesday", "Thursday",
                 "Friday", "Saturday", "Sunday"]

MONTH_NAMES = ["January", "February", "March", "April", "May", "June",
               "July", "August", "September", "October", "November", "December"]

# Coarse cadence label kept on the row for card/table display continuity.
FREQUENCY_LABEL = {
    WEEKLY: "Weekly", BIWEEKLY: "Every two weeks", SEMIMONTHLY: "Semi-monthly",
    MONTHLY: "Monthly", MONTHLY_WEEKDAY: "Monthly", QUARTERLY: "Quarterly",
    ANNUAL: "Annual", ONE_TIME: "One-time", NONE: "Irregular",
}

ORDINAL_LABEL = {1: "First", 2: "Second", 3: "Third", 4: "Fourth", -1: "Last"}


# ---------------------------------------------------------------------------
# NaN-safe coercion (rows may be pandas Series; avoid importing pandas here)
# ---------------------------------------------------------------------------

def _is_nan(v: object) -> bool:
    return isinstance(v, float) and v != v


def _opt_int(v: object) -> int | None:
    """An int, or None for blank/NaN/non-numeric."""
    if v is None or _is_nan(v):
        return None
    s = str(v).strip()
    if not s or s.lower() in ("nan", "none"):
        return None
    try:
        return int(float(s))
    except (TypeError, ValueError):
        return None


def _opt_str(v: object) -> str:
    if v is None or _is_nan(v):
        return ""
    s = str(v).strip()
    return "" if s.lower() in ("nan", "none") else s


def _int_list(v: object) -> list[int]:
    """A csv string or list → list[int]; ignores blanks/non-numeric parts."""
    if isinstance(v, (list, tuple)):
        return [int(x) for x in v if str(x).strip().lstrip("-").isdigit()]
    out = []
    for part in _opt_str(v).split(","):
        part = part.strip()
        if part.lstrip("-").isdigit():
            out.append(int(part))
    return out


def _to_date(v: object) -> date | None:
    if isinstance(v, date):
        return v
    s = _opt_str(v)
    if not s:
        return None
    try:
        return date.fromisoformat(s[:10])
    except ValueError:
        return None


# ---------------------------------------------------------------------------
# Build a normalized schedule dict from a stored row (dict or pandas Series)
# ---------------------------------------------------------------------------

def from_row(row: dict | pd.Series) -> dict:
    """Normalize a stored income row into a schedule dict. Legacy rows that
    predate the schedule columns carry only day-of-month ints in ``pay_days``;
    treat those as a semimonthly (fixed days each month) schedule so they keep
    rendering exactly as before."""
    get = row.get if hasattr(row, "get") else (lambda k, d=None: None)
    stype = _opt_str(get("schedule_type")).lower()
    month_days = _int_list(get("pay_days"))
    if stype not in ALL_TYPES or not stype:
        stype = SEMIMONTHLY if month_days else NONE
    return {
        "type": stype,
        "weekday": _opt_int(get("weekday")),
        "ordinal": _opt_int(get("week_ordinal")),
        "anchor": _to_date(get("anchor_date")),
        "month_days": month_days,
        "months": _int_list(get("months")),
    }


# ---------------------------------------------------------------------------
# Core: which days of a given month does the schedule fire on?
# ---------------------------------------------------------------------------

def _weekday_days(year: int, month: int, weekday: int) -> list[int]:
    _, ndays = calendar.monthrange(year, month)
    return [d for d in range(1, ndays + 1)
            if date(year, month, d).weekday() == weekday]


def occurrences_in_month(sched: dict, year: int, month: int) -> list[int]:
    """Sorted, de-duplicated day-of-month ints the schedule fires on in
    (year, month). Days from month-day rules are clamped to the month length
    (so a "31st" rule lands on the last day of a short month)."""
    stype = str(sched.get("type") or NONE).strip().lower()
    if stype in ("", NONE):
        return []

    _, ndays = calendar.monthrange(year, month)
    days = set()

    if stype == WEEKLY:
        wd = sched.get("weekday")
        anchor = _to_date(sched.get("anchor"))
        if wd is not None:
            # Nothing fires before the anchor (the first pay date) — matching
            # the annual/one_time gating below.
            days.update(d for d in _weekday_days(year, month, int(wd))
                        if anchor is None or date(year, month, d) >= anchor)

    elif stype == BIWEEKLY:
        anchor = _to_date(sched.get("anchor"))
        if anchor is not None:
            for d in range(1, ndays + 1):
                delta = (date(year, month, d) - anchor).days
                # delta >= 0: Python's modulo is non-negative for negative
                # deltas too, so without the gate a FUTURE anchor would fire
                # 14, 28… days before its first pay date.
                if delta >= 0 and delta % 14 == 0:
                    days.add(d)

    elif stype == MONTHLY_WEEKDAY:
        wd, ordn = sched.get("weekday"), sched.get("ordinal")
        if wd is not None and ordn is not None:
            matches = _weekday_days(year, month, int(wd))
            ordn = int(ordn)
            if matches:
                if ordn == -1:
                    days.add(matches[-1])
                elif 1 <= ordn <= len(matches):
                    days.add(matches[ordn - 1])

    elif stype in (SEMIMONTHLY, MONTHLY, QUARTERLY):
        if stype == QUARTERLY:
            months = _int_list(sched.get("months"))
            if not months:
                # No month selection saved: derive a quarter cycle from the anchor
                # month (default Jan) rather than degrading to firing every month.
                anchor = _to_date(sched.get("anchor"))
                base = anchor.month if anchor is not None else 1
                months = [(base - 1 + 3 * k) % 12 + 1 for k in range(4)]
            if month not in months:
                return []
        for d in _int_list(sched.get("month_days")):
            days.add(min(max(d, 1), ndays))

    elif stype == ANNUAL:
        anchor = _to_date(sched.get("anchor"))
        # The anchor also dates the first occurrence: an annual payment anchored
        # 2027-06-20 doesn't exist in June 2026 (one_time already checks its year).
        if anchor is not None and anchor.month == month and year >= anchor.year:
            days.add(min(max(anchor.day, 1), ndays))

    elif stype == ONE_TIME:
        anchor = _to_date(sched.get("anchor"))
        if anchor is not None and anchor.year == year and anchor.month == month:
            days.add(min(max(anchor.day, 1), ndays))

    return sorted(days)


# ---------------------------------------------------------------------------
# Human-readable summary + coarse frequency label
# ---------------------------------------------------------------------------

def frequency_label(stype: str | None) -> str:
    return FREQUENCY_LABEL.get(str(stype or NONE), "Irregular")


def occurrences_per_year(sched: dict) -> float:
    """Roughly how many times a year this schedule fires — the factor that turns a
    per-occurrence amount into an annual run-rate (and back, ÷12, into a monthly
    burn). It equals the number of draft/deposit days the schedule places in a
    typical year, so annualized totals stay in lockstep with the day-by-day
    Accounts projection that uses ``occurrences_in_month``.

    ``one_time``/``none`` aren't a recurring run-rate, so they annualize to 0 (a
    one-time charge still lands on its date in the projection/calendar — it just
    isn't counted as ongoing monthly burn)."""
    stype = str(sched.get("type") or NONE).strip().lower()
    if stype == WEEKLY:
        return 52.0
    if stype == BIWEEKLY:
        return 26.0
    if stype == MONTHLY_WEEKDAY:
        return 12.0
    if stype in (SEMIMONTHLY, MONTHLY):
        # One draft per chosen day, every month (a plain monthly with no day saved
        # still bills monthly → 12).
        n = len(_int_list(sched.get("month_days")))
        return 12.0 * (n if n else 1)
    if stype == QUARTERLY:
        days = len(_int_list(sched.get("month_days"))) or 1
        months = _int_list(sched.get("months"))
        # No months saved means the every-3-months default (4 a year); see
        # occurrences_in_month, which derives the same quarter cycle.
        return float(days * (len(months) if months else 4))
    if stype == ANNUAL:
        return 1.0
    return 0.0    # one_time / none — not a recurring run-rate


def describe(sched: dict) -> str:
    """One-line plain-English summary for cards and notes. Returns "" when the
    schedule is too incomplete to ever fire (a day-of-month type with no days),
    so callers can show their 'finish the fields' guidance instead of a label
    like "Monthly" that the calendar will never honor."""
    stype = str(sched.get("type") or NONE).strip().lower()
    # NaN-safe and range-checked: a corrupt stored weekday/ordinal must not
    # crash every page that renders this row's description.
    wd = _opt_int(sched.get("weekday"))
    wname = WEEKDAY_NAMES[wd] if wd is not None and 0 <= wd <= 6 else "weekday"

    if stype == WEEKLY:
        return f"Every {wname}"
    if stype == BIWEEKLY:
        anchor = _to_date(sched.get("anchor"))
        day = WEEKDAY_NAMES[anchor.weekday()] if anchor else wname
        return f"Every other {day}"
    if stype == MONTHLY_WEEKDAY:
        ordn = _opt_int(sched.get("ordinal"))
        ord_name = ORDINAL_LABEL.get(ordn if ordn is not None else 0, "")
        return f"{ord_name} {wname} of the month".strip()
    if stype in (SEMIMONTHLY, MONTHLY):
        md = _int_list(sched.get("month_days"))
        if md:
            return " & ".join(_ordinal(d) for d in sorted(md)) + " of the month"
        return ""                  # no days saved: never fires in any month
    if stype == QUARTERLY:
        md = _int_list(sched.get("month_days"))
        if not md:
            return ""              # no days saved: never fires in any month
        months = _int_list(sched.get("months"))
        day_part = _ordinal(md[0])
        mon_part = ", ".join(MONTH_NAMES[m - 1][:3] for m in sorted(months) if 1 <= m <= 12)
        if day_part and mon_part:
            return f"{day_part} of {mon_part}"
        return "Quarterly"
    if stype == ANNUAL:
        anchor = _to_date(sched.get("anchor"))
        return f"Yearly on {MONTH_NAMES[anchor.month - 1][:3]} {anchor.day}" if anchor \
            else "Once a year"
    if stype == ONE_TIME:
        anchor = _to_date(sched.get("anchor"))
        return f"One-time on {anchor.strftime('%m/%d/%Y')}" if anchor else "One-time"
    return ""
