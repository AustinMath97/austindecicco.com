@echo off
rem ===========================================================================
rem  Start Wallet.bat - one-click launcher for the Wallet finance dashboard.
rem
rem  First run: installs 'uv' (a tiny, self-contained Python/dependency manager),
rem  which downloads a private Python runtime and the app's pinned libraries from
rem  the internet, then starts the app. Nothing is installed system-wide and no
rem  admin rights are needed. Later runs detect the local .venv and start in
rem  seconds. Everything lives inside this folder; delete the folder to remove.
rem
rem  The app's code and requirements live in the "app" subfolder; this launcher
rem  and its .venv sit alongside it at the top level.
rem ===========================================================================
setlocal enableextensions
cd /d "%~dp0"

set "VENV=.venv"
set "STREAMLIT=%VENV%\Scripts\streamlit.exe"
set "APP=app"

rem --- fast path: already set up ---------------------------------------------
if exist "%STREAMLIT%" goto run

echo ===========================================================================
echo   Wallet - first-time setup
echo ===========================================================================
echo This one-time step downloads a private Python runtime and the app's
echo libraries (a few hundred MB) and may take several minutes. Future
echo launches start in seconds. An internet connection is required now.
echo.

rem --- ensure the setup helper 'uv' is available -----------------------------
rem The uv installer drops the binary in %USERPROFILE%\.local\bin (newer) or
rem \.cargo\bin (older); add both so we can use it in this same window.
set "PATH=%USERPROFILE%\.local\bin;%USERPROFILE%\.cargo\bin;%PATH%"
where uv >nul 2>nul
if %errorlevel%==0 goto haveuv

echo Installing setup helper (uv)...
powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://astral.sh/uv/install.ps1 | iex"
where uv >nul 2>nul
if %errorlevel%==0 goto haveuv

echo.
echo Automatic setup could not run. Please install Python 3 from
echo https://www.python.org/downloads/ and then start this file again.
start "" https://www.python.org/downloads/
pause
exit /b 1

:haveuv
echo Creating environment (downloading Python if needed)...
uv venv "%VENV%" --python 3.14
if errorlevel 1 goto fail
echo Installing libraries (this is the long part)...
uv pip install --python "%VENV%\Scripts\python.exe" -r "%APP%\requirements.lock"
if errorlevel 1 goto fail

:run
echo.
echo Starting Wallet... your web browser will open in a moment.
echo Keep this window open while you use the app; close it to quit.
echo.
"%STREAMLIT%" run "%APP%\dashboard.py"
exit /b 0

:fail
echo.
echo Setup failed - please check your internet connection and try again.
echo If it keeps failing, install Python from python.org and rerun this file.
pause
exit /b 1
