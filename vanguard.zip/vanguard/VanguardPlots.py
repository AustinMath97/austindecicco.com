import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from Vanguard import VANGUARD_ETFS, YFINANCE_COLUMNS
from VanguardStats import vanguard_columns


def pair_returns(ticker_a, ticker_b, column='Adj Close', columns=None) -> pd.DataFrame:
    """Daily percent changes for two tickers over the dates they share.

    Args:
        ticker_a: One of VANGUARD_ETFS, case-sensitive.
        ticker_b: One of VANGUARD_ETFS, case-sensitive.
        column: One of YFINANCE_COLUMNS. 'Adj Close' gives total return,
            'Close' price-only return.
        columns: Column name -> date-indexed DataFrame of tickers. Defaults to
            the full-history vanguard_columns.

    Returns:
        A Date-indexed DataFrame with one column per ticker, holding only the
        dates where both funds traded.
    """
    for ticker in (ticker_a, ticker_b):
        if ticker not in VANGUARD_ETFS:
            raise ValueError(f"{ticker!r} is not a Vanguard ETF in VANGUARD_ETFS")
    if column not in YFINANCE_COLUMNS:
        raise ValueError(f"Unknown column {column!r}; expected one of {sorted(YFINANCE_COLUMNS)}")
    if ticker_a == ticker_b:
        raise ValueError(f"{ticker_a!r} paired with itself; correlation is always 1")

    if columns is None:
        columns = vanguard_columns

    # Drop to the shared dates first, so a gap in one fund doesn't turn into a
    # multi-day return in the other.
    both = columns[column][[ticker_a, ticker_b]].dropna()
    # A change from 0 is +/-inf; NaN keeps it out of the correlation.
    return both.pct_change().replace([np.inf, -np.inf], np.nan).dropna()


def rolling_pair_corr(ticker_a, ticker_b, window=252, column='Adj Close', columns=None) -> pd.Series:
    """Correlation of two tickers' daily returns over a moving window.

    Each point is the correlation of the `window` trading days ending that
    day, so the series shows how the relationship shifted over time rather
    than giving one number for the whole history.

    Args:
        ticker_a: One of VANGUARD_ETFS, case-sensitive.
        ticker_b: One of VANGUARD_ETFS, case-sensitive.
        window: Trading days per correlation, e.g. 252 for a rolling year.
        column: One of YFINANCE_COLUMNS, passed to pair_returns.
        columns: Column name -> DataFrame, passed to pair_returns.

    Returns:
        A Date-indexed Series of correlations, starting `window` days after
        the pair's first shared date.
    """
    if window < 2:
        raise ValueError(f"window must be at least 2 returns, got {window!r}")

    returns = pair_returns(ticker_a, ticker_b, column, columns)
    if len(returns) < window:
        raise ValueError(f"{ticker_a} and {ticker_b} share only {len(returns)} returns; "
                         f"not enough for a {window}-day window")

    # .rolling().corr() lines the two series up window by window. The first
    # window-1 days have too little data, so they come out NaN and are dropped.
    return returns[ticker_a].rolling(window).corr(returns[ticker_b]).dropna()


def plot_pair_corr(ticker_a, ticker_b, windows=(63, 252), column='Adj Close',
                   columns=None, ylim=(-1.05, 1.05), save_path=None, show=True) -> plt.Axes:
    """Plot rolling correlation between two tickers, one line per window.

    Args:
        ticker_a: One of VANGUARD_ETFS, case-sensitive.
        ticker_b: One of VANGUARD_ETFS, case-sensitive.
        windows: Window lengths in trading days. Short windows react quickly
            and jump around; long ones are smoother but lag.
        column: One of YFINANCE_COLUMNS, passed to rolling_pair_corr.
        columns: Column name -> DataFrame, passed to rolling_pair_corr.
        ylim: Y-axis limits. The default full scale keeps plots comparable,
            but flattens a pair that never leaves the high 0.9s; pass None to
            let matplotlib fit the data instead.
        save_path: Write the figure here instead of displaying it.
        show: Display the figure when no save_path is given. Pass False to
            build several figures and call plt.show() once yourself.

    Returns:
        The Axes, so the caller can adjust the plot before showing it.
    """
    fig, ax = plt.subplots(figsize=(11, 5))

    for window in sorted(windows):
        series = rolling_pair_corr(ticker_a, ticker_b, window, column, columns)
        ax.plot(series.index, series.to_numpy(), linewidth=1.2, label=f"{window}d")

    if ylim is not None:
        ax.set_ylim(*ylim)
    # Zero is the line that matters: above it the funds move together. It is
    # drawn after the limits are set, and only when it falls inside them, so
    # that it can't stretch an auto-scaled axis all the way down to 0.
    low, high = ax.get_ylim()
    if low <= 0 <= high:
        ax.axhline(0, color='black', linewidth=0.8)
    ax.set_title(f"{ticker_a} vs {ticker_b}: rolling correlation of daily {column} returns")
    ax.set_ylabel("correlation")
    ax.grid(alpha=0.3)
    ax.legend(title="window")
    fig.tight_layout()

    if save_path:
        fig.savefig(save_path, dpi=150)
    elif show:
        plt.show()
    return ax


if __name__ == '__main__':
    # Two pairs worth looking at: stocks against bonds, which moves around a
    # lot, and an ESG fund against the market it screens, which barely does.
    plot_pair_corr('VOO', 'BND', show=False)
    plot_pair_corr('ESGV', 'VTI', show=False)
    plt.show()
