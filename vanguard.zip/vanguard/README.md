# Vanguard ETF Pairs Trading Research

A small research pipeline over every active Vanguard ETF. It downloads daily
price history, measures how the funds move together, screens pairs for
cointegration, and backtests a long-only rotation between the two legs of a
pair. Everything it produces is a PDF report.

Nothing here places orders or connects to a broker. It is a research tool, and
the backtests are deliberately optimistic — see **Limitations** before reading
any return figure as achievable.

---

## Quick start

```bash
pip install pandas numpy yfinance matplotlib statsmodels scipy
python RunDaily.py
```

The first run downloads about 25 years of daily history for 116 tickers (a few
seconds) and caches it. A full run at the default settings takes well under a
minute; see **Runtime** for what makes it slower.

To look at one pair you already care about:

```bash
python VanguardPairReport.py BIV VGIT
```

---

## What it does, in order

1. **Download** daily OHLC, adjusted close, volume, dividends, splits and
   capital gains for every ticker in `VANGUARD_ETFS`, from Yahoo Finance.
2. **Align** them into one DataFrame per column type, indexed by date, so
   every fund shares one calendar with `NaN` before it existed.
3. **Correlate** every pair, on price levels and on daily returns, and rank
   the most correlated pairs.
4. **Screen** the top-ranked pairs for cointegration with the Engle-Granger
   test, run in both directions.
5. **Signal** on the price ratio's z-score against its rolling mean: when the
   ratio is unusually low the first fund is cheap, so buy it; unusually high
   and the second is the cheap one.
6. **Backtest** that rule long-only under several exit levels, and combine the
   pairs into an equally weighted portfolio.

The distinction driving the design: **correlation says two funds move
together, cointegration says the gap between them comes back.** Only the
second is tradable, and the two rarely agree — the most correlated pairs in
this universe are usually the *least* cointegrated, because near-identical
index funds drift apart without ever being pulled back.

---

## The files

Each is runnable on its own (`python <file>.py`) and importable.

| File | What it is | Writes |
|---|---|---|
| `Vanguard.py` | The ticker universe and the data layer: download, daily cache, column extraction, gap reporting. | `price_history.pkl` |
| `VanguardStats.py` | Aligned column DataFrames and the correlation matrices, on levels and on returns. | — |
| `VanguardReporter.py` | Correlation report: the most correlated pairs and their rolling correlation over time. | `VanguardCorrReport.pdf` |
| `VanguardPairsTrading.py` | The cointegration screen: Engle-Granger both ways, ratio z-scores, signal counts. | `VanguardPairsReport.pdf`, `screen_cache.pkl` |
| `VanguardPairsPortfolio.py` | Today's signals, the long-only backtest under each exit rule, and the combined portfolio. | `VanguardPairsPortfolioReport.pdf` |
| `VanguardPairReport.py` | One pair on demand, by ticker. Refuses if the pair isn't cointegrated. | `VanguardPair_<A>_<B>.pdf` |
| `VanguardPlots.py` | Rolling correlation charts for a pair; used by the reports, usable directly. | — |
| `RunDaily.py` | Runs the whole suite in order, each stage fed by the one before it. | all of the above |

### The three reports

**Correlation report** — the most correlated pairs by daily return, each with
its rolling correlation over its full shared history, so you can see whether a
relationship is stable or drifting.

**Cointegration screen** — every ranked pair tested, ordered by significance
rather than correlation. Page 1 is a contents list; pairs that pass get their
prices, test statistics and signal history charted.

**Portfolio report** — starts with what is actionable today: the live signals,
a tally of how many pairs point at buying each fund, and where every candidate
sits relative to its trigger. Then the backtest of those pairs under each exit
rule, the portfolio equity curve against a buy-and-hold benchmark, and a page
per pair.

---

## How the method works

**Universe.** `VANGUARD_ETFS` in `Vanguard.py` holds 116 active Vanguard ETFs,
verified against public listings. Edit the set to change what gets screened.

**Ranking.** Pairs are ranked on the correlation of daily *returns* over a
lookback window (252 trading days by default). Returns rather than prices: two
funds that both trend up correlate at 0.99 on price levels whether or not they
have anything to do with each other.

**Cointegration.** `statsmodels`' Engle-Granger test on the price levels. The
test regresses its first argument on its second and is not symmetric, so it is
run both ways and **the weaker p-value is the one reported** — a pair passes
only if it holds up whichever fund is treated as dependent. This matters: some
pairs move from p = 0.009 to p = 0.118 when swapped.

**Minimum history.** A pair needs at least 200 shared trading days
(`MIN_TEST_ROWS`, two rolling windows) to be tested at all. Shorter pairs are
excluded and named, rather than reported on a sample that can't support them.
Without this, recently launched funds dominate the results.

**Signal.** The z-score of the price ratio `A/B` against its 100-day rolling
mean. Below −2, the first fund is cheap; above +2, the second is. The
notebook-style dollar spread `A − B` was tried and dropped: it depends on the
price scale of each fund, assumes they move one for one, and failed its own
stationarity test on every pair here.

**Trading, long only.** No shorting. A signal names which fund to *own*: the
sleeve goes fully into it, sells when the z-score returns to the exit level,
and holds cash otherwise. Three exit rules are compared on identical entries —
`z = 0` (take the reversion), `z = ±1`, and `z = ±2` (hold until the pair says
to buy the other fund).

**Portfolio.** Equally weighted across the signalling pairs, rebalanced daily.
A sleeve in cash contributes nothing, which is why the portfolio's return sits
well below that of the funds it holds.

---

## Configuration

Most settings are module constants, near the top of their file:

| Constant | File | Default | Meaning |
|---|---|---|---|
| `ROLLING_WINDOW` | `VanguardPairsTrading.py` | 100 | Days in the z-score's rolling mean |
| `ENTRY_THRESHOLD` | `VanguardPairsTrading.py` | 2 | Z-score that triggers a signal |
| `P_VALUE_CUTOFF` | `VanguardPairsTrading.py` | 0.05 | Cointegration cutoff |
| `MIN_TEST_ROWS` | `VanguardPairsTrading.py` | 200 | Shortest testable shared history |
| `EXIT_THRESHOLDS` | `VanguardPairsPortfolio.py` | (0, 1, 2) | Exit rules compared |
| `SCREEN_PAIRS` | `RunDaily.py` | 150, overridden in `__main__` | Pairs ranked and tested |
| `LOOKBACK` | `RunDaily.py` | 252 | Days behind the correlation ranking |

Most functions take the same values as arguments, so nothing needs editing to
try something: `build_pairs_report(n=500, lookback=None)` screens 500 pairs
ranked over all history.

---

## Caching

Two caches, both on disk next to the code, both safe to delete:

- **`price_history.pkl`** — the day's download. Reused when it was written
  today, re-downloaded otherwise. Daily bars don't change until the next
  session closes, so a same-day cache is as current as a fresh download.
- **`screen_cache.pkl`** — the last cointegration screen, with the settings
  and timestamp that produced it. The portfolio report reuses it *whatever its
  age* so it doesn't repeat hundreds of regressions; every report that reads it
  prints when it was built. Pass `refresh_screen=True` to rebuild.

There are also in-process caches (`PAIR_FRAMES`, `PAIR_TESTS`) shared by every
module in a run, which is what makes `RunDaily.py` cheaper than running the
files separately.

---

## Runtime

Roughly, on a warm price cache:

| Stage | Time |
|---|---|
| Load cached prices, build columns and matrices | ~3s |
| Correlation report | ~4s |
| Cointegration screen, 150 pairs | ~15s |
| Cointegration screen, 2,000 pairs | ~5min |
| Portfolio report from a cached screen | ~1–5s |
| Single-pair report | ~1s |

The cointegration tests dominate: each pair costs two regressions, and the
cost scales with the number of pairs, not the universe size.

---

## Limitations

Read these before treating any number as a result.

- **No costs.** No commissions, spreads, slippage or taxes. Every return is an
  upper bound, and the strategy trades often enough for that to matter.
- **Multiple testing.** Screening 2,000 pairs at p < 0.05 expects about 100
  false positives by chance alone. Pairs that survive Bonferroni or
  Benjamini-Hochberg correction are a much smaller set; the screen reports raw
  p-values, so apply that discount yourself.
- **Short histories flatter.** The 200-day floor removes the worst of it, but
  a pair with 300 days of shared history and a tiny p-value is still weaker
  evidence than one with 4,000.
- **Adjusted prices are not traded prices.** `Adj Close` restates history at
  every dividend, so a cointegration verdict on it can differ from one on
  `Close`. For bond funds, where most of the return is income, this flips
  verdicts. Pass `column='Close'` to test what you'd actually trade.
- **The rolling window supplies the mean reversion.** Re-centering every 100
  days makes even a non-stationary ratio produce plausible entries: two
  independent random walks put through this rule generate roughly as many
  signals as a real pair. The cointegration test is the only thing separating
  signal from noise, which is why it gates everything.
- **The tested combination isn't quite the traded one.** Engle-Granger tests
  `A − βB` with β estimated from the data; the ratio signal effectively
  assumes a different weighting. They usually agree in direction, not exactly.
- **Long-only gives up the hedge.** Without shorting, a sleeve carries the
  market risk of whichever fund it holds, so drawdowns track the market rather
  than the spread.
- **Survivorship.** The universe is *currently active* Vanguard ETFs. Funds
  that closed are absent, and their absence flatters the history.

---

## Requirements

Built and tested on Python 3.14 with pandas 3.0.5, numpy 2.5.3, yfinance
1.7.0, matplotlib 3.11.2, statsmodels 0.15.0 and scipy 1.18.1. Nothing
depends on a recent language feature beyond the `X | None` type syntax, so
Python 3.10+ should work; pandas 2.x may warn on a couple of `concat` calls.

Data comes from Yahoo Finance through `yfinance`, which is unofficial and
occasionally changes shape or omits columns for individual funds. The loader
handles missing columns by filling them with `NaN` rather than failing.
