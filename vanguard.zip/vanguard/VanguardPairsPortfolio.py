from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages

from VanguardPairsTrading import (ENTRY_THRESHOLD, MIN_TEST_ROWS, PAIR_FRAMES,
                                  PAIR_TESTS, ROLLING_WINDOW, SCREEN_ROWS_PER_PAGE,
                                  TRADING_DAYS, load_screen, pair_frame, save_screen,
                                  screen_pairs)
from VanguardStats import vanguard_columns

# The finished report lands next to this module unless told otherwise.
DEFAULT_OUTPUT = Path(__file__).with_name('VanguardPairsPortfolioReport.pdf')

# A position is closed once the ratio has reverted to its rolling mean, which
# is the notebook's exit_threshold of 0.
EXIT_THRESHOLD = 0

# The exit rules the reports compare, on identical entries: take the reversion
# as soon as it arrives, wait for half the move back out, or hold until the
# ratio has swung to the point where the other fund is the buy.
EXIT_THRESHOLDS = (EXIT_THRESHOLD, 1, ENTRY_THRESHOLD)

# Plotted against the portfolio for context.
BENCHMARK = 'VTI'


def add_signals(data, entry_threshold=ENTRY_THRESHOLD,
                exit_threshold=EXIT_THRESHOLD) -> pd.DataFrame:
    """Turn the ratio's z-score into which fund to own, and when to sell.

    Without shorting, a signal names which fund to own rather than which side
    to take. A z-score below the threshold means the first fund is cheap
    against the second, so buy the first; above it the second is the cheap
    one, so buy that instead.

    Args:
        data: A frame from pair_frame, carrying 'Ratio Z'.
        entry_threshold: How far the z-score must travel to signal.
        exit_threshold: Level it must return to before selling. Mirrored for
            the second fund, so exiting at 0 means the same thing to both
            sides while exiting at 2 holds the first fund until the ratio
            reads +2 and the second until it reads -2.

    Returns:
        The same frame with 'Buy A', 'Buy B', 'Exit A' and 'Exit B' columns.
    """
    data = data.copy()
    z_score = data['Ratio Z']

    # Unusually low: the first fund is the cheap leg.
    data['Buy A'] = (z_score < -entry_threshold).astype(int)
    # Unusually high: the first fund is expensive, so the second is the cheap one.
    data['Buy B'] = (z_score > entry_threshold).astype(int)
    # Sell once the gap that justified the holding has closed.
    data['Exit A'] = (z_score >= exit_threshold).astype(int)
    data['Exit B'] = (z_score <= -exit_threshold).astype(int)
    return data


def backtest_pair(ticker_a, ticker_b, column='Adj Close', columns=None,
                  window=ROLLING_WINDOW, entry_threshold=ENTRY_THRESHOLD,
                  exit_threshold=EXIT_THRESHOLD, cache=PAIR_FRAMES) -> dict:
    """Rotate between the two funds on the ratio signal, long only.

    The rules: when the ratio says one fund is cheap against the other, buy
    that fund with the whole sleeve. Sell when the ratio has returned to the
    exit level, and hold cash until the next signal. Nothing is ever sold
    short, so the sleeve is either fully in one fund or fully in cash, and
    cash earns nothing.

    Returns are the held fund's own returns, which means this carries market
    risk rather than hedging it out. There are no transaction costs, so the
    figures are an upper bound on what the rules could have produced.

    Args:
        ticker_a: One of VANGUARD_ETFS, bought when the pair reads low.
        ticker_b: One of VANGUARD_ETFS, bought when the pair reads high.
        column: One of YFINANCE_COLUMNS, passed to pair_frame.
        columns: Column name -> DataFrame, passed to pair_frame.
        window: Periods in the rolling window.
        entry_threshold: How far the z-score must travel to signal.
        exit_threshold: Level it must return to before selling.
        cache: Frame cache shared with the cointegration screen.

    Returns:
        A dict holding the trade list, the daily return series, the equity
        curve and the summary statistics for the pair.
    """
    data = add_signals(pair_frame(ticker_a, ticker_b, column, columns, window,
                                  entry_threshold, cache),
                       entry_threshold, exit_threshold)

    returns = data[[ticker_a, ticker_b]].pct_change().fillna(0.0)
    dates = data.index
    buy_a, buy_b = data['Buy A'].to_numpy(), data['Buy B'].to_numpy()
    exit_a, exit_b = data['Exit A'].to_numpy(), data['Exit B'].to_numpy()
    return_a, return_b = returns[ticker_a].to_numpy(), returns[ticker_b].to_numpy()

    held = np.empty(len(data), dtype=object)  # which fund the sleeve owns
    daily_values = np.zeros(len(data))
    trades = []
    entry_index, side = None, None

    for i in range(len(data)):
        if entry_index is None:
            # Buy at this close; the first day of P&L is the next bar.
            if buy_a[i]:
                entry_index, side = i, ticker_a
            elif buy_b[i]:
                entry_index, side = i, ticker_b
            continue

        held[i] = side
        daily_values[i] = return_a[i] if side == ticker_a else return_b[i]
        # Sell at this close, so today's move still counts.
        closing = exit_a[i] if side == ticker_a else exit_b[i]
        if closing or i == len(data) - 1:
            prices = data[side]
            trades.append({
                'entry_date': dates[entry_index],
                'exit_date': dates[i],
                'held': side,
                'days': i - entry_index,
                'return': float(prices.iloc[i] / prices.iloc[entry_index] - 1),
                'open_at_end': bool(not closing and i == len(data) - 1),
            })
            entry_index, side = None, None

    daily = pd.Series(daily_values, index=dates, name=f"{ticker_a}/{ticker_b}")
    equity = (1 + daily).cumprod()

    trades = pd.DataFrame(trades, columns=['entry_date', 'exit_date', 'held', 'days',
                                           'return', 'open_at_end'])
    invested = pd.Series(held, index=dates).notna()
    years = len(data) / TRADING_DAYS
    total_return = float(equity.iloc[-1] - 1)
    drawdown = equity / equity.cummax() - 1

    return {
        'ticker_a': ticker_a,
        'ticker_b': ticker_b,
        'data': data,
        'trades': trades,
        'daily': daily,
        'equity': equity,
        'held': pd.Series(held, index=dates),
        'buy_a_days': int(data['Buy A'].sum()),
        'buy_b_days': int(data['Buy B'].sum()),
        'n_trades': len(trades),
        'trades_a': int((trades['held'] == ticker_a).sum()),
        'trades_b': int((trades['held'] == ticker_b).sum()),
        'win_rate': float((trades['return'] > 0).mean()) if len(trades) else np.nan,
        'avg_days': float(trades['days'].mean()) if len(trades) else np.nan,
        'median_days': float(trades['days'].median()) if len(trades) else np.nan,
        # What one holding earned on average, as opposed to what the sleeve
        # compounded over the whole history.
        'avg_trade': float(trades['return'].mean()) if len(trades) else np.nan,
        'median_trade': float(trades['return'].median()) if len(trades) else np.nan,
        'best_trade': float(trades['return'].max()) if len(trades) else np.nan,
        'worst_trade': float(trades['return'].min()) if len(trades) else np.nan,
        'total_return': total_return,
        'cagr': float((1 + total_return) ** (1 / years) - 1) if years > 0 else np.nan,
        'max_drawdown': float(drawdown.min()),
        'exposure': float(invested.mean()),
        'first_date': dates[0],
        'last_date': dates[-1],
        'rows': len(data),
    }


def signal_status(screen, column='Adj Close', columns=None, window=ROLLING_WINDOW,
                  entry_threshold=ENTRY_THRESHOLD, cointegrated_only=True,
                  cache=PAIR_FRAMES) -> pd.DataFrame:
    """Where each selected pair's ratio stands as of the latest bar.

    This is what decides whether a pair belongs in the portfolio report: a
    pair is signalling only if its z-score is past the entry threshold on the
    most recent trading day, not merely at some point in the past.

    Args:
        screen: The results table from screen_pairs or build_pairs_report.
        column: One of YFINANCE_COLUMNS, passed to pair_frame.
        columns: Column name -> DataFrame. Defaults to vanguard_columns.
        window: Periods in the rolling window.
        entry_threshold: How far the z-score must travel to signal.
        cointegrated_only: Look only at the pairs the screen passed.
        cache: Frame cache shared with the screen.

    Returns:
        One row per candidate pair with its latest date and z-score, which
        fund that z-score calls cheap, whether it is signalling now, and how
        many trading days have passed since it last did.
    """
    if columns is None:
        columns = vanguard_columns

    candidates = screen[screen['tested']]
    if cointegrated_only:
        candidates = candidates[candidates['cointegrated']]

    rows = []
    for _, row in candidates.iterrows():
        ticker_a, ticker_b = row['ticker_a'], row['ticker_b']
        data = add_signals(pair_frame(ticker_a, ticker_b, column, columns, window,
                                      entry_threshold, cache),
                           entry_threshold)
        z_score = data['Ratio Z'].iloc[-1]
        buy_a, buy_b = bool(data['Buy A'].iloc[-1]), bool(data['Buy B'].iloc[-1])

        # How long since the z-score was last past the threshold either way.
        fired = data.index[(data['Buy A'] == 1) | (data['Buy B'] == 1)]
        days_since = (len(data) - 1 - data.index.get_loc(fired[-1])) if len(fired) else np.nan

        # How long the current signal has been standing, for a signalling pair.
        running = 0
        if buy_a or buy_b:
            side = 'Buy A' if buy_a else 'Buy B'
            firing = data[side].to_numpy()
            while running < len(firing) and firing[-1 - running] == 1:
                running += 1

        rows.append({
            'ticker_a': ticker_a,
            'ticker_b': ticker_b,
            'p_value': row['p_value'],
            'last_date': data.index[-1],
            'last_z': float(z_score),
            'signalling': buy_a or buy_b,
            # The cheap fund to buy, and the expensive one it is bought against.
            'buy': ticker_a if buy_a else (ticker_b if buy_b else ''),
            'sell': ticker_b if buy_a else (ticker_a if buy_b else ''),
            'days_signalling': running,
            'days_since_signal': days_since,
        })
    return pd.DataFrame(rows)


def signal_tally(status) -> pd.DataFrame:
    """Count how many pairs point at buying or selling each fund today.

    A fund can appear in several pairs at once, so this is where a weak
    signal repeated across pairs becomes visible: three pairs all calling
    VGIT cheap is a different statement from one pair doing so.

    Args:
        status: The table from signal_status.

    Returns:
        One row per fund named by a live signal, with how many pairs call it
        cheap, how many call it expensive, the net of the two, and the pairs
        behind each side. Sorted by net, strongest buy first.
    """
    tally = {}

    def entry(ticker):
        return tally.setdefault(ticker, {'ticker': ticker, 'buy_signals': 0,
                                         'sell_signals': 0, 'buy_pairs': [],
                                         'sell_pairs': []})

    for _, row in status[status['signalling']].iterrows():
        pair = f"{row['ticker_a']}/{row['ticker_b']}"
        buying = entry(row['buy'])
        buying['buy_signals'] += 1
        buying['buy_pairs'].append(pair)
        selling = entry(row['sell'])
        selling['sell_signals'] += 1
        selling['sell_pairs'].append(pair)

    if not tally:
        return pd.DataFrame(columns=['ticker', 'buy_signals', 'sell_signals', 'net',
                                     'buy_pairs', 'sell_pairs'])

    frame = pd.DataFrame(tally.values())
    frame['net'] = frame['buy_signals'] - frame['sell_signals']
    return frame.sort_values(['net', 'buy_signals'], ascending=False, ignore_index=True)


def agreeing_pairs(screen, column='Adj Close', columns=None, window=ROLLING_WINDOW,
                   entry_threshold=ENTRY_THRESHOLD, exit_threshold=EXIT_THRESHOLD,
                   cointegrated_only=True, min_trades=1, only_pairs=None,
                   cache=PAIR_FRAMES) -> list[dict]:
    """Backtest the pairs the cointegration screen selected.

    The universe is the screen's own output, not a fresh ranking: by default
    only the pairs it found cointegrated, which are the ones charted in the
    cointegration report. Of those, a pair is kept when the ratio signal
    fired often enough to produce trades.

    Args:
        screen: The results table from screen_pairs, or from
            build_pairs_report, which returns it as its second value.
        column: One of YFINANCE_COLUMNS, used for trading.
        columns: Column name -> DataFrame. Defaults to vanguard_columns.
        window: Periods in the rolling window.
        entry_threshold: How far both z-scores must travel to signal.
        exit_threshold: Level both must return to before selling.
        cointegrated_only: Keep only the pairs the screen passed. False widens
            the universe to every pair the screen had enough history to test.
        min_trades: Least completed entries a pair needs to be reported.
        only_pairs: Restrict to these (ticker_a, ticker_b) pairs, e.g. the
            ones signalling today. None keeps every candidate.
        cache: Frame cache shared with the screen, so no pair is rebuilt.

    Returns:
        A list of backtest_pair results, sorted by total return.
    """
    if columns is None:
        columns = vanguard_columns

    candidates = screen[screen['tested']]
    if cointegrated_only:
        candidates = candidates[candidates['cointegrated']]
    if only_pairs is not None:
        only_pairs = set(only_pairs)
        candidates = candidates[[(row['ticker_a'], row['ticker_b']) in only_pairs
                                 for _, row in candidates.iterrows()]]

    results = []
    for _, row in candidates.iterrows():
        result = backtest_pair(row['ticker_a'], row['ticker_b'], column, columns,
                               window, entry_threshold, exit_threshold, cache)
        # The signal has to fire often enough to actually produce trades.
        if result['n_trades'] < min_trades:
            continue
        # Carry the screen's numbers through so the report can show both.
        result['ranked_corr'] = row['ranked_corr']
        result['p_value'] = row['p_value']
        result['cointegrated'] = row['cointegrated']
        results.append(result)

    return sorted(results, key=lambda result: result['total_return'], reverse=True)


def simulate_portfolio(results, columns=None, benchmark=BENCHMARK) -> dict:
    """Combine the pair sleeves into one equally weighted portfolio.

    Capital is split evenly across the pairs and rebalanced daily, so each
    day's return is the average across the sleeves trading by then. A sleeve
    sitting in cash contributes zero, which is why the portfolio's return is
    well below that of the funds it holds.

    Args:
        results: Backtest results from agreeing_pairs.
        columns: Column name -> DataFrame. Defaults to vanguard_columns.
        benchmark: Ticker to plot alongside, or None to skip it.

    Returns:
        A dict with the portfolio's daily returns, equity curve, benchmark
        equity curve and summary statistics.
    """
    if columns is None:
        columns = vanguard_columns

    # Union of dates; .mean() skips NaN, so each day is split across the pairs
    # that existed by then rather than across all of them.
    daily = pd.concat([result['daily'] for result in results], axis=1, sort=True)
    live = daily.notna().sum(axis=1)
    portfolio_daily = daily.mean(axis=1).fillna(0.0)
    equity = (1 + portfolio_daily).cumprod()

    years = len(equity) / TRADING_DAYS
    total_return = float(equity.iloc[-1] - 1)
    drawdown = equity / equity.cummax() - 1
    # A sleeve holding a fund on a flat day still counts as invested, so use
    # the held series rather than a non-zero return.
    # Aligning boolean columns leaves NaN where a pair hadn't started, which
    # makes the frame object dtype, so cast before counting.
    invested = pd.concat([result['held'].notna() for result in results], axis=1, sort=True)
    invested = invested.fillna(False).astype(bool).sum(axis=1)

    all_trades = pd.concat([result['trades'] for result in results], ignore_index=True)

    benchmark_equity = None
    if benchmark:
        prices = columns['Adj Close'][benchmark].reindex(equity.index).ffill()
        benchmark_equity = prices / prices.iloc[0]

    return {
        'daily': portfolio_daily,
        'equity': equity,
        'invested': invested,
        'live': live,
        'benchmark': benchmark_equity,
        'benchmark_ticker': benchmark,
        'pairs': len(results),
        'total_return': total_return,
        'cagr': float((1 + total_return) ** (1 / years) - 1) if years > 0 else np.nan,
        'max_drawdown': float(drawdown.min()),
        'volatility': float(portfolio_daily.std() * np.sqrt(TRADING_DAYS)),
        'sharpe': float(portfolio_daily.mean() / portfolio_daily.std() * np.sqrt(TRADING_DAYS))
        if portfolio_daily.std() else np.nan,
        'exposure': float((invested > 0).mean()),
        'avg_invested': float(invested.mean()),
        'n_trades': int(sum(result['n_trades'] for result in results)),
        # Pooled across every sleeve, so one long holding doesn't hide behind
        # a pair that traded often.
        'avg_days': float(all_trades['days'].mean()) if len(all_trades) else np.nan,
        'median_days': float(all_trades['days'].median()) if len(all_trades) else np.nan,
        'avg_trade': float(all_trades['return'].mean()) if len(all_trades) else np.nan,
        'median_trade': float(all_trades['return'].median()) if len(all_trades) else np.nan,
        'win_rate': float((all_trades['return'] > 0).mean()) if len(all_trades) else np.nan,
        'first_date': equity.index[0],
        'last_date': equity.index[-1],
        'years': years,
    }


def compare_exits(screen, exit_thresholds=EXIT_THRESHOLDS, column='Adj Close', columns=None,
                  window=ROLLING_WINDOW, entry_threshold=ENTRY_THRESHOLD,
                  cointegrated_only=True, min_trades=1, only_pairs=None,
                  benchmark=BENCHMARK, cache=PAIR_FRAMES) -> dict:
    """Run the same pairs under several exit rules and keep each result.

    Entries are identical across the rules; only the sell differs. Exiting at
    0 takes the money as soon as the gap closes, exiting at the entry
    threshold holds until the pair has swung to the opposite extreme, which is
    the point the other fund becomes the buy.

    Args:
        screen: The results table from screen_pairs or build_pairs_report.
        exit_thresholds: Exit levels to compare, e.g. (0, 2).
        column: One of YFINANCE_COLUMNS, used for trading.
        columns: Column name -> DataFrame. Defaults to vanguard_columns.
        window: Periods in the rolling window.
        entry_threshold: How far both z-scores must travel to signal.
        cointegrated_only: Trade only the pairs the screen passed.
        min_trades: Least completed entries a pair needs to be reported.
        only_pairs: Restrict to these pairs, passed to agreeing_pairs.
        benchmark: Ticker to plot against the portfolios, or None.
        cache: Frame cache shared with the screen.

    Returns:
        Exit threshold -> {'results': per-pair backtests, 'portfolio': summary}.
    """
    strategies = {}
    for exit_threshold in exit_thresholds:
        results = agreeing_pairs(screen, column, columns, window, entry_threshold,
                                 exit_threshold, cointegrated_only, min_trades,
                                 only_pairs, cache)
        if not results:
            continue
        strategies[exit_threshold] = {
            'results': results,
            'portfolio': simulate_portfolio(results, columns, benchmark),
        }
    return strategies


# One palette for the whole report, so a colour means the same thing on every
# page: green is a fund to buy, red one to sell, amber a near miss.
BUY_FILL = '#dff0d8'
SELL_FILL = '#f7e0e0'
NEAR_FILL = '#fdf2e6'
HEADER_FILL = '#e8e8e8'
BUY_TEXT = '#1a6b2a'
SELL_TEXT = '#8b1a1a'


def _heading(fig, title, subtitle=None, top=0.965) -> None:
    """Title block with a rule under it, identical on every page."""
    fig.text(0.06, top, title, fontsize=17, weight='bold', va='top')
    if subtitle:
        fig.text(0.06, top - 0.038, subtitle, fontsize=9, color='0.35', va='top')
    fig.add_artist(plt.Line2D([0.06, 0.94], [top - 0.062, top - 0.062],
                              color='0.75', linewidth=0.8))


def _section(fig, label, y, x=0.06) -> None:
    """Section label above a table, spaced out to read as a heading."""
    fig.text(x, y, ' '.join(label.upper()), fontsize=8.5, weight='bold', color='0.3',
             va='top')


def _draw_table(ax, body, col_labels, row_fills=None, fontsize=8, row_height=1.3,
                col_widths=None) -> None:
    """Render one table with the report's house style.

    Keeping this in one place is what makes the pages look alike: the same
    header shade, the same light gridlines, the same padding.
    """
    ax.axis('off')
    table = ax.table(cellText=body, colLabels=col_labels, cellLoc='center',
                     loc='upper center', colWidths=col_widths)
    table.auto_set_font_size(False)
    table.set_fontsize(fontsize)
    table.scale(1.0, row_height)
    for (row_index, _), cell in table.get_celld().items():
        cell.set_edgecolor('0.85')
        cell.set_linewidth(0.6)
        if row_index == 0:
            cell.set_facecolor(HEADER_FILL)
            cell.set_text_props(weight='bold')
            cell.set_height(cell.get_height() * 1.7)
        elif row_fills is not None:
            cell.set_facecolor(row_fills[row_index - 1])


# A page only holds so many rows before the type has to shrink past reading
# size, so the signal tables spill onto further pages instead.
ACTION_ROWS_PER_PAGE = 15
CANDIDATE_ROWS_PER_PAGE = 22
PAIR_ROWS_PER_PAGE = 24


def _signals_pages(status, tally, column, entry_threshold, cointegrated_only,
                   first_page, total_pages) -> list[plt.Figure]:
    """The front of the report: what to do today, and where everything stands.

    Page one is the actions and the tally behind them; the candidate list
    follows on as many pages as it needs. Long tables paginate rather than
    shrink, so the report stays readable whether four pairs are in play or
    four hundred.

    Args:
        status: The table from signal_status.
        tally: The table from signal_tally.
        column: One of YFINANCE_COLUMNS, named in the text.
        entry_threshold: The z-score that counts as a signal.
        cointegrated_only: Whether the candidates are the cointegrated ones.
        first_page: Page number of the first page produced.
        total_pages: Pages in the finished report, for the footers.

    Returns:
        The figures, in order.
    """
    pages = []
    as_of = status['last_date'].max() if len(status) else pd.NaT
    firing = status[status['signalling']]
    subtitle = (f"Prices through {as_of:%B %d, %Y}  ·  generated "
                f"{pd.Timestamp.today():%B %d, %Y}  ·  "
                f"{'cointegrated pairs only' if cointegrated_only else 'all tested pairs'}")

    # --- page one: the actions ------------------------------------------
    fig = plt.figure(figsize=(11, 8.5))
    _heading(fig, "Vanguard ETF Pairs — Today's Signals", subtitle)

    if len(firing):
        # Name the first few actions, then count the rest: the table has them.
        named = ', '.join(f"buy {row['buy']}" for _, row in firing.head(4).iterrows())
        extra = f", and {len(firing) - 4} more" if len(firing) > 4 else ''
        headline = f"{len(firing)} active signal{'s' if len(firing) > 1 else ''}: {named}{extra}"
        colour = BUY_TEXT
    else:
        headline = (f"No active signals — no pair's {column} ratio is past "
                    f"+/-{entry_threshold} on the latest bar")
        colour = '0.25'
    fig.text(0.06, 0.865, headline, fontsize=12, weight='bold', color=colour, va='top')

    shown = firing.head(ACTION_ROWS_PER_PAGE)
    _section(fig, f"Active signals ({len(firing)})", 0.805)
    ax_signals = fig.add_axes([0.06, 0.12, 0.50, 0.67])
    if len(firing):
        body, fills = [], []
        for _, row in shown.iterrows():
            body.append([
                f"{row['ticker_a']}/{row['ticker_b']}",
                row['buy'],
                row['sell'],
                f"{row['last_z']:+.2f}",
                f"{row['days_signalling']:.0f}",
                f"{row['p_value']:.4f}" if pd.notna(row['p_value']) else 'n/a',
            ])
            fills.append(BUY_FILL)
        _draw_table(ax_signals, body,
                    ['pair', 'buy', 'sell', 'z', 'days\nstanding', 'coint p'],
                    fills, fontsize=8.5, row_height=1.4,
                    col_widths=[0.24, 0.15, 0.15, 0.13, 0.16, 0.17])
        if len(firing) > len(shown):
            fig.text(0.06, 0.10, f"... and {len(firing) - len(shown)} more signalling "
                                 f"pairs, listed on the candidate pages",
                     fontsize=8, style='italic', color='0.45')
    else:
        ax_signals.axis('off')
        ax_signals.text(0.5, 0.95, "Nothing to act on today.", ha='center', va='top',
                        fontsize=10, color='0.45', transform=ax_signals.transAxes)

    _section(fig, f"Tally by fund ({len(tally)})", 0.805, x=0.60)
    ax_tally = fig.add_axes([0.60, 0.12, 0.34, 0.67])
    if len(tally):
        body, fills = [], []
        for _, row in tally.head(ACTION_ROWS_PER_PAGE).iterrows():
            pairs = row['buy_pairs'] or row['sell_pairs']
            listed = ', '.join(pairs[:2]) + (f" +{len(pairs) - 2}" if len(pairs) > 2 else '')
            body.append([
                row['ticker'],
                f"{row['buy_signals']}",
                f"{row['sell_signals']}",
                f"{row['net']:+d}",
                listed,
            ])
            fills.append(BUY_FILL if row['net'] > 0 else
                         (SELL_FILL if row['net'] < 0 else 'white'))
        _draw_table(ax_tally, body, ['fund', 'buy', 'sell', 'net', 'from pairs'],
                    fills, fontsize=8.5, row_height=1.4,
                    col_widths=[0.17, 0.11, 0.11, 0.11, 0.50])
    else:
        ax_tally.axis('off')
        ax_tally.text(0.5, 0.95, "No funds signalled.", ha='center', va='top',
                      fontsize=10, color='0.45', transform=ax_tally.transAxes)

    fig.text(0.5, 0.055,
             "A fund's net tally is its buy signals minus its sell signals, so a fund "
             "called cheap by several pairs at once stands out.\n"
             "'days standing' is how long the current signal has been in place.",
             ha='center', fontsize=8, style='italic', color='0.35')
    _footer(fig, first_page, total_pages, 'Signals')
    pages.append(fig)

    # --- the candidate list, however many pages it takes ------------------
    ordered = status.reindex(status['last_z'].abs().sort_values(ascending=False).index)
    chunks = [ordered.iloc[start:start + CANDIDATE_ROWS_PER_PAGE]
              for start in range(0, len(ordered), CANDIDATE_ROWS_PER_PAGE)] or [ordered]

    for index, chunk in enumerate(chunks):
        fig = plt.figure(figsize=(11, 8.5))
        part = '' if len(chunks) == 1 else f"  (part {index + 1} of {len(chunks)})"
        _heading(fig, f"All candidates, nearest to signalling first{part}",
                 f"{len(ordered)} pairs · {int(status['signalling'].sum())} signalling "
                 f"· {subtitle}")

        ax = fig.add_axes([0.06, 0.10, 0.88, 0.78])
        body, fills = [], []
        for _, row in chunk.iterrows():
            distance = entry_threshold - abs(row['last_z'])
            favours = row['ticker_a'] if row['last_z'] < 0 else row['ticker_b']
            body.append([
                f"{row['ticker_a']}/{row['ticker_b']}",
                f"{row['p_value']:.4f}" if pd.notna(row['p_value']) else 'n/a',
                f"{row['last_z']:+.2f}",
                'signalling' if row['signalling'] else f"{distance:.2f}",
                favours,
                f"{row['days_since_signal']:.0f}" if pd.notna(row['days_since_signal']) else 'never',
            ])
            if row['signalling']:
                fills.append(BUY_FILL)
            else:
                # Amber for anything within half a standard deviation of firing.
                fills.append(NEAR_FILL if distance <= 0.5 else 'white')
        _draw_table(ax, body,
                    ['pair', 'coint p', 'latest z', 'z still needed', 'favours',
                     'days since\nlast signal'],
                    fills, fontsize=8.5, row_height=1.35,
                    col_widths=[0.17, 0.15, 0.15, 0.18, 0.15, 0.18])

        fig.text(0.5, 0.045,
                 "'z still needed' is how much further the ratio must move to trigger; "
                 "'favours' names the fund that reading leans towards.\n"
                 "Green rows are signalling now; amber rows are within half a standard "
                 "deviation of it.",
                 ha='center', fontsize=8, style='italic', color='0.35')
        _footer(fig, first_page + 1 + index, total_pages, 'Candidates')
        pages.append(fig)

    return pages


def _footer(fig, page_number, total_pages, label='') -> None:
    """Page number and section name, on every page."""
    fig.text(0.5, 0.02, f"page {page_number} of {total_pages}", ha='center', fontsize=7.5,
             color='0.45')
    if label:
        fig.text(0.06, 0.02, label, ha='left', fontsize=7.5, color='0.45')


def _strategy_label(exit_threshold, short=False) -> str:
    """How an exit rule is named everywhere in the report."""
    if exit_threshold == 0:
        return 'z = 0' if short else 'Exit at z = 0, taking the reversion'
    if short:
        return f"z = +/-{exit_threshold}"
    return f"Exit at z = +/-{exit_threshold}, holding to the opposite extreme"


def _strategy_pages(strategies, column, entry_threshold, cointegrated_only, screened,
                    first_page, total_pages, screen_built=None) -> list[plt.Figure]:
    """The rules and the portfolio under each exit rule, then pair by pair.

    The per-pair comparison is one row per pair per rule, so it runs past a
    page as soon as there are more than a handful of pairs; it spills onto
    further pages rather than shrinking to fit.
    """
    pages = []
    thresholds = list(strategies)
    first = strategies[thresholds[0]]['portfolio']
    results = strategies[thresholds[0]]['results']
    traded = len(results)

    fig = plt.figure(figsize=(11, 8.5))

    built = (f"  ·  screen built {screen_built:%Y-%m-%d %H:%M}"
             if screen_built is not None else '')
    _heading(fig, "How the signalling pairs have behaved",
             f"{traded} of {screened} "
             f"{'cointegrated' if cointegrated_only else 'tested'} pairs are signalling "
             f"today; each one's record below covers its full history{built}")

    # The rules, as a labelled block rather than a paragraph.
    rules = [
        ('Signal', f"{column} price ratio's z-score against its "
                   f"{ROLLING_WINDOW}-day rolling mean"),
        ('Buy', f"below -{entry_threshold} buys the first fund, "
                f"above +{entry_threshold} buys the second"),
        ('Sell', f"at z = {' or z = '.join('0' if t == 0 else f'+/-{t}' for t in thresholds)}"
                 f", the {len(thresholds)} rules compared side by side below"),
        ('Position', 'long only, one fund at a time, no shorting or leverage; '
                     'cash earns nothing'),
        ('Portfolio', f"equally weighted sleeves rebalanced daily, "
                      f"{first['first_date']:%Y-%m-%d} to {first['last_date']:%Y-%m-%d} "
                      f"({first['years']:.1f} years)"),
        ('Costs', 'none modelled — no commissions, no slippage'),
    ]
    y = 0.865
    for label, text in rules:
        fig.text(0.06, y, f"{label}", fontsize=8.5, weight='bold', color='0.3', va='top')
        fig.text(0.155, y, text, fontsize=8.5, color='0.2', va='top')
        y -= 0.026

    # --- portfolio, one row per exit rule -------------------------------
    _section(fig, 'Portfolio under each exit rule', 0.685)
    ax_top = fig.add_axes([0.06, 0.53, 0.88, 0.14])
    body, fills = [], []
    for position, threshold in enumerate(thresholds):
        portfolio = strategies[threshold]['portfolio']
        body.append([
            ('z = 0, take the reversion' if threshold == 0
             else f"z = +/-{threshold}, hold to the extreme"),
            f"{portfolio['total_return'] * 100:+.1f}%",
            f"{portfolio['cagr'] * 100:+.2f}%",
            f"{portfolio['max_drawdown'] * 100:.1f}%",
            f"{portfolio['sharpe']:.2f}",
            f"{portfolio['n_trades']}",
            f"{portfolio['avg_days']:.0f}d",
            f"{portfolio['avg_trade'] * 100:+.2f}%",
            f"{portfolio['win_rate'] * 100:.0f}%",
            f"{portfolio['exposure'] * 100:.0f}%",
        ])
        fills.append('#eef4fb' if position == 0 else NEAR_FILL)
    _draw_table(ax_top, body,
                ['exit rule', 'ROI', 'CAGR', 'max DD', 'Sharpe', 'holds', 'mean\nhold',
                 'mean ROI\nper hold', 'win rate', 'time in\nmarket'],
                fills, fontsize=8.5, row_height=1.5,
                col_widths=[0.25] + [0.083] * 9)

    fig.text(0.5, 0.42,
             "Each pair's own record follows, one row per exit rule.\n"
             "Mean ROI per hold is the average return of a single holding and does not "
             "compound; ROI is what the sleeve compounded over its whole history.",
             ha='center', fontsize=9, style='italic', color='0.35')
    _footer(fig, first_page, total_pages, 'Strategy comparison')
    pages.append(fig)

    # --- the same comparison per pair, across as many pages as it needs ---
    ordering = [(r['ticker_a'], r['ticker_b']) for r in results]
    per_page = max(1, PAIR_ROWS_PER_PAGE // max(1, len(thresholds)))
    chunks = [ordering[start:start + per_page]
              for start in range(0, len(ordering), per_page)] or [ordering]

    for index, chunk in enumerate(chunks):
        fig = plt.figure(figsize=(11, 8.5))
        part = '' if len(chunks) == 1 else f"  (part {index + 1} of {len(chunks)})"
        _heading(fig, f"Each pair under each exit rule{part}",
                 f"{traded} signalling pairs × {len(thresholds)} exit rules, "
                 f"measured over each pair's full history")

        ax = fig.add_axes([0.04, 0.10, 0.92, 0.78])
        body, fills = [], []
        for pair in chunk:
            for position, threshold in enumerate(thresholds):
                match = [r for r in strategies[threshold]['results']
                         if (r['ticker_a'], r['ticker_b']) == pair]
                if not match:
                    continue
                result = match[0]
                body.append([
                    f"{result['ticker_a']}/{result['ticker_b']}" if position == 0 else '',
                    'z = 0' if threshold == 0 else f"z = +/-{threshold}",
                    f"{result['rows']}",
                    f"{result['p_value']:.4f}" if pd.notna(result['p_value']) else 'n/a',
                    f"{result['buy_a_days']}/{result['buy_b_days']}",
                    f"{result['trades_a']}/{result['trades_b']}",
                    f"{result['avg_days']:.0f}d",
                    f"{result['avg_trade'] * 100:+.2f}%",
                    f"{result['win_rate'] * 100:.0f}%",
                    f"{result['exposure'] * 100:.0f}%",
                    f"{result['total_return'] * 100:+.1f}%",
                    f"{result['cagr'] * 100:+.1f}%",
                    f"{result['max_drawdown'] * 100:.1f}%",
                ])
                # Shade by exit rule so the rules read as columns of colour.
                fills.append(('#eef4fb', NEAR_FILL, '#f3eef9',
                              '#f0f0ea')[position % 4])
        _draw_table(ax, body,
                    ['pair', 'exit', 'days', 'coint p', 'signal buys\nA/B', 'holds\nA/B',
                     'mean hold', 'mean ROI\nper hold', 'win rate', 'time in\nmarket',
                     'ROI', 'CAGR', 'max DD'],
                    fills, fontsize=8, row_height=1.4,
                    col_widths=[0.10, 0.075, 0.06, 0.07, 0.085, 0.07, 0.07, 0.085,
                                0.065, 0.075, 0.07, 0.06, 0.065])

        fig.text(0.5, 0.045,
                 "Signal buys A/B counts the days the z-score called each fund cheap; "
                 "holds A/B splits completed holdings by which fund was owned.\n"
                 "Time in market is the share of days the sleeve owned anything at all.",
                 ha='center', fontsize=8, style='italic', color='0.35')
        _footer(fig, first_page + 1 + index, total_pages, 'Pair comparison')
        pages.append(fig)

    return pages


STRATEGY_COLORS = ('tab:blue', 'tab:orange', 'tab:purple', 'tab:brown')


def _portfolio_page(strategies, page_number=None, total_pages=None) -> plt.Figure:
    """Page 2: both equity curves, their drawdowns, and sleeves in the market."""
    fig, axes = plt.subplots(3, 1, figsize=(11, 8.5), sharex=True,
                             gridspec_kw={'height_ratios': [3, 1, 1]})
    thresholds = list(strategies)

    for position, threshold in enumerate(thresholds):
        portfolio = strategies[threshold]['portfolio']
        colour = STRATEGY_COLORS[position % len(STRATEGY_COLORS)]
        equity = portfolio['equity']
        axes[0].plot(equity.index, equity.to_numpy(), color=colour, linewidth=1.3,
                     label=f"{_strategy_label(threshold)}: "
                           f"{portfolio['total_return'] * 100:+.1f}%")

        drawdown = equity / equity.cummax() - 1
        axes[1].plot(drawdown.index, drawdown.to_numpy() * 100, color=colour,
                     linewidth=0.9)
        axes[2].plot(portfolio['invested'].index, portfolio['invested'].to_numpy(),
                     color=colour, linewidth=0.8)

    first = strategies[thresholds[0]]['portfolio']
    if first['benchmark'] is not None:
        axes[0].plot(first['benchmark'].index, first['benchmark'].to_numpy(),
                     color='0.6', linewidth=1.0, linestyle='--',
                     label=f"{first['benchmark_ticker']} buy and hold: "
                           f"{(first['benchmark'].iloc[-1] - 1) * 100:+.0f}%")

    axes[0].set_ylabel('growth of $1')
    axes[0].set_title("Signalling pairs portfolio, long only\n"
                      f"{first['pairs']} pairs equally weighted over "
                      f"{first['years']:.1f} years, same entries under "
                      f"{len(thresholds)} exit rules")
    axes[0].legend(fontsize=8, loc='upper left')
    axes[0].grid(alpha=0.3)

    axes[1].set_ylabel('drawdown %')
    axes[1].grid(alpha=0.3)

    # How many sleeves owned a fund, against how many pairs existed by then.
    axes[2].plot(first['live'].index, first['live'].to_numpy(), color='0.5',
                 linewidth=0.8, linestyle='--', label='pairs trading yet')
    axes[2].legend(fontsize=7, loc='upper left')
    axes[2].set_ylabel('sleeves\nholding')
    axes[2].grid(alpha=0.3)

    fig.tight_layout(rect=(0, 0.035, 1, 1))
    if page_number is not None:
        _footer(fig, page_number, total_pages, 'Portfolio')
    return fig


def _pair_page(pair, by_threshold, entry_threshold, status=None, page_number=None,
               total_pages=None) -> plt.Figure:
    """One page per pair: the signals once, then both exit rules compared."""
    ticker_a, ticker_b = pair
    thresholds = list(by_threshold)
    reference = by_threshold[thresholds[0]]
    data = reference['data']

    fig, axes = plt.subplots(2, 1, figsize=(11, 8.5), sharex=True,
                             gridspec_kw={'height_ratios': [3, 2]})

    axes[0].plot(data.index, data['Ratio Z'].to_numpy(), linewidth=0.8, color='tab:blue',
                 label=f"{ticker_a}/{ticker_b} ratio z-score")
    axes[0].axhline(-entry_threshold, color='green', linestyle='--', linewidth=0.9,
                    label=f"Buy {ticker_a} (-{entry_threshold})")
    axes[0].axhline(entry_threshold, color='purple', linestyle='--', linewidth=0.9,
                    label=f"Buy {ticker_b} (+{entry_threshold})")
    axes[0].axhline(0, color='black', linewidth=0.8)

    # Shade the holdings of the first rule, coloured by which fund was owned.
    for _, trade in reference['trades'].iterrows():
        axes[0].axvspan(trade['entry_date'], trade['exit_date'],
                        color='green' if trade['held'] == ticker_a else 'purple',
                        alpha=0.10)
    for ticker, colour, marker in ((ticker_a, 'green', '^'), (ticker_b, 'purple', 'v')):
        side = reference['trades'][reference['trades']['held'] == ticker]
        if len(side):
            points = data.loc[side['entry_date'], 'Ratio Z']
            axes[0].scatter(points.index, points.to_numpy(), color=colour, marker=marker,
                            s=30, zorder=3, label=f"Bought {ticker} ({len(side)})")

    axes[0].set_ylabel('ratio z-score')
    axes[0].grid(alpha=0.3)
    axes[0].legend(fontsize=7, loc='upper left', ncol=5)

    # Say what the pair is doing right now, since that is why it is in here.
    now = ''
    if status is not None:
        match = status[(status['ticker_a'] == ticker_a) & (status['ticker_b'] == ticker_b)]
        if len(match):
            row = match.iloc[0]
            now = (f"  ·  NOW: buy {row['buy']} at z = {row['last_z']:+.2f}, "
                   f"standing {row['days_signalling']:.0f} day"
                   f"{'s' if row['days_signalling'] != 1 else ''}"
                   if row['signalling'] else
                   f"  ·  now: no signal, z = {row['last_z']:+.2f}")
    axes[0].set_title(f"{ticker_a} / {ticker_b}  ·  coint p {reference['p_value']:.4f}{now}\n"
                      f"own {ticker_a} below -{entry_threshold}, {ticker_b} above "
                      f"+{entry_threshold}, else cash — shading marks holdings under the "
                      f"z = {thresholds[0]} exit")

    # Both equity curves on one axis: same entries, different sells.
    for position, threshold in enumerate(thresholds):
        result = by_threshold[threshold]
        colour = STRATEGY_COLORS[position % len(STRATEGY_COLORS)]
        equity = result['equity']
        axes[1].plot(equity.index, equity.to_numpy(), color=colour, linewidth=1.2,
                     label=f"exit z={threshold}: {result['total_return'] * 100:+.1f}%, "
                           f"{result['n_trades']} holds, mean {result['avg_days']:.0f}d, "
                           f"mean ROI/hold {result['avg_trade'] * 100:+.2f}%")
    axes[1].axhline(1.0, color='0.5', linewidth=0.8)
    axes[1].set_ylabel('growth of $1')
    axes[1].legend(fontsize=7, loc='upper left')
    axes[1].grid(alpha=0.3)

    lines = []
    for threshold in thresholds:
        result = by_threshold[threshold]
        lines.append(
            f"exit z={threshold}: {result['trades_a']} in {ticker_a} / "
            f"{result['trades_b']} in {ticker_b}   "
            f"mean hold {result['avg_days']:.0f}d (median {result['median_days']:.0f}d)   "
            f"mean ROI/hold {result['avg_trade'] * 100:+.2f}% "
            f"(median {result['median_trade'] * 100:+.2f}%)   "
            f"best {result['best_trade'] * 100:+.1f}% / worst {result['worst_trade'] * 100:+.1f}%   "
            f"in market {result['exposure'] * 100:.0f}%   "
            f"max DD {result['max_drawdown'] * 100:.1f}%"
        )
    fig.text(0.5, 0.048, '\n'.join(lines), ha='center', fontsize=7.5, family='monospace',
             color='0.3')
    fig.tight_layout(rect=(0, 0.085, 1, 1))
    if page_number is not None:
        _footer(fig, page_number, total_pages, f"{ticker_a}/{ticker_b}")
    return fig


def build_portfolio_report(screen=None, column='Adj Close', lookback=252, n=50,
                           columns=None, window=ROLLING_WINDOW,
                           entry_threshold=ENTRY_THRESHOLD,
                           exit_thresholds=EXIT_THRESHOLDS,
                           min_rows=MIN_TEST_ROWS, cointegrated_only=True, min_trades=1,
                           signalling_only=True, benchmark=BENCHMARK, cache=PAIR_FRAMES,
                           refresh_screen=False,
                           output_path=DEFAULT_OUTPUT) -> tuple[Path, dict, pd.DataFrame]:
    """Write a PDF comparing the signalling pairs under each exit rule.

    Page 1 states the rules and puts the portfolios side by side, with mean
    hold and mean ROI per hold for each. Page 2 plots both equity curves
    against a buy-and-hold benchmark. After that, one page per pair shows the
    signals once and both exit rules' results together.

    Only pairs signalling on the latest bar are included, so the report says
    what is actionable now rather than what once was. Their statistics still
    cover their whole history. On a day when nothing signals, the PDF is a
    single page showing how far each candidate is from triggering.

    Pass the screen from build_pairs_report to reuse its work: with the same
    frame cache, no pair is rebuilt and no cointegration test is rerun, which
    is what makes a daily run of both reports cheap.

    Args:
        screen: The results table from screen_pairs or build_pairs_report. One
            is built from the arguments below when omitted.
        column: One of YFINANCE_COLUMNS, used for ranking and trading.
        lookback: Trading days of returns behind the ranking. None uses all.
        n: How many pairs to rank, when building the screen here.
        columns: Column name -> DataFrame. Defaults to vanguard_columns.
        window: Periods in the rolling window.
        entry_threshold: How far both z-scores must travel to signal.
        exit_thresholds: Exit levels to compare. The default runs both the
            take-the-reversion rule and the hold-to-the-opposite-extreme one.
        min_rows: Shortest shared history worth testing, when screening here.
        cointegrated_only: Trade only the pairs the screen passed.
        min_trades: Least completed entries a pair needs to be reported.
        signalling_only: Report only the pairs signalling on the latest bar.
            False reports every candidate, as earlier versions did.
        refresh_screen: Ignore the screen saved on disk and rebuild it. By
            default the saved one is reused however old it is, and the report
            prints the date it was built.
        benchmark: Ticker to plot against the portfolios, or None.
        cache: Frame cache shared with the cointegration report.
        output_path: Where to write the PDF.

    Returns:
        (path written, strategies, status). Strategies is keyed by exit
        threshold as compare_exits returns it, and is empty when nothing is
        signalling; status is where every candidate's ratio stands today.
    """
    if columns is None:
        columns = vanguard_columns

    # Reuse the screen the cointegration report left on disk rather than
    # repeating its tests. It is taken whatever its age, so the pages say when
    # it was built; refresh_screen=True rebuilds and re-saves it.
    screen_built = None
    if screen is None and not refresh_screen:
        cached = load_screen()
        if cached is not None:
            screen, screen_built = cached['screen'], cached['saved_at']
    if screen is None:
        screen = screen_pairs(None, column, lookback, n, columns, window,
                              entry_threshold, min_rows, cache, PAIR_TESTS)
        screen_built = pd.Timestamp.now()
        save_screen(screen, {'column': column, 'lookback': lookback, 'n': n,
                             'window': window, 'entry_threshold': entry_threshold,
                             'min_rows': min_rows})

    status = signal_status(screen, column, columns, window, entry_threshold,
                           cointegrated_only, cache)
    tally = signal_tally(status)
    only_pairs = None
    if signalling_only:
        firing = status[status['signalling']]
        only_pairs = list(zip(firing['ticker_a'], firing['ticker_b']))

    output_path = Path(output_path)

    # How many pages the signals section needs, so footers can count properly.
    signal_pages = 1 + max(1, -(-len(status) // CANDIDATE_ROWS_PER_PAGE))

    # Nothing to trade today: the signals section alone says so, and shows how
    # close each candidate came.
    if signalling_only and not only_pairs:
        with PdfPages(output_path) as pdf:
            for page in _signals_pages(status, tally, column, entry_threshold,
                                       cointegrated_only, 1, signal_pages):
                pdf.savefig(page)
                plt.close(page)
            pdf.infodict()['Title'] = "Vanguard ETF pairs: nothing signalling"
        return output_path, {}, status

    strategies = compare_exits(screen, exit_thresholds, column, columns, window,
                               entry_threshold, cointegrated_only, min_trades,
                               only_pairs, benchmark, cache)
    if not strategies:
        raise ValueError("No selected pair produced a trade from the ratio signal")

    screened = int(screen['cointegrated'].sum()) if cointegrated_only else int(screen['tested'].sum())
    thresholds = list(strategies)

    # Group each pair's results across the rules, keeping the first rule's
    # ordering by return.
    by_pair = {}
    for threshold in thresholds:
        for result in strategies[threshold]['results']:
            by_pair.setdefault((result['ticker_a'], result['ticker_b']), {})[threshold] = result

    # Signals section, strategy comparison, portfolio curves, then one per pair.
    traded = strategies[thresholds[0]]['results']
    per_page = max(1, PAIR_ROWS_PER_PAGE // max(1, len(thresholds)))
    strategy_pages = 1 + max(1, -(-len(traded) // per_page))
    total_pages = signal_pages + strategy_pages + 1 + len(traded)

    with PdfPages(output_path) as pdf:
        for page in _signals_pages(status, tally, column, entry_threshold,
                                   cointegrated_only, 1, total_pages):
            pdf.savefig(page)
            plt.close(page)

        for page in _strategy_pages(strategies, column, entry_threshold,
                                    cointegrated_only, screened, signal_pages + 1,
                                    total_pages, screen_built):
            pdf.savefig(page)
            plt.close(page)

        page = _portfolio_page(strategies, signal_pages + strategy_pages + 1, total_pages)
        pdf.savefig(page)
        plt.close(page)

        for number, result in enumerate(
                traded, start=signal_pages + strategy_pages + 2):
            pair = (result['ticker_a'], result['ticker_b'])
            page = _pair_page(pair, by_pair[pair], entry_threshold, status, number,
                              total_pages)
            pdf.savefig(page)
            plt.close(page)

        pdf.infodict()['Title'] = "Vanguard ETF agreed-signal pairs portfolio"

    return output_path, strategies, status


if __name__ == '__main__':
    # Reuse the screen the cointegration report saved rather than repeating
    # its tests. Run VanguardPairsTrading.py, or RunDaily.py, to rebuild it.
    saved = load_screen()
    if saved is None:
        print("No saved screen found; run VanguardPairsTrading.py first to build one.")
        raise SystemExit(2)
    print(f"Using the screen saved {saved['saved_at']:%Y-%m-%d %H:%M} "
          f"({len(saved['screen'])} pairs, settings {saved['settings']})")

    path, strategies, status = build_portfolio_report()

    print("\nWhere each cointegrated pair's ratio stands today:")
    print(status[['ticker_a', 'ticker_b', 'last_date', 'last_z', 'signalling', 'buy',
                  'days_since_signal']].to_string(index=False, float_format='{:.2f}'.format))

    if not strategies:
        print("\nNothing is signalling on the latest bar; the report is the signals "
              "section only.")
        print(f"Wrote {path}")
        raise SystemExit

    # Per pair, one row per exit rule.
    table = pd.DataFrame([{
        'pair': f"{r['ticker_a']}/{r['ticker_b']}",
        'exit_z': threshold,
        'days': r['rows'],
        'coint_p': r['p_value'],
        'buys_a': r['buy_a_days'],
        'buys_b': r['buy_b_days'],
        'holds': r['n_trades'],
        'mean_hold_d': r['avg_days'],
        'median_hold_d': r['median_days'],
        'mean_roi_hold': r['avg_trade'],
        'win_rate': r['win_rate'],
        'exposure': r['exposure'],
        'roi': r['total_return'],
        'cagr': r['cagr'],
        'max_dd': r['max_drawdown'],
    } for threshold, strategy in strategies.items() for r in strategy['results']])
    print(table.sort_values(['pair', 'exit_z']).to_string(index=False,
                                                          float_format='{:.3f}'.format))

    print("\nPortfolios, same entries and different sells:")
    for threshold, strategy in strategies.items():
        portfolio = strategy['portfolio']
        print(f"  exit z={threshold}: ROI {portfolio['total_return'] * 100:+.1f}%   "
              f"CAGR {portfolio['cagr'] * 100:+.2f}%   "
              f"max DD {portfolio['max_drawdown'] * 100:.1f}%   "
              f"Sharpe {portfolio['sharpe']:.2f}")
        print(f"    {portfolio['n_trades']} holds   "
              f"mean hold {portfolio['avg_days']:.0f}d "
              f"(median {portfolio['median_days']:.0f}d)   "
              f"mean ROI per hold {portfolio['avg_trade'] * 100:+.2f}% "
              f"(median {portfolio['median_trade'] * 100:+.2f}%)   "
              f"win rate {portfolio['win_rate'] * 100:.0f}%   "
              f"in market {portfolio['exposure'] * 100:.0f}%")
    print(f"Wrote {report_path}")
    print(f"Wrote {path}")
