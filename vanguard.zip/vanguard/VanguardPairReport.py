"""Report on one pair of interest, chosen by ticker rather than by screen.

Run it with two tickers:

    python VanguardPairReport.py VIS VTI

The pair is tested on its own terms, so it doesn't have to appear in any
screen. It does have to be cointegrated: a pair whose gap doesn't mean-revert
has nothing for these rules to trade, so the report stops rather than dressing
one up.
"""
import sys
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages

from Vanguard import VANGUARD_ETFS
from VanguardPairsPortfolio import (BUY_TEXT, EXIT_THRESHOLDS, NEAR_FILL, _draw_table,
                                    _footer, _heading, _pair_page, _section,
                                    add_signals, backtest_pair)
from VanguardPairsTrading import (ENTRY_THRESHOLD, MIN_TEST_ROWS, P_VALUE_CUTOFF,
                                  PAIR_FRAMES, ROLLING_WINDOW, pair_frame, test_pair)
from VanguardPlots import rolling_pair_corr
from VanguardStats import vanguard_columns

# Reports land next to this module, named after the pair. Exit rules are
# whatever the portfolio report compares, so the two agree.
HERE = Path(__file__).parent


class NotCointegrated(ValueError):
    """Raised when the pair fails the test, so no report is written."""


def pair_status(ticker_a, ticker_b, column='Adj Close', columns=None,
                window=ROLLING_WINDOW, entry_threshold=ENTRY_THRESHOLD,
                cache=PAIR_FRAMES) -> pd.DataFrame:
    """Where this pair's ratio stands on the latest bar.

    Returns the same one-row shape signal_status produces for a screen, so
    the shared page helpers can read it without special cases.
    """
    data = add_signals(pair_frame(ticker_a, ticker_b, column, columns, window,
                                  entry_threshold, cache),
                       entry_threshold)
    buy_a, buy_b = bool(data['Buy A'].iloc[-1]), bool(data['Buy B'].iloc[-1])

    # How long the current signal has stood, in trading days.
    running = 0
    if buy_a or buy_b:
        firing = data['Buy A' if buy_a else 'Buy B'].to_numpy()
        while running < len(firing) and firing[-1 - running] == 1:
            running += 1

    return pd.DataFrame([{
        'ticker_a': ticker_a,
        'ticker_b': ticker_b,
        'last_date': data.index[-1],
        'last_z': float(data['Ratio Z'].iloc[-1]),
        'signalling': buy_a or buy_b,
        'buy': ticker_a if buy_a else (ticker_b if buy_b else ''),
        'sell': ticker_b if buy_a else (ticker_a if buy_b else ''),
        'days_signalling': running,
    }])


def _verdict_page(test, status, results, column, entry_threshold, window,
                  page_number, total_pages) -> plt.Figure:
    """Page 1: the cointegration verdict, today's reading, and the rules."""
    ticker_a, ticker_b = test['ticker_a'], test['ticker_b']
    row = status.iloc[0]
    fig = plt.figure(figsize=(11, 8.5))

    _heading(fig, f"{ticker_a} / {ticker_b}",
             f"{test['rows']} shared trading days, "
             f"{test['first_date']:%Y-%m-%d} to {test['last_date']:%Y-%m-%d}  ·  "
             f"prices from {column}  ·  generated {pd.Timestamp.today():%B %d, %Y}")

    fig.text(0.06, 0.885,
             f"Cointegrated: p = {test['p_value']:.4f} in the weaker direction, "
             f"under the {P_VALUE_CUTOFF} cutoff",
             fontsize=12, weight='bold', color=BUY_TEXT, va='top')

    if row['signalling']:
        action = (f"Signalling now: buy {row['buy']} against {row['sell']} "
                  f"at z = {row['last_z']:+.2f}, standing "
                  f"{row['days_signalling']:.0f} day"
                  f"{'s' if row['days_signalling'] != 1 else ''}")
        colour = BUY_TEXT
    else:
        action = (f"No signal today: z = {row['last_z']:+.2f}, "
                  f"{entry_threshold - abs(row['last_z']):.2f} short of "
                  f"+/-{entry_threshold}")
        colour = '0.3'
    fig.text(0.06, 0.845, action, fontsize=11, weight='bold', color=colour, va='top')

    # --- the test ---------------------------------------------------------
    _section(fig, 'Cointegration test', 0.785)
    ax_test = fig.add_axes([0.06, 0.60, 0.42, 0.17])
    _draw_table(ax_test, [
        ['Engle-Granger stat', f"{test['coint_stat']:.4f}"],
        [f"p, {ticker_a} on {ticker_b}", f"{test['p_ab']:.4f}"],
        [f"p, {ticker_b} on {ticker_a}", f"{test['p_ba']:.4f}"],
        ['critical values', f"1% {test['crit_1pct']:.2f}   5% {test['crit_5pct']:.2f}   "
                            f"10% {test['crit_10pct']:.2f}"],
        ['price level correlation', f"{test['price_corr']:.4f}"],
        ['ratio volatility', f"{test['ratio_vol'] * 100:.2f}% annualized"],
    ], ['measure', 'value'], fontsize=9, row_height=1.4, col_widths=[0.45, 0.55])

    # --- the rules --------------------------------------------------------
    _section(fig, 'Trading rules', 0.785, x=0.54)
    ax_rules = fig.add_axes([0.54, 0.60, 0.40, 0.17])
    _draw_table(ax_rules, [
        ['signal', f"ratio z-score, {window}-day window"],
        ['buy', f"z below -{entry_threshold} buys {ticker_a}"],
        ['', f"z above +{entry_threshold} buys {ticker_b}"],
        ['sell', 'at each exit rule below'],
        ['position', 'long only, one fund or cash'],
        ['costs', 'none modelled'],
    ], ['rule', 'setting'], fontsize=9, row_height=1.4, col_widths=[0.28, 0.72])

    # --- how each exit rule did -------------------------------------------
    _section(fig, 'Result under each exit rule', 0.545)
    ax_exits = fig.add_axes([0.06, 0.16, 0.88, 0.36])
    body, fills = [], []
    for position, (threshold, result) in enumerate(results.items()):
        body.append([
            'z = 0, take the reversion' if threshold == 0
            else f"z = +/-{threshold}, hold to the extreme",
            f"{result['n_trades']}",
            f"{result['trades_a']}/{result['trades_b']}",
            f"{result['avg_days']:.0f}d",
            f"{result['median_days']:.0f}d",
            f"{result['avg_trade'] * 100:+.2f}%",
            f"{result['win_rate'] * 100:.0f}%",
            f"{result['exposure'] * 100:.0f}%",
            f"{result['total_return'] * 100:+.1f}%",
            f"{result['cagr'] * 100:+.2f}%",
            f"{result['max_drawdown'] * 100:.1f}%",
        ])
        fills.append(('#eef4fb', NEAR_FILL, '#f3eef9', '#f0f0ea')[position % 4])
    _draw_table(ax_exits, body,
                ['exit rule', 'holds', f"holds\n{ticker_a}/{ticker_b}", 'mean\nhold',
                 'median\nhold', 'mean ROI\nper hold', 'win rate', 'time in\nmarket',
                 'ROI', 'CAGR', 'max DD'],
                fills, fontsize=8.5, row_height=1.5,
                col_widths=[0.24] + [0.076] * 10)

    fig.text(0.5, 0.10,
             "Mean ROI per hold is the average return of a single holding and does not "
             "compound; ROI is what the sleeve compounded over the pair's whole history.\n"
             "Returns assume the whole sleeve moves into the named fund and sits in cash "
             "otherwise, with no costs of any kind.",
             ha='center', fontsize=8, style='italic', color='0.35')
    _footer(fig, page_number, total_pages, f"{ticker_a}/{ticker_b}")
    return fig


def _prices_page(test, data, column, page_number, total_pages) -> plt.Figure:
    """Page 2: both price series, their ratio, and the rolling correlation."""
    ticker_a, ticker_b = test['ticker_a'], test['ticker_b']
    fig, axes = plt.subplots(3, 1, figsize=(11, 8.5), sharex=True,
                             gridspec_kw={'height_ratios': [3, 2, 2]})

    # Different price scales, so the second fund gets its own axis.
    axes[0].plot(data.index, data[ticker_a].to_numpy(), color='tab:blue', linewidth=1.0,
                 label=ticker_a)
    axes[0].set_ylabel(f"{ticker_a} ({column})", color='tab:blue')
    axes[0].tick_params(axis='y', labelcolor='tab:blue')
    twin = axes[0].twinx()
    twin.plot(data.index, data[ticker_b].to_numpy(), color='tab:orange', linewidth=1.0,
              label=ticker_b)
    twin.set_ylabel(f"{ticker_b} ({column})", color='tab:orange')
    twin.tick_params(axis='y', labelcolor='tab:orange')
    axes[0].set_title(f"{ticker_a} / {ticker_b}: prices, ratio and rolling correlation")
    axes[0].grid(alpha=0.3)

    axes[1].plot(data.index, data['Ratio'].to_numpy(), color='tab:green', linewidth=1.0)
    axes[1].axhline(data['Ratio'].mean(), color='0.5', linestyle='--', linewidth=0.8,
                    label='full-history mean')
    axes[1].set_ylabel(f"{ticker_a}/{ticker_b}")
    axes[1].legend(fontsize=7, loc='upper left')
    axes[1].grid(alpha=0.3)

    # The same pair seen as return correlation, for context on the test above.
    for window, colour in ((63, 'tab:blue'), (252, 'tab:orange')):
        if len(data) > window:
            series = rolling_pair_corr(ticker_a, ticker_b, window, column)
            axes[2].plot(series.index, series.to_numpy(), color=colour, linewidth=0.9,
                         label=f"{window}d return correlation")
    axes[2].set_ylabel('correlation')
    axes[2].legend(fontsize=7, loc='lower left')
    axes[2].grid(alpha=0.3)

    fig.tight_layout(rect=(0, 0.035, 1, 1))
    _footer(fig, page_number, total_pages, f"{ticker_a}/{ticker_b}")
    return fig


def build_pair_report(ticker_a, ticker_b, column='Adj Close', columns=None,
                      window=ROLLING_WINDOW, entry_threshold=ENTRY_THRESHOLD,
                      exit_thresholds=EXIT_THRESHOLDS, min_rows=MIN_TEST_ROWS,
                      cache=PAIR_FRAMES, output_path=None) -> tuple[Path, dict, dict]:
    """Test one pair and, if it holds up, write its report.

    Args:
        ticker_a: One of VANGUARD_ETFS, bought when the ratio reads low.
        ticker_b: One of VANGUARD_ETFS, bought when the ratio reads high.
        column: One of YFINANCE_COLUMNS, used for the test and the trading.
        columns: Column name -> DataFrame. Defaults to vanguard_columns.
        window: Periods in the rolling window.
        entry_threshold: How far the z-score must travel to signal.
        exit_thresholds: Exit levels to compare.
        min_rows: Shortest shared history worth testing.
        cache: Frame cache shared with the other reports.
        output_path: Where to write. Defaults to VanguardPair_A_B.pdf here.

    Returns:
        (path written, the test result, results keyed by exit threshold).

    Raises:
        ValueError: if a ticker is unknown or the pair is too short to test.
        NotCointegrated: if the pair fails the test, in which case nothing is
            written.
    """
    if columns is None:
        columns = vanguard_columns

    test = test_pair(ticker_a, ticker_b, column, columns, window, entry_threshold,
                     min_rows, cache)
    if not test['tested']:
        raise ValueError(f"{ticker_a}/{ticker_b} share only {test['rows']} trading days; "
                         f"{min_rows} are needed to test the pair")
    if not test['cointegrated']:
        raise NotCointegrated(
            f"{ticker_a}/{ticker_b} is not cointegrated: p = {test['p_value']:.4f} "
            f"in the weaker direction ({ticker_a} on {ticker_b} {test['p_ab']:.4f}, "
            f"{ticker_b} on {ticker_a} {test['p_ba']:.4f}), against a "
            f"{P_VALUE_CUTOFF} cutoff. No report written.")

    results = {}
    for threshold in exit_thresholds:
        result = backtest_pair(ticker_a, ticker_b, column, columns, window,
                               entry_threshold, threshold, cache)
        # The shared pair page expects the test's p-value alongside.
        result['p_value'] = test['p_value']
        results[threshold] = result

    status = pair_status(ticker_a, ticker_b, column, columns, window, entry_threshold,
                         cache)
    data = results[exit_thresholds[0]]['data']

    output_path = Path(output_path or HERE / f"VanguardPair_{ticker_a}_{ticker_b}.pdf")
    total_pages = 3
    with PdfPages(output_path) as pdf:
        pages = (
            _verdict_page(test, status, results, column, entry_threshold, window,
                          1, total_pages),
            _prices_page(test, data, column, 2, total_pages),
            _pair_page((ticker_a, ticker_b), results, entry_threshold, status, 3,
                       total_pages),
        )
        for page in pages:
            pdf.savefig(page)
            plt.close(page)
        pdf.infodict()['Title'] = f"Vanguard pair report: {ticker_a}/{ticker_b}"

    return output_path, test, results


if __name__ == '__main__':
    if len(sys.argv) != 3:
        print(__doc__)
        print(f"Known tickers: {len(VANGUARD_ETFS)} in VANGUARD_ETFS")
        raise SystemExit(2)

    first, second = sys.argv[1].upper(), sys.argv[2].upper()
    try:
        path, test, results = build_pair_report(first, second)
    except NotCointegrated as failure:
        print(failure)
        raise SystemExit(1)
    except ValueError as failure:
        print(failure)
        raise SystemExit(2)

    print(f"{first}/{second}: cointegrated, p = {test['p_value']:.4f} "
          f"({test['rows']} shared days)")
    for threshold, result in results.items():
        print(f"  exit z={threshold}: ROI {result['total_return'] * 100:+.1f}%   "
              f"{result['n_trades']} holds   "
              f"mean hold {result['avg_days']:.0f}d   "
              f"mean ROI per hold {result['avg_trade'] * 100:+.2f}%")
    print(f"Wrote {path}")
