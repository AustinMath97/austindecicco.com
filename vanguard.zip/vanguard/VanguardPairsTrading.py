from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
from statsmodels.tsa.stattools import coint

from Vanguard import VANGUARD_ETFS, YFINANCE_COLUMNS
from VanguardReporter import top_pair_table
from VanguardStats import vanguard_columns

# The finished report lands next to this module unless told otherwise.
DEFAULT_OUTPUT = Path(__file__).with_name('VanguardPairsReport.pdf')

# Same settings as the AUD/NZD notebook this follows: a 100-period rolling
# window for the z-score, entries at +/-2 standard deviations, and a 0.05
# cutoff on the cointegration p-value.
ROLLING_WINDOW = 100
ENTRY_THRESHOLD = 2
P_VALUE_CUTOFF = 0.05

# Daily bars here, where the notebook had hourly ones, so volatility scales by
# the number of trading days in a year rather than 365.25 * 24.
TRADING_DAYS = 252

# Shortest shared history a pair can be tested on. The rolling window eats the
# first ROLLING_WINDOW rows before a single z-score exists, and Engle-Granger
# leans on asymptotics that a short sample doesn't support, so a pair needs at
# least as many usable z-scores as the window that produced them. Below this,
# a pair is left untested rather than reported on a sample that can't carry it.
MIN_TEST_ROWS = 2 * ROLLING_WINDOW

# Table rows that fit on one landscape page before it needs splitting, and
# contents lines that fit above the legend on page 1.
SCREEN_ROWS_PER_PAGE = 26
CONTENTS_MAX_LINES = 16

# Built frames, keyed by the arguments that produced them. Building a pair
# costs a groupby and two rolling passes, and a daily run hits the same pairs
# from the screen, the report and the portfolio, so they are kept. Every
# module that imports this one shares the dict, which is the point: work done
# for one report is already done for the next. Pass cache={} to opt out, or
# call PAIR_FRAMES.clear() to release the memory (a few hundred KB per pair).
PAIR_FRAMES = {}

# Finished test results, keyed the same way. Building a frame is cheap next to
# the two Engle-Granger regressions, so this is the cache that makes a second
# screen in the same run essentially free. Both dicts live as long as the
# process, so a daily run still starts from fresh data.
PAIR_TESTS = {}

# The last screen written to disk, so a separate run of the portfolio report
# doesn't have to repeat the cointegration tests. It is reused whatever its
# age: the reports that read it say when it was built, and passing
# refresh=True rebuilds it.
SCREEN_CACHE_PATH = Path(__file__).with_name('screen_cache.pkl')


def save_screen(screen, settings=None, cache_path=SCREEN_CACHE_PATH) -> Path:
    """Write a finished screen to disk with the settings that produced it.

    Args:
        screen: The results table from screen_pairs.
        settings: What it was built with, for the reports to quote.
        cache_path: Where to write. Defaults next to this module.

    Returns:
        The path written.
    """
    cache_path = Path(cache_path)
    pd.to_pickle({'screen': screen, 'settings': dict(settings or {}),
                  'saved_at': pd.Timestamp.now()}, cache_path)
    return cache_path


def load_screen(cache_path=SCREEN_CACHE_PATH) -> dict | None:
    """Read the last screen written by save_screen.

    Returns:
        A dict with 'screen', 'settings' and 'saved_at', or None if there is
        nothing readable there. Age is not checked: the caller decides what
        counts as too old, and the reports print the date either way.
    """
    cache_path = Path(cache_path)
    if not cache_path.exists():
        return None
    try:
        return pd.read_pickle(cache_path)
    except Exception:
        # A truncated file shouldn't stop a run; the caller rebuilds instead.
        return None


def pair_frame(ticker_a, ticker_b, column='Adj Close', columns=None,
               window=ROLLING_WINDOW, entry_threshold=ENTRY_THRESHOLD,
               cache=PAIR_FRAMES) -> pd.DataFrame:
    """Build the price ratio, its z-score and its signals for one pair.

    The ratio is ticker_a's price over ticker_b's, scored against its own
    rolling mean and standard deviation. A buy means ticker_a is unusually
    cheap against ticker_b.

    The notebook's dollar spread is deliberately not built: a difference of
    two prices depends on the price scale of each fund, assumes they move one
    for one, and failed its own stationarity test on every pair here.

    Args:
        ticker_a: One of VANGUARD_ETFS, case-sensitive.
        ticker_b: One of VANGUARD_ETFS, case-sensitive.
        column: One of YFINANCE_COLUMNS. 'Adj Close' gives total-return prices.
        columns: Column name -> date-indexed DataFrame of tickers. Defaults to
            the full-history vanguard_columns.
        window: Periods in the rolling mean and standard deviation.
        entry_threshold: Z-score at which a position is signalled.
        cache: Dict of already-built frames, keyed by these arguments. Shared
            across modules by default; pass {} for a private one, or None to
            rebuild every time. Callers must not modify what they get back.

    Returns:
        A Date-indexed DataFrame over the pair's shared dates, holding both
        price series plus 'Ratio', 'Ratio Z', 'Ratio Buy' and 'Ratio Sell'.
    """
    # Default columns are only resolved below, so key on the id of whatever
    # was passed: a caller supplying its own frames gets its own entries.
    key = (ticker_a, ticker_b, column, window, entry_threshold,
           None if columns is None else id(columns))
    if cache is not None and key in cache:
        return cache[key]
    for ticker in (ticker_a, ticker_b):
        if ticker not in VANGUARD_ETFS:
            raise ValueError(f"{ticker!r} is not a Vanguard ETF in VANGUARD_ETFS")
    if column not in YFINANCE_COLUMNS:
        raise ValueError(f"Unknown column {column!r}; expected one of {sorted(YFINANCE_COLUMNS)}")
    if ticker_a == ticker_b:
        raise ValueError(f"{ticker_a!r} paired with itself")

    if columns is None:
        columns = vanguard_columns

    # Only the dates both funds traded, so the ratio is never stale on one leg.
    data = columns[column][[ticker_a, ticker_b]].dropna().copy()
    data['Ratio'] = data[ticker_a] / data[ticker_b]

    rolling = data['Ratio'].rolling(window=window)
    z_score = (data['Ratio'] - rolling.mean()) / rolling.std()
    data['Ratio Z'] = z_score
    # Buy when the ratio is unusually low, sell when unusually high.
    data['Ratio Buy'] = np.where(z_score < -entry_threshold, 1, 0)
    data['Ratio Sell'] = np.where(z_score > entry_threshold, -1, 0)

    if cache is not None:
        cache[key] = data
    return data


def test_pair(ticker_a, ticker_b, column='Adj Close', columns=None,
              window=ROLLING_WINDOW, entry_threshold=ENTRY_THRESHOLD,
              min_rows=MIN_TEST_ROWS, cache=PAIR_FRAMES, tests=PAIR_TESTS) -> dict:
    """Run the notebook's checks on one pair.

    The checks are price correlation (the notebook wants > 0.7), the
    Engle-Granger cointegration test run in both directions (cointegrated only
    when both clear p < 0.05), a count of the z-score signals, and the
    annualized volatility of the ratio.

    Args:
        ticker_a: One of VANGUARD_ETFS, case-sensitive.
        ticker_b: One of VANGUARD_ETFS, case-sensitive.
        column: One of YFINANCE_COLUMNS, passed to pair_frame.
        columns: Column name -> DataFrame, passed to pair_frame.
        window: Periods in the rolling window.
        entry_threshold: Z-score at which a position is signalled.
        min_rows: Shortest shared history worth testing. A pair below this is
            left untested.
        cache: Frame cache, passed to pair_frame.
        tests: Dict of results already computed for these arguments. Shared
            across modules by default; pass {} for a private one, or None to
            rerun the regressions every time.

    Returns:
        A dict of the test results. 'p_ab' and 'p_ba' are the two directions;
        'p_value' and 'coint_stat' are the weaker of the two, and 'direction'
        names which one that was. 'cointegrated' is True only when both
        directions clear P_VALUE_CUTOFF. A pair with fewer than min_rows
        shared days comes back with 'tested' False, NaN statistics and
        'cointegrated' False.
    """
    key = (ticker_a, ticker_b, column, window, entry_threshold, min_rows,
           None if columns is None else id(columns))
    if tests is not None and key in tests:
        # A copy, so a caller adding its own fields can't corrupt the cache.
        return dict(tests[key])

    data = pair_frame(ticker_a, ticker_b, column, columns, window, entry_threshold, cache)

    result = {
        'ticker_a': ticker_a,
        'ticker_b': ticker_b,
        'rows': len(data),
        'tested': False,
        'first_date': data.index[0] if len(data) else pd.NaT,
        'last_date': data.index[-1] if len(data) else pd.NaT,
        'price_corr': np.nan,
        'coint_stat': np.nan,
        'p_value': np.nan,
        'p_ab': np.nan,
        'p_ba': np.nan,
        'direction': '',
        'crit_1pct': np.nan,
        'crit_5pct': np.nan,
        'crit_10pct': np.nan,
        'cointegrated': False,
        'ratio_buys': int(data.get('Ratio Buy', pd.Series(dtype=int)).sum()),
        'ratio_sells': int(data.get('Ratio Sell', pd.Series(dtype=int)).eq(-1).sum()),
        'ratio_vol': np.nan,
    }

    # Too little shared history to test: leave the statistics NaN rather than
    # report numbers the sample can't support.
    if len(data) < max(min_rows, window + 2):
        if tests is not None:
            tests[key] = dict(result)
        return result
    result['tested'] = True

    # Correlation of the price levels, as in the notebook's "Corr > 0.7" check.
    result['price_corr'] = data[ticker_a].corr(data[ticker_b])

    # Engle-Granger: the null is no cointegration, so a small p-value is the
    # evidence that the spread mean-reverts. The test regresses its first
    # argument on its second, so it is not symmetric: swapping the two funds
    # can change the verdict. Run it both ways and keep the weaker result, so
    # a pair passes only when it holds up whichever fund is the dependent one.
    stat_ab, p_ab, crit_ab = coint(data[ticker_a], data[ticker_b])
    stat_ba, p_ba, crit_ba = coint(data[ticker_b], data[ticker_a])
    result['p_ab'] = p_ab
    result['p_ba'] = p_ba

    if p_ab >= p_ba:
        score, p_value, critical_values = stat_ab, p_ab, crit_ab
        result['direction'] = f"{ticker_a}~{ticker_b}"
    else:
        score, p_value, critical_values = stat_ba, p_ba, crit_ba
        result['direction'] = f"{ticker_b}~{ticker_a}"

    result['coint_stat'] = score
    result['p_value'] = p_value
    result['crit_1pct'], result['crit_5pct'], result['crit_10pct'] = critical_values
    # p_value is the larger of the two, so this is true only if both directions
    # clear the cutoff.
    result['cointegrated'] = bool(p_value < P_VALUE_CUTOFF)

    # Volatility of the ratio's log returns, annualized over trading days.
    log_returns = np.log(data['Ratio'] / data['Ratio'].shift(1))
    result['ratio_vol'] = log_returns.std() * np.sqrt(TRADING_DAYS)

    if tests is not None:
        tests[key] = dict(result)
    return result


def screen_pairs(pairs=None, column='Adj Close', lookback=252, n=25, columns=None,
                 window=ROLLING_WINDOW, entry_threshold=ENTRY_THRESHOLD,
                 min_rows=MIN_TEST_ROWS, cache=PAIR_FRAMES,
                 tests=PAIR_TESTS) -> pd.DataFrame:
    """Test every pair in a ranked table and collect the results.

    Args:
        pairs: A table from top_pair_table. Built with the arguments below
            when omitted.
        column: One of YFINANCE_COLUMNS, used for ranking and testing.
        lookback: Trading days of returns behind the ranking. None uses all.
        n: How many pairs to rank and test.
        columns: Column name -> DataFrame. Defaults to vanguard_columns.
        window: Periods in the rolling window.
        entry_threshold: Z-score at which a position is signalled.
        min_rows: Shortest shared history worth testing.
        cache: Frame cache, passed to pair_frame.
        tests: Result cache, passed to test_pair.

    Returns:
        One row per pair, in rank order, holding the ranked correlation and
        every field from test_pair. Pairs with too little shared history are
        still listed, with 'tested' False.
    """
    if columns is None:
        columns = vanguard_columns
    if pairs is None:
        pairs = top_pair_table(column, lookback, n, columns)

    results = []
    for _, row in pairs.iterrows():
        result = test_pair(row['ticker_a'], row['ticker_b'], column, columns,
                           window, entry_threshold, min_rows, cache, tests)
        # Keep the ranking alongside the tests, so the report can show both.
        results.append({'rank': row['rank'], 'ranked_corr': row['corr'], **result})
    return pd.DataFrame(results)


def _significance(p_value) -> str:
    """Star rating for a p-value, the usual 1% / 5% / 10% convention."""
    if pd.isna(p_value):
        return ''
    if p_value < 0.01:
        return '***'
    if p_value < 0.05:
        return '**'
    if p_value < 0.10:
        return '*'
    return ''


def _add_footer(fig, page_number, total_pages, label='') -> None:
    """Stamp every page with its number, so the contents can point at it."""
    fig.text(0.5, 0.015, f"page {page_number} of {total_pages}", ha='center', fontsize=7,
             color='0.35')
    if label:
        fig.text(0.04, 0.015, label, ha='left', fontsize=7, color='0.35')


def _contents_page(ordered, passed, page_map, screen_pages, column, lookback,
                   window, entry_threshold, skipped, min_rows) -> plt.Figure:
    """Page 1: what the report is, how it was built, and what's where."""
    fig = plt.figure(figsize=(11, 8.5))

    window_text = 'full history' if lookback is None else f'last {lookback} trading days'
    fig.text(0.06, 0.93, "Vanguard ETF Pairs Trading Screen", fontsize=20, weight='bold')
    fig.text(0.06, 0.895, f"Generated {pd.Timestamp.today():%B %d, %Y}", fontsize=9,
             color='0.35')

    # What was tested, in the order someone would ask it.
    universe = len(ordered) + len(skipped)
    setup = (
        f"Universe   : top {universe} ETF pairs by daily {column} return correlation "
        f"over the {window_text}\n"
        f"Excluded   : {len(skipped)} pairs with fewer than {min_rows} shared trading days, "
        f"too short to test\n"
        f"Tests      : price-level correlation, then Engle-Granger cointegration "
        f"run in both directions\n"
        f"             (null = no cointegration; the weaker of the two p-values is "
        f"the one reported)\n"
        f"Signals    : {window}-day rolling z-score of the price ratio, "
        f"entry at +/-{entry_threshold}\n"
        f"Cutoff     : cointegrated when p < {P_VALUE_CUTOFF}\n"
        f"Result     : {len(passed)} of the {len(ordered)} tested pairs cointegrated, "
        f"charted in full below"
    )
    fig.text(0.06, 0.845, setup, fontsize=9.5, family='monospace', va='top')

    fig.text(0.06, 0.675, "Contents", fontsize=13, weight='bold')
    fig.text(0.06, 0.652, "Everything below is ordered by cointegration significance, "
                          "strongest first.", fontsize=8.5, style='italic', color='0.35')

    # Dot leaders line the numbers up on the right without a table.
    lines = [(f"Screen results — all {len(ordered)} tested pairs",
              f"p. 2" if screen_pages == 1 else f"pp. 2-{1 + screen_pages}")]
    for _, row in passed.iterrows():
        first = page_map[(row['ticker_a'], row['ticker_b'])]
        lines.append((f"No. {row['entry']}   {row['ticker_a']} / {row['ticker_b']}"
                      f"   p = {row['p_value']:.4f} {_significance(row['p_value'])}",
                      f"pp. {first}-{first + 1}"))

    # Only so many lines fit above the legend; the rest are counted instead.
    overflow = max(0, len(lines) - CONTENTS_MAX_LINES)
    y = 0.615
    for label, page_text in lines[:CONTENTS_MAX_LINES]:
        dots = '.' * max(2, 74 - len(label) - len(page_text))
        fig.text(0.06, y, f"{label} {dots} {page_text}", fontsize=9.5, family='monospace')
        y -= 0.028
    if overflow:
        fig.text(0.06, y, f"... and {overflow} more cointegrated pairs, charted in the "
                          f"same order", fontsize=9.5, family='monospace', color='0.35')
        y -= 0.028

    notes = []
    if len(passed) < len(ordered):
        notes.append(f"The other {len(ordered) - len(passed)} tested pairs failed the "
                     f"cointegration test and appear in the screen table only.")
    if skipped:
        # Name the excluded pairs so their absence isn't a silent gap.
        names = ', '.join(f"{a}/{b}" for a, b in skipped[:8])
        if len(skipped) > 8:
            names += f", and {len(skipped) - 8} more"
        notes.append(f"Excluded for short history (< {min_rows} shared days): {names}.")
    for note in notes:
        fig.text(0.06, y - 0.01, note, fontsize=9, style='italic', color='0.35',
                 wrap=True)
        y -= 0.03

    fig.text(0.06, 0.09,
             "Significance: *** p < 0.01    ** p < 0.05    * p < 0.10\n"
             "A low p-value is evidence the gap between the two funds mean-reverts, which "
             "is what a pairs trade needs. High correlation alone is not.",
             fontsize=8.5, color='0.25')
    return fig


def _screen_page(chunk, part, parts, ordered, passed, page_map, column, lookback) -> plt.Figure:
    """A page of the screen table, ranked by p-value with the best first."""
    fig, ax = plt.subplots(figsize=(11, 8.5))
    ax.axis('off')

    window_text = 'full history' if lookback is None else f'last {lookback} trading days'
    part_text = '' if parts == 1 else f"  (part {part} of {parts})"
    ax.set_title(f"Screen results{part_text}\n"
                 f"{len(ordered)} pairs with enough history to test, ranked on daily "
                 f"{column} returns over the {window_text}; "
                 f"{len(passed)} cointegrated at p < {P_VALUE_CUTOFF}",
                 pad=16, fontsize=12)

    body, row_colors = [], []
    for _, row in chunk.iterrows():
        charted = page_map.get((row['ticker_a'], row['ticker_b']))
        body.append([
            str(row['entry']),
            f"{row['ticker_a']}/{row['ticker_b']}",
            str(row['rank']),
            f"{row['rows']}",
            f"{row['price_corr']:.4f}" if pd.notna(row['price_corr']) else 'n/a',
            f"{row['coint_stat']:.3f}" if pd.notna(row['coint_stat']) else 'n/a',
            f"{row['p_ab']:.4f}" if pd.notna(row['p_ab']) else 'n/a',
            f"{row['p_ba']:.4f}" if pd.notna(row['p_ba']) else 'n/a',
            _significance(row['p_value']),
            'YES' if row['cointegrated'] else 'no',
            f"{row['ratio_vol'] * 100:.1f}%" if pd.notna(row['ratio_vol']) else 'n/a',
            f"p. {charted}" if charted else '-',
        ])
        # Tint the pairs that passed, so they stand out in a long table.
        row_colors.append('#dff0d8' if row['cointegrated'] else 'white')

    table = ax.table(cellText=body,
                     colLabels=['no.', 'pair', 'corr\nrank', 'days', 'price\ncorr',
                                'EG stat\n(weaker)', 'p\nA~B', 'p\nB~A', 'sig', 'coint',
                                'ratio\nvol', 'charts'],
                     cellLoc='center', loc='upper center')
    table.auto_set_font_size(False)
    table.set_fontsize(7.5)
    table.scale(1.0, 1.15)

    for (row_index, _), cell in table.get_celld().items():
        cell.set_edgecolor('0.8')
        if row_index == 0:
            cell.set_facecolor('0.9')
            cell.set_text_props(weight='bold')
            cell.set_height(cell.get_height() * 1.6)
        else:
            cell.set_facecolor(row_colors[row_index - 1])

    ax.text(0.5, 0.03,
            "Price corr is on price levels, as in the source notebook. EG stat is the "
            "Engle-Granger statistic; more negative is stronger.\n"
            "The test is not symmetric, so it is run both ways: p A~B regresses the first "
            "fund on the second, p B~A the reverse. A pair is cointegrated only if both "
            "clear the cutoff.\n"
            "Significance: *** p < 0.01    ** p < 0.05    * p < 0.10",
            ha='center', fontsize=8, style='italic', color='0.3', transform=ax.transAxes)
    fig.tight_layout()
    return fig


def _stats_page(data, result, column, position, of_total) -> plt.Figure:
    """Page one for a cointegrated pair: both price series and the numbers."""
    ticker_a, ticker_b = result['ticker_a'], result['ticker_b']

    fig, ax = plt.subplots(figsize=(11, 8.5))
    # The two funds can trade at very different prices, so the second one gets
    # its own axis rather than being squashed against the first.
    ax.plot(data.index, data[ticker_a].to_numpy(), color='tab:blue', linewidth=1.0,
            label=ticker_a)
    ax.set_ylabel(f"{ticker_a} {column}", color='tab:blue')
    ax.tick_params(axis='y', labelcolor='tab:blue')

    twin = ax.twinx()
    twin.plot(data.index, data[ticker_b].to_numpy(), color='tab:orange', linewidth=1.0,
              label=ticker_b)
    twin.set_ylabel(f"{ticker_b} {column}", color='tab:orange')
    twin.tick_params(axis='y', labelcolor='tab:orange')

    stars = _significance(result['p_value'])
    ax.set_title(f"No. {result['entry']}  ·  {ticker_a} / {ticker_b}  ·  "
                 f"cointegrated pair {position} of {of_total}\n"
                 f"p = {result['p_value']:.4f} {stars}   |   {column} prices over "
                 f"{result['rows']} shared trading days")
    ax.grid(alpha=0.3)

    summary = (
        f"ranked return corr : {result['ranked_corr']:.4f}\n"
        f"price level corr   : {result['price_corr']:.4f}\n"
        f"Engle-Granger stat : {result['coint_stat']:.4f}  ({result['direction']}, "
        f"the weaker direction)\n"
        f"p-value            : {result['p_value']:.4f}   "
        f"[{ticker_a}~{ticker_b} {result['p_ab']:.4f} / "
        f"{ticker_b}~{ticker_a} {result['p_ba']:.4f}]\n"
        f"critical values    : 1% {result['crit_1pct']:.3f}   "
        f"5% {result['crit_5pct']:.3f}   10% {result['crit_10pct']:.3f}\n"
        f"ratio volatility   : {result['ratio_vol'] * 100:.2f}% annualized\n"
        f"ratio signals      : {result['ratio_buys']} buy / {result['ratio_sells']} sell\n"
        f"sample             : {result['first_date']:%Y-%m-%d} to {result['last_date']:%Y-%m-%d}"
    )
    # Leave room under the chart for the numbers.
    fig.subplots_adjust(bottom=0.42)
    fig.text(0.08, 0.06, summary, family='monospace', fontsize=9, va='bottom')
    return fig


def _signal_page(data, result, entry_threshold, position, of_total) -> plt.Figure:
    """Page two for a cointegrated pair: the ratio z-score and its signals."""
    ticker_a, ticker_b = result['ticker_a'], result['ticker_b']
    fig, ax = plt.subplots(figsize=(11, 8.5))

    z_score = data['Ratio Z']
    ax.plot(data.index, z_score.to_numpy(), linewidth=0.9,
            label=f"Z-score of {ticker_a}/{ticker_b}")
    ax.axhline(entry_threshold, color='red', linestyle='--', linewidth=0.9,
               label=f"Upper threshold (+{entry_threshold})")
    ax.axhline(-entry_threshold, color='green', linestyle='--', linewidth=0.9,
               label=f"Lower threshold (-{entry_threshold})")
    ax.axhline(0, color='black', linewidth=0.8)

    # Mark the days a position would have been opened.
    buys = data[data['Ratio Buy'] == 1]
    sells = data[data['Ratio Sell'] == -1]
    ax.scatter(buys.index, buys['Ratio Z'].to_numpy(), color='green', marker='^',
               s=18, label=f"Buy ({len(buys)})")
    ax.scatter(sells.index, sells['Ratio Z'].to_numpy(), color='red', marker='v',
               s=18, label=f"Sell ({len(sells)})")

    ax.set_ylabel('ratio z-score')
    ax.grid(alpha=0.3)
    ax.legend(fontsize=8, loc='upper left', ncol=3)
    ax.set_title(f"No. {result['entry']}  ·  {ticker_a} / {ticker_b}  ·  "
                 f"cointegrated pair {position} of {of_total}: trading signals\n"
                 f"buy = {ticker_a} cheap against {ticker_b}, "
                 f"sell = {ticker_a} expensive against {ticker_b}")
    fig.tight_layout()
    return fig


def build_pairs_report(column='Adj Close', lookback=252, n=25, columns=None,
                       window=ROLLING_WINDOW, entry_threshold=ENTRY_THRESHOLD,
                       min_rows=MIN_TEST_ROWS, cache=PAIR_FRAMES, tests=PAIR_TESTS,
                       output_path=DEFAULT_OUTPUT) -> tuple[Path, pd.DataFrame]:
    """Screen the top pairs and write a PDF covering the cointegrated ones.

    Everything in the report is ordered by cointegration significance rather
    than by correlation, and each pair carries an entry number ('No. 1' is the
    lowest p-value) that ties the contents, the screen table and the charts
    together. Page 1 is the contents, then the screen table covering every
    pair tested, then two pages per cointegrated pair: prices with the test
    numbers, and the ratio's z-score with entry signals marked.

    Pairs whose shared history is shorter than min_rows are left out of the
    report entirely, since their statistics would rest on a sample too short
    to support them. They are counted and named on the contents page, and
    still come back in the returned results with 'tested' False.

    Args:
        column: One of YFINANCE_COLUMNS, used for ranking and testing.
        lookback: Trading days of returns behind the ranking. None uses all.
        n: How many pairs to rank and test.
        columns: Column name -> DataFrame. Defaults to vanguard_columns.
        window: Periods in the rolling window.
        entry_threshold: Z-score at which a position is signalled.
        min_rows: Shortest shared history a pair needs to appear at all.
        cache: Frame cache, shared with anything else built this run.
        tests: Result cache, shared the same way.
        output_path: Where to write the PDF.

    Returns:
        (path written, screen results), the second holding every pair, the
        excluded ones included, with 'entry' numbering only the tested ones.
    """
    if columns is None:
        columns = vanguard_columns

    results = screen_pairs(None, column, lookback, n, columns, window, entry_threshold,
                           min_rows, cache, tests)

    # Pairs without enough shared history are kept out of the report, but
    # named on the contents page so the gap is visible.
    skipped = [(row['ticker_a'], row['ticker_b'])
               for _, row in results[~results['tested']].iterrows()]

    # Significance order, most significant first.
    ordered = (results[results['tested']]
               .sort_values('p_value', na_position='last')
               .reset_index(drop=True))
    ordered.insert(0, 'entry', range(1, len(ordered) + 1))
    passed = ordered[ordered['cointegrated']]

    # The page layout is fixed once the counts are known, so the contents can
    # name real page numbers: contents, the screen table, then 2 per pair.
    chunks = [ordered.iloc[start:start + SCREEN_ROWS_PER_PAGE]
              for start in range(0, len(ordered), SCREEN_ROWS_PER_PAGE)] or [ordered]
    first_pair_page = 2 + len(chunks)
    page_map = {(row['ticker_a'], row['ticker_b']): first_pair_page + 2 * position
                for position, (_, row) in enumerate(passed.iterrows())}
    total_pages = 1 + len(chunks) + 2 * len(passed)

    output_path = Path(output_path)
    with PdfPages(output_path) as pdf:
        page = _contents_page(ordered, passed, page_map, len(chunks), column, lookback,
                              window, entry_threshold, skipped, min_rows)
        _add_footer(page, 1, total_pages, 'Contents')
        pdf.savefig(page)
        plt.close(page)

        for index, chunk in enumerate(chunks):
            page = _screen_page(chunk, index + 1, len(chunks), ordered, passed,
                                page_map, column, lookback)
            _add_footer(page, 2 + index, total_pages, 'Screen results')
            pdf.savefig(page)
            plt.close(page)

        for position, (_, result) in enumerate(passed.iterrows(), start=1):
            data = pair_frame(result['ticker_a'], result['ticker_b'], column, columns,
                              window, entry_threshold, cache)
            label = f"No. {result['entry']}  {result['ticker_a']}/{result['ticker_b']}"
            first = page_map[(result['ticker_a'], result['ticker_b'])]
            pages = (_stats_page(data, result, column, position, len(passed)),
                     _signal_page(data, result, entry_threshold, position, len(passed)))
            for offset, page in enumerate(pages):
                _add_footer(page, first + offset, total_pages, label)
                pdf.savefig(page)
                plt.close(page)

        pdf.infodict()['Title'] = f"Vanguard ETF pairs trading screen ({column})"

    # Leave the screen on disk so the portfolio report can pick it up in a
    # separate run instead of repeating every cointegration test.
    save_screen(results, {'column': column, 'lookback': lookback, 'n': n,
                          'window': window, 'entry_threshold': entry_threshold,
                          'min_rows': min_rows})

    return output_path, results


if __name__ == '__main__':
    path, results = build_pairs_report(n=1000)

    # Same order as the report: most significant cointegration first. Pairs
    # without enough shared history are listed after, untested.
    tested = results[results['tested']].sort_values('p_value')
    tested.insert(0, 'entry', range(1, len(tested) + 1))
    shown = tested[['entry', 'rank', 'ticker_a', 'ticker_b', 'rows', 'price_corr',
                    'coint_stat', 'p_ab', 'p_ba', 'p_value', 'cointegrated', 'ratio_vol']]
    print(shown.to_string(index=False, float_format='{:.4f}'.format))

    skipped = results[~results['tested']]
    if len(skipped):
        names = ', '.join(f"{row['ticker_a']}/{row['ticker_b']} ({row['rows']}d)"
                          for _, row in skipped.iterrows())
        print(f"\nExcluded, under {MIN_TEST_ROWS} shared days: {names}")
    print(f"\n{int(tested['cointegrated'].sum())} of {len(tested)} tested pairs "
          f"cointegrated at p < {P_VALUE_CUTOFF}")
    print(f"Wrote {path}")
