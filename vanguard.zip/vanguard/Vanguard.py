from datetime import datetime, time, timedelta
from pathlib import Path

import pandas as pd
import yfinance as yf

VANGUARD_ETFS = {
    # U.S. Broad Market ETFs
    'VOO',   # Vanguard S&P 500 ETF
    'VTI',   # Vanguard Total Stock Market ETF
    'VV',    # Vanguard Large-Cap ETF
    'VO',    # Vanguard Mid-Cap ETF
    'VB',    # Vanguard Small-Cap ETF
    'VXF',   # Vanguard Extended Market ETF
    'VTHR',  # Vanguard Russell 3000 ETF
    'VONE',  # Vanguard Russell 1000 ETF
    'VTWO',  # Vanguard Russell 2000 ETF
    'MGC',   # Vanguard Mega Cap ETF
    'IVOO',  # Vanguard S&P Mid-Cap 400 ETF
    'VIOO',  # Vanguard S&P Small-Cap 600 ETF

    # U.S. Style (Growth / Value) ETFs
    'VUG',   # Vanguard Growth ETF
    'VTV',   # Vanguard Value ETF
    'VOT',   # Vanguard Mid-Cap Growth ETF
    'VOE',   # Vanguard Mid-Cap Value ETF
    'VBK',   # Vanguard Small-Cap Growth ETF
    'VBR',   # Vanguard Small-Cap Value ETF
    'MGK',   # Vanguard Mega Cap Growth ETF
    'MGV',   # Vanguard Mega Cap Value ETF
    'VOOG',  # Vanguard S&P 500 Growth ETF
    'VOOV',  # Vanguard S&P 500 Value ETF
    'VONG',  # Vanguard Russell 1000 Growth ETF
    'VONV',  # Vanguard Russell 1000 Value ETF
    'VTWG',  # Vanguard Russell 2000 Growth ETF
    'VTWV',  # Vanguard Russell 2000 Value ETF
    'IVOG',  # Vanguard S&P Mid-Cap 400 Growth ETF
    'IVOV',  # Vanguard S&P Mid-Cap 400 Value ETF
    'VIOG',  # Vanguard S&P Small-Cap 600 Growth ETF
    'VIOV',  # Vanguard S&P Small-Cap 600 Value ETF

    # Factor ETFs
    'VFMO',  # Vanguard U.S. Momentum Factor ETF
    'VFMF',  # Vanguard U.S. Multifactor ETF
    'VFVA',  # Vanguard U.S. Value Factor ETF
    'VFQY',  # Vanguard U.S. Quality Factor ETF
    'VFMV',  # Vanguard U.S. Minimum Volatility ETF

    # Dividend ETFs
    'VIG',   # Vanguard Dividend Appreciation ETF
    'VYM',   # Vanguard High Dividend Yield Index ETF
    'VIGI',  # Vanguard International Dividend Appreciation ETF
    'VYMI',  # Vanguard International High Dividend Yield ETF

    # ESG ETFs
    'ESGV',  # Vanguard ESG U.S. Stock ETF
    'VSGX',  # Vanguard ESG International Stock ETF
    'VCEB',  # Vanguard ESG U.S. Corporate Bond ETF

    # Sector ETFs
    'VGT',   # Vanguard Information Technology ETF
    'VHT',   # Vanguard Health Care ETF
    'VFH',   # Vanguard Financials ETF
    'VDE',   # Vanguard Energy ETF
    'VIS',   # Vanguard Industrials ETF
    'VDC',   # Vanguard Consumer Staples ETF
    'VCR',   # Vanguard Consumer Discretionary ETF
    'VOX',   # Vanguard Communication Services ETF
    'VPU',   # Vanguard Utilities ETF
    'VAW',   # Vanguard Materials ETF
    'VNQ',   # Vanguard Real Estate ETF
    'VNQI',  # Vanguard Global ex-U.S. Real Estate ETF

    # International / Global Equity ETFs
    'VT',    # Vanguard Total World Stock ETF
    'VXUS',  # Vanguard Total International Stock ETF
    'VEU',   # Vanguard FTSE All-World ex-US ETF
    'VEA',   # Vanguard FTSE Developed Markets ETF
    'VWO',   # Vanguard FTSE Emerging Markets ETF
    'VGK',   # Vanguard FTSE Europe ETF
    'VPL',   # Vanguard FTSE Pacific ETF
    'VSS',   # Vanguard FTSE All-World ex-US Small-Cap ETF
    'VEXC',  # Vanguard Emerging Markets ex-China ETF
    'VDV',   # Vanguard Developed Markets ex-US Value Index ETF
    'VDG',   # Vanguard Developed Markets ex-US Growth Index ETF

    # Taxable Bond ETFs
    'BND',   # Vanguard Total Bond Market ETF
    'BNDX',  # Vanguard Total International Bond ETF
    'BNDW',  # Vanguard Total World Bond ETF
    'BSV',   # Vanguard Short-Term Bond ETF
    'BIV',   # Vanguard Intermediate-Term Bond ETF
    'BLV',   # Vanguard Long-Term Bond ETF
    'VCSH',  # Vanguard Short-Term Corporate Bond ETF
    'VCIT',  # Vanguard Intermediate-Term Corporate Bond ETF
    'VCLT',  # Vanguard Long-Term Corporate Bond ETF
    'VTC',   # Vanguard Total Corporate Bond ETF
    'VGSH',  # Vanguard Short-Term Treasury ETF
    'VGIT',  # Vanguard Intermediate-Term Treasury ETF
    'VGLT',  # Vanguard Long-Term Treasury ETF
    'EDV',   # Vanguard Extended Duration Treasury ETF
    'VGVT',  # Vanguard Government Securities Active ETF
    'VTG',   # Vanguard Total Treasury ETF
    'VBIL',  # Vanguard 0-3 Month Treasury Bill ETF
    'VGUS',  # Vanguard Ultra-Short Treasury ETF
    'VUSB',  # Vanguard Ultra-Short Bond ETF
    'VMBS',  # Vanguard Mortgage-Backed Securities ETF
    'VTIP',  # Vanguard Short-Term Inflation-Protected Securities ETF
    'VTP',   # Vanguard Total Inflation-Protected Securities ETF
    'VWOB',  # Vanguard Emerging Markets Government Bond ETF
    'VCRB',  # Vanguard Core Bond ETF
    'VPLS',  # Vanguard Core Plus Bond ETF
    'BNDP',  # Vanguard Core-Plus Bond Index ETF
    'VSDB',  # Vanguard Short Duration Bond ETF
    'VGHY',  # Vanguard High-Yield Active ETF
    'VCHY',  # Vanguard US High-Yield Corporate Bond Index ETF
    'VGMS',  # Vanguard Multi-Sector Income Bond ETF

    # Municipal (Tax-Exempt) Bond ETFs
    'VTEB',  # Vanguard Tax-Exempt Bond ETF
    'VTES',  # Vanguard Short-Term Tax-Exempt Bond ETF
    'VTEI',  # Vanguard Intermediate-Term Tax-Exempt Bond ETF
    'VTEL',  # Vanguard Long-Term Tax-Exempt Bond ETF
    'VTEC',  # Vanguard California Tax-Exempt Bond ETF
    'MUNY',  # Vanguard New York Tax-Exempt Bond ETF
    'VCRM',  # Vanguard Core Tax-Exempt Bond ETF
    'VSDM',  # Vanguard Short Duration Tax-Exempt Bond ETF

    # Target Maturity Corporate Bond ETFs
    'VBCA',  # Vanguard Target Maturity 2027 Corporate Bond ETF
    'VBCB',  # Vanguard Target Maturity 2028 Corporate Bond ETF
    'VBCC',  # Vanguard Target Maturity 2029 Corporate Bond ETF
    'VBCD',  # Vanguard Target Maturity 2030 Corporate Bond ETF
    'VBCE',  # Vanguard Target Maturity 2031 Corporate Bond ETF
    'VBCF',  # Vanguard Target Maturity 2032 Corporate Bond ETF
    'VBCG',  # Vanguard Target Maturity 2033 Corporate Bond ETF
    'VBCH',  # Vanguard Target Maturity 2034 Corporate Bond ETF
    'VBCI',  # Vanguard Target Maturity 2035 Corporate Bond ETF
    'VBCJ',  # Vanguard Target Maturity 2036 Corporate Bond ETF

    # Active (Wellington-Managed) ETFs
    'VUSV',  # Vanguard Wellington U.S. Value Active ETF
    'VUSG',  # Vanguard Wellington U.S. Growth Active ETF
    'VDIG',  # Vanguard Wellington Dividend Growth Active ETF
}

YFINANCE_COLUMNS = {
    'Open',
    'High',
    'Low',
    'Close',
    'Adj Close',
    'Volume',
    'Dividends',
    'Stock Splits',
    'Capital Gains',
}

# Downloaded frames are kept here so a day's data is fetched once.
CACHE_PATH = Path(__file__).with_name('price_history.pkl')

# US market hours, read in this machine's local time. Daily bars are only
# final once the session closes, so these decide when a cache has gone stale.
MARKET_OPEN = time(9, 30)
MARKET_CLOSE = time(16, 0)


def last_expected_close(now=None) -> datetime:
    """The close whose data a current cache should already contain.

    Before the open, nothing has happened since the previous session, so
    yesterday's close is the bar to have. Once a session has opened, today's
    close is: during the session that time is still ahead, which is what makes
    an intraday cache stale and refreshes prices while the market moves.

    Holidays are not modelled. On one, this asks for a close that never
    happened and the data is re-downloaded, which costs a few seconds and
    returns the same bars.

    Args:
        now: The moment to judge from. Defaults to now, local time.

    Returns:
        The datetime a cache must be newer than to count as current.
    """
    now = now or datetime.now()
    weekend = now.weekday() >= 5

    if weekend or now.time() < MARKET_OPEN:
        # Walk back to the previous weekday and take its close.
        day = now.date() - timedelta(days=1)
        while day.weekday() >= 5:
            day -= timedelta(days=1)
        return datetime.combine(day, MARKET_CLOSE)

    return datetime.combine(now.date(), MARKET_CLOSE)


def cache_is_stale(cache_path=CACHE_PATH, now=None) -> bool:
    """Whether the price cache predates the close it should contain.

    Args:
        cache_path: The cache to check. Defaults to CACHE_PATH.
        now: The moment to judge from. Defaults to now, local time.

    Returns:
        True if the file is missing, or was written before the close returned
        by last_expected_close.
    """
    cache_path = Path(cache_path)
    if not cache_path.exists():
        return True
    written = datetime.fromtimestamp(cache_path.stat().st_mtime)
    return written < last_expected_close(now)


def _read_cache(cache_path) -> dict[str, pd.DataFrame]:
    """Current cached frames, or an empty dict if there are none to use.

    Currency is judged against the market clock rather than the calendar, so
    a file written after yesterday's close still counts before this morning's
    open, and one written before today's close does not count after it.
    """
    cache_path = Path(cache_path)
    if cache_is_stale(cache_path):
        return {}
    try:
        return pd.read_pickle(cache_path)
    except Exception:
        # A truncated or half-written file shouldn't stop a download.
        return {}


def _write_cache(cache_path, frames) -> None:
    """Store frames in the cache, keeping any other tickers cached today."""
    pd.to_pickle({**_read_cache(cache_path), **frames}, Path(cache_path))


def load_price_history(tickers=VANGUARD_ETFS, use_cache=True,
                       cache_path=CACHE_PATH) -> dict[str, pd.DataFrame]:
    """Download each ticker's full daily history, reusing a current cache.

    yfinance is called only when the cache has gone stale against the market
    clock (see cache_is_stale) or is missing one of the tickers asked for, so
    repeated runs between one close and the next open cost nothing. A ticker
    that returns no data is never cached, so asking for it again re-downloads
    it.

    Args:
        tickers: Tickers to load. Defaults to every fund in VANGUARD_ETFS.
        use_cache: False skips the cache in both directions, always
            downloading and leaving the stored file untouched.
        cache_path: Where the cache lives. Defaults to price_history.pkl next
            to this module.

    Returns:
        Ticker -> DataFrame of that fund's history, one row per trading day
        and every column in YFINANCE_COLUMNS.
    """
    tickers = sorted(tickers)

    cached = _read_cache(cache_path) if use_cache else {}
    if all(ticker in cached for ticker in tickers):
        return {ticker: cached[ticker] for ticker in tickers}

    raw = yf.download(
        tickers,
        period='max',
        interval='1d',
        auto_adjust=False,
        actions=True,
        group_by='ticker',
        threads=True,
    )

    frames = {}
    for ticker in tickers:
        if ticker not in raw.columns.get_level_values(0):
            continue
        # A multi-ticker download aligns every ticker to the union of dates,
        # so drop the NaN rows from before each fund's inception.
        df = raw[ticker].dropna(subset=['Close']).copy()
        if df.empty:
            continue
        df.columns.name = None
        # yfinance omits columns a ticker has no data for (e.g. 'Capital Gains'
        # for some target-maturity bond ETFs). Add them as NaN so every
        # DataFrame has all of YFINANCE_COLUMNS.
        df = df.reindex(columns=[*df.columns, *sorted(YFINANCE_COLUMNS - set(df.columns))])
        df.attrs['ticker'] = ticker
        frames[ticker] = df

    if use_cache:
        _write_cache(cache_path, frames)
    return frames


def get_column(ticker, column, dfs=None) -> pd.DataFrame:
    """Return one column of a ticker's price history, with its dates.

    Args:
        ticker: One of VANGUARD_ETFS, e.g. 'VOO'. Case-sensitive.
        column: One of YFINANCE_COLUMNS, e.g. 'Close'. Case-sensitive.
        dfs: Optional dict of already-downloaded DataFrames from
            load_price_history(). If omitted, only this ticker is downloaded.

    Returns:
        DataFrame with two columns: 'Date' and the requested column.
    """
    # Only allow tickers from our verified Vanguard list, so a typo or a
    # non-Vanguard symbol like 'SPY' fails before any download happens.
    if ticker not in VANGUARD_ETFS:
        raise ValueError(f"{ticker!r} is not a Vanguard ETF in VANGUARD_ETFS")

    # Catch typos like 'close' up front with a clear message, instead of a
    # pandas KeyError after a download.
    if column not in YFINANCE_COLUMNS:
        raise ValueError(f"Unknown column {column!r}; expected one of {sorted(YFINANCE_COLUMNS)}")

    # No preloaded data: fetch just this one ticker rather than all 116.
    if dfs is None:
        dfs = load_price_history({ticker})

    # Double brackets keep the result a DataFrame (single brackets give a
    # Series); reset_index moves the Date index into a regular column.
    return dfs[ticker][[column]].reset_index()


def get_column_all_tickers(column, dfs=None) -> pd.DataFrame:
    """Return one column for every Vanguard ETF, aligned by date.

    Args:
        column: One of YFINANCE_COLUMNS, e.g. 'Close'. Case-sensitive.
        dfs: Optional dict of already-downloaded DataFrames from
            load_price_history(). If omitted, all tickers are downloaded once.

    Returns:
        DataFrame indexed by Date with one column per ticker (sorted A-Z).
        Covers every date any ticker traded; where a ticker has no data
        (e.g. before the fund launched) the value is NaN. Nothing is
        forward- or back-filled.
    """
    # Check the column before downloading, since a full download takes
    # about a minute.
    if column not in YFINANCE_COLUMNS:
        raise ValueError(f"Unknown column {column!r}; expected one of {sorted(YFINANCE_COLUMNS)}")

    # Download everything in one batch; calling get_column without dfs would
    # download each of the 116 tickers separately.
    if dfs is None:
        dfs = load_price_history()

    # Pull each ticker's column as a Series indexed by date. Tickers that
    # failed to download are skipped instead of raising.
    series = {
        ticker: get_column(ticker, column, dfs).set_index('Date')[column]
        for ticker in sorted(VANGUARD_ETFS & dfs.keys())
    }

    # Building a DataFrame from Series aligns them on the union of their dates,
    # which puts NaN wherever a ticker has no row for that date.
    return pd.DataFrame(series).sort_index()


def _gap_sizes(series) -> pd.Series:
    """Return the length (in rows) of each run of NaN between real values."""
    first, last = series.first_valid_index(), series.last_valid_index()
    if first is None:
        return pd.Series(dtype=int)

    # Trim to first..last real value, so NaNs before launch (or after the
    # last value) aren't counted as gaps.
    is_nan = series.loc[first:last].isna()

    # Give each run of consecutive NaN / non-NaN rows its own id, then count
    # the NaNs in each run. Non-NaN runs count 0 and are dropped.
    run_id = is_nan.ne(is_nan.shift()).cumsum()
    sizes = is_nan.groupby(run_id).sum()
    return sizes[sizes > 0]


def gap_report(columns) -> dict[str, pd.DataFrame]:
    """Report NaN gaps between real data for every ticker in every column.

    Args:
        columns: Dict of column name -> date-aligned DataFrame, as built by
            get_column_all_tickers (e.g. vanguard_columns).

    Returns:
        Dict with the same keys. Each value is a DataFrame indexed by ticker:
            num_gaps: number of separate NaN runs between real values
            biggest_gap: rows in the longest run
            total_gap_size: rows across all runs
            data_points: non-NaN values (0 counts as real data)
            gap_ratio: total_gap_size / (data_points + total_gap_size);
                NaN when the ticker has no real data in that column
    """
    reports = {}
    for column, df in columns.items():
        rows = {}
        for ticker in df.columns:
            series = df[ticker]
            gaps = _gap_sizes(series)
            data_points = int(series.notna().sum())
            total_gap = int(gaps.sum())
            rows[ticker] = {
                'num_gaps': len(gaps),
                'biggest_gap': int(gaps.max()) if len(gaps) else 0,
                'total_gap_size': total_gap,
                'data_points': data_points,
                # With no real data the ratio would be 0/0, so use NaN.
                'gap_ratio': total_gap / (data_points + total_gap) if data_points else float('nan'),
            }
        report = pd.DataFrame.from_dict(rows, orient='index')
        report.index.name = 'ticker'
        reports[column] = report
    return reports


def rank_first_dates(columns) -> pd.DataFrame:
    """Rank tickers by the first date they have any data, oldest first.

    Args:
        columns: Dict of column name -> date-aligned DataFrame, as built by
            get_column_all_tickers (e.g. vanguard_columns).

    Returns:
        DataFrame with one row per ticker, sorted by first_date then ticker:
            rank: 1 = oldest; tickers sharing a first date share a rank
                (e.g. 3, 3, 3, 6)
            ticker
            first_date: earliest date with a non-NaN value in any column
            one column per column type (e.g. 'Close'): that column's
                gap_ratio from gap_report
    """
    # First real date per ticker in each column, then the earliest across
    # columns. All-NaN columns give NaT, which min() skips.
    first_dates = pd.concat(
        [df.apply(pd.Series.first_valid_index) for df in columns.values()],
        axis=1,
    ).min(axis=1)

    # One gap_ratio column per column type, indexed by ticker.
    ratios = pd.DataFrame({
        column: report['gap_ratio'] for column, report in gap_report(columns).items()
    })

    ranked = pd.concat([first_dates.rename('first_date'), ratios], axis=1)
    ranked.index.name = 'ticker'
    ranked = ranked.reset_index().sort_values(['first_date', 'ticker'], ignore_index=True)

    # method='min' gives tied dates the lowest rank of the group, then skips.
    ranked.insert(0, 'rank', ranked['first_date'].rank(method='min').astype(int))
    return ranked


if __name__ == '__main__':
    vanguard_dfs = load_price_history()

    missing = sorted(VANGUARD_ETFS - vanguard_dfs.keys())
    print(f"\nLoaded {len(vanguard_dfs)} of {len(VANGUARD_ETFS)} tickers")
    if missing:
        print(f"No data for: {', '.join(missing)}")

    # One date-aligned DataFrame per column type, keyed by column name, e.g.
    # vanguard_columns['Close'] has a row per date and a column per ticker.
    # Reuses vanguard_dfs so nothing is downloaded again.
    vanguard_columns = {
        column: get_column_all_tickers(column, vanguard_dfs)
        for column in sorted(YFINANCE_COLUMNS)
    }

    # Rank tickers by first date; the columns after rank/ticker/first_date
    # are the gap ratios, one per column type.
    ranked = rank_first_dates(vanguard_columns)

    # True when every gap ratio is 0 (no gaps) or NaN (no data in that column).
    gap_ratios = ranked[list(vanguard_columns)]
    only_zero_or_nan = bool((gap_ratios.eq(0) | gap_ratios.isna()).all().all())
    print("Zero gaps in data:", only_zero_or_nan)