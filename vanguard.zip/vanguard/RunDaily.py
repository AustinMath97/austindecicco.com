"""Run the whole Vanguard suite end to end, one stage at a time.

Every stage waits on the one before it and is handed that stage's output, so
nothing is computed twice: the price download feeds the aligned columns, those
feed the correlation matrices and reports, the cointegration screen feeds the
portfolio report. A stage that doesn't produce its expected file stops the run
rather than letting the next stage work from stale output.

Run it with `python RunDaily.py`.
"""
import matplotlib

# Figures are written to files, never shown, so a scheduled run can't block on
# a window. This has to happen before anything imports pyplot.
matplotlib.use('Agg')

import time
from datetime import date, datetime
from pathlib import Path

# How much of the universe each stage looks at.
CORRELATION_PAIRS = 25    # pairs charted in the correlation report
SCREEN_PAIRS = 150        # pairs ranked and cointegration-tested
LOOKBACK = 252            # trading days behind the correlation ranking


def _announce(number, total, title) -> float:
    """Print a stage header and return its start time."""
    print(f"\n[{number}/{total}] {title}")
    print('-' * 72)
    return time.perf_counter()


def _finish(started, outputs=()) -> None:
    """Print how long a stage took and confirm what it left behind.

    Raises if an expected file is missing or dates from before today, so a
    later stage can never read yesterday's output by mistake. Today's date
    rather than a few minutes is the test, because the price cache is meant
    to be reused within the day rather than rewritten each run.
    """
    for path in outputs:
        path = Path(path)
        if not path.exists():
            raise FileNotFoundError(f"stage did not produce {path}")
        written = datetime.fromtimestamp(path.stat().st_mtime)
        if written.date() != date.today():
            raise RuntimeError(f"{path.name} is from {written:%Y-%m-%d}, not today")
        print(f"  {path.name}  ({path.stat().st_size / 1e6:.2f} MB, "
              f"{written:%H:%M})")
    print(f"  done in {time.perf_counter() - started:.1f}s")


def _still_current(path, price_written) -> bool:
    """Whether an output was built from price data at least this new.

    Every stage is a pure function of the price history and its settings, so
    an artifact written after the current price cache cannot be improved by
    running the stage again.
    """
    path = Path(path)
    return path.exists() and datetime.fromtimestamp(path.stat().st_mtime) >= price_written


def run_suite(correlation_pairs=CORRELATION_PAIRS, screen_pairs=SCREEN_PAIRS,
              lookback=LOOKBACK, force=False) -> dict:
    """Run every stage in order and return what each one produced.

    Stages are skipped when their output already reflects the current prices:
    if the price cache wasn't refreshed this run, the screen and the reports
    would recompute to exactly what is already on disk. The screen also has to
    have been built with the same settings to count.

    Args:
        correlation_pairs: Pairs to chart in the correlation report.
        screen_pairs: Pairs to rank and cointegration-test.
        lookback: Trading days of returns behind the correlation ranking.
        force: Rebuild everything even when the outputs are current.

    Returns:
        A dict of the stage outputs: the loaded frames, the aligned columns,
        the cointegration screen, the portfolio strategies, the signal status
        and the paths written.
    """
    # Charts live inside the PDFs; nothing writes loose image files.
    total = 6
    started_all = time.perf_counter()
    started_wall = datetime.now()
    artifacts = []

    # Imports happen inside the stages they belong to: importing VanguardStats
    # is what triggers the download, so it has to sit under its own heading.
    started = _announce(1, total, "Price history (yfinance, cached to the market clock)")
    from Vanguard import (CACHE_PATH, VANGUARD_ETFS, cache_is_stale,
                          last_expected_close, load_price_history)

    # Stale means the cache predates the last close it should hold: before the
    # open that is yesterday's 4pm, once a session has begun it is today's, so
    # an intraday run always refreshes.
    wanted = last_expected_close()
    stale = cache_is_stale(CACHE_PATH)
    if CACHE_PATH.exists():
        written = datetime.fromtimestamp(CACHE_PATH.stat().st_mtime)
        print(f"  cache written {written:%Y-%m-%d %H:%M}, "
              f"needs to cover the {wanted:%Y-%m-%d %H:%M} close")
    else:
        print(f"  no cache; needs to cover the {wanted:%Y-%m-%d %H:%M} close")
    print(f"  {'stale, downloading' if stale else 'current, reusing'}")

    vanguard_dfs = load_price_history()
    missing = sorted(VANGUARD_ETFS - vanguard_dfs.keys())
    print(f"  loaded {len(vanguard_dfs)} of {len(VANGUARD_ETFS)} tickers"
          + (f", no data for {', '.join(missing)}" if missing else ""))

    # A stale cache must have been rewritten by the download just now; a
    # current one is left alone, so its own timestamp is the proof.
    written = datetime.fromtimestamp(CACHE_PATH.stat().st_mtime)
    if stale and written < started_wall:
        raise RuntimeError(f"{CACHE_PATH.name} was stale but not rewritten")
    print(f"  {CACHE_PATH.name}  ({CACHE_PATH.stat().st_size / 1e6:.2f} MB, "
          f"{written:%H:%M})")
    _finish(started)

    started = _announce(2, total, "Aligned columns and correlation matrices")
    from VanguardStats import vanguard_columns, vanguard_corr, vanguard_returns_corr
    rows = len(vanguard_columns['Adj Close'])
    print(f"  {len(vanguard_columns)} column types, {rows} trading days, "
          f"{vanguard_columns['Adj Close'].shape[1]} tickers")
    print(f"  {len(vanguard_corr)} level and {len(vanguard_returns_corr)} returns matrices")
    _finish(started)

    started = _announce(3, total, "Data quality check")
    from Vanguard import rank_first_dates
    ranked = rank_first_dates(vanguard_columns)
    ratios = ranked[list(vanguard_columns)]
    clean = bool((ratios.eq(0) | ratios.isna()).all().all())
    print(f"  first dates {ranked['first_date'].min():%Y-%m-%d} to "
          f"{ranked['first_date'].max():%Y-%m-%d}")
    print(f"  no internal gaps in any column: {clean}")
    if not clean:
        # Not fatal: the reports still build, but the numbers deserve a look.
        gappy = ratios.gt(0).any(axis=1).sum()
        print(f"  WARNING: {gappy} tickers have gaps between real observations")
    _finish(started)

    started = _announce(4, total, f"Correlation report (top {correlation_pairs} pairs)")
    from VanguardReporter import DEFAULT_OUTPUT as CORR_OUTPUT
    corr_path = Path(CORR_OUTPUT)
    if not force and _still_current(corr_path, written):
        print(f"  {corr_path.name} already covers these prices, skipping")
        _finish(started)
    else:
        from VanguardReporter import build_report
        corr_path = build_report(lookback=lookback, n=correlation_pairs,
                                 columns=vanguard_columns)
        _finish(started, [corr_path])
    artifacts.append(corr_path)

    started = _announce(5, total, f"Cointegration screen ({screen_pairs} pairs)")
    from VanguardPairsTrading import (DEFAULT_OUTPUT as PAIRS_OUTPUT, SCREEN_CACHE_PATH,
                                      load_screen)
    pairs_path = Path(PAIRS_OUTPUT)
    wanted_settings = {'column': 'Adj Close', 'lookback': lookback, 'n': screen_pairs}

    # The screen is a pure function of the prices and these settings, so a
    # saved one built on the current prices would recompute to itself.
    saved = load_screen()
    reusable = (not force
                and saved is not None
                and _still_current(SCREEN_CACHE_PATH, written)
                and _still_current(pairs_path, written)
                and all(saved['settings'].get(key) == value
                        for key, value in wanted_settings.items()))

    if reusable:
        screen = saved['screen']
        print(f"  screen from {saved['saved_at']:%Y-%m-%d %H:%M} covers these prices "
              f"at the same settings, skipping {screen_pairs} cointegration tests")
        _finish(started)
    else:
        if saved is not None and not force:
            # Say which of the two reasons it was: settings or fresh prices.
            mismatch = {key: (saved['settings'].get(key), value)
                        for key, value in wanted_settings.items()
                        if saved['settings'].get(key) != value}
            print(f"  rebuilding: {'settings changed ' + str(mismatch) if mismatch else 'prices are newer than the saved screen'}")
        from VanguardPairsTrading import build_pairs_report
        pairs_path, screen = build_pairs_report(lookback=lookback, n=screen_pairs,
                                                columns=vanguard_columns)
        _finish(started, [pairs_path])

    tested = int(screen['tested'].sum())
    passed = int(screen['cointegrated'].sum())
    print(f"  {tested} of {len(screen)} pairs had enough history to test")
    print(f"  {passed} cointegrated:")
    for _, row in screen[screen['cointegrated']].sort_values('p_value').head(10).iterrows():
        print(f"    {row['ticker_a']}/{row['ticker_b']:6} p = {row['p_value']:.4f}"
              f"   {row['rows']} shared days")
    if passed > 10:
        print(f"    ... and {passed - 10} more, listed in the report")
    artifacts.append(pairs_path)

    started = _announce(6, total, "Portfolio report (pairs signalling today)")
    from VanguardPairsPortfolio import build_portfolio_report
    portfolio_path, strategies, status = build_portfolio_report(
        screen=screen, lookback=lookback, n=screen_pairs, columns=vanguard_columns)
    firing = status[status['signalling']]
    if len(firing):
        for _, row in firing.iterrows():
            print(f"  SIGNAL {row['ticker_a']}/{row['ticker_b']}: z = {row['last_z']:+.2f}, "
                  f"buy {row['buy']}")
        for threshold, strategy in strategies.items():
            portfolio = strategy['portfolio']
            print(f"  exit z={threshold}: ROI {portfolio['total_return'] * 100:+.1f}%, "
                  f"mean hold {portfolio['avg_days']:.0f}d, "
                  f"mean ROI per hold {portfolio['avg_trade'] * 100:+.2f}%")
    else:
        from VanguardPairsTrading import ENTRY_THRESHOLD
        closest = status.reindex(status['last_z'].abs().sort_values(ascending=False).index)
        nearest = closest.iloc[0]
        short_by = ENTRY_THRESHOLD - abs(nearest['last_z'])
        print(f"  nothing signalling as of {status['last_date'].max():%Y-%m-%d}; "
              f"status page only")
        print(f"  closest is {nearest['ticker_a']}/{nearest['ticker_b']} at "
              f"z = {nearest['last_z']:+.2f}, {short_by:.2f} short of the threshold")
    artifacts.append(portfolio_path)
    _finish(started, [portfolio_path])

    print(f"\n{'=' * 72}")
    print(f"Suite finished in {time.perf_counter() - started_all:.1f}s")
    for path in artifacts:
        path = Path(path)
        written = datetime.fromtimestamp(path.stat().st_mtime)
        print(f"  {path.name:34} {path.stat().st_size / 1e6:6.2f} MB   "
              f"{written:%Y-%m-%d %H:%M}")

    return {
        'frames': vanguard_dfs,
        'columns': vanguard_columns,
        'ranked': ranked,
        'screen': screen,
        'strategies': strategies,
        'status': status,
        'artifacts': artifacts,
    }


if __name__ == '__main__':
    run_suite(screen_pairs=2000)
