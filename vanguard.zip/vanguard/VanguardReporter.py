from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages

from VanguardPlots import pair_returns, plot_pair_corr
from VanguardStats import returns_corr, top_pairs, vanguard_columns

# The finished report lands next to this module unless told otherwise.
DEFAULT_OUTPUT = Path(__file__).with_name('VanguardCorrReport.pdf')


def top_pair_table(column='Adj Close', lookback=252, n=25, columns=None) -> pd.DataFrame:
    """Rank the n most correlated pairs by daily return over a lookback window.

    Args:
        column: One of YFINANCE_COLUMNS. 'Adj Close' gives total return.
        lookback: Trading days of returns to correlate, counting back from the
            newest date. None uses the whole history.
        n: How many pairs to keep.
        columns: Column name -> date-indexed DataFrame of tickers. Defaults to
            the full-history vanguard_columns.

    Returns:
        A DataFrame with columns 'rank', 'ticker_a', 'ticker_b', 'corr',
        highest correlation first.
    """
    if columns is None:
        columns = vanguard_columns
    matrix = returns_corr(columns, lookback)[column]
    return top_pairs({column: matrix}, n)[column]


def _usable_windows(ticker_a, ticker_b, windows, column, columns) -> list[int]:
    """Drop rolling windows longer than the pair's shared history.

    A young fund like VBCI has only months of data, so a 252-day rolling
    correlation can't be computed for it and would otherwise raise.
    """
    shared = len(pair_returns(ticker_a, ticker_b, column, columns))
    return [window for window in sorted(windows) if window <= shared]


def _table_page(pairs, column, lookback, skipped) -> plt.Figure:
    """Render the ranked pairs as the report's first page."""
    fig, ax = plt.subplots(figsize=(11, 8.5))
    ax.axis('off')

    window_text = 'full history' if lookback is None else f'last {lookback} trading days'
    ax.set_title(f"Most correlated Vanguard ETF pairs\n"
                 f"daily {column} returns, {window_text}", pad=24)

    # matplotlib wants plain strings, so format the correlations here.
    body = [[str(row['rank']), row['ticker_a'], row['ticker_b'], f"{row['corr']:.4f}"]
            for _, row in pairs.iterrows()]
    table = ax.table(cellText=body, colLabels=['rank', 'ticker A', 'ticker B', 'corr'],
                     cellLoc='center', loc='upper center')
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(0.7, 1.25)

    if skipped:
        # Say so on the page rather than silently dropping pairs.
        ax.text(0.5, 0.02, f"No chart for {', '.join(skipped)}: too little shared history",
                ha='center', fontsize=8, style='italic', transform=ax.transAxes)
    fig.tight_layout()
    return fig


def build_report(column='Adj Close', lookback=252, n=25, windows=(63, 252),
                 columns=None, output_path=DEFAULT_OUTPUT) -> Path:
    """Write one PDF holding the ranked pairs and a chart for each of them.

    Page 1 is the ranked table. Every page after it plots one pair's rolling
    correlation, in rank order, on an auto-scaled axis because these pairs sit
    in a narrow band near 1 where a full -1..1 axis shows nothing.

    Args:
        column: One of YFINANCE_COLUMNS, used for both ranking and plotting.
        lookback: Trading days of returns used for the ranking. The charts
            always cover each pair's full shared history.
        n: How many pairs to rank and chart.
        windows: Rolling windows to draw per pair. Windows longer than a
            pair's history are dropped for that pair.
        columns: Column name -> DataFrame. Defaults to vanguard_columns.
        output_path: Where to write the PDF.

    Returns:
        The path written.
    """
    if columns is None:
        columns = vanguard_columns

    pairs = top_pair_table(column, lookback, n, columns)

    # Work out which pairs can be charted before writing the table page, so
    # the table can name the ones that can't.
    plans = {}
    for _, row in pairs.iterrows():
        usable = _usable_windows(row['ticker_a'], row['ticker_b'], windows, column, columns)
        plans[(row['ticker_a'], row['ticker_b'])] = usable
    skipped = [f"{a}/{b}" for (a, b), usable in plans.items() if not usable]

    output_path = Path(output_path)
    with PdfPages(output_path) as pdf:
        page = _table_page(pairs, column, lookback, skipped)
        pdf.savefig(page)
        plt.close(page)

        for _, row in pairs.iterrows():
            ticker_a, ticker_b = row['ticker_a'], row['ticker_b']
            usable = plans[(ticker_a, ticker_b)]
            if not usable:
                continue
            # ylim=None auto-scales: these pairs all sit in the high 0.9s.
            ax = plot_pair_corr(ticker_a, ticker_b, windows=usable, column=column,
                                columns=columns, ylim=None, show=False)
            ax.set_title(f"#{row['rank']}  {ticker_a} vs {ticker_b}"
                         f"  |  ranked corr {row['corr']:.4f}\n"
                         f"rolling correlation of daily {column} returns")
            # Re-run the layout: plot_pair_corr fitted the figure to its own
            # one-line title, and this one is taller.
            ax.figure.tight_layout()
            pdf.savefig(ax.figure)
            plt.close(ax.figure)

        pdf.infodict()['Title'] = f"Vanguard ETF pair correlations ({column})"

    return output_path


if __name__ == '__main__':
    path = build_report()
    print(f"Wrote {path}")
