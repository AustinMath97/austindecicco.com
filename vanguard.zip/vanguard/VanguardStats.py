import numpy as np
import pandas as pd

from Vanguard import YFINANCE_COLUMNS, load_price_history, get_column_all_tickers


def upper_triangle_pairs(matrix) -> pd.DataFrame:
    """Flatten the upper-right triangle of a correlation matrix into pairs.

    Only cells above the diagonal are kept, so each pair of tickers appears
    once (no A-B and B-A duplicates) and no ticker is paired with itself.

    Args:
        matrix: A square ticker-by-ticker DataFrame, e.g. vanguard_corr['Close'].

    Returns:
        A DataFrame with columns 'ticker_a', 'ticker_b', 'corr', one row per
        pair, sorted by corr from highest to lowest. NaN pairs are dropped.
    """
    # True above the diagonal (k=1 skips the diagonal itself), False elsewhere.
    upper = np.triu(np.ones(matrix.shape, dtype=bool), k=1)

    # .where() blanks everything outside the triangle to NaN, then .stack()
    # turns the grid into a Series indexed by (row ticker, column ticker).
    # pandas 3 keeps NaN when stacking, so drop them explicitly: that removes
    # the lower triangle, the diagonal, and pairs that had no correlation.
    pairs = matrix.where(upper).stack().dropna()

    pairs = pairs.rename_axis(['ticker_a', 'ticker_b']).rename('corr').reset_index()
    # Sort by corr, breaking exact ties by ticker names so the order is stable.
    return pairs.sort_values(['corr', 'ticker_a', 'ticker_b'],
                             ascending=[False, True, True], ignore_index=True)


def _rank_pairs(corr_dict, count, highest) -> dict[str, pd.DataFrame]:
    """Shared logic for top_pairs and bottom_pairs.

    Args:
        corr_dict: Column name -> correlation matrix, e.g. vanguard_corr.
        count: How many pairs to keep per column.
        highest: True for the most correlated pairs, False for the least.

    Returns:
        Column name -> DataFrame with columns 'rank', 'ticker_a', 'ticker_b',
        'corr'. A column whose matrix is all NaN gets an empty DataFrame.
    """
    ranked = {}
    for column, matrix in corr_dict.items():
        pairs = upper_triangle_pairs(matrix)
        # upper_triangle_pairs sorts highest first; flip it for the bottom.
        if not highest:
            pairs = pairs.iloc[::-1].reset_index(drop=True)
        pairs = pairs.head(count)
        # Rank 1 is the most extreme pair. Equal correlations share a rank
        # (method='min'), so two pairs tied for 3rd are both 3 and the next is 5.
        pairs.insert(0, 'rank', pairs['corr'].rank(method='min', ascending=not highest).astype(int))
        ranked[column] = pairs
    return ranked


def top_pairs(corr_dict, n=10) -> dict[str, pd.DataFrame]:
    """Rank the n most correlated ticker pairs in each correlation matrix.

    Args:
        corr_dict: Column name -> correlation matrix, e.g. vanguard_corr or
            vanguard_returns_corr.
        n: How many pairs to keep per column.

    Returns:
        Column name -> DataFrame of the top n pairs, highest corr first, with
        columns 'rank', 'ticker_a', 'ticker_b', 'corr'.
    """
    return _rank_pairs(corr_dict, n, highest=True)


def bottom_pairs(corr_dict, m=10) -> dict[str, pd.DataFrame]:
    """Rank the m least correlated ticker pairs in each correlation matrix.

    "Least" means the lowest value, so strongly negative correlations come
    first, not the ones closest to zero.

    Args:
        corr_dict: Column name -> correlation matrix, e.g. vanguard_corr or
            vanguard_returns_corr.
        m: How many pairs to keep per column.

    Returns:
        Column name -> DataFrame of the bottom m pairs, lowest corr first, with
        columns 'rank', 'ticker_a', 'ticker_b', 'corr'.
    """
    return _rank_pairs(corr_dict, m, highest=False)


def level_corr(columns, lookback=None) -> dict[str, pd.DataFrame]:
    """Correlate the raw values of each column across tickers.

    Args:
        columns: Column name -> date-indexed DataFrame of tickers, i.e. the
            shape of vanguard_columns.
        lookback: How many trading days back from the newest date to use.
            None (the default) uses the whole history, and so does any window
            longer than the history. The count is rows of the aligned calendar,
            so a fund that didn't exist that far back still contributes only
            the days it has.

    Returns:
        Column name -> ticker-by-ticker correlation matrix.
    """
    return {column: _tail(df, lookback).corr() for column, df in columns.items()}


def returns_corr(columns, lookback=None) -> dict[str, pd.DataFrame]:
    """Correlate day-over-day percent changes of each column across tickers.

    Differencing strips out the shared long-term trend that inflates
    level_corr, so this measures same-day co-movement.

    Args:
        columns: Column name -> date-indexed DataFrame of tickers, i.e. the
            shape of vanguard_columns.
        lookback: How many trading days of returns to use, counting back from
            the newest date. None (the default) uses the whole history, and so
            does any window longer than the history.

    Returns:
        Column name -> ticker-by-ticker correlation matrix.
    """
    # Checked here rather than in _tail, which sees lookback + 1 rows and so
    # would let a single return through.
    if lookback is not None and lookback < 2:
        raise ValueError(f"lookback must be at least 2 returns, got {lookback!r}")

    matrices = {}
    for column, df in columns.items():
        # pct_change() turns N rows into N-1 returns, so take one extra row to
        # end up with `lookback` usable returns. If that runs past the start of
        # the history, _tail clamps and you get every return there is.
        window = _tail(df, lookback if lookback is None else lookback + 1)
        # A change from 0 (e.g. zero Volume or Dividends) is +/-inf; set those
        # to NaN so .corr() skips them instead of propagating infinities.
        matrices[column] = window.pct_change().replace([np.inf, -np.inf], np.nan).corr()
    return matrices


def _tail(df, lookback) -> pd.DataFrame:
    """Keep the most recent `lookback` rows, or all of them when None.

    A window longer than the history is clamped to the whole history, which is
    what .tail() does anyway, so any oversized window gives the same result as
    the full-history correlation.
    """
    if lookback is None:
        return df
    if lookback < 2:
        raise ValueError(f"lookback must be at least 2 rows, got {lookback!r}")
    return df.tail(lookback)


# Download every ticker once (about a minute).
# vanguard_dfs['VOO'] -> one ticker's full history, all columns.
vanguard_dfs = load_price_history()

# vanguard_columns['Close'] -> one column for all tickers, aligned by date.
vanguard_columns = {
    column: get_column_all_tickers(column, vanguard_dfs)
    for column in sorted(YFINANCE_COLUMNS)
}

# Full-history matrices. Call level_corr / returns_corr with a lookback for a
# shorter window, e.g. returns_corr(vanguard_columns, 504) for two years.
#
# vanguard_corr['Close'] -> ticker-by-ticker Pearson correlation matrix of that
# column. .corr() is pairwise: each pair uses only the dates where both tickers
# have data, so younger funds are compared over their shorter history. A pair
# comes out NaN if either side is constant (e.g. all-zero Stock Splits) or has
# no data (e.g. the NaN Capital Gains columns).
vanguard_corr = level_corr(vanguard_columns)

# vanguard_returns_corr['Close'] -> correlation of day-over-day percent changes
# instead of raw levels, so shared long-term trends don't inflate the result.
vanguard_returns_corr = returns_corr(vanguard_columns)


if __name__ == '__main__':
    print(f"Loaded {len(vanguard_dfs)} tickers and {len(vanguard_columns)} column types")
    print(f"Built {len(vanguard_corr)} level and {len(vanguard_returns_corr)} returns correlation matrices")

    # Print the 25 most correlated pairs by daily total return over the full
    # history. Only the 'Adj Close' matrix is passed in, so the other columns
    # aren't ranked.
    pairs = top_pairs({'Adj Close': vanguard_returns_corr['Adj Close']}, n=25)['Adj Close']
    print("\n=== Returns | Adj Close | Top 25 ===")
    print(pairs.to_string(index=False))
