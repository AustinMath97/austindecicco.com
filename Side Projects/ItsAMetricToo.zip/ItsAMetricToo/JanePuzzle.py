"""JanePuzzle: color an 11x11 clue grid into states, mark capitols, and check the clues.

Each same-color region is a state and each black dot is a capitol. A step between orthogonal
neighbors costs the smaller of the two squares' state sizes, and a clue is the cheapest cost of
travelling from its square to any capitol. So a 0 marks a capitol: it shows as a dot, not a
number, and that dot can't be removed.

Mouse
  Left click / drag       select cells (hold Shift to add, Ctrl to add or remove)
  Right click / drag      toggle capitol dots
  Top-left swatches       color, uncolor, or dot the selected cells
  Top-right switches      check the clues / show region sizes in place of the clues
  Hover a clue            with checks on: its possible cost, problems, and cheapest route so far

Keys
  1-4                     color the selection (the same color again removes it)
  0 / Delete / Backspace  uncolor the selection
  D / Space               toggle capitol dots on the selection
  > 12 Enter              the selection's states have at least 12 squares (> Enter clears)
  < 12 Enter              the selection's states have at most 12 squares (< Enter clears)
  = 12 Enter              grey guess of 12 for what the selected squares' black numbers would be
                          (= Enter clears)
  => 12 Enter             their black numbers would be at least 12 (=> Enter clears)
                          "=> 1" says the square isn't a capitol
  =< 12 Enter             their black numbers would be at most 12 (=< Enter clears)
  F                       mark the states under the selection complete, or unmark them
  C                       toggle clue checks
  T                       toggle region sizes
  S                       make a save point (kept in savepoint.json, so it outlasts the window)
  R                       reload the save point (press R again to confirm)
  Ctrl+A / Esc            select all / clear the selection

Bound tags read "≥a", "≤b" or "a–b". They're blue while open, green once met, and red when they
can't hold, alone or against your other bounds; a red tag is ignored by the checks. Gray tags
are bounds that follow from the clues. When a state's bounds meet at one size before its shape
is finished, its tags read "=k" in blue and the size shows as its blue number, underlined.
Every bound also feeds the clue checks. A grey guess gives a square's number outright, so it
replaces any grey bounds there, and a grey bound replaces a guess. Grey upper bounds are notes
only; a grey guess or lower bound of 1 or more rules a capitol out of its square, which the
checks do use. A state marked complete gets a
bold border, and the checks treat its shape and its capitol dot as final.

With checks on, a capitol dot turns red when it can't be its state's capitol: two dots in one
state, or a dot in a finished state that isn't the one square every symmetry of that state
fixes. A finished state whose capitol has no dot gets a red ring there. Hover either for why.
"""

import heapq
import json
import math
import os
import time
from collections import namedtuple

# These must be set before pygame is imported.
os.environ.setdefault("SDL_VIDEO_CENTERED", "1")
os.environ.setdefault("SDL_WINDOWS_DPI_AWARENESS", "permonitorv2")  # crisp text on scaled displays
os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

import pygame

N = 11
CELLS = [(r, c) for r in range(N) for c in range(N)]

# Starting clues, from Jane Street's puzzle "It's a Metric, Too". "." is a blank cell, and a 0 shows as a capitol dot.
PUZZLE = """
.  8  4  .  .  11 .  .  .  5  .
.  .  .  .  .  .  .  11 .  .  .
.  .  7  .  .  1  .  .  .  .  14
28 .  .  51 .  .  1  .  6  .  .
.  22 .  .  .  .  .  .  4  .  1
.  .  .  15 .  10 .  0  .  .  .
11 .  11 .  .  .  .  .  .  9  .
.  .  17 .  14 .  .  10 .  .  13
30 .  .  .  .  6  .  .  45 .  .
.  .  .  10 .  .  .  .  .  .  .
.  26 .  .  .  0  .  .  77 61 .
"""

# Fill colors for keys 1-4. None of them is blue, so blue region sizes stay readable.
FILLS = [(244, 156, 156), (250, 220, 115), (148, 212, 148), (196, 168, 228)]
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (20, 50, 190)
GHOST_BLUE = (100, 130, 215)
GUESS = (110, 110, 122)
GOOD = (0, 115, 40)
BAD = (175, 0, 0)
DERIVED = (130, 130, 140)
PREVIEW = (255, 236, 150)
ROUTE = (235, 120, 0)
BACKGROUND = (232, 232, 236)
LINE = (60, 60, 60)
SELECTION = (0, 140, 255)
MUTED = (80, 80, 90)
SWITCH_OFF = (185, 185, 192)
ERASER = (205, 50, 50)
TAG_COLORS = {"open": BLUE, "met": GOOD, "impossible": BAD, "derived": DERIVED, "preview": BLUE,
              "settled": BLUE, "guess": GUESS, "guess preview": GUESS}

COLOR_KEYS = {
    pygame.K_1: 1, pygame.K_2: 2, pygame.K_3: 3, pygame.K_4: 4,
    pygame.K_KP1: 1, pygame.K_KP2: 2, pygame.K_KP3: 3, pygame.K_KP4: 4,
    pygame.K_0: 0, pygame.K_KP0: 0, pygame.K_DELETE: 0, pygame.K_BACKSPACE: 0,
}
DIGIT_KEYS = {getattr(pygame, f"K_{d}"): str(d) for d in range(10)}
DIGIT_KEYS.update({getattr(pygame, f"K_KP{d}"): str(d) for d in range(10)})
HELP = [
    "Drag: select  ·  Shift: add  ·  Ctrl: add/remove  ·  Ctrl+A: all  ·  Esc: none",
    "1-4: color  ·  0/Del: uncolor  ·  D or right-click: capitol  ·  F: mark complete",
    "> 12 Enter: 12+ squares  ·  < 12 Enter: at most 12  ·  gray tags come from clues",
    "= 12: grey guess  ·  => 1: at least 1  ·  =< 12: at most 12  ·  =k: size settled",
    "T: region sizes  ·  C: checks (green = confirmed, red = impossible)  ·  hover clues and red dots",
]
ENTRY_HELP = "Type digits, then Enter to set  ·  Enter with no number clears  ·  Esc cancels"
SAVE_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "savepoint.json")
GRIDS = ("colors", "dots", "lower", "upper", "guesses", "guess_upper", "guess_lower")
BLANK = {"colors": 0, "dots": False, "lower": 0, "upper": 0,  # an empty square, per grid
         "guesses": None, "guess_upper": None, "guess_lower": None}

# The window is laid out in cell-size units: toolbar, grid, then help text.
WIDTH_UNITS, HEIGHT_UNITS = 12, 15.6
MIN_CELL = 24

Toggle = namedtuple("Toggle", "attr text accent label_pos track hit")
SizeInfo = namedtuple("SizeInfo", "region reach low high settled rejected")

draw_circle = getattr(pygame.draw, "aacircle", pygame.draw.circle)  # anti-aliased on pygame-ce

# The seven rotations and reflections of the square grid, as 2x2 matrices: three turns, then the
# mirrors that swap or flip rows and columns.
SYMMETRIES = (((0, -1), (1, 0)), ((-1, 0), (0, -1)), ((0, 1), (-1, 0)),
              ((1, 0), (0, -1)), ((-1, 0), (0, 1)), ((0, 1), (1, 0)), ((0, -1), (-1, 0)))


def capitol_of(cells):
    """A state's capitol: the one square all its symmetries fix, or None if it has none.

    Any symmetry of a shape keeps its centre of mass in place, so each candidate is applied
    about that point, in coordinates scaled by the size so they stay whole. The state has a
    capitol when it has at least one symmetry and each of them fixes exactly one square, which
    is then always the same one.
    """
    cells = set(cells)
    n = len(cells)
    sr, sc = sum(r for r, _ in cells), sum(c for _, c in cells)
    fixed_by = []
    for (a, b), (c, d) in SYMMETRIES:
        image, fixed = set(), []
        for r, col in cells:
            x, y = n * r - sr, n * col - sc
            nr, nc = a * x + b * y + sr, c * x + d * y + sc
            if nr % n or nc % n:
                break  # this one doesn't land on whole squares
            square = (nr // n, nc // n)
            image.add(square)
            if square == (r, col):
                fixed.append(square)
        else:
            if image == cells:
                fixed_by.append(fixed)
    if fixed_by and all(len(f) == 1 for f in fixed_by) and len({f[0] for f in fixed_by}) == 1:
        return fixed_by[0][0]
    return None


def parse_puzzle(text):
    rows = [line.split() for line in text.strip().splitlines()]
    if len(rows) != N or any(len(row) != N for row in rows):
        raise ValueError(f"PUZZLE must be {N} rows of {N} entries")
    return [[None if token == "." else int(token) for token in row] for row in rows]


def neighbors(cell):
    r, c = cell
    for nr, nc in ((r - 1, c), (r + 1, c), (r, c - 1), (r, c + 1)):
        if 0 <= nr < N and 0 <= nc < N:
            yield nr, nc


def components(cells):
    """Map each cell of a set to its orthogonally connected group within that set."""
    group_of = {}
    for start in cells:
        if start in group_of:
            continue
        group, stack = {start}, [start]
        while stack:
            for nb in neighbors(stack.pop()):
                if nb in cells and nb not in group:
                    group.add(nb)
                    stack.append(nb)
        group = frozenset(group)
        for cell in group:
            group_of[cell] = group
    return group_of


def cheapest_costs(capitols, size):
    """Cheapest travel cost from every cell to its nearest capitol, and each cell's next step there.

    A step between neighbors costs the smaller of their state sizes. Cells that can reach no
    capitol are left out.
    """
    cost = dict.fromkeys(capitols, 0)
    next_step = {}
    heap = [(0, cell) for cell in capitols]
    heapq.heapify(heap)
    while heap:
        spent, cell = heapq.heappop(heap)
        if spent > cost[cell]:
            continue
        for nb in neighbors(cell):
            total = spent + min(size[cell], size[nb])
            if total < cost.get(nb, math.inf):
                cost[nb] = total
                next_step[nb] = cell
                heapq.heappush(heap, (total, nb))
    return cost, next_step


def grid_of(marks, name):
    """A save point's grid, or an empty one where a save point from an older version lacks it."""
    rows = marks.get(name)
    return [row[:] for row in rows] if rows else [[BLANK[name]] * N for _ in range(N)]


def when(stamp):
    """A save point's "YYYY-MM-DD HH:MM:SS" time, short: just the clock if it's from today."""
    day, clock = stamp.split()
    return clock if day == time.strftime("%Y-%m-%d") else f"{day} {clock[:5]}"


class App:
    def __init__(self, screen, save_path=SAVE_FILE):
        self.screen = screen
        self.clues = parse_puzzle(PUZZLE)
        # A 0 says its square is a capitol, so it isn't checked as a clue: it's a dot that stays.
        self.given_dots = {(r, c) for r, c in CELLS if self.clues[r][c] == 0}
        self.clue_of = {(r, c): self.clues[r][c] for r, c in CELLS if self.clues[r][c]}
        self.colors = [[0] * N for _ in range(N)]  # 0 = uncolored, 1-4 = FILLS[n - 1]
        self.dots = [[(r, c) in self.given_dots for c in range(N)] for r in range(N)]  # capitols
        self.bounds = [[0] * N for _ in range(N)]  # your lower bounds on each cell's state size
        self.upper = [[0] * N for _ in range(N)]  # your upper bounds on each cell's state size
        self.guesses = [[None] * N for _ in range(N)]  # your grey guesses at the missing black numbers
        self.guess_upper = [[None] * N for _ in range(N)]  # your upper bounds on those numbers
        self.guess_lower = [[None] * N for _ in range(N)]  # your lower bounds on those numbers
        self.complete = set()  # regions (as frozensets of cells) you've marked complete
        # (what's being typed, digits so far): "lower", "upper", "guess", "guess_upper", "guess_lower"
        self.entry = None
        self.save_path = save_path
        self.saved = self.read_save_point()  # {"time": ..., "marks": snapshot()} or None
        self.save_note = f"save point from {when(self.saved['time'])}" if self.saved else "no save point yet"
        self.confirm_reload = False  # R was pressed once; a second R reloads
        self.selected = set()
        self.show_sizes = False
        self.show_checks = True
        self.drag = None  # "add" or "remove" while left-dragging a selection
        self.dot_drag = None  # True (placing) or False (erasing) while right-dragging dots
        self.last_pos = (0, 0)
        self.layout(*screen.get_size())

    # ---- layout and text ----------------------------------------------------

    def layout(self, width, height):
        s = self.cell = max(MIN_CELL, int(min(width / WIDTH_UNITS, height / HEIGHT_UNITS)))
        top = max(0, int((height - HEIGHT_UNITS * s) / 2))
        bar = pygame.Rect((width - N * s) // 2, top + int(0.35 * s), N * s, int(0.9 * s))
        self.grid = pygame.Rect(bar.x, bar.bottom + int(0.3 * s), N * s, N * s)
        self.help_y = self.grid.bottom + int(0.3 * s)

        def font(names, size, bold=False):
            return pygame.font.SysFont(names, max(8, int(size * s)), bold=bold)

        self.fonts = {
            "clue": font("arial", 0.55),
            "size": font("arial", 0.55, bold=True),
            "ghost": font("arial", 0.4),
            "tag": font("arial", 0.22, bold=True),
            "label": font("segoeui,arial", 0.34),
            "small": font("segoeui,arial", 0.3),
        }
        self.text_cache = {}

        # Color swatches 1-4, then the eraser and capitol tools after a small break.
        size, gap = int(0.66 * s), int(0.15 * s)
        self.buttons = []
        x = bar.x
        for action in [("color", 1), ("color", 2), ("color", 3), ("color", 4), ("color", 0), ("dot", None)]:
            if action == ("color", 0):
                x += gap
            self.buttons.append((action, pygame.Rect(x, bar.centery - size // 2, size, size)))
            x += size + gap

        # Switches are laid out right to left, so "Region sizes" keeps the top-right corner.
        self.toggles = []
        right = bar.right
        for attr, text, accent in (("show_sizes", "Region sizes", BLUE), ("show_checks", "Checks", GOOD)):
            track = pygame.Rect(0, 0, s, s // 2)
            track.midright = (right, bar.centery)
            label = self.text("label", text, BLACK).get_rect(midright=(track.x - int(0.2 * s), bar.centery))
            hit = label.union(track).inflate(int(0.2 * s), int(0.2 * s))
            self.toggles.append(Toggle(attr, text, accent, label.topleft, track, hit))
            right = label.x - int(0.5 * s)

    def text(self, font, text, color):
        key = (font, text, color)
        if key not in self.text_cache:
            self.text_cache[key] = self.fonts[font].render(text, True, color)
        return self.text_cache[key]

    def blit_centered(self, font, text, color, center, highlight=None):
        """Center the text's ink (not its line box) so digits sit in the middle of a cell."""
        surface = self.text(font, text, color)
        ink = surface.get_bounding_rect()
        x, y = center[0] - ink.centerx, center[1] - ink.centery
        if highlight:
            pygame.draw.rect(self.screen, highlight, ink.move(x, y).inflate(8, 6), border_radius=4)
        self.screen.blit(surface, (x, y))
        return ink.move(x, y)

    # ---- grid geometry ------------------------------------------------------

    def cell_rect(self, r, c):
        return pygame.Rect(self.grid.x + c * self.cell, self.grid.y + r * self.cell, self.cell, self.cell)

    def cell_at(self, pos):
        x, y = int(pos[0]) - self.grid.x, int(pos[1]) - self.grid.y
        if 0 <= x < self.grid.w and 0 <= y < self.grid.h:
            return y // self.cell, x // self.cell
        return None

    def cells_between(self, start, end):
        """Cells under the straight mouse path from start to end, so fast drags skip nothing."""
        (x0, y0), (x1, y1) = start, end
        steps = max(1, int(max(abs(x1 - x0), abs(y1 - y0)) * 4 / self.cell))
        cells = []
        for i in range(steps + 1):
            cell = self.cell_at((x0 + (x1 - x0) * i / steps, y0 + (y1 - y0) * i / steps))
            if cell and cell not in cells:
                cells.append(cell)
        return cells

    # ---- editing ------------------------------------------------------------

    def color_selection(self, color):
        if color and all(self.colors[r][c] == color for r, c in self.selected):
            color = 0  # applying the color the selection already has removes it
        for r, c in self.selected:
            self.colors[r][c] = color

    def toggle_dots(self):
        cells = self.selected - self.given_dots  # a 0's dot stays
        place = not all(self.dots[r][c] for r, c in cells)
        for r, c in cells:
            self.dots[r][c] = place

    def guess_targets(self):
        """Selected squares that can take a guess: the ones without a black number or a 0's dot."""
        return [(r, c) for r, c in self.selected if self.clues[r][c] is None]

    def start_entry(self, kind):
        """Start typing a "lower" or "upper" bound or a "guess" for the selection."""
        targets = self.guess_targets() if kind == "guess" else self.selected
        if targets:
            self.entry = (kind, "")

    def grey_grid(self, kind):
        """The grid behind a grey mark: the guesses themselves, or one of their bounds."""
        return {"guess": self.guesses, "guess_upper": self.guess_upper,
                "guess_lower": self.guess_lower}[kind]

    def commit_entry(self):
        """Set the typed bound or guess on the selection; no number clears it.

        A guess gives the number outright, so it replaces any grey bounds on its square, and a
        grey bound replaces a guess.
        """
        kind, digits = self.entry
        value = int(digits) if digits else None
        if kind.startswith("guess"):
            grid = self.grey_grid(kind)
            replaced = ("guess_lower", "guess_upper") if kind == "guess" else ("guess",)
            for r, c in self.guess_targets():
                grid[r][c] = value
                if value is not None:
                    for other in replaced:
                        self.grey_grid(other)[r][c] = None
        else:
            grid = self.bounds if kind == "lower" else self.upper
            for r, c in self.selected:
                grid[r][c] = value or 0
        self.entry = None

    # ---- save point ---------------------------------------------------------

    def snapshot(self):
        """Everything you've marked on the grid, as plain data."""
        grids = dict(zip(GRIDS, (self.colors, self.dots, self.bounds, self.upper,
                                 self.guesses, self.guess_upper, self.guess_lower)))
        marks = {name: [row[:] for row in grid] for name, grid in grids.items()}
        marks["complete"] = sorted(sorted([r, c] for r, c in group) for group in self.complete)
        return marks

    def restore(self, marks):
        (self.colors, self.dots, self.bounds, self.upper, self.guesses, self.guess_upper,
         self.guess_lower) = (grid_of(marks, name) for name in GRIDS)
        for r, c in self.given_dots:  # the 0s' dots, even if the save point lacks them
            self.dots[r][c] = True
        self.complete = {frozenset((r, c) for r, c in group) for group in marks["complete"]}
        self.selected.clear()
        self.entry = None

    def make_save_point(self):
        """Save the marks in memory and in the save file, replacing any earlier save point."""
        self.saved = {"time": time.strftime("%Y-%m-%d %H:%M:%S"), "marks": self.snapshot()}
        self.save_note = f"saved {when(self.saved['time'])}"
        try:
            with open(self.save_path + ".tmp", "w", encoding="utf-8") as f:
                json.dump(self.saved, f)
            os.replace(self.save_path + ".tmp", self.save_path)
        except OSError:
            self.save_note += " (this session only: the file couldn't be written)"

    def read_save_point(self):
        """The save point an earlier session left in the save file, if it's usable."""
        try:
            with open(self.save_path, encoding="utf-8") as f:
                saved = json.load(f)
            marks = saved["marks"]
            if "colors" in marks and all(len(marks[name]) == N and all(len(row) == N for row in marks[name])
                                         for name in GRIDS if name in marks):
                when(saved["time"])  # a malformed time raises here
                if all(len(cell) == 2 for group in marks["complete"] for cell in group):
                    return saved
        except (OSError, ValueError, KeyError, TypeError, AttributeError):
            pass
        return None

    def reload_save_point(self):
        self.restore(self.saved["marks"])
        self.save_note = f"reloaded {when(self.saved['time'])}"

    def toggle_complete(self):
        """Mark the states under the selection complete, or unmark them if they all are already."""
        region = self.regions()
        touched = {region[cell] for cell in self.selected if cell in region}
        if touched <= self.complete:
            self.complete -= touched
        else:
            self.complete |= touched

    # ---- states, bounds, and clue checks ------------------------------------

    def regions(self):
        """Map each colored cell to its region: the connected cells sharing its color (its state)."""
        region = {}
        for color in range(1, 5):
            region.update(components({(r, c) for r, c in CELLS if self.colors[r][c] == color}))
        return region

    def region_sizes(self):
        return {cell: len(group) for cell, group in self.regions().items()}

    def clue_pairs(self):
        """Neighboring clues a and b that differ by more than 1, as (square, square, |a - b|)."""
        pairs = []
        for cell, value in self.clue_of.items():
            for nb in neighbors(cell):
                if nb > cell and nb in self.clue_of and abs(value - self.clue_of[nb]) > 1:
                    pairs.append((cell, nb, abs(value - self.clue_of[nb])))
        return pairs

    def derived_bounds(self):
        """Lower bounds on state sizes that follow from the clues and capitols.

        A step costs the smaller of its two state sizes and can't change the travel cost by more
        than it costs. So neighboring clues a and b need both states to have at least |a - b|
        squares, and a clue next to a capitol needs both states to be at least the clue.
        """
        derived = {}

        def raise_to(cell, value):
            derived[cell] = max(derived.get(cell, 0), value)

        for x, y, k in self.clue_pairs():
            raise_to(x, k)
            raise_to(y, k)
        for cell, value in self.clue_of.items():
            for r, c in neighbors(cell):
                if self.dots[r][c] and value > 1:
                    raise_to(cell, value)
                    raise_to((r, c), value)
        return derived

    def finished_regions(self, region):
        """Regions whose shape is final: marked complete, or with no uncolored square beside them."""
        return {group for group in set(region.values())
                if group in self.complete or all(nb in region for cell in group for nb in neighbors(cell))}

    def size_info(self):
        """Everything known about how big each square's state can end up.

        A colored square's state can only grow from its current region, and only through
        uncolored squares; an uncolored square can still take any of the four colors. A region
        marked complete doesn't grow, and nothing else can grow into it. A colored region is one
        state, so a bound on any of its squares covers all of them. Bounds from the clues are
        facts. One of your bounds that can't hold, on its own or against your other bounds on the
        same state, is rejected: its tag shows red and the checks ignore it.

        Returns SizeInfo:
          region    colored square -> its region
          reach     largest size the square's state can grow to, from the colors and marks alone
          low/high  smallest and largest size the state can end up, after the bounds
          settled   square -> size, where the bounds pin down a state whose shape isn't final yet
          rejected  (square, "lower" or "upper") for each of your bounds that can't hold
        """
        region = self.regions()
        uncolored = {cell for cell in CELLS if cell not in region}
        open_cells = {cell for cell, group in region.items() if group not in self.complete}
        by_color = [components(uncolored | {(r, c) for r, c in open_cells if self.colors[r][c] == color})
                    for color in range(1, 5)]
        reach = {}
        for r, c in CELLS:
            cell, color = (r, c), self.colors[r][c]
            if not color:
                reach[cell] = max(len(groups[cell]) for groups in by_color)
            else:
                reach[cell] = len(by_color[color - 1][cell]) if cell in open_cells else len(region[cell])

        derived = self.derived_bounds()
        finished = self.finished_regions(region)
        low, high, settled, rejected = {}, {}, {}, set()
        for state in {region.get(cell, frozenset([cell])) for cell in CELLS}:  # an uncolored square stands alone
            limit = reach[next(iter(state))]
            facts = max([len(state)] + [derived[c] for c in state if c in derived and derived[c] <= limit])
            lowers = [(c, self.bounds[c[0]][c[1]]) for c in state if self.bounds[c[0]][c[1]]]
            uppers = [(c, self.upper[c[0]][c[1]]) for c in state if self.upper[c[0]][c[1]]]
            # Reject what can't hold on its own: too big to fit, or below the state's current size
            # or a bound from the clues...
            rejected |= {(c, "lower") for c, v in lowers if v > limit}
            rejected |= {(c, "upper") for c, v in uppers if v < facts}
            lowers = [(c, v) for c, v in lowers if v <= limit]
            uppers = [(c, v) for c, v in uppers if v >= facts]
            floor = max([facts] + [v for _, v in lowers])
            ceiling = min([limit] + [v for _, v in uppers])
            if floor > ceiling:  # ...then the bounds of yours that contradict each other
                bad_lower = {c for c, v in lowers if v > ceiling}
                bad_upper = {c for c, v in uppers if v < floor}
                rejected |= {(c, "lower") for c in bad_lower} | {(c, "upper") for c in bad_upper}
                floor = max([facts] + [v for c, v in lowers if c not in bad_lower])
                ceiling = min([limit] + [v for c, v in uppers if c not in bad_upper])
            for c in state:
                low[c], high[c] = floor, ceiling
                if floor == ceiling and state not in finished:
                    settled[c] = floor
        return SizeInfo(region, reach, low, high, settled, rejected)

    def size_bounds(self):
        """(region, low, high) from size_info()."""
        info = self.size_info()
        return info.region, info.low, info.high

    def bound_tags(self, info):
        """The tag to show on each square, as (text, style), from a size_info() result.

        Your bounds read "≥a", "≤b" or "a–b", and are "open", "met" once the region satisfies
        them for good, or "impossible" when rejected. Bounds derived from the clues are
        "derived" (or "impossible" when the colors rule them out) and show only where you haven't
        set one. Where the bounds settle a state's size, a tagged square reads "=k" in blue.
        """
        region, high, settled = info.region, info.high, info.settled
        tags = {cell: (f"≥{value}", "impossible" if value > info.reach[cell] else "derived")
                for cell, value in self.derived_bounds().items()}
        for r, c in CELLS:
            cell, lower, upper = (r, c), self.bounds[r][c], self.upper[r][c]
            if not lower and not upper:
                if cell in settled and cell not in region and cell not in tags:
                    tags[cell] = (f"={settled[cell]}", "settled")  # e.g. boxed in: a single square
                continue
            size = len(region[cell]) if cell in region else 0
            parts = []
            if lower:
                parts.append("impossible" if (cell, "lower") in info.rejected
                             else "met" if size >= lower else "open")
            if upper:
                parts.append("impossible" if (cell, "upper") in info.rejected
                             else "met" if size == high[cell] and size <= upper else "open")
            if "impossible" not in parts and cell in settled:
                tags[cell] = (f"={settled[cell]}", "settled")
                continue
            if "impossible" in parts:
                style = "impossible"
            elif all(part == "met" for part in parts):
                style = "met"
            else:
                style = "open"
            if lower and upper:
                text = f"={lower}" if lower == upper else f"{lower}–{upper}"
            else:
                text = f"≥{lower}" if lower else f"≤{upper}"
            tags[cell] = (text, style)
        return tags

    def cost_bounds(self, region, low, high):
        """Lowest and highest travel cost each cell can still end up with.

        A region with no uncolored neighbor, or one marked complete, is finished: its size is
        final, and its dot, if it has one, is its only capitol. For the low bound everything
        unfinished is as cheap as it could get: states at their smallest, and every undotted
        square that could still become a capitol counted as one. For the high bound states are
        as big as they could grow and only dotted squares are capitols. A square you've given a
        grey guess or lower bound of 1 or more is never counted as a capitol. Returns (low_cost,
        high_cost, next_step); a cell left out of a cost map can reach no capitol.
        """
        dots = {(r, c) for r, c in CELLS if self.dots[r][c]}
        finished = self.finished_regions(region)
        maybe = set(dots)
        for cell in CELLS:
            if cell in dots or cell in self.clue_of:  # a clue's square is never a capitol
                continue
            told = self.guess_lower[cell[0]][cell[1]] or self.guesses[cell[0]][cell[1]] or 0
            if told >= 1:  # your grey number or lower bound rules a capitol out here
                continue
            if cell not in region:
                maybe.add(cell)
            elif region[cell] not in finished and not region[cell] & dots:  # unfinished, no capitol yet
                maybe.add(cell)
        low_cost, _ = cheapest_costs(maybe, low)
        high_cost, next_step = cheapest_costs(dots, high)
        return low_cost, high_cost, next_step

    def check_clues(self, info=None):
        """Judge each clue, and each grey guess, against the colors, capitols, and bounds so far.

        info is the result of size_info(), if it has already been computed. Returns
        ({clue cell: (status, low, high, problems)}, {guess cell: the same}, next_step). The
        status is "bad" when no way of finishing the grid can make the number true, "good" when
        its cost is pinned to exactly the number, and "open" otherwise. Guesses are only judged:
        they never feed the checks on anything else.
        """
        info = info or self.size_info()
        low_cost, high_cost, next_step = self.cost_bounds(info.region, info.low, info.high)
        results = {cell: self.judge(cell, value, info, low_cost, high_cost) for cell, value in self.clue_of.items()}
        guesses = {(r, c): self.judge((r, c), self.guesses[r][c], info, low_cost, high_cost)
                   for r, c in CELLS if self.guesses[r][c] is not None and self.clues[r][c] is None}
        return results, guesses, next_step

    def judge(self, cell, value, info, low_cost, high_cost):
        """(status, low, high, problems) for a black or grey number on a cell; see check_clues."""
        low, high = info.low, info.high
        problems = []
        # A single-square state is always its own capitol, so its neighbors cost at most 1.
        if value and high[cell] == 1:
            problems.append("a single-square state is its own capitol")
        if value == 1 and not any(low[nb] == 1 and nb not in self.clue_of for nb in neighbors(cell)):
            problems.append("a 1 needs a single-square neighbor")
        if value >= 2 and any(high[nb] == 1 for nb in neighbors(cell)):
            problems.append("a single-square neighbor caps the cost at 1")
        # One step can't change the cost by more than that step costs.
        for nb in neighbors(cell):
            other = self.clue_of.get(nb)
            if other is not None and abs(value - other) > min(high[cell], high[nb]):
                problems.append(f"next to the {other}, both states need {abs(value - other)}+ squares")
        low_end, high_end = low_cost.get(cell, math.inf), high_cost.get(cell, math.inf)
        if low_end == math.inf:
            problems.append("no capitol can be reached")
        elif value < low_end:
            problems.append("a 0 must be a capitol" if value == 0 else f"every route costs at least {low_end}")
        if value > high_end:
            problems.append(f"a route costing {high_end} already exists")
        if problems:
            status = "bad"
        elif low_end == high_end == value:
            status = "good"
        else:
            status = "open"
        return status, low_end, high_end, problems

    def check_dots(self, info=None):
        """Dots that can't be capitols as drawn, and finished states whose capitol has no dot.

        A state has at most one capitol, so two dots in one region are always wrong. A finished
        state's shape is final, so its capitol, if it has one, is known: a dot anywhere else in it
        is wrong, and so is leaving the capitol undotted. An unfinished region with one dot isn't
        judged yet. Returns {square: problem}.
        """
        info = info or self.size_info()
        finished = self.finished_regions(info.region)
        problems = {}
        for group in set(info.region.values()):
            dots = sorted(cell for cell in group if self.dots[cell[0]][cell[1]])
            if len(dots) > 1:
                for cell in dots:
                    problems[cell] = f"a state has one capitol, and this one has {len(dots)} dots"
                continue
            if group not in finished:
                continue
            capitol = capitol_of(group)
            if dots and dots[0] != capitol:
                problems[dots[0]] = ("this finished state has no capitol" if capitol is None else
                                     f"this finished state's capitol is R{capitol[0] + 1}C{capitol[1] + 1}")
            if capitol is not None and capitol not in dots:  # missing, or the dot is elsewhere
                problems[capitol] = "this finished state's capitol needs a dot"
        return problems

    # ---- input --------------------------------------------------------------

    def handle(self, event):
        if event.type == pygame.VIDEORESIZE:
            self.screen = pygame.display.get_surface()
            self.layout(*self.screen.get_size())
        elif event.type == pygame.MOUSEBUTTONDOWN:
            self.mouse_down(event.pos, event.button)
        elif event.type == pygame.MOUSEMOTION:
            if not event.buttons[0]:
                self.drag = None
            if not event.buttons[2]:
                self.dot_drag = None
            self.drag_to(event.pos)
        elif event.type == pygame.MOUSEBUTTONUP:
            if event.button == 1:
                self.drag = None
            elif event.button == 3:
                self.dot_drag = None
        elif event.type == pygame.KEYDOWN:
            self.key_down(event.key, event.mod, getattr(event, "unicode", ""))

    def mouse_down(self, pos, button):
        self.confirm_reload = False  # a click cancels a pending reload
        if self.entry and self.entry[1]:  # clicking away sets a bound or guess that has digits...
            self.commit_entry()
        self.entry = None  # ...and drops one that doesn't
        self.last_pos = pos
        cell = self.cell_at(pos)
        if button == 3 and cell:
            r, c = cell
            self.dot_drag = not self.dots[r][c]
            self.drag_to(pos)
        elif button == 1:
            for toggle in self.toggles:
                if toggle.hit.collidepoint(pos):
                    setattr(self, toggle.attr, not getattr(self, toggle.attr))
                    return
            for (kind, value), rect in self.buttons:
                if rect.collidepoint(pos):
                    if kind == "color":
                        self.color_selection(value)
                    else:
                        self.toggle_dots()
                    return
            mods = pygame.key.get_mods()
            if not mods & (pygame.KMOD_SHIFT | pygame.KMOD_CTRL):
                self.selected.clear()
            if cell:
                self.drag = "remove" if mods & pygame.KMOD_CTRL and cell in self.selected else "add"
                self.drag_to(pos)

    def drag_to(self, pos):
        if self.drag is not None or self.dot_drag is not None:
            for r, c in self.cells_between(self.last_pos, pos):
                if self.drag == "add":
                    self.selected.add((r, c))
                elif self.drag == "remove":
                    self.selected.discard((r, c))
                if self.dot_drag is not None and (r, c) not in self.given_dots:  # a 0's dot stays
                    self.dots[r][c] = self.dot_drag
        self.last_pos = pos

    def key_down(self, key, mod, text=""):
        if self.confirm_reload:  # waiting on a second R; any other key cancels the reload
            self.confirm_reload = False
            if key == pygame.K_r:
                self.reload_save_point()
                return
            if key == pygame.K_ESCAPE:
                return
        if self.entry is not None:
            self.entry_key(key, text)
        elif key == pygame.K_s:
            self.make_save_point()
        elif key == pygame.K_r:
            if self.saved:
                self.confirm_reload = True
            else:
                self.save_note = "no save point to reload yet"
        elif text == ">" or key == pygame.K_GREATER:
            self.start_entry("lower")
        elif text == "<" or key == pygame.K_LESS:
            self.start_entry("upper")
        elif text == "=":
            self.start_entry("guess")
        elif key == pygame.K_f:
            self.toggle_complete()
        elif key in COLOR_KEYS:
            self.color_selection(COLOR_KEYS[key])
        elif key in (pygame.K_d, pygame.K_SPACE):
            self.toggle_dots()
        elif key == pygame.K_t:
            self.show_sizes = not self.show_sizes
        elif key == pygame.K_c:
            self.show_checks = not self.show_checks
        elif key == pygame.K_ESCAPE:
            self.selected.clear()
        elif key == pygame.K_a and mod & pygame.KMOD_CTRL:
            self.selected = {(r, c) for r in range(N) for c in range(N)}

    def entry_key(self, key, text=""):
        """Keys while typing a bound or guess: digits, Backspace, Enter to set, Esc to cancel.

        A "<" or ">" straight after "=" turns a grey guess into a grey upper or lower bound.
        """
        kind, digits = self.entry
        if key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.commit_entry()
        elif key == pygame.K_ESCAPE:
            self.entry = None
        elif key == pygame.K_BACKSPACE:
            back = kind in ("guess_upper", "guess_lower") and not digits
            self.entry = ("guess", "") if back else (kind, digits[:-1])
        elif kind == "guess" and not digits and (text == "<" or key == pygame.K_LESS):
            self.entry = ("guess_upper", "")
        elif kind == "guess" and not digits and (text == ">" or key == pygame.K_GREATER):
            self.entry = ("guess_lower", "")
        elif key in DIGIT_KEYS and len(digits) < 3:
            self.entry = (kind, digits + DIGIT_KEYS[key])

    # ---- drawing ------------------------------------------------------------

    def draw(self):
        info = self.size_info()
        checks, guess_checks, next_step = self.check_clues(info) if self.show_checks else ({}, {}, {})
        judged = {**checks, **guess_checks}  # hovering a grey guess works like hovering a clue
        dot_problems = self.check_dots(info) if self.show_checks else {}
        tags = self.bound_tags(info)
        hoverable = {**{cell: ("bad", math.inf, math.inf, []) for cell in dot_problems}, **judged}
        hovered = self.hovered_clue(hoverable)
        route = [hovered] if hovered in judged else []
        while route and route[-1] in next_step:
            route.append(next_step[route[-1]])

        self.screen.fill(BACKGROUND)
        self.draw_toolbar()
        self.draw_grid(info, judged, tags, route, dot_problems)
        self.draw_selection()
        self.draw_help()
        if hovered:
            self.draw_tooltip(hovered, hoverable[hovered], dot_problems.get(hovered))

    def hovered_clue(self, checks):
        """The clue under the mouse, while checks are on and nothing is being dragged."""
        if not checks or self.drag or self.dot_drag is not None or not pygame.mouse.get_focused():
            return None
        cell = self.cell_at(pygame.mouse.get_pos())
        return cell if cell in checks else None

    def draw_toolbar(self):
        s = self.cell
        mouse = pygame.mouse.get_pos() if pygame.mouse.get_focused() else (-1, -1)
        radius = max(3, s // 8)
        for (kind, value), rect in self.buttons:
            pygame.draw.rect(self.screen, FILLS[value - 1] if value else WHITE, rect, border_radius=radius)
            if kind == "dot":
                draw_circle(self.screen, BLACK, rect.center, max(3, int(0.14 * s)))
            elif value:
                self.blit_centered("small", str(value), MUTED, rect.center)
            else:  # eraser: a red slash
                inset = rect.w // 4
                pygame.draw.line(self.screen, ERASER, (rect.left + inset, rect.bottom - inset),
                                 (rect.right - inset, rect.top + inset), max(2, s // 20))
            hovered = rect.collidepoint(mouse)
            pygame.draw.rect(self.screen, LINE if hovered else SWITCH_OFF, rect, 2 if hovered else 1,
                             border_radius=radius)

        for toggle in self.toggles:
            on, track = getattr(self, toggle.attr), toggle.track
            self.screen.blit(self.text("label", toggle.text, toggle.accent if on else BLACK), toggle.label_pos)
            pygame.draw.rect(self.screen, toggle.accent if on else SWITCH_OFF, track, border_radius=track.h // 2)
            if toggle.hit.collidepoint(mouse):
                pygame.draw.rect(self.screen, LINE, track, 2, border_radius=track.h // 2)
            knob_x = track.right - track.h // 2 if on else track.x + track.h // 2
            draw_circle(self.screen, WHITE, (knob_x, track.centery), track.h // 2 - max(2, track.h // 8))

    def draw_grid(self, info, checks, tags, route, dot_problems=None):
        s, grid, region, settled = self.cell, self.grid, info.region, info.settled
        dot_problems = dot_problems or {}
        for r, c in CELLS:
            color = self.colors[r][c]
            pygame.draw.rect(self.screen, FILLS[color - 1] if color else WHITE, self.cell_rect(r, c))
        thin = max(1, s // 45)
        for i in range(1, N):
            x, y = grid.x + i * s, grid.y + i * s
            pygame.draw.line(self.screen, LINE, (x, grid.top), (x, grid.bottom - 1), thin)
            pygame.draw.line(self.screen, LINE, (grid.left, y), (grid.right - 1, y), thin)
        self.draw_complete(region)
        if len(route) > 1:
            self.draw_route(route)

        typing = self.entry[0] if self.entry else None
        for r, c in CELLS:
            cell, rect = (r, c), self.cell_rect(r, c)
            tag = tags.get(cell)
            if typing in ("lower", "upper") and cell in self.selected:
                tag = (f"{'≥' if typing == 'lower' else '≤'}{self.entry[1]}_", "preview")

            # The middle of the cell holds a clue, your grey guess, or a region size. In the size
            # view, a size settled by bounds shows underlined, and an uncolored cell's bound stands
            # in for the size it will get.
            middle = None
            if self.show_sizes:
                if cell in settled:
                    middle = (str(settled[cell]), "size", BLUE, None)
                    if tag and tag[1] != "preview":
                        tag = None  # the number in the middle already says it
                elif cell in region:
                    middle = (str(len(region[cell])), "size", BLUE, None)
                elif tag and tag[1] != "preview":
                    middle = (tag[0], "ghost", GHOST_BLUE if tag[1] == "open" else TAG_COLORS[tag[1]], None)
                    tag = None
            elif cell in self.given_dots:
                pass  # a 0 shows as its capitol dot alone
            elif self.clues[r][c] is not None:
                status = checks[cell][0] if cell in checks else "open"
                if status == "open":
                    middle = (str(self.clues[r][c]), "clue", BLACK, None)
                else:  # bold green when confirmed, bold red when impossible
                    middle = (str(self.clues[r][c]), "size", GOOD if status == "good" else BAD, None)
            elif typing == "guess" and cell in self.selected:
                middle = (f"{self.entry[1]}_", "clue", GUESS, PREVIEW)
            elif self.guesses[r][c] is not None:  # green or red once checked, in normal weight
                status = checks[cell][0] if cell in checks else "open"
                tint = GOOD if status == "good" else BAD if status == "bad" else GUESS
                middle = (str(self.guesses[r][c]), "clue", tint, None)
            if middle:
                text, font, tint, highlight = middle
                ink = self.blit_centered(font, text, tint, rect.center, highlight)
                if self.show_sizes and cell in settled:  # settled by bounds, not counted from colors
                    y = ink.bottom + max(2, s // 20)
                    pygame.draw.line(self.screen, tint, (ink.left, y), (ink.right, y), max(2, s // 28))
            if self.dots[r][c] or cell in dot_problems:
                ink = BAD if cell in dot_problems else BLACK
                if middle is None:
                    center, radius = rect.center, max(3, int(0.14 * s))
                else:  # tuck the dot into the corner so the number stays readable
                    center, radius = (rect.x + int(0.2 * s), rect.y + int(0.2 * s)), max(2, int(0.08 * s))
                if self.dots[r][c]:
                    draw_circle(self.screen, ink, center, radius)
                else:  # a finished state's capitol with no dot: a red ring where it belongs
                    pygame.draw.circle(self.screen, ink, center, radius, max(2, s // 25))
            if tag:
                self.draw_tag(rect, *tag)
            # Grey bounds sit in the bottom-right corner, below the guess, in the clue view.
            if not self.show_sizes and self.clues[r][c] is None:
                grey = self.guess_bound_tag(cell, typing)
                if grey:
                    self.draw_tag(rect, *grey, bottom=True)

        border = max(2, s // 16)
        pygame.draw.rect(self.screen, BLACK, grid.inflate(border, border), border)

    def draw_complete(self, region):
        """A bold border around each state marked complete, along the edges it shares with others."""
        s, w = self.cell, max(3, self.cell // 11)
        for group in self.complete & set(region.values()):
            for r, c in group:
                x, y = self.grid.x + c * s, self.grid.y + r * s
                sides = (((-1, 0), (x - w // 2, y - w // 2, s + w, w)),
                         ((1, 0), (x - w // 2, y + s - w // 2, s + w, w)),
                         ((0, -1), (x - w // 2, y - w // 2, w, s + w)),
                         ((0, 1), (x + s - w // 2, y - w // 2, w, s + w)))
                for (dr, dc), edge in sides:
                    if (r + dr, c + dc) not in group:
                        self.screen.fill(BLACK, edge)

    def guess_bound_tag(self, cell, typing):
        """The grey bound on a blank square's black number: "≥1", "≤12", "1–12", or what's typed."""
        r, c = cell
        if typing in ("guess_lower", "guess_upper") and cell in self.selected:
            sign = "≥" if typing == "guess_lower" else "≤"
            return f"{sign}{self.entry[1]}_", "guess preview"
        if self.guesses[r][c] is not None:
            return None  # the grey number in the middle already gives it
        lower, upper = self.guess_lower[r][c], self.guess_upper[r][c]
        if lower is None and upper is None:
            return None
        if lower is None:
            return f"≤{upper}", "guess"
        if upper is None:
            return f"≥{lower}", "guess"
        return (f"={lower}" if lower == upper else f"{lower}–{upper}"), "guess"

    def draw_tag(self, rect, text, style, bottom=False):
        """A small tag in the top-right (or bottom-right) corner of a cell, clear of its number."""
        surface = self.text("tag", text, TAG_COLORS[style])
        ink = surface.get_bounding_rect()  # place the glyphs themselves, not their line box
        x = rect.right - int(0.08 * self.cell) - ink.right
        if bottom:
            y = rect.bottom - int(0.08 * self.cell) - ink.bottom
        else:
            y = rect.top + int(0.06 * self.cell) - ink.top
        if style in ("preview", "guess preview"):
            pygame.draw.rect(self.screen, PREVIEW, ink.move(x, y).inflate(6, 4), border_radius=3)
        self.screen.blit(surface, (x, y))

    def draw_route(self, route):
        """Draw the cheapest route found so far from the hovered clue to a capitol."""
        points = [self.cell_rect(*cell).center for cell in route]
        width = max(3, self.cell // 10) | 1  # odd, so the lines and joint circles share a center
        for color, w in ((WHITE, width + 4), (ROUTE, width)):
            pygame.draw.lines(self.screen, color, False, points, w)
            for point in points:  # round off the joints
                draw_circle(self.screen, color, point, w // 2)

    def help_lines(self):
        """The lines under the grid, as (text, font, color): a pending prompt, or the key reference."""
        if self.confirm_reload:
            return [(f"Reload the save point from {when(self.saved['time'])}?", "label", BAD),
                    ("Marks made since then will be lost  ·  R: reload  ·  Esc: keep working", "small", MUTED)]
        if self.entry is not None:
            kind, digits = self.entry
            if kind.startswith("guess"):
                count = len(self.guess_targets())
                what, shown = {"guess": ("Grey guess", digits),
                               "guess_lower": ("Grey lower bound", f"≥{digits}"),
                               "guess_upper": ("Grey upper bound", f"≤{digits}")}[kind]
                prompt = f"{what} for {count} blank square{'' if count == 1 else 's'}:  {shown}_"
            else:
                count = len(self.selected)
                what, sign = ("Lower", "≥") if kind == "lower" else ("Upper", "≤")
                prompt = f"{what} bound for {count} selected square{'' if count == 1 else 's'}:  {sign}{digits}_"
            return [(prompt, "label", BLUE), (ENTRY_HELP, "small", MUTED)]
        save_line = f"S: make a save point  ·  R: reload it  ·  {self.save_note}"
        return [(line, "small", MUTED) for line in HELP + [save_line]]

    def draw_help(self):
        y = self.help_y
        for text, font, color in self.help_lines():
            surface = self.text(font, text, color)
            self.screen.blit(surface, surface.get_rect(midtop=(self.grid.centerx, y)))
            y += surface.get_height()

    def draw_tooltip(self, cell, check, dot_problem=None):
        _, low, high, problems = check
        if cell in self.clue_of:
            summary = f"Clue {self.clue_of[cell]}"
        elif self.guesses[cell[0]][cell[1]] is not None:
            summary = f"Guess {self.guesses[cell[0]][cell[1]]}"
        else:
            summary = "Capitol dot" if self.dots[cell[0]][cell[1]] else "Missing capitol dot"
        problems = list(problems) + ([dot_problem] if dot_problem else [])
        if low == high < math.inf:
            summary += f": cost is exactly {low}"
        elif high == math.inf and low < math.inf:
            summary += f": cost can be {low} or more"
        elif low < math.inf:
            summary += f": cost can be {low}–{high}"
        lines = [self.text("small", summary, BLACK)] + [self.text("small", p, BAD) for p in problems]

        pad, offset = int(0.15 * self.cell), int(0.35 * self.cell)
        box = pygame.Rect(0, 0, max(line.get_width() for line in lines) + 2 * pad,
                          sum(line.get_height() for line in lines) + 2 * pad)
        mx, my = pygame.mouse.get_pos()
        box.topleft = (mx + offset, my + offset)
        screen = self.screen.get_rect()
        if box.right > screen.right:  # flip to the other side of the cursor near the edges
            box.right = mx - offset
        if box.bottom > screen.bottom:
            box.bottom = my - offset
        box.clamp_ip(screen)
        radius = max(3, self.cell // 10)
        pygame.draw.rect(self.screen, WHITE, box, border_radius=radius)
        pygame.draw.rect(self.screen, LINE, box, 1, border_radius=radius)
        y = box.y + pad
        for line in lines:
            self.screen.blit(line, (box.x + pad, y))
            y += line.get_height()

    def draw_selection(self):
        """Outline the selection's outer edges, so a group of cells reads as one shape."""
        s, t, sel = self.cell, max(2, self.cell // 13), self.selected
        for r, c in sel:
            x, y = self.grid.x + c * s, self.grid.y + r * s
            sides = (((-1, 0), (x, y, s, t)), ((1, 0), (x, y + s - t, s, t)),
                     ((0, -1), (x, y, t, s)), ((0, 1), (x + s - t, y, t, s)))
            for (dr, dc), edge in sides:
                if (r + dr, c + dc) not in sel:
                    self.screen.fill(SELECTION, edge)
            # Fill the inside corner of L-shaped selections, which would otherwise show a notch.
            for dr, dc in ((-1, -1), (-1, 1), (1, -1), (1, 1)):
                if (r + dr, c) in sel and (r, c + dc) in sel and (r + dr, c + dc) not in sel:
                    corner = (x if dc < 0 else x + s - t, y if dr < 0 else y + s - t, t, t)
                    self.screen.fill(SELECTION, corner)


def main():
    pygame.init()
    desktop = pygame.display.Info()
    s = max(MIN_CELL, int(min(desktop.current_w / WIDTH_UNITS, desktop.current_h * 0.8 / HEIGHT_UNITS)))
    screen = pygame.display.set_mode((int(WIDTH_UNITS * s), int(HEIGHT_UNITS * s)), pygame.RESIZABLE)
    pygame.display.set_caption("JanePuzzle")
    app = App(screen)
    while True:
        app.draw()
        pygame.display.flip()
        for event in [pygame.event.wait(), *pygame.event.get()]:
            if event.type == pygame.QUIT:
                pygame.quit()
                return
            app.handle(event)


if __name__ == "__main__":
    main()
