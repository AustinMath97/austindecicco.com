# It's a Metric, Too

A puzzle by **Jane Street**, with an app for working it out on screen.

The original is at https://www.janestreet.com/puzzles/current-puzzle/ while it is the current
puzzle, and in the archive at https://www.janestreet.com/puzzles/archive/ after that. That page
shows the grid, a worked example of the answer, and the answer form.

## The rules, in Jane Street's words

> The 11-by-11 region above can be subdivided into various states. A “state” is a connected group
> of 1 or more squares that is symmetric in some way, be it via rotation or reflection. If every
> nontrivial rotation or reflection of the plane that takes a state to itself leaves exactly 1 of
> its squares fixed, then that square is its capitol. (So, for example, a 1-by-3 region has no
> capitol, nor does the “X” pentomino.)
>
> The cost of traveling from one square to an orthogonally adjacent square in this nation is equal
> to the size (i.e. number of squares) of the state you are travelling in, or, if travelling between
> two states, the lesser of the two states’ sizes. A number in a cell (below) denotes the lowest cost
> of travelling from the numbered square to any state capitol.
>
> After determining the shapes of the states, label each cell with the size of the state it is in.
> Compute the sum of these values in each row, and submit as your answer the sum of the squares of
> these row sums (as in the example).

"Above" and "below" refer to the pictures on Jane Street's page. The app shows the same grid,
with each 0 drawn as a capitol dot.

## Running the app

You need Python 3 and pygame-ce:

```
pip install -r requirements.txt
python JanePuzzle.py
```

The controls are listed along the bottom of the window. The top of `JanePuzzle.py` has the full
reference.

## What the app does

- **Drawing.** Colour squares with 1–4; touching squares of one colour form a state. Right-click
  or press D to place a capitol dot, and press F to mark a state complete.
- **Your notes.** Type `> k` or `< k` to bound a state's size, and `= k` to note a square's cost.
  A note turns red when it can't hold.
- **Help, on from the start:**
  - Grey tags show size bounds that follow from the clues.
  - Each clue turns green once its cost is pinned to its number, and red when it can't be met.
    Hover over a clue to see its possible costs and its cheapest route so far.
  - A capitol dot turns red when it can't be its state's capitol, and a red ring marks where a
    finished state's capitol must go.
  - Press C to hide or show this help, and T to show each region's size in place of the clues.
- **Saving.** S saves your progress to `savepoint.json` next to the app, and R reloads it.

## Also included

`StateShapeCatalog.pdf` lists every valid state of 1 to 7 squares and shows which ones have a
capitol.
